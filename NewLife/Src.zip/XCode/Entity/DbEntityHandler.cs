﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace XCode.Entity
//{
//    class DbEntityHandler : IEntityHandler
//    {
//        /// <summary>
//        /// 添加
//        /// </summary>
//        /// <param name="entity"></param>
//        /// <returns></returns>
//        public Int32 OnInsert(IEntity entity)
//        {
//            return 0;
//        }

//        /// <summary>
//        /// 更新
//        /// </summary>
//        /// <param name="entity"></param>
//        /// <returns></returns>
//        public Int32 OnUpdate(IEntity entity)
//        {
//            return 0;
//        }

//        /// <summary>
//        /// 删除
//        /// </summary>
//        /// <param name="entity"></param>
//        /// <returns></returns>
//        public Int32 OnDelete(IEntity entity)
//        {
//            return 0;
//        }

//        /// <summary>
//        /// 加载
//        /// </summary>
//        /// <param name="entity"></param>
//        /// <returns></returns>
//        public Int32 OnLoad(IEntity entity)
//        {
//            return 0;
//        }
//    }
//}