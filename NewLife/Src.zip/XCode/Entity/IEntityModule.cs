﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XCode
{
    interface IEntityModule
    {
        void Init();
    }
}