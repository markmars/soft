﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using NewLife.Collections;

//namespace XCode
//{
//    class EntityHandlerManager
//    {
//        static DictionaryCache<Type, IEntityHandler[]> _cache = new DictionaryCache<Type, IEntityHandler[]>(true);
//        public static IEntityHandler[] GetHandlers(Type type)
//        {
//            //return _cache.GetItem(type,)
//            return null;
//        }
//    }
//}