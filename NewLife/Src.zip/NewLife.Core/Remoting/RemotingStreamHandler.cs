﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using NewLife.Messaging;

//namespace NewLife.Remoting
//{
//    class RemotingStreamHandler : MessageStreamHandler
//    {
//    }
//}