﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using NewLife.Messaging;

//namespace NewLife.Remoting
//{
//    /// <summary>
//    /// 方法消息
//    /// </summary>
//    public class MethodMessage : RemotingMessage
//    {
//        #region 属性
//        /// <summary>消息类型</summary>
//        public override RemotingMessageType MessageType
//        {
//            get { return RemotingMessageType.Method; }
//        }
//        #endregion
//    }
//}