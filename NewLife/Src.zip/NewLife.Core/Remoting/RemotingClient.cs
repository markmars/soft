﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using NewLife.IO;

//namespace NewLife.Remoting
//{
//    /// <summary>远程客户端</summary>
//    public class RemotingClient
//    {
//        #region 属性
//        private StreamClient _Client;
//        /// <summary>数据流客户端</summary>
//        public StreamClient Client { get { return _Client; } set { _Client = value; } }
//        #endregion

//        #region 同步

//        #endregion
//    }
//}