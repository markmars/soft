﻿
namespace NewLife
{
    //class Cctor
    //{
    //    public static void Init()
    //    {
    //        //Console.WriteLine("Init");
    //    }

    //    public static void Finish()
    //    {
    //        //Console.WriteLine("Finish");
    //    }
    //}
}