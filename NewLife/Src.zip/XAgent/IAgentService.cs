﻿
namespace XAgent
{
    interface IAgentService
    {
    }
}
