﻿
namespace XAgent
{
    class Program
    {
        static void Main(string[] args)
        {
            AgentService.ServiceMain();
        }
    }
}