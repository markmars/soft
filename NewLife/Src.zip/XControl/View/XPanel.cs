﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.Web.UI.WebControls;
//using System.ComponentModel;

//namespace XControl.View
//{
//    [ToolboxItem(false)]
//    internal class XPanel : WebControl
//    {
//    }
//}
