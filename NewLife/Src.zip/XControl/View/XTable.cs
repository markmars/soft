//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.Web.UI.WebControls;
//using System.ComponentModel;

//namespace XControl.View
//{
//    /// <summary>
//    /// ����
//    /// </summary>
//    [ToolboxItem(false)]
//    internal class XTable : Panel
//    {
//    }

//    /// <summary>
//    /// ��
//    /// </summary>
//    [ToolboxItem(false)]
//    internal class XRow : Panel
//    {
//    }

//    /// <summary>
//    /// ��Ԫ��
//    /// </summary>
//    [ToolboxItem(false)]
//    internal class XCell : Panel
//    {
//    }
//}