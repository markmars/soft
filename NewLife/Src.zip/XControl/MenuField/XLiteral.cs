﻿
namespace XControl
{
    ///// <summary>
    ///// 增加字段值
    ///// 专为MenuField提供
    ///// </summary>
    //internal class XLiteral : Literal
    //{
    //    private String _DataFieldValue;
    //    /// <summary>
    //    /// 绑定字段值
    //    /// OnDataBind时生成
    //    /// </summary>
    //    public String DataFieldValue
    //    {
    //        get { return _DataFieldValue; }
    //        set { _DataFieldValue = value; }
    //    }

    //    private String _DataField;
    //    /// <summary>
    //    /// 绑定字段值
    //    /// OnDataBind时生成
    //    /// </summary>
    //    public String DataField
    //    {
    //        get { return _DataField; }
    //        set { _DataField = value; }
    //    }

    //    private String _ConditionField;
    //    /// <summary>条件字段</summary>
    //    public String ConditionField
    //    {
    //        get { return _ConditionField; }
    //        set { _ConditionField = value; }
    //    }

    //    private String _ConditionFieldValue;
    //    /// <summary>条件值</summary>
    //    public String ConditionFieldValue
    //    {
    //        get { return _ConditionFieldValue; }
    //        set { _ConditionFieldValue = value; }
    //    }
    //}

}
