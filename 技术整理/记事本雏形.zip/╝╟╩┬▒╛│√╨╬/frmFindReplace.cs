﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace 记事本
{
    public partial class frmFindReplace : Form
    {
        public frmFindReplace()
        {
            InitializeComponent();
        }

        private void 查找_Load(object sender, EventArgs e)
        {
            main = (Form1)this.Owner;
        }
        Form1 main;
        bool blFlag;
        private void button1_Click(object sender, EventArgs e)
        {
            
                int loc = main.richTextBox1.Text.IndexOf(textBox1.Text,
                     main.richTextBox1.SelectionStart + main.richTextBox1.SelectionLength);
                if (loc != -1)
                {
                    main.richTextBox1.Select(loc, textBox1.Text.Length);

                    main.richTextBox1.Focus();
                    blFlag = true;

                }
                else
                {
                    if (blFlag == true)
                    {
                        MessageBox.Show("查找完毕！");
                        

                    }
                    else
                    {
                        MessageBox.Show("没有找到！");
                        
                    }
                    
                }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            main.richTextBox1.SelectionStart = 0;
            main.richTextBox1.SelectionLength = 0;
            blFlag = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
                int loc = main.richTextBox1.Text.IndexOf(textBox1.Text,
                     main.richTextBox1.SelectionStart + main.richTextBox1.SelectionLength);
                if (loc != -1)
                {
                    main.richTextBox1.Select(loc, textBox1.Text.Length);//5^1^a^s^p^x
                    main.richTextBox1.Text = main.richTextBox1.Text.Replace(textBox1.Text, textBox2.Text);//全部替换
                    blFlag = true;
                }
            
                else
                {
                    if (blFlag == true)
                    {
                        MessageBox.Show("替换完毕！");

                    }
                    else
                    {
                        MessageBox.Show("替换的内容不存在，请从新输入！");
                    }
                }            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            main.richTextBox1.SelectionStart = 0;
            main.richTextBox1.SelectionLength = 0;
            blFlag = false;
        }
        
    }
}