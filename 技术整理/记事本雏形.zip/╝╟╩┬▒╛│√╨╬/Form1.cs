﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Text;  //系统字体的命名空间

//源码下载www.5~1-a-s-p-x
namespace 记事本
{
    public partial class Form1 : Form
    {
        string strFileName;
        string strRTF;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //button9_Click(sender, e);
            //将系统安装的字体添加到组合框中
            InstalledFontCollection installFont = new InstalledFontCollection();
            foreach (FontFamily font in installFont.Families)
            {
              toolStripComboBox1.Items.Add(font.Name);
            }
            //InstalledFontCollection installFont = new InstalledFontCollection();
            //foreach (FontFamily font in installFont.Families)
            //{
            //    toolStripComboBox1.Items.Add(font.Name);
            //}
        }

        private void 新建NToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Rtf != strRTF)
            {
                DialogResult dr = MessageBox.Show("文档已修改，但还未保存，是否确定现在进行保存？",
                    "询问", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.No)
                {
                    richTextBox1.Text = "";
                }
                if(dr == DialogResult.Yes)
                {
                    保存SToolStripMenuItem_Click(sender, e);
                    //if (richTextBox1.Rtf != strRTF)
                    //{
                    //    e.Cancel = true;
                    //}
                }
            }
            else
            {
                richTextBox1.Text = "";
                strFileName = "";
                strRTF = richTextBox1.Rtf;
            }
        }

        private void 字体FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog font = new FontDialog();
            font.Font = richTextBox1.SelectionFont;
            DialogResult dr = font.ShowDialog();
            if(dr==DialogResult.OK)
            {
                richTextBox1.SelectionFont=font.Font;
            }
        }

        private void 剪切TToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void 复制CToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void 粘贴PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void 恢复RToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void 全选AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }

        private void 删除LToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void 退出XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void 打开0ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.InitialDirectory = @"c:\";
            open.Filter = "文本文件(*.txt)|*.txt|RTF文件(*.rtf)|*.rtf";
            open.FilterIndex = 1;
            DialogResult dr = open.ShowDialog();
            if (dr == DialogResult.OK)
            {
                strFileName = open.FileName;
                string str = Path.GetExtension(strFileName).ToLower();
                switch (str)
                {
                    case ".txt":
                        richTextBox1.LoadFile(strFileName, RichTextBoxStreamType.PlainText);
                        break;
                    case ".rtf":
                        richTextBox1.LoadFile(strFileName, RichTextBoxStreamType.RichText);
                        break;
                }
                strRTF = richTextBox1.Rtf;
            }
        }

        private void 颜色CToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ColorDialog color = new ColorDialog();
            color.FullOpen = true;
            DialogResult dr = color.ShowDialog();
            if (dr == DialogResult.OK)
            {
                richTextBox1.SelectionColor = color.Color;
            }
        }

        private void 自动换行WToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.WordWrap = true;

        }

        private void 时间PToolStripMenuItem_Click(object sender, EventArgs e)
        {
           richTextBox1.SelectedText=DateTime.Now.ToString();
        }

        private void 保存SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(strFileName))
            {
                另存为AToolStripMenuItem_Click(sender, e);
            }
            else
            {
                string str = Path.GetExtension(strFileName).ToLower();
                switch (str)
                {
                    case ".txt":
                        richTextBox1.SaveFile(strFileName, RichTextBoxStreamType.PlainText);
                        break;
                    case ".rtf":
                        richTextBox1.SaveFile(strFileName, RichTextBoxStreamType.RichText);
                        break;
                }
                strRTF = richTextBox1.Rtf;
            }
        }

        private void 另存为AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.InitialDirectory = @"c:\";
            save.Filter = "文本文件(*.txt)|*.txt|RTF文件(*.rtf)|*.rtf";
            //save.DefaultExt = "";
            DialogResult dr = save.ShowDialog();
            if (dr == DialogResult.OK)
            {
                strFileName = save.FileName;
                string str = Path.GetExtension(strFileName).ToLower();
                switch (str)
                {
                    case ".txt":
                        richTextBox1.SaveFile(strFileName, RichTextBoxStreamType.PlainText);
                        break;
                    case ".rtf":
                        richTextBox1.SaveFile(strFileName, RichTextBoxStreamType.RichText);
                        break;
                    default:
                        MessageBox.Show("系统不支持该类型！");
                        break;
                }
                strRTF = richTextBox1.Rtf;
            }
    }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Rtf != strRTF)
            {
                DialogResult dr = MessageBox.Show("文档已修改，但还未保存，是否确定现在进行保存？",
                    "询问", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.No)
                {
                    richTextBox1.Text = "";
                }
                if (dr == DialogResult.Yes)
                {
                    保存SToolStripMenuItem_Click(sender, e);
                    //if (richTextBox1.Rtf != strRTF)
                    //{
                    //    e.Cancel = true;
                    //}
                }
            }
            else
            {
                richTextBox1.Text = "";
                strFileName = "";
                strRTF = richTextBox1.Rtf;
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.InitialDirectory = @"c:\";
            open.Filter = "文本文件(*.txt)|*.txt|RTF文件(*.rtf)|*.rtf";
            open.FilterIndex = 1;
            DialogResult dr = open.ShowDialog();
            if (dr == DialogResult.OK)
            {
                strFileName = open.FileName;
                string str = Path.GetExtension(strFileName).ToLower();
                switch (str)
                {
                    case ".txt":
                        richTextBox1.LoadFile(strFileName, RichTextBoxStreamType.PlainText);
                        break;
                    case ".rtf":
                        richTextBox1.LoadFile(strFileName, RichTextBoxStreamType.RichText);
                        break;
                }
                strRTF = richTextBox1.Rtf;
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(strFileName))
            {
                另存为AToolStripMenuItem_Click(sender, e);
            }
            else
            {
                string str = Path.GetExtension(strFileName).ToLower();
                switch (str)
                {
                    case ".txt":
                        richTextBox1.SaveFile(strFileName, RichTextBoxStreamType.PlainText);
                        break;
                    case ".rtf":
                        richTextBox1.SaveFile(strFileName, RichTextBoxStreamType.RichText);
                        break;
                }
                strRTF = richTextBox1.Rtf;
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (richTextBox1.Text == "")
            {
                Application.Exit();
            }
            else if (richTextBox1.Rtf != strRTF)
            {
                DialogResult dr = MessageBox.Show("文档已修改，但还未保存，是否确定现在进行保存？",
                    "询问", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
                else if(dr == DialogResult.Yes)
                {
                    保存SToolStripMenuItem_Click(sender, e);
                    if (richTextBox1.Rtf != strRTF)
                    {
                        e.Cancel = true;
                    }
                }
            }
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
            //无效
        }

        private void toolStripComboBox2_Click(object sender, EventArgs e)
        {
            //无效
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont.Bold==true)
            {
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style ^ FontStyle.Bold);
            }
            else
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style | FontStyle.Bold);
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont.Italic == true)
            {
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style^FontStyle.Italic);
            }
            else
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont .Style| FontStyle.Italic);
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont.Underline == true)
            {
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style ^ FontStyle.Underline);
            }
            else
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style | FontStyle.Underline);
        }

        private void 撤销UToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int loc = richTextBox1.SelectionStart;
            int length = richTextBox1.SelectionLength;
            for (int i = loc; i < loc + length; i++)
            {
                richTextBox1.Select(i, 1);
                richTextBox1.SelectionFont = new Font(toolStripComboBox1.Text,
                    richTextBox1.SelectionFont.Size,
                    richTextBox1.SelectionFont.Style);
            }
            richTextBox1.Select(loc, length);
            richTextBox1.Focus();
        
            //if (toolStripComboBox1.SelectedIndex == 0)
            //    richTextBox1.SelectionFont = new Font("Arial", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else if (toolStripComboBox1.SelectedIndex == 1)
            //    richTextBox1.SelectionFont = new Font("Times New Roman", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else if (toolStripComboBox1.SelectedIndex == 2)
            //    richTextBox1.SelectionFont = new Font("黑体", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else if (toolStripComboBox1.SelectedIndex == 3)
            //    richTextBox1.SelectionFont = new Font("隶书", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else if (toolStripComboBox1.SelectedIndex == 4)
            //    richTextBox1.SelectionFont = new Font("华文新魏", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else if (toolStripComboBox1.SelectedIndex == 5)
            //    richTextBox1.SelectionFont = new Font("华文行楷", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else if (toolStripComboBox1.SelectedIndex == 6)
            //    richTextBox1.SelectionFont = new Font("华文彩云", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else if (toolStripComboBox1.SelectedIndex == 7)
            //    richTextBox1.SelectionFont = new Font("微软雅黑", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else if (toolStripComboBox1.SelectedIndex == 8)
            //    richTextBox1.SelectionFont = new Font("幼圆", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
            //else
            //    richTextBox1.SelectionFont = new Font("Arial", richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);
               
        }

        private void toolStripComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // int loc = richTextBox1.SelectionStart;
            //int length = richTextBox1.SelectionLength;
            //RichTextBox rich = new RichTextBox();
            //rich.Rtf = richTextBox1.SelectedRtf;
            //for (int i = 0; i < length; i++)
            //{
            //    rich.Select(i, 1);
            //    rich.SelectionFont = new Font(toolStripComboBox2.Text,
            //        rich.SelectionFont.Size,
            //        rich.SelectionFont.Style);
            //}
            //rich.Select(0, length);
            //richTextBox1.SelectedRtf = rich.SelectedRtf;
            //richTextBox1.Focus();
            if (toolStripComboBox2.SelectedIndex == 0)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 10, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 1)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 14, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 2)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 16, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 3)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 18, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 4)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 22, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 5)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 28, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 6)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 32, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 7)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 36, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 8)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 42, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 9)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 56, richTextBox1.SelectionFont.Style);
            else if (toolStripComboBox2.SelectedIndex == 10)
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 72, richTextBox1.SelectionFont.Style);
            else
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, 10, richTextBox1.SelectionFont.Style);
        }

        private void 查找FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFindReplace findReplace = new frmFindReplace();
            findReplace.textBox2.Enabled = false;
            findReplace.button2.Enabled = false;
            findReplace.Show(this);

        }

        private void 替换RToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFindReplace findReplace = new frmFindReplace();
            //findReplace.textBox2.Enabled = false;
            //findReplace.button2.Enabled = false;
            findReplace.Show(this);

        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void 编辑ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void richTextBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                //弹出右键菜单
                this.contextMenuStrip1.Show(MousePosition);
            }
            
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
           
        }

        private void 撤销ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void 剪切ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void 复制ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void 粘贴ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void 全选ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }
    }
}