﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmailSpider
{
    public enum WorkStatus
    {
        Init,
        Runing,
        /// <summary>
        /// 任务已完成
        /// </summary>
        TaskFinish,
        /// <summary>
        /// 工作线程已结束，如需启动请new
        /// </summary>
        WorkDispose
    }
    public class Common
    {
    }
}
