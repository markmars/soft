﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Web;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Net.Sockets;
using System.Diagnostics;
using System.Data.OleDb;
namespace EmailSpider
{
    public class WorkThread
    {
        private WorkManage wm;//线程管理对象
        public Uri CurrentUrl;//工作线程当前访问的网址
        private static object getLinkLock = new object();//获取超链接的锁。
        public DateTime StartTime = DateTime.Now;//工作开始的时间
        private string name = "";//线程名称
        public string Name
        {
            get {
                return Thread.CurrentThread.Name;
            }
        }
        public WorkThread( WorkManage wmobj)
        {
            wm = wmobj;
        }
        public void Ttart(object obj)
        {
            int max = 0;
            int cut = 0;
            ThreadPool.GetAvailableThreads(out max,out cut);
            Thread.CurrentThread.Name = (max-1).ToString()+"Thread";
            if (null == obj) return;
            CurrentUrl = new Uri(obj.ToString());
            string pageHtml = "";
            Logger.DebugFile("ChildStartTime,CurrentUrl:" + CurrentUrl, Thread.CurrentThread.Name + "debug.txt");
            StartTime = DateTime.Now;
            try
            {
                HttpHelps htmHelper = new HttpHelps();
                pageHtml = htmHelper.GetHttpRequestStringByNUll_Get(CurrentUrl.ToString(), Encoding.Default);
                Logger.DebugFile("GetHtmlFinish:", Thread.CurrentThread.Name + "debug.txt");
                if (wm.KeyWord.Trim() != "")
                {
                    string[] words = wm.KeyWord.Split(' ');
                    int contentCount = 0;
                    foreach (string tmp in words)
                    {
                        if (!pageHtml.Contains(tmp)) contentCount++;
                    }
                    if ((float)contentCount / words.Length >= wm.PiPeiDu)
                    {
                        EmailHelper.QueryAndAddEmail(pageHtml, wm.Pattren);
                        if (wm.GetNoPipeiPageLink)
                        {
                            UrlHelper.JieXieLInk(pageHtml, CurrentUrl.ToString(),wm);
                        }
                        Logger.DebugFile("HaveKeyCodeEmail:", Thread.CurrentThread.Name + "debug.txt");
                    }
                }
                else
                {
                    EmailHelper.QueryAndAddEmail(pageHtml, wm.Pattren);
                    Logger.DebugFile("GetEmail:", Thread.CurrentThread.Name + "debug.txt");
                    //处理完成后挂起线程、修改当前状态
                    UrlHelper.JieXieLInk(pageHtml, CurrentUrl.ToString(),wm);
                    Logger.DebugFile("GetLinkEnd:", Thread.CurrentThread.Name + "debug.txt");
                }
            }
            catch (IOException ioEx)
            {
                if (ioEx.InnerException != null)
                {
                    if (ioEx.InnerException is SocketException)
                    {
                        SocketException socketEx = (SocketException)ioEx.InnerException;
                        if (socketEx.NativeErrorCode == 10054)
                        {
                            wm.frm1.AddMsg(" 远程主机强迫关闭了一个现有的连接。");
                            //Logger.Error(ioEx.Message);
                        }
                    }
                    else
                    {
                        int hr = (int)ioEx.GetType().GetProperty("HResult",
                            System.Reflection.BindingFlags.Instance |
                            System.Reflection.BindingFlags.NonPublic).GetValue(ioEx, null);

                        if (hr == -2147024864)
                        {
                            // 另一个程序正在使用此文件，进程无法访问。 
                            // 束手无策 TODO: 想个办法
                            //Logger.Error(ioEx.Message);
                        }
                        else
                        {
                            //throw;
                            //Logger.Error(ioEx.Message);
                        }
                    }
                }
            }
            catch (NotSupportedException /*nsEx*/)
            {
                wm.frm1.AddMsg("无法识别该 URI 前缀。" + CurrentUrl);
                // 束手无策 TODO: 想个办法
                //Logger.Error(nsEx.Message);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            finally
            {
                Logger.DebugFile("EndTask:", Thread.CurrentThread.Name + "debug.txt");
            }

        }
    }
}
