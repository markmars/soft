﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Text.RegularExpressions;
namespace EmailSpider
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            EmailHelper.GetAEmail += new EventHandler(EmailHelper_GetAEmail);
            labEmail.Text = EmailHelper.GetEmailCount().ToString();
            DataTable dt = new DataTable();
            string confiPath = Application.StartupPath + "\\config.xml";
            if (System.IO.File.Exists(confiPath))
            {
                dt.ReadXml(confiPath);
                DataRow dr = dt.Rows[0];
                 txtRegx.Text= dr[0].ToString();
                txtKeyWord.Text = dr[1].ToString();
                  txtPiPeiDu.Text=dr[2].ToString();
                 cboGetLink.Checked=Convert.ToBoolean( dr[3]);
               txtMaxThread.Text =  dr[4].ToString();
            }
        }
        WorkManage wm;
        public void AddMsg(string msg)
        {
            DelegateAddMsg delelgateMsg = new DelegateAddMsg(AddmsgToListbox);
            this.Invoke(delelgateMsg, msg);
        }
        private void AddmsgToListbox(string msg)
        {
            if (lboMsg.Items.Count > 2000)
                lboMsg.Items.Clear();
            lboMsg.Items.Add(msg);
            lboMsg.SelectedIndex = lboMsg.Items.Count - 1;
            Logger.Info(msg);
        }

        public void stop(object obj)
        { 
             if (wm != null)
            wm.StopWork();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.GetCurrentProcess().Kill();
                wm.StopWork();
            }
            catch { }
            try
            {
                Application.Exit();
                Application.ExitThread();
            }
            catch { }
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                int maxThread=Convert.ToInt32(txtMaxThread.Text);
                if(maxThread<5)
                {
                    MessageBox.Show("因线程池限制，最大线程数不能小于5！请根据PC配置以及实际需要进行配置。");
                    return;
                }
                wm = new WorkManage(maxThread, txtRegx.Text.Trim());
                AddMsg("Start ");
                wm.frm1 = this;
                wm.KeyWord = txtKeyWord.Text.Trim();
                wm.GetNoPipeiPageLink = cboGetLink.Checked;
                wm.PiPeiDu = float.Parse(txtPiPeiDu.Text);
                wm.StartWork();
            }
            catch (FormatException fe)
            {
                MessageBox.Show("配置输入格式错误！");
                return;
            }
            catch (Exception eo)
            {
                Logger.Error(eo);
            }
            btnStart.Enabled = false;
            btnStop.Enabled = true;
            btnCheack.Enabled = true;
            labStatus.Text = WorkManage.GetWorkStatus();
        }


        private void btnStop_Click(object sender, EventArgs e)
        {
         System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(stop));
         btnStart.Enabled = true;
         btnStop.Enabled = false;
         labStatus.Text = WorkManage.GetWorkStatus();
        }

        private void btnCheack_Click(object sender, EventArgs e)
        {
            labStatus.Text = WorkManage.GetWorkStatus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Regx");
            dt.Columns.Add("KeyWord");
            dt.Columns.Add("PiPeiDu");
            dt.Columns.Add("IsContinue");
            dt.Columns.Add("MaxThread");
            DataRow dr = dt.NewRow();
            dr[0] = txtRegx.Text;
            dr[1] = txtKeyWord.Text;
            dr[2] = txtPiPeiDu.Text;
            dr[3] = cboGetLink.Checked;
            dr[4] = txtMaxThread.Text;
            dt.Rows.Add(dr);
            dt.TableName = "config";
            dt.WriteXml("config.xml",XmlWriteMode.WriteSchema);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("iexplore.exe ", @"http://www.bugucn.com");
        }

        void EmailHelper_GetAEmail(object sender, EventArgs e)
        {
            labEmail.Text = EmailHelper.GetEmailCount().ToString();
        }
    }
    delegate void DelegateAddMsg(string msg);
}