﻿
namespace EmailSpider
{
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Threading;
    using System.Text;

    public class Logger
    {
        private static object lockDebug = new object();
        private static object lockDebugFile = new object();
        private static object lockInfo = new object();
        private static object LockError = new object();
        private static string ErrorFilePath = GetNewFilePath("Error.txt");
        private static string InfoFilePath = GetNewFilePath("Info.txt");
        private static string DebugFilePath = GetNewFilePath("Debug.txt");

        public static void Error(Exception ex)
        {
            lock (LockError)
            {
                try
                {
                    FileInfo fi = new FileInfo(ErrorFilePath);
                    if (fi.Exists && fi.Length > 3 * 1024 * 1024)
                        ErrorFilePath = GetNewFilePath("Error.txt");
                    System.IO.File.AppendAllText(ErrorFilePath, string.Format("{0} : {1}{2}{3}{4}{5}"
                    , DateTime.Now.ToString("yyyyMMddHHmmss"),
                    ex.Message, Environment.NewLine,
                    ex.StackTrace, Environment.NewLine));
                }
                catch (Exception En)
                {
                }
            }
        }
        public static void Info(string str)
        {
            lock (lockInfo)
            {
                try
                {
                    FileInfo fi = new FileInfo(InfoFilePath);
                    if (fi.Exists && fi.Length > 2 * 1024 * 1024)
                        InfoFilePath = GetNewFilePath("Info.txt");
                    System.IO.File.AppendAllText(InfoFilePath, str + Environment.NewLine);
                }
                catch (Exception En)
                {
                    Error(En);
                }
            }
        }
   //     [Conditional("DEBUG")]
        public static void DebugFile(string debugMsg)
        {
            #if (DEBUG)
            string timeStr = string.Format("{0}{1}>>{2}{3}", DateTime.Now.ToString("HHmmss:"), DateTime.Now.Millisecond.ToString(), debugMsg, Environment.NewLine);
            lock (lockDebug)
            {
                try
                {
                    FileInfo fi = new FileInfo(DebugFilePath);
                    if (fi.Exists && fi.Length > 2 * 1024 * 1024)
                        DebugFilePath = GetNewFilePath("Debug.txt");
                    System.IO.File.AppendAllText(DebugFilePath,timeStr);
                }
                catch (Exception En)
                {
                    Error(En);
                }

            }
            #endif
        }
        public static void DebugFile(string debugMsg, string fileName)
        { 
            #if(DEBUG)
            string timeStr = string.Format("{0}{1}>>{2}{3}", DateTime.Now.ToString("HHmmss:"), DateTime.Now.Millisecond.ToString(), debugMsg, Environment.NewLine);
           lock (lockDebugFile)
            {
                try
                {
                    string direct=string.Format("{0}\\log\\debug\\", AppDomain.CurrentDomain.BaseDirectory);
                    if (!System.IO.Directory.Exists(direct))
                        System.IO.Directory.CreateDirectory(direct);
                    string filePath = string.Format("{0}{1}",direct, fileName);
                    System.IO.File.AppendAllText(filePath, timeStr);
                }
                catch (Exception En)
                {
                }

            }
#endif
        }

        [Conditional("DEBUG")]
        public static void DebugConsle(string debuginfo)
        {
            Console.WriteLine(debuginfo);
        }
        private static string GetNewFilePath(string fileName)
        {
            string path=string.Format("{0}{1}",AppDomain.CurrentDomain.BaseDirectory , "\\log\\");
            if (!System.IO.Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(path);
            }
            return string.Format(@"{0}{1}", path, DateTime.Now.ToString("yyMMddHHmmss") + fileName);
        }
    }
}
