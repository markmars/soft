﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace EmailSpider
{
    public static class EmailHelper
    {
        public static event EventHandler GetAEmail;
        public static object lockEmai = new object();
         private static bool Exists(string EmailStr)
         {
             string strSql0 = string.Format("select count(1) from EmailOther where Email='{0}'", EmailStr);
             string strSql1 = string.Format("select count(1) from EmailCom where Email='{0}'", EmailStr);
             bool exit = SqlHelper.Exists(strSql0);
             bool exit2 = SqlHelper.Exists(strSql1);

             if (exit || exit2) return true;
             else
                 return false;
         }
         public static int GetEmailCount()
         {
             string strSql0 = "select count(1) from EmailOther";
             string strSql1 = "select count(1) from EmailCom";
             object exit = SqlHelper.GetSingle(strSql0);
             object exit2 = SqlHelper.GetSingle(strSql1);
             return Convert.ToInt32(exit) + Convert.ToInt32(exit2);
         }
        /// <summary>
         /// 查询指定的页面内的内容。
        /// </summary>
        /// <param name="html"></param>
        /// <param name="pattren"></param>
        /// <param name="svType"></param>
         public static void QueryAndAddEmail(string html, string pattren)
        {
            Regex reg = new Regex(pattren);
            MatchCollection mcs = reg.Matches(html);
            for (int i = 0; i < mcs.Count; i++)
            {
                try
                {
                    string EmlTmp = mcs[i].Value.ToLower();
                    if (EmlTmp.Length > 50) continue;
                    if (!Exists(EmlTmp))
                    {
                        StringBuilder strSql = new StringBuilder();
                        strSql.Append("insert into ");
                        if (EmlTmp.EndsWith(".com"))
                            strSql.Append("EmailCom (Email) values('");
                        else
                            strSql.Append("EmailOther(Email) values('");
                        strSql.Append(mcs[i].Value);
                        strSql.Append("')");
                        lock (lockEmai)
                        {
                            SqlHelper.ExecuteSql(strSql.ToString());
                            GetAEmail(mcs[i].Value, new EventArgs());
                        }
                    }
                }
                catch (System.Data.SqlClient.SqlException e)
                {
                    Logger.Error(e);
                }
                catch (Exception e)
                {
                    Logger.Error(e);
                }
            }
        }
    }
}
