﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace EmailSpider
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
#if (DEBUG)
            Application.Run(new Form1());
#else
            Application.Run(new Form1());
#endif


        }

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            MessageBox.Show(string.Format("没抓到的异常{0}", ((Exception)e.ExceptionObject).Message));

        }

        static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            MessageBox.Show(string.Format("1017没抓到的异常：{0}{1}", e.Exception.Message, e.Exception.StackTrace), "异常", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
    }
}