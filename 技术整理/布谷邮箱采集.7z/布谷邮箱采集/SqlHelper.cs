using System;    
using System.Text;    
using System.Collections;    
using System.Collections.Specialized;    
using System.Data;    
using System.Data.SqlClient;    
using System.Configuration;
using System.Text.RegularExpressions;
namespace EmailSpider
{    /// <summary>    
    /// ���ݷ��ʳ��������(ACCESS)    
    /// </summary>    
    public abstract class SqlHelper
    {
        //���ݿ������ַ���(web.config������)    
        //public static string connectionString = ConfigurationManager.AppSettings["ConnectionString"];    
        // public static string connectionString = System.Web.HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["AccessConnectionString"]);    
        private static string connectionString = ConfigurationManager.AppSettings["SqlConnectionString"];
        public SqlHelper()
        {
        }

        #region ���÷���
        /// <summary>
        /// ��ȡ��������ID�е����ֵ��
        /// </summary>
        /// <param name="FieldName">ID�е�����</param>
        /// <param name="TableName">����</param>
        /// <returns></returns>
        public static int GetMaxID(string FieldName, string TableName)
        {
            string strsql = "select max(" + FieldName + ")+1 from " + TableName;
            object obj = SqlHelper.GetSingle(strsql);
            if (obj == null)
            {
                return 1;
            }
            else
            {
                return int.Parse(obj.ToString());
            }
        }
        /// <summary>
        /// ʹ��sql����ѯָ�������������Ƿ���� Selected count(*) from xxx  where .....
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public static bool Exists(string strSql)
        {
            object obj = SqlHelper.GetSingle(strSql);
            int cmdresult;
            if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
            {
                cmdresult = 0;
            }
            else
            {
                cmdresult = int.Parse(obj.ToString());
            }
            if (cmdresult == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public static bool Exists(string strSql, params SqlParameter[] cmdParms)
        {
            object obj = SqlHelper.GetSingle(strSql, cmdParms);
            int cmdresult;
            if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
            {
                cmdresult = 0;
            }
            else
            {
                cmdresult = int.Parse(obj.ToString());
            }
            if (cmdresult == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        protected static SqlParameter CreateParameter(string name,
                      SqlDbType dbType,
                      int size,
                      object value)
        {
            SqlParameter param = CreateParameter(name, dbType, size, ParameterDirection.Input, true, string.Empty, DataRowVersion.Default, value);

            return param;
        }
        protected static SqlParameter CreateParameter(string name, SqlDbType dbType, object value)
        {
            SqlParameter param = new SqlParameter(name, dbType);
            param.Value = value;
            param.Direction = ParameterDirection.Input;
            return param;
        }
        protected static SqlParameter CreateParameter(string name,
                              SqlDbType dbType,
                              int size,
                              ParameterDirection direction,
                              object value)
        {
            SqlParameter param = CreateParameter(name, dbType, size, direction, true, string.Empty, DataRowVersion.Default, value);

            return param;
        }

        protected static SqlParameter CreateParameter(string name,
                                      SqlDbType dbType,
                                      int size,
                                      ParameterDirection direction,
                                      bool nullable,
                                      object value)
        {
            SqlParameter param = CreateParameter(name, dbType, size, direction, nullable, string.Empty, DataRowVersion.Default, value);

            return param;
        }
        public static SqlParameter CreateParameter(string name,
                                          SqlDbType dbType,
                                          int size,
                                          ParameterDirection direction,
                                          bool nullable,
                                          string sourceColumn,
                                          DataRowVersion sourceVersion,
                                          object value)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = name;
            param.SqlDbType = dbType;
            param.Size = size;
            param.Value = value ?? DBNull.Value;
            param.Direction = direction;
            param.IsNullable = nullable;
            param.SourceColumn = sourceColumn;
            param.SourceVersion = sourceVersion;
            return param;
        }
        /// <summary>
        /// �޸������ַ���,�޸Ļᵼ���������������ַ����ı䡣
        /// </summary>
        /// <param name="conStr">���ݿ������ַ���</param>
        public static void ChangeConnStr(string conStr)
        {
            connectionString = conStr;
        }
        #endregion

        #region  ִ�м�SQL���

        /// <summary>    
        /// ִ��SQL��䣬����Ӱ��ļ�¼��    
        /// </summary>    
        /// <param name="SQLString">SQL���</param>    
        /// <returns>Ӱ��ļ�¼��</returns>    
        public static int ExecuteSql(string SQLString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQLString, connection))
                {
                    try
                    {
                        connection.Open();
                        int rows = cmd.ExecuteNonQuery();
                        return rows;
                    }
                    catch (System.Data.SqlClient.SqlException E)
                    {
                        connection.Close();
                        throw new Exception(E.Message);
                    }
                }
            }
        }

        /// <summary>    
        /// ִ��SQL��䣬���������ִ�еȴ�ʱ��    
        /// </summary>    
        /// <param name="SQLString"></param>    
        /// <param name="Times"></param>    
        /// <returns></returns>    
        public static int ExecuteSqlByTime(string SQLString, int Times)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQLString, connection))
                {
                    try
                    {
                        connection.Open();
                        cmd.CommandTimeout = Times;
                        int rows = cmd.ExecuteNonQuery();
                        return rows;
                    }
                    catch (System.Data.SqlClient.SqlException E)
                    {
                        connection.Close();
                        throw new Exception(E.Message);
                    }
                }
            }
        }

        /// <summary>    
        /// ִ�ж���SQL��䣬ʵ�����ݿ�����    
        /// </summary>    
        /// <param name="SQLStringList">����SQL���</param>        
        public static void ExecuteSqlTran(ArrayList SQLStringList)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                SqlTransaction tx = conn.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    for (int n = 0; n < SQLStringList.Count; n++)
                    {
                        string strsql = SQLStringList[n].ToString();
                        if (strsql.Trim().Length > 1)
                        {
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                }
                catch (System.Data.SqlClient.SqlException E)
                {
                    tx.Rollback();
                    throw new Exception(E.Message);
                }
            }
        }

        /// <summary>    
        /// �����ݿ������ͼ���ʽ���ֶ�(������������Ƶ���һ��ʵ��)    
        /// </summary>    
        /// <param name="strSQL">SQL���</param>    
        /// <param name="fs">ͼ���ֽ�,���ݿ���ֶ�����Ϊimage�����</param>    
        /// <returns>Ӱ��ļ�¼��</returns>    
        public static int ExecuteSqlInsertImg(string strSQL, byte[] fs)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(strSQL, connection);
                System.Data.SqlClient.SqlParameter myParameter = new System.Data.SqlClient.SqlParameter("@fs", SqlDbType.Image);
                myParameter.Value = fs;
                cmd.Parameters.Add(myParameter);
                try
                {
                    connection.Open();
                    int rows = cmd.ExecuteNonQuery();
                    return rows;
                }
                catch (System.Data.SqlClient.SqlException E)
                {
                    throw new Exception(E.Message);
                }
                finally
                {
                    cmd.Dispose();
                    connection.Close();
                }
            }
        }

        /// <summary>    
        /// ִ��һ�������ѯ�����䣬���ز�ѯ�����object����    
        /// </summary>    
        /// <param name="SQLString">�����ѯ������</param>    
        /// <returns>��ѯ�����object��</returns>    
        public static object GetSingle(string SQLString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQLString, connection))
                {
                    try
                    {
                        connection.Open();
                        object obj = cmd.ExecuteScalar();
                        if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
                        {
                            return null;
                        }
                        else
                        {
                            return obj;
                        }
                    }
                    catch (System.Data.SqlClient.SqlException e)
                    {
                        connection.Close();
                        throw new Exception(e.Message);
                    }
                }
            }
        }

        /// <summary>    
        /// ִ�в�ѯ��䣬����SqlDataReader(ʹ�ø÷����м�Ҫ�ֹ��ر�SqlDataReader������)    
        /// </summary>    
        /// <param name="strSQL">��ѯ���</param>    
        /// <returns>SqlDataReader</returns>    
        public static SqlDataReader ExecuteReader(string strSQL)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(strSQL, connection);
            try
            {
                connection.Open();
                SqlDataReader myReader = cmd.ExecuteReader();
                return myReader;
            }
            catch (System.Data.SqlClient.SqlException e)
            {
                throw new Exception(e.Message);
            }
            //finally //�����ڴ˹رգ����򣬷��صĶ����޷�ʹ��    
            //{    
            //  cmd.Dispose();    
            //  connection.Close();    
            //}      
        }
        /// <summary>    
        /// ִ�в�ѯ��䣬����DataSet    
        /// </summary>    
        /// <param name="SQLString">��ѯ���</param>    
        /// <returns>DataSet</returns>    
        public static DataSet Query(string SQLString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                DataSet ds = new DataSet();
                try
                {
                    connection.Open();
                    SqlDataAdapter command = new SqlDataAdapter(SQLString, connection);
                    command.Fill(ds, "ds");
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                return ds;
            }
        }
        /// <summary>    
        /// ִ�в�ѯ��䣬����DataSet,���������ִ�еȴ�ʱ��    
        /// </summary>    
        /// <param name="SQLString"></param>    
        /// <param name="Times"></param>    
        /// <returns></returns>    
        public static DataSet Query(string SQLString, int Times)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                DataSet ds = new DataSet();
                try
                {
                    connection.Open();
                    SqlDataAdapter command = new SqlDataAdapter(SQLString, connection);
                    command.SelectCommand.CommandTimeout = Times;
                    command.Fill(ds, "ds");
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                return ds;
            }
        }

        #endregion

        #region ִ�д�������SQL���

        /// <summary>    
        /// ִ��SQL��䣬����Ӱ��ļ�¼��    
        /// </summary>    
        /// <param name="SQLString">SQL���</param>    
        /// <returns>Ӱ��ļ�¼��</returns>    
        public static int ExecuteSql(string SQLString, params SqlParameter[] cmdParms)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                        int rows = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        return rows;
                    }
                    catch (System.Data.SqlClient.SqlException E)
                    {
                        throw new Exception(E.Message);
                    }
                }
            }
        }

        /// <summary>    
        /// ִ�ж���SQL��䣬ʵ�����ݿ�����    
        /// </summary>    
        /// <param name="SQLStringList">SQL���Ĺ�ϣ����keyΪsql��䣬value�Ǹ�����SqlParameter[]��</param>    
        public static void ExecuteSqlTran(Hashtable SQLStringList)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlTransaction trans = conn.BeginTransaction())
                {
                    SqlCommand cmd = new SqlCommand();
                    try
                    {
                        //ѭ��    
                        foreach (DictionaryEntry myDE in SQLStringList)
                        {
                            string cmdText = myDE.Key.ToString();
                            SqlParameter[] cmdParms = (SqlParameter[])myDE.Value;
                            PrepareCommand(cmd, conn, trans, cmdText, cmdParms);
                            int val = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            trans.Commit();
                        }
                    }
                    catch
                    {
                        trans.Rollback();
                        throw;
                    }
                }
            }
        }

        /// <summary>    
        /// ִ��һ�������ѯ�����䣬���ز�ѯ�����object����    
        /// </summary>    
        /// <param name="SQLString">�����ѯ������</param>    
        /// <returns>��ѯ�����object��</returns>    
        public static object GetSingle(string SQLString, params SqlParameter[] cmdParms)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                        object obj = cmd.ExecuteScalar();
                        cmd.Parameters.Clear();
                        if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
                        {
                            return null;
                        }
                        else
                        {
                            return obj;
                        }
                    }
                    catch (System.Data.SqlClient.SqlException e)
                    {
                        throw new Exception(e.Message);
                    }
                }
            }
        }
        /// <summary>    
        /// ִ�в�ѯ��䣬����SqlDataReader (ʹ�ø÷����м�Ҫ�ֹ��ر�SqlDataReader������)    
        /// </summary>    
        /// <param name="strSQL">��ѯ���</param>    
        /// <returns>SqlDataReader</returns>    
        public static SqlDataReader ExecuteReader(string SQLString, params SqlParameter[] cmdParms)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand();
            try
            {
                PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                SqlDataReader myReader = cmd.ExecuteReader();
                cmd.Parameters.Clear();
                return myReader;
            }
            catch (System.Data.SqlClient.SqlException e)
            {
                throw new Exception(e.Message);
            }
            //finally //�����ڴ˹رգ����򣬷��صĶ����޷�ʹ��    
            //{    
            //  cmd.Dispose();    
            //  connection.Close();    
            //}      
        }

        /// <summary>    
        /// ִ�в�ѯ��䣬����DataSet    
        /// </summary>    
        /// <param name="SQLString">��ѯ���</param>    
        /// <returns>DataSet</returns>    
        public static DataSet Query(string SQLString, params SqlParameter[] cmdParms)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand();
                PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataSet ds = new DataSet();
                    try
                    {
                        da.Fill(ds, "ds");
                        cmd.Parameters.Clear();
                    }
                    catch (System.Data.SqlClient.SqlException ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    return ds;
                }
            }
        }

        private static void PrepareCommand(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, string cmdText, SqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
                conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null)
                cmd.Transaction = trans;
            cmd.CommandType = CommandType.Text;//cmdType;    
            if (cmdParms != null)
            {


                foreach (SqlParameter parameter in cmdParms)
                {
                    if ((parameter.Direction == ParameterDirection.InputOutput || parameter.Direction == ParameterDirection.Input) &&
                        (parameter.Value == null))
                    {
                        parameter.Value = DBNull.Value;
                    }
                    cmd.Parameters.Add(parameter);
                }
            }
        }

        #endregion

        #region ִ�д洢����
        /// <summary>
        /// ִ�д洢����
        /// </summary>
        /// <param name="storedProcName">�洢������</param>
        /// <param name="parameters">�洢���̲���</param>
        /// <returns>DataSet</returns>
        public static DataSet ExecProcedureDs(string storedProcName, SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand();
                PrepareCommand(cmd, connection, null, storedProcName, parameters);
                cmd.CommandType = CommandType.StoredProcedure;
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataSet ds = new DataSet();
                    try
                    {
                        da.Fill(ds, "ds");
                        cmd.Parameters.Clear();
                    }
                    catch (System.Data.SqlClient.SqlException ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    return ds;
                }
            }
        }
        /// <summary>
        /// ִ�д洢����
        /// </summary>
        /// <param name="storedProcName">�洢������</param>
        /// <param name="parameters">�洢���̲���</param>
        /// <returns>int</returns>
        public static int ExecProcedureInt(string storedProcName, SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, storedProcName, parameters);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 60;
                        int rows = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        return rows;
                    }
                    catch (System.Data.SqlClient.SqlException E)
                    {
                        throw new Exception(E.Message);
                    }
                }
            }
        }
        /// <summary>
        /// ִ�д洢����
        /// </summary>
        /// <param name="storedProcName">�洢������</param>
        /// <param name="parameters">�洢���̲���</param>
        /// <returns>OracleDataReader</returns>
        public static SqlDataReader ExecProcedureDr(string storedProcName, SqlParameter[] parameters)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            SqlDataReader returnReader;
            connection.Open();
            SqlCommand command=new SqlCommand();
            PrepareCommand(command,connection,null, storedProcName, parameters);
            command.CommandType = CommandType.StoredProcedure;
            returnReader = command.ExecuteReader();
            return returnReader;
        }
        #endregion

        #region ��ȡ����ָ���ֶ����򲢷�ҳ��ѯ��


        /**/
        /// <summary>    
        /// ��ҳ��ѯ���ݼ�¼������ȡ    
        /// </summary>    
        /// <param name="_tbName">----Ҫ��ʾ�ı�������������</param>    
        /// <param name="_ID">----����������</param>    
        /// <param name="_strCondition">----��ѯ����,����where</param>            
        /// <param name="_Dist">----�Ƿ����Ӳ�ѯ�ֶε� DISTINCT Ĭ��0������/1����</param>    
        /// <returns></returns>    
        public static string getPageListCounts(string _ID, string _tbName, string _strCondition, int _Dist)
        {
            //---���ȡ�ò�ѯ��������Ĳ�ѯ���                        
            //---�Ժ���DISTINCT�Ĳ�ѯ����SQL����    
            //---�Ժ���DISTINCT��������ѯ����SQL����    
            string strTmp = "", SqlSelect = "", SqlCounts = "";

            if (_Dist == 0)
            {
                SqlSelect = "Select ";
                SqlCounts = "COUNT(*)";
            }
            else
            {
                SqlSelect = "Select DISTINCT ";
                SqlCounts = "COUNT(DISTINCT " + _ID + ")";
            }
            if (_strCondition == string.Empty)
            {
                strTmp = SqlSelect + " " + SqlCounts + " FROM " + _tbName;
            }
            else
            {
                strTmp = SqlSelect + " " + SqlCounts + " FROM " + " Where (1=1) " + _strCondition;
            }
            return strTmp;
        }

        /// <summary>    
        /// ���ܷ���SQL���    
        /// </summary>    
        /// <param name="primaryKey">����������Ϊ�գ�</param>    
        /// <param name="queryFields">��ȡ�ֶΣ�����Ϊ�գ�</param>    
        /// <param name="tableName">�������������������</param>    
        /// <param name="condition">���������Կգ�</param>    
        /// <param name="OrderBy">���򣬸�ʽ���ֶ���+""+ASC�����Կգ�</param>    
        /// <param name="pageSize">��ҳ��������Ϊ�գ�</param>    
        /// <param name="pageIndex">��ǰҳ����ʼΪ��1������Ϊ�գ�</param>    
        /// <returns></returns>      
        public static string getPageListSql(string primaryKey, string queryFields, string tableName, string condition, string orderBy, int pageSize, int pageIndex)
        {
            string strTmp = ""; //---strTmp���ڷ��ص�SQL���    
            string SqlSelect = "", SqlPrimaryKeySelect = "", strOrderBy = "", strWhere = " where 1=1 ", strTop = "";
            //0����ҳ����    
            //1:��ȡ�ֶ�    
            //2:��    
            //3:����    
            //4:���������ڵļ�¼    
            //5:����    
            SqlSelect = " select top {0} {1} from {2} {3} {4} {5}";
            //0:����    
            //1:TOP����,Ϊ��ҳ��*(�����-1)    
            //2:��    
            //3:����    
            //4:����    
            SqlPrimaryKeySelect = " and {0} not in (select {1} {0} from {2} {3} {4}) ";
            if (orderBy != "")
                strOrderBy = " order by " + orderBy;
            if (condition != "")
                strWhere += " and " + condition;
            int pageindexsize = (pageIndex - 1) * pageSize;
            if (pageindexsize > 0)
            {
                strTop = " top " + pageindexsize.ToString();

                SqlPrimaryKeySelect = String.Format(SqlPrimaryKeySelect, primaryKey, strTop, tableName, strWhere, strOrderBy);

                strTmp = String.Format(SqlSelect, pageSize.ToString(), queryFields, tableName, strWhere, SqlPrimaryKeySelect, strOrderBy);

            }
            else
            {
                strTmp = String.Format(SqlSelect, pageSize.ToString(), queryFields, tableName, strWhere, "", strOrderBy);

            }
            return strTmp;
        }

        /// <summary>    
        /// ��ȡ����ָ���ֶ����򲢷�ҳ��ѯ��DataSet    
        /// </summary>    
        /// <param name="pageSize">ÿҳҪ��ʾ�ļ�¼����Ŀ</param>    
        /// <param name="pageIndex">Ҫ��ʾ��ҳ������</param>    
        /// <param name="tableName">Ҫ��ѯ�����ݱ�</param>    
        /// <param name="queryFields">Ҫ��ѯ���ֶ�,�����ȫ���ֶ�����д��*</param>    
        /// <param name="primaryKey">�����ֶΣ����������õ�</param>    
        /// <param name="orderBy">�Ƿ�Ϊ�������У�0Ϊ����1Ϊ����</param>    
        /// <param name="condition">��ѯ��ɸѡ����</param>    
        /// <returns>�������򲢷�ҳ��ѯ��DataSet</returns>    
        public static DataSet GetPagingList(string primaryKey, string queryFields, string tableName, string condition, string orderBy, int pageSize, int pageIndex)
        {
            string sql = getPageListSql(primaryKey, queryFields, tableName, condition, orderBy, pageSize, pageIndex);

            return Query(sql);
        }
        public static string GetPagingListSQL(string primaryKey, string queryFields, string tableName, string condition, string orderBy, int pageSize, int pageIndex)
        {
            string sql = getPageListSql(primaryKey, queryFields, tableName, condition, orderBy, pageSize, pageIndex);

            return sql;
        }
        public static int GetRecordCount(string _ID, string _tbName, string _strCondition, int _Dist)
        {
            string sql = getPageListCounts(_ID, _tbName, _strCondition, _Dist);

            object obj = SqlHelper.GetSingle(sql);
            if (obj == null)
            {
                return 1;
            }
            else
            {
                return int.Parse(obj.ToString());
            }
        }

        /// <summary>
        /// ʹ�ô洢���̽��з�ҳ
        /// </summary>
        /// <param name="tableName">����</param>
        /// <param name="NeedRtCol">��Ҫ���ص���</param>
        /// <param name="orderCol">������</param>
        /// <param name="pageSize">ҳ��С</param>
        /// <param name="PageIndex">ҳ��</param>
        /// <param name="GetCount">�Ƿ��Ƿ��ؼ�¼����, �� 0 ֵ�򷵻� </param>
        /// <param name="orderType">������������, �� 0 ֵ���� </param>
        /// <param name="Where">��ѯ���� (ע��: ��Ҫ�� where) </param>
        /// <returns></returns>
        public static DataTable GetPageDataByPro
            (string tableName,string NeedRtCol,string orderCol,int pageSize,int PageIndex,int GetCount,int orderType,string Where)
        {
            SqlParameter[] param = new SqlParameter[]{
                CreateParameter("@tbName",SqlDbType.NVarChar,tableName),
                CreateParameter("@strGetFields",SqlDbType.NVarChar,NeedRtCol),
                CreateParameter("@fldName",SqlDbType.NVarChar,orderCol),
                CreateParameter("@PageSize",SqlDbType.Int,pageSize),
                CreateParameter("@PageIndex",SqlDbType.Int,PageIndex),
                CreateParameter("@doCount",SqlDbType.Bit,GetCount),
                CreateParameter("@OrderType",SqlDbType.Bit,orderType),
                CreateParameter("@strWhere",SqlDbType.NVarChar,Where)
            };
            return ExecProcedureDs("pagination", param).Tables[0];
        }

        /*��ҳ�洢����
         * if exists(select *From sysobjects where name ='pagination')
drop proc pagination
go
CREATE PROCEDURE pagination
@tblName varchar(255), -- ���� 
@strGetFields varchar(1000) = '*', -- ��Ҫ���ص��� 
@fldName varchar(255)='', -- ������ֶ��� 
@PageSize int = 10, -- ҳ�ߴ� 
@PageIndex int = 1, -- ҳ�� 
@doCount bit = 0, -- ���ؼ�¼����, �� 0 ֵ�򷵻� 
@OrderType bit = 0, -- ������������, �� 0 ֵ���� 
@strWhere varchar(1500) = '' -- ��ѯ���� (ע��: ��Ҫ�� where) 
AS 

declare @strSQL varchar(5000) -- ����� 
declare @strTmp varchar(110) -- ��ʱ���� 
declare @strOrder varchar(400) -- �������� 
if @doCount != 0 --��Ҫ���ؼ�¼����
begin 
if @strWhere !='' 
set @strSQL = 'select count(*) as Total from [' + @tblName + '] where '+@strWhere 
else 
set @strSQL = 'select count(*) as Total from [' + @tblName + ']' 
end 
--���ϴ������˼�����@doCount���ݹ����Ĳ���0����ִ������ͳ�ơ����µ����д��붼��@doCountΪ0����� 

else 
begin 
if @OrderType != 0 
begin 
set @strTmp = '<(select min' 
set @strOrder = ' order by [' + @fldName +'] desc' 
--���@OrderType����0����ִ�н���������Ҫ�� 
end 

else 
begin 
set @strTmp = '>(select max' 
set @strOrder = ' order by [' + @fldName +'] asc' 
end 
if @PageIndex = 1 
begin 
if @strWhere != '' 
set @strSQL = 'select top ' + str(@PageSize) +' '+@strGetFields+ ' from [' + @tblName + '] where ' + @strWhere + ' ' + @strOrder 
else 
set @strSQL = 'select top ' + str(@PageSize) +' '+@strGetFields+ ' from ['+ @tblName + '] '+ @strOrder 
--����ǵ�һҳ��ִ�����ϴ��룬������ӿ�ִ���ٶ� 
end 

else 
begin 
--���´��븳����@strSQL������ִ�е�SQL���� 
set @strSQL = 'select top ' + str(@PageSize) +' '+@strGetFields+ ' from [' 
+ @tblName + '] where [' + @fldName + ']' + @strTmp + '(['+ @fldName + ']) from (select top ' + str((@PageIndex-1)*@PageSize) + ' ['+ @fldName + '] from [' + @tblName + ']' + @strOrder + ') as tblTmp)'+ @strOrder 
print @strsql
if @strWhere != '' 
set @strSQL = 'select top ' + str(@PageSize) +' '+@strGetFields+ ' from [' 
+ @tblName + '] where [' + @fldName + ']' + @strTmp + '([' 
+ @fldName + ']) from (select top ' + str((@PageIndex-1)*@PageSize) + ' [' 
+ @fldName + '] from [' + @tblName + '] where ' + @strWhere + ' ' 
+ @strOrder + ') as tblTmp) and ' + @strWhere + ' ' + @strOrder 

end 
end
print @strsql
exec (@strSQL)
GO*/

        #endregion
    }
}