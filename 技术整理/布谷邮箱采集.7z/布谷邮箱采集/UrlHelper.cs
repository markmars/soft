﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;
namespace EmailSpider
{
    public static class UrlHelper
    {
        public static object lockAdd=new object();
        /// <summary>
        /// 解析页面的URL
        /// </summary>
        /// <param name="html"></param>
        /// <param name="currentUrl"></param>
        /// <param name="wm"></param>
        public static void JieXieLInk(string html, string currentUrl, WorkManage wm)
        {
            currentUrl = currentUrl.ToLower();

            Regex reg = new Regex(@"(?is)<a[^>]*?href=(['""]?)(?<url>[^'""\s>]+)\1[^>]*>(?<text>(?:(?!</?a\b).)*)</a>");
            MatchCollection mc = reg.Matches(html);
            Logger.DebugFile("AddChildLinkStart:" + mc.Count, System.Threading.Thread.CurrentThread.Name + "debug.txt");
            foreach (Match m in mc)
            {
                string url = m.Groups["url"].Value.ToLower();
                if (url.Length > 256) continue;

                if (url.EndsWith(".com") || url.EndsWith(".cn") || url.EndsWith(".org") || url.EndsWith(".net"))
                    goto tag2;
                if (url.EndsWith(".html") || url.EndsWith(".htm") || url.EndsWith(".php") || url.EndsWith(".aspx"))
                    goto tag1;
                if (url.EndsWith(".png") ||//不关心的连接不添加
                url.EndsWith(".jpg") ||
                url.EndsWith(".js") ||
                url.EndsWith(".css") ||
                url.EndsWith(".gif") ||
                url.EndsWith(".bmp") ||
                url.EndsWith(".doc") ||
                url.EndsWith(".xls") ||
                url.EndsWith(".zip") ||
                url.EndsWith(".rar") ||
                url.EndsWith(".swf") ||
                url.EndsWith(".avi") ||
                url.EndsWith(".pdf") ||
                url.EndsWith(".7z") ||
                url.EndsWith(".dll") ||
                     url.EndsWith(".docx") ||
                    url.EndsWith(".exe"))
                {
                    continue;
                }
            tag1:
                ////给页面上没添加当前网站域名前缀的连接添加前缀
                if (!url.Contains(".com") && !url.Contains(".cn")
                    && !url.Contains(".org") && !url.Contains(".net")
                    && !url.Contains(".hk") && !url.Contains(".cc")
                    && !url.Contains(".name") && !url.Contains(".co")
                    && !url.Contains(".so") && !url.Contains(".info")
                    && !url.Contains(".biz") && !url.Contains(".中国"))
                {
                    currentUrl = currentUrl.Substring(0, currentUrl.LastIndexOf("/") + 1);
                    url = string.Format("{0}{1}", currentUrl, url);
                }

            tag2:
                Uri urlM;
                try
                {
                    urlM = new Uri(url);
                }
                catch (UriFormatException e)
                {
                    continue;
                }

                if (!urlM.Scheme.ToLower().Equals("http") &&
                    !urlM.Scheme.ToLower().Equals("https"))
                    continue;
                if(!wm.urlNeedAdd.Contains(url))//只判断当前程序的待添加URL缓冲中是否已存在。
                    wm.urlNeedAdd.Add(url);
            }
        }

        /// <summary>
        /// 获取一个可访问的Link
        /// </summary>
        /// <returns></returns>
        public static DataTable GetRunLink()
        {
            DataSet ds= SqlHelper.ExecProcedureDs("GetNewUrl",null);
            for (int i = 0; i < ds.Tables.Count; i++)
            {
                if (ds.Tables[i].Rows.Count > 0) return ds.Tables[i];
            }
            return null;
        }

        //public static void DeleteLink(string link)
        //{
        //    string sql = string.Format("delete NewUrlOther where url='{0}'", link);
        //    SqlHelper.ExecuteSql(sql);
        //}

        public static string GetNewUrlcount()
        {
            SqlParameter sqt = new SqlParameter();
            sqt.SqlDbType = SqlDbType.Int;
            sqt.Direction = ParameterDirection.ReturnValue;
            SqlHelper.ExecProcedureInt("GetNewUrlSum",new SqlParameter[1]{sqt});
            return sqt.Value.ToString();
        }
        public static string GetOldUrlcount()
        {
            SqlParameter sqt = new SqlParameter();
            sqt.SqlDbType = SqlDbType.Int;
            sqt.Direction = ParameterDirection.ReturnValue;
            SqlHelper.ExecProcedureInt("GetOldUrlSum", new SqlParameter[1] { sqt });
            return sqt.Value.ToString();
        }
    }
}
