﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;


namespace EmailSpider
{
    public class WorkManage
    {
        public Form1 frm1;//显示界面用来传递线程消息
        private bool IsRuning = false;//工作状态
        private static string MangeTime = "";//管理线程最新运行时间
        public List<string> urlNeedAdd = new List<string>();//当前url
        //提取数据的正则表达式
        private string pattren = @"(?is)[a-z\d]\w+([-+.']\w+)*[@＠]\w+([-.]\w+)*[\.．][\w\s]*?([-.]\w+)*?(com(\.cn)?|org(\.cn)?|gov(\.cn)?|net(\.cn)?|com|cn|net|cc|org|hk|biz|name|in|mobi|ac|tw|cm)";
        public string KeyWord = "";//关键字
        public float PiPeiDu = 0.5f;//关键字匹配度
        public bool GetNoPipeiPageLink = true;//是否获取不匹配页面的连接
        public bool UrlDbIsNull = false;//url库的url 是否已经处理完
        public static System.Threading.Thread thMain;
        public static System.Threading.Thread thAddUrl;

        public string Pattren
        {
          get { return pattren; }
        }

        public WorkManage(int MaxThread,string pattr)
        {
            ThreadPool.SetMaxThreads(MaxThread,MaxThread);

            if(pattr!="")
            pattren = pattr;
        }
        public void StartWork()
        {
            thMain = new System.Threading.Thread(new System.Threading.ThreadStart(StartThread));
            IsRuning = true;
            thMain.Name = "0 Thread";
            thMain.Start();

            thAddUrl = new Thread(new ThreadStart(AddUrl));
            thAddUrl.Name = "AddUrl";
            thAddUrl.Start();
        }

        /// <summary>
        /// 开启工作线程，判断线程池是否有空闲线程，有则获取URL排入线程池。
        /// </summary>
        private void StartThread()
        {
            while (IsRuning)
            {
                System.Threading.Thread.Sleep(1000);
                int workThread = 0;
                int canUserThread = 0;

                ThreadPool.GetAvailableThreads(out workThread, out canUserThread);
                if (workThread >=5)//线程池有可用线程
                {
                    System.Data.DataTable dt = UrlHelper.GetRunLink();
                    if (null != dt && dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string urlTmp = dt.Rows[0][0].ToString();
                            WorkThread wkth = new WorkThread(this);
                            ThreadPool.QueueUserWorkItem(new WaitCallback(wkth.Ttart), urlTmp);//排入一个方法到线程池。
                        }
                    }
                    else
                    {
                        UrlDbIsNull = true;
                        frm1.AddMsg("0 Thread：Url 已空。");
                    }
                }
                Logger.DebugFile("Heart>>" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                MangeTime = DateTime.Now.ToString();
            }
        }

        /// <summary>
        /// 遍历可添加的URL集合，逐个添加URL。
        /// </summary>
        private void AddUrl()
        {
            while (IsRuning)
            {
                StringBuilder strSql = new StringBuilder();
                Thread.Sleep(600);
                try
                {
                    if (urlNeedAdd.Count > 100||UrlDbIsNull)
                    {
                        for (int i = 0; i < 100; i++)
                        {
                            if (strSql.Length > 7500) break;
                            if (urlNeedAdd.Count == 0) break;
                            string url = urlNeedAdd[0];
                            strSql.Append(url);
                            strSql.Append(";");
                            urlNeedAdd.Remove(url);
                        }
                        System.Data.SqlClient.SqlParameter sp = new System.Data.SqlClient.SqlParameter("@UrlStr", System.Data.SqlDbType.VarChar, 8000);
                        sp.Value = strSql.ToString();
                        SqlHelper.ExecProcedureInt("AddUrl", new System.Data.SqlClient.SqlParameter[] { sp });
                        UrlDbIsNull = false;
                    }
                }
                catch (Exception ex)
                {
                    frm1.AddMsg(ex.Message + ex.StackTrace);
                    Logger.Error(ex);
                }
            }
        }

        public void StopWork()
        {
            IsRuning = false;
            try
            {
                thMain.Abort();
                thAddUrl.Abort();
            }
            catch { }
            frm1.AddMsg("Stop Finish!");
        }
        /// <summary>
        /// 获取线程状态
        /// </summary>
        public static string GetWorkStatus()
        {
            int workThread = 0;
            int canUserThread = 0;

            ThreadPool.GetAvailableThreads(out workThread,out canUserThread);
            string EmailCount = "【数据库方式才支持！】";
            try
            {
                EmailCount = EmailHelper.GetEmailCount().ToString() ;

            }catch{
                EmailCount = "【获取异常】";
            }
            string msg = string.Format(@"空闲线程数:[{0}]，心跳[{1}]，URL：New[{2}]\Old[{3}]", workThread, MangeTime, UrlHelper.GetNewUrlcount(), UrlHelper.GetOldUrlcount());
           return msg;
        }
    }
}
