﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web;
namespace Process
{
    public partial class URL : Form
    {
        public URL()
        {
            InitializeComponent();
        }
    

        private void button1_Click_1(object sender, EventArgs e)
        {
            textBox2.Text = HttpUtility.UrlEncodeUnicode(textBox1.Text.Trim());
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox2.Text = HttpUtility.UrlEncodeUnicode(textBox1.Text.Trim());
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            textBox2.Text = HttpUtility.UrlDecode(textBox1.Text.Trim());
        }

        private void label3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("QQ：292501067");
        }

    

    }
}
