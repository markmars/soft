﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Process
{
    public partial class WLljxz : Form
    {


        public WLljxz()
        {
            InitializeComponent();
        }

        private NetworkAdapter[] adapters;
        private NetworkMonitor monitor;

        private void WLljxz_Load(object sender, EventArgs e)
        {

            monitor = new NetworkMonitor();
            this.adapters = monitor.Adapters;

            if (adapters.Length == 0)
            {
               
                MessageBox.Show("在计算机上没有找到网络适配器");
                return;
            }

            comboBox1.Items.AddRange(adapters);
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            monitor.StopMonitoring();
            monitor.StartMonitoring(adapters[comboBox1.SelectedIndex]);
            this.TimerCounter.Start();
        }

        private void TimerCounter_Tick(object sender, EventArgs e)
        {
            NetworkAdapter adapter = this.adapters[comboBox1.SelectedIndex];
            this.label2.Text = String.Format("{0:n} kbps", adapter.DownloadSpeedKbps);
            this.label3.Text= String.Format("{0:n} kbps", adapter.UploadSpeedKbps);
        }

      

     
    }
}
