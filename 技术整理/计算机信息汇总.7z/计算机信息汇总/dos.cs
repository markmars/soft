﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Process
{
    public partial class dos : Form
    {
        public dos()
        {
            InitializeComponent();
        }

    
        private void dos_Load(object sender, EventArgs e)
        {
            textBox1.Text = "systeminfo";
            timer1.Start();
        }
        private returnDOS rdcmd;
        private string zifu;
     
        private void df()
        {
            rdcmd = new returnDOS();
          zifu+=rdcmd.cmd(textBox1.Text );
                
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(df);
            th.Start();
            button1.Enabled = false;
          
          
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (zifu != null)
            {
                richTextBox1.Text += zifu;                
                button1.Enabled = true;
               
                //richTextBox1.Focus();
                //richTextBox1.ScrollToCaret();
                //richTextBox1.AppendText("");
                richTextBox1.Focus();
                richTextBox1.Select(richTextBox1.Text.Length, 0); 
                zifu = null;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = comboBox1.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (fontDialog1.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.Font = fontDialog1.Font;

                }
            }
            catch(Exception )
            { MessageBox.Show("不支持此字体","提醒"); }
        }

   

       
    }
}
