﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
//|5|1|a|s|p|x
namespace Process
{
    class regedit
    {
        public RegistryKey reky;
        public string tj(string strname,string pathname)
        {
            if (!System.IO.File.Exists( pathname)) { return "文件不存在"; }
            reky = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run");
            try
            {
                reky.SetValue(strname, pathname);
                
            }
            catch (Exception)
            { return "创建失败！"; }
            finally { reky.Close(); }
            return "OK";
       
        }

        public bool jzcz(string jz)
        {
            string[] subkeyNames;

            RegistryKey hkml = Registry.LocalMachine;

            RegistryKey software = hkml.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run");

            //RegistryKey software = hkml.OpenSubKey("SOFTWARE\\test", true);  

            subkeyNames = software.GetValueNames();

            //取得该项下所有键值的名称的序列，并传递给预定的数组中  

            foreach (string keyName in subkeyNames)
            {

                if (keyName == jz)   //判断键值的名称  
                {

                    hkml.Close();

                    return true;

                }

            }

            hkml.Close();

            return false;  
  
        }
        public string delkey(string jz)
        {
         
           reky = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);//打开注册表子项
           if (jzcz(jz))
           {
               try
               {
                   reky.DeleteValue(jz);
                   

               }
               catch (Exception ex)
               {
                   return "删除失败"+ex.ToString();
               }
               finally { reky.Close(); }
               return "删除成功！";
           }
           else { return "键值不存在"; }
        }
    }
}
