﻿namespace Process
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.查看详情ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kill杀死ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开程序所在位置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.程序文件属性ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.强制结束该进程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.禁止启动ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除删除启动慎用ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开程序位置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新建启动项ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.直接运行该程序ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button5 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.progressBar7 = new System.Windows.Forms.ProgressBar();
            this.progressBar6 = new System.Windows.Forms.ProgressBar();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.progressBar5 = new System.Windows.Forms.ProgressBar();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.listView3 = new System.Windows.Forms.ListView();
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.尝试开启此服务ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.尝试关闭此服务ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label22 = new System.Windows.Forms.Label();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button34 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button29 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.performanceCounter1 = new System.Diagnostics.PerformanceCounter();
            this.performanceCounter2 = new System.Diagnostics.PerformanceCounter();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.performanceCounter3 = new System.Diagnostics.PerformanceCounter();
            this.performanceCounter4 = new System.Diagnostics.PerformanceCounter();
            this.performanceCounter5 = new System.Diagnostics.PerformanceCounter();
            this.performanceCounter6 = new System.Diagnostics.PerformanceCounter();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.打开ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myCMDToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.编辑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.马上屏保ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.气泡ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.旋转的射线ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.流光ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图片ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.d文字ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开或关闭windows功能ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.更改消息通知设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.防火墙ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.计算机管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sql配置管理器ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.注册表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.作者ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.contextMenuStrip3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter6)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查看详情ToolStripMenuItem,
            this.kill杀死ToolStripMenuItem,
            this.打开程序所在位置ToolStripMenuItem,
            this.程序文件属性ToolStripMenuItem,
            this.强制结束该进程ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(185, 114);
            // 
            // 查看详情ToolStripMenuItem
            // 
            this.查看详情ToolStripMenuItem.Name = "查看详情ToolStripMenuItem";
            this.查看详情ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.查看详情ToolStripMenuItem.Text = "查看详情";
            // 
            // kill杀死ToolStripMenuItem
            // 
            this.kill杀死ToolStripMenuItem.Name = "kill杀死ToolStripMenuItem";
            this.kill杀死ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.kill杀死ToolStripMenuItem.Text = "结束该进程(及树)";
            this.kill杀死ToolStripMenuItem.Click += new System.EventHandler(this.kill杀死ToolStripMenuItem_Click);
            // 
            // 打开程序所在位置ToolStripMenuItem
            // 
            this.打开程序所在位置ToolStripMenuItem.Name = "打开程序所在位置ToolStripMenuItem";
            this.打开程序所在位置ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.打开程序所在位置ToolStripMenuItem.Text = "打开程该序所在位置";
            this.打开程序所在位置ToolStripMenuItem.Click += new System.EventHandler(this.打开程序所在位置ToolStripMenuItem_Click);
            // 
            // 程序文件属性ToolStripMenuItem
            // 
            this.程序文件属性ToolStripMenuItem.Name = "程序文件属性ToolStripMenuItem";
            this.程序文件属性ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.程序文件属性ToolStripMenuItem.Text = "程序文件属性";
            this.程序文件属性ToolStripMenuItem.Click += new System.EventHandler(this.程序文件属性ToolStripMenuItem_Click);
            // 
            // 强制结束该进程ToolStripMenuItem
            // 
            this.强制结束该进程ToolStripMenuItem.ForeColor = System.Drawing.Color.DarkRed;
            this.强制结束该进程ToolStripMenuItem.Name = "强制结束该进程ToolStripMenuItem";
            this.强制结束该进程ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.强制结束该进程ToolStripMenuItem.Text = "强制结束该进程";
            this.强制结束该进程ToolStripMenuItem.Click += new System.EventHandler(this.强制结束该进程ToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(622, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "总进程数：";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(0, 28);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(826, 325);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.button20);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.listView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(818, 299);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "  进程控制   ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(43, 281);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(173, 12);
            this.label14.TabIndex = 9;
            this.label14.Text = "◎提示：右键选定启动项操作~~";
            // 
            // button20
            // 
            this.button20.ForeColor = System.Drawing.Color.DarkRed;
            this.button20.Location = new System.Drawing.Point(481, 275);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(109, 23);
            this.button20.TabIndex = 8;
            this.button20.Text = "☆强行结束某进程";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("楷体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.ForeColor = System.Drawing.Color.Green;
            this.button1.Location = new System.Drawing.Point(749, 277);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 19);
            this.button1.TabIndex = 7;
            this.button1.Text = "◎刷新";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.ForestGreen;
            this.label3.Location = new System.Drawing.Point(693, 281);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "数量";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader18,
            this.columnHeader19});
            this.listView1.ContextMenuStrip = this.contextMenuStrip1;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(1, 1);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(814, 270);
            this.listView1.TabIndex = 4;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "   进程名";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "执行用户名";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "程序路径";
            this.columnHeader3.Width = 130;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "ID";
            this.columnHeader4.Width = 50;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "句柄数";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "描述";
            this.columnHeader7.Width = 90;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "执行时间";
            this.columnHeader8.Width = 100;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "进程表示符";
            this.columnHeader9.Width = 90;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "优先级";
            this.columnHeader10.Width = 50;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "峰值公作集";
            this.columnHeader18.Width = 90;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "实际虚拟内存";
            this.columnHeader19.Width = 90;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.listView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(818, 299);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "开机启动项管理";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(408, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "◎提示：右键选定启动项操作~~";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Green;
            this.label9.Location = new System.Drawing.Point(731, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 5;
            this.label9.Text = "复制到剪切板";
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(168, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "禁止选中启动项";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(87, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "添加启动项";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button3.Location = new System.Drawing.Point(6, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 1;
            this.button3.Text = "查看启动项";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.SystemColors.Window;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader11});
            this.listView2.ContextMenuStrip = this.contextMenuStrip2;
            this.listView2.FullRowSelect = true;
            this.listView2.GridLines = true;
            this.listView2.Location = new System.Drawing.Point(6, 41);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(811, 261);
            this.listView2.TabIndex = 0;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "启动项";
            this.columnHeader6.Width = 200;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "exe位置";
            this.columnHeader11.Width = 500;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.禁止启动ToolStripMenuItem,
            this.删除删除启动慎用ToolStripMenuItem,
            this.打开程序位置ToolStripMenuItem,
            this.新建启动项ToolStripMenuItem,
            this.直接运行该程序ToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(181, 114);
            // 
            // 禁止启动ToolStripMenuItem
            // 
            this.禁止启动ToolStripMenuItem.Name = "禁止启动ToolStripMenuItem";
            this.禁止启动ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.禁止启动ToolStripMenuItem.Text = "禁止启动";
            // 
            // 删除删除启动慎用ToolStripMenuItem
            // 
            this.删除删除启动慎用ToolStripMenuItem.ForeColor = System.Drawing.Color.DarkRed;
            this.删除删除启动慎用ToolStripMenuItem.Name = "删除删除启动慎用ToolStripMenuItem";
            this.删除删除启动慎用ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.删除删除启动慎用ToolStripMenuItem.Text = "删除删除启动(慎用)";
            this.删除删除启动慎用ToolStripMenuItem.Click += new System.EventHandler(this.删除删除启动慎用ToolStripMenuItem_Click);
            // 
            // 打开程序位置ToolStripMenuItem
            // 
            this.打开程序位置ToolStripMenuItem.Name = "打开程序位置ToolStripMenuItem";
            this.打开程序位置ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.打开程序位置ToolStripMenuItem.Text = "打开该程序位置";
            this.打开程序位置ToolStripMenuItem.Click += new System.EventHandler(this.打开程序位置ToolStripMenuItem_Click);
            // 
            // 新建启动项ToolStripMenuItem
            // 
            this.新建启动项ToolStripMenuItem.ForeColor = System.Drawing.Color.Indigo;
            this.新建启动项ToolStripMenuItem.Name = "新建启动项ToolStripMenuItem";
            this.新建启动项ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.新建启动项ToolStripMenuItem.Text = "新建启动项";
            this.新建启动项ToolStripMenuItem.Click += new System.EventHandler(this.新建启动项ToolStripMenuItem_Click);
            // 
            // 直接运行该程序ToolStripMenuItem
            // 
            this.直接运行该程序ToolStripMenuItem.Name = "直接运行该程序ToolStripMenuItem";
            this.直接运行该程序ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.直接运行该程序ToolStripMenuItem.Text = "直接运行该程序";
            this.直接运行该程序ToolStripMenuItem.Click += new System.EventHandler(this.直接运行该程序ToolStripMenuItem_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.button16);
            this.tabPage4.Controls.Add(this.listBox2);
            this.tabPage4.Controls.Add(this.button11);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(818, 299);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "  网络连接  ";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label10.Location = new System.Drawing.Point(721, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 6;
            this.label10.Text = "复制到剪切板";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.SeaGreen;
            this.label8.Location = new System.Drawing.Point(418, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 12);
            this.label8.TabIndex = 4;
            this.label8.Text = "已安装网络协议数量：";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(228, 12);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(144, 24);
            this.button16.TabIndex = 3;
            this.button16.Text = "查看已安装的网络协议";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Location = new System.Drawing.Point(6, 47);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(792, 244);
            this.listBox2.TabIndex = 2;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(114, 12);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(110, 23);
            this.button11.TabIndex = 1;
            this.button11.Text = "网络连接现状监视";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(9, 12);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(99, 23);
            this.button10.TabIndex = 0;
            this.button10.Text = "网络适配器信息";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.button19);
            this.tabPage5.Controls.Add(this.button18);
            this.tabPage5.Controls.Add(this.button17);
            this.tabPage5.Controls.Add(this.button15);
            this.tabPage5.Controls.Add(this.button8);
            this.tabPage5.Controls.Add(this.button7);
            this.tabPage5.Controls.Add(this.button6);
            this.tabPage5.Controls.Add(this.listBox1);
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(818, 299);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "  硬件信息  ";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Green;
            this.label11.Location = new System.Drawing.Point(737, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 12;
            this.label11.Text = "复制到剪切板";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(600, 12);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 23);
            this.button19.TabIndex = 11;
            this.button19.Text = "显示器";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(496, 12);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(98, 23);
            this.button18.TabIndex = 10;
            this.button18.Text = "鼠标/点入设备";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(415, 12);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 9;
            this.button17.Text = "键盘";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(334, 12);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 8;
            this.button15.Text = "主板";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(253, 12);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 7;
            this.button8.Text = "硬盘";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("楷体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button7.Location = new System.Drawing.Point(9, 12);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 6;
            this.button7.Text = "CPU";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(172, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 5;
            this.button6.Text = "内存";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(3, 50);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(811, 256);
            this.listBox1.TabIndex = 2;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(91, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 1;
            this.button5.Text = "显卡";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.Controls.Add(this.listBox3);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.button13);
            this.tabPage3.Controls.Add(this.button12);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(818, 299);
            this.tabPage3.TabIndex = 5;
            this.tabPage3.Text = "  系统资源  ";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.progressBar3);
            this.panel1.Location = new System.Drawing.Point(3, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(365, 253);
            this.panel1.TabIndex = 15;
            this.panel1.Visible = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(284, 16);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 12);
            this.label21.TabIndex = 5;
            this.label21.Text = "label21";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(31, 16);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 12);
            this.label20.TabIndex = 4;
            this.label20.Text = "CPU：";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.progressBar7);
            this.groupBox4.Controls.Add(this.progressBar6);
            this.groupBox4.Controls.Add(this.progressBar4);
            this.groupBox4.Controls.Add(this.progressBar5);
            this.groupBox4.Location = new System.Drawing.Point(14, 43);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(277, 96);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "各内核";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(9, 77);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 10;
            this.label19.Text = "核4:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(9, 58);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 9;
            this.label18.Text = "核3:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(9, 39);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 8;
            this.label17.Text = "核2:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 7;
            this.label16.Text = "核1:";
            // 
            // progressBar7
            // 
            this.progressBar7.Location = new System.Drawing.Point(58, 76);
            this.progressBar7.Name = "progressBar7";
            this.progressBar7.Size = new System.Drawing.Size(197, 13);
            this.progressBar7.TabIndex = 6;
            // 
            // progressBar6
            // 
            this.progressBar6.Location = new System.Drawing.Point(58, 57);
            this.progressBar6.Name = "progressBar6";
            this.progressBar6.Size = new System.Drawing.Size(197, 13);
            this.progressBar6.TabIndex = 5;
            // 
            // progressBar4
            // 
            this.progressBar4.Location = new System.Drawing.Point(58, 19);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(197, 13);
            this.progressBar4.TabIndex = 4;
            // 
            // progressBar5
            // 
            this.progressBar5.Location = new System.Drawing.Point(58, 38);
            this.progressBar5.Name = "progressBar5";
            this.progressBar5.Size = new System.Drawing.Size(197, 13);
            this.progressBar5.TabIndex = 2;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(72, 10);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(197, 18);
            this.progressBar3.TabIndex = 3;
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.SystemColors.Menu;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 12;
            this.listBox3.Location = new System.Drawing.Point(3, 46);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(811, 256);
            this.listBox3.TabIndex = 14;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Green;
            this.label12.Location = new System.Drawing.Point(737, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 13;
            this.label12.Text = "复制到剪切板";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(171, 12);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(118, 23);
            this.button13.TabIndex = 2;
            this.button13.Text = "CPU实时占用状态";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Enabled = false;
            this.button12.Location = new System.Drawing.Point(90, 12);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 1;
            this.button12.Text = "内存";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(9, 12);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 0;
            this.button9.Text = "硬盘存储";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Controls.Add(this.button14);
            this.tabPage6.Controls.Add(this.listView3);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(818, 299);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "  服务  ";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label15.Location = new System.Drawing.Point(454, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(173, 12);
            this.label15.TabIndex = 14;
            this.label15.Text = "◎提示：右键选定启动项操作~~";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Green;
            this.label13.Location = new System.Drawing.Point(737, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 12);
            this.label13.TabIndex = 13;
            this.label13.Text = "复制到剪切板";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(9, 12);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(120, 23);
            this.button14.TabIndex = 0;
            this.button14.Text = "查看本地所有服务";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // listView3
            // 
            this.listView3.BackColor = System.Drawing.SystemColors.Window;
            this.listView3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17});
            this.listView3.ContextMenuStrip = this.contextMenuStrip3;
            this.listView3.FullRowSelect = true;
            this.listView3.GridLines = true;
            this.listView3.Location = new System.Drawing.Point(0, 41);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(814, 265);
            this.listView3.TabIndex = 1;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "服务名称";
            this.columnHeader12.Width = 100;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "ID";
            this.columnHeader13.Width = 50;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "服务描述";
            this.columnHeader14.Width = 220;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "关于服务程序地址";
            this.columnHeader15.Width = 200;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "状态";
            this.columnHeader16.Width = 80;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "StartMode";
            this.columnHeader17.Width = 110;
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.尝试开启此服务ToolStripMenuItem,
            this.尝试关闭此服务ToolStripMenuItem});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(161, 48);
            // 
            // 尝试开启此服务ToolStripMenuItem
            // 
            this.尝试开启此服务ToolStripMenuItem.Name = "尝试开启此服务ToolStripMenuItem";
            this.尝试开启此服务ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.尝试开启此服务ToolStripMenuItem.Text = "尝试开启此服务";
            this.尝试开启此服务ToolStripMenuItem.Click += new System.EventHandler(this.尝试开启此服务ToolStripMenuItem_Click);
            // 
            // 尝试关闭此服务ToolStripMenuItem
            // 
            this.尝试关闭此服务ToolStripMenuItem.Name = "尝试关闭此服务ToolStripMenuItem";
            this.尝试关闭此服务ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.尝试关闭此服务ToolStripMenuItem.Text = "尝试关闭此服务";
            this.尝试关闭此服务ToolStripMenuItem.Click += new System.EventHandler(this.尝试关闭此服务ToolStripMenuItem_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.label22);
            this.tabPage7.Controls.Add(this.button54);
            this.tabPage7.Controls.Add(this.button53);
            this.tabPage7.Controls.Add(this.groupBox6);
            this.tabPage7.Controls.Add(this.button46);
            this.tabPage7.Controls.Add(this.groupBox5);
            this.tabPage7.Controls.Add(this.groupBox3);
            this.tabPage7.Controls.Add(this.groupBox2);
            this.tabPage7.Controls.Add(this.groupBox1);
            this.tabPage7.Controls.Add(this.button21);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(818, 299);
            this.tabPage7.TabIndex = 7;
            this.tabPage7.Text = "   工具   ";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(492, 273);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(317, 12);
            this.label22.TabIndex = 24;
            this.label22.Text = "当你的电脑没有相关资源时，系统会跳转到“我的文档”！";
            // 
            // button54
            // 
            this.button54.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button54.ForeColor = System.Drawing.Color.Maroon;
            this.button54.Location = new System.Drawing.Point(28, 141);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(80, 44);
            this.button54.TabIndex = 23;
            this.button54.Text = "网络地媒体址播放";
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // button53
            // 
            this.button53.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button53.ForeColor = System.Drawing.Color.Maroon;
            this.button53.Location = new System.Drawing.Point(28, 88);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(80, 43);
            this.button53.TabIndex = 22;
            this.button53.Text = "笔记本来电源提醒";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button52);
            this.groupBox6.Controls.Add(this.button51);
            this.groupBox6.Controls.Add(this.button50);
            this.groupBox6.Controls.Add(this.button49);
            this.groupBox6.Controls.Add(this.button48);
            this.groupBox6.Location = new System.Drawing.Point(659, 18);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(112, 212);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "工具";
            // 
            // button52
            // 
            this.button52.Font = new System.Drawing.Font("微软雅黑", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button52.ForeColor = System.Drawing.Color.Red;
            this.button52.Location = new System.Drawing.Point(15, 161);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(80, 28);
            this.button52.TabIndex = 18;
            this.button52.Text = "nslookup.exe";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button51
            // 
            this.button51.Font = new System.Drawing.Font("微软雅黑", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button51.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button51.Location = new System.Drawing.Point(16, 129);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(80, 28);
            this.button51.TabIndex = 17;
            this.button51.Text = "截图";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button50
            // 
            this.button50.Font = new System.Drawing.Font("微软雅黑", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button50.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button50.Location = new System.Drawing.Point(16, 92);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(80, 28);
            this.button50.TabIndex = 16;
            this.button50.Text = " 远程桌面";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button49
            // 
            this.button49.Font = new System.Drawing.Font("微软雅黑", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button49.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button49.Location = new System.Drawing.Point(15, 55);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(80, 28);
            this.button49.TabIndex = 15;
            this.button49.Text = "造字程序";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button48
            // 
            this.button48.Font = new System.Drawing.Font("微软雅黑", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button48.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button48.Location = new System.Drawing.Point(15, 19);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(80, 28);
            this.button48.TabIndex = 14;
            this.button48.Text = "创建自解压文件";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button46
            // 
            this.button46.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button46.ForeColor = System.Drawing.Color.Maroon;
            this.button46.Location = new System.Drawing.Point(28, 52);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(80, 30);
            this.button46.TabIndex = 20;
            this.button46.Text = "URL编码转换";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button34);
            this.groupBox5.Controls.Add(this.button42);
            this.groupBox5.Controls.Add(this.button43);
            this.groupBox5.Controls.Add(this.button44);
            this.groupBox5.Controls.Add(this.button47);
            this.groupBox5.Controls.Add(this.button45);
            this.groupBox5.Controls.Add(this.button27);
            this.groupBox5.Location = new System.Drawing.Point(145, 18);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(136, 255);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "监视及属性";
            // 
            // button34
            // 
            this.button34.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button34.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button34.Location = new System.Drawing.Point(11, 218);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(110, 27);
            this.button34.TabIndex = 17;
            this.button34.Text = "系统属性";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button42
            // 
            this.button42.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button42.Location = new System.Drawing.Point(11, 185);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(110, 27);
            this.button42.TabIndex = 19;
            this.button42.Text = " 逻辑磁盘";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button43.Location = new System.Drawing.Point(11, 152);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(110, 27);
            this.button43.TabIndex = 20;
            this.button43.Text = "用户和组";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button44.Location = new System.Drawing.Point(11, 119);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(110, 27);
            this.button44.TabIndex = 21;
            this.button44.Text = "内存诊断";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button47
            // 
            this.button47.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button47.Location = new System.Drawing.Point(11, 53);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(110, 27);
            this.button47.TabIndex = 26;
            this.button47.Text = "性能监视器";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button45
            // 
            this.button45.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button45.Location = new System.Drawing.Point(11, 86);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(110, 27);
            this.button45.TabIndex = 24;
            this.button45.Text = "资源监视器";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button27.Location = new System.Drawing.Point(11, 21);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(110, 27);
            this.button27.TabIndex = 23;
            this.button27.Text = "事件查看";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button40);
            this.groupBox3.Controls.Add(this.button39);
            this.groupBox3.Controls.Add(this.button41);
            this.groupBox3.Controls.Add(this.button37);
            this.groupBox3.Controls.Add(this.button36);
            this.groupBox3.Controls.Add(this.button35);
            this.groupBox3.Controls.Add(this.button38);
            this.groupBox3.Location = new System.Drawing.Point(287, 17);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(121, 268);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "管理";
            // 
            // button40
            // 
            this.button40.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button40.ForeColor = System.Drawing.Color.DimGray;
            this.button40.Location = new System.Drawing.Point(6, 97);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(110, 27);
            this.button40.TabIndex = 22;
            this.button40.Text = "防火墙";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button39
            // 
            this.button39.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button39.ForeColor = System.Drawing.Color.DarkGreen;
            this.button39.Location = new System.Drawing.Point(6, 196);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(110, 27);
            this.button39.TabIndex = 21;
            this.button39.Text = " 更改消息通知";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button41
            // 
            this.button41.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button41.ForeColor = System.Drawing.Color.DimGray;
            this.button41.Location = new System.Drawing.Point(6, 229);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(110, 27);
            this.button41.TabIndex = 18;
            this.button41.Text = "备份还原";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button37
            // 
            this.button37.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button37.ForeColor = System.Drawing.Color.DarkRed;
            this.button37.Location = new System.Drawing.Point(6, 130);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(110, 27);
            this.button37.TabIndex = 20;
            this.button37.Text = " 注册表";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button36
            // 
            this.button36.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button36.ForeColor = System.Drawing.Color.DarkGreen;
            this.button36.Location = new System.Drawing.Point(6, 49);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(110, 42);
            this.button36.TabIndex = 19;
            this.button36.Text = "打开或关闭windows功能";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button35
            // 
            this.button35.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button35.ForeColor = System.Drawing.Color.DimGray;
            this.button35.Location = new System.Drawing.Point(6, 163);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(110, 27);
            this.button35.TabIndex = 18;
            this.button35.Text = "sql配置管理器";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button38
            // 
            this.button38.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button38.ForeColor = System.Drawing.Color.DimGray;
            this.button38.Location = new System.Drawing.Point(6, 15);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(110, 28);
            this.button38.TabIndex = 16;
            this.button38.Text = "计算机管理";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button33);
            this.groupBox2.Controls.Add(this.button32);
            this.groupBox2.Controls.Add(this.button31);
            this.groupBox2.Controls.Add(this.button30);
            this.groupBox2.Controls.Add(this.button28);
            this.groupBox2.Location = new System.Drawing.Point(414, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(105, 195);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "马上屏保";
            // 
            // button33
            // 
            this.button33.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button33.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button33.Location = new System.Drawing.Point(15, 157);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(74, 27);
            this.button33.TabIndex = 11;
            this.button33.Text = "流光";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button32.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button32.Location = new System.Drawing.Point(15, 124);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(74, 27);
            this.button32.TabIndex = 10;
            this.button32.Text = "旋转的射线";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button31
            // 
            this.button31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button31.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button31.Location = new System.Drawing.Point(15, 90);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(74, 27);
            this.button31.TabIndex = 9;
            this.button31.Text = "图片屏保";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button30
            // 
            this.button30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button30.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button30.Location = new System.Drawing.Point(15, 55);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(74, 27);
            this.button30.TabIndex = 8;
            this.button30.Text = "旋转文字";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button28
            // 
            this.button28.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button28.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button28.Location = new System.Drawing.Point(15, 21);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(74, 27);
            this.button28.TabIndex = 7;
            this.button28.Text = "气泡屏保";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button29);
            this.groupBox1.Controls.Add(this.button25);
            this.groupBox1.Controls.Add(this.button23);
            this.groupBox1.Controls.Add(this.button26);
            this.groupBox1.Controls.Add(this.button22);
            this.groupBox1.Controls.Add(this.button24);
            this.groupBox1.Location = new System.Drawing.Point(525, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(114, 223);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "控制面板";
            // 
            // button29
            // 
            this.button29.Font = new System.Drawing.Font("微软雅黑", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button29.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button29.Location = new System.Drawing.Point(19, 20);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(80, 28);
            this.button29.TabIndex = 8;
            this.button29.Text = "添加或删除程序";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button25.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button25.Location = new System.Drawing.Point(19, 54);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(80, 28);
            this.button25.TabIndex = 4;
            this.button25.Text = "Internet选项";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button23.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button23.Location = new System.Drawing.Point(19, 88);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(80, 28);
            this.button23.TabIndex = 2;
            this.button23.Text = "用户帐户";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button26.ForeColor = System.Drawing.SystemColors.Desktop;
            this.button26.Location = new System.Drawing.Point(19, 184);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(80, 28);
            this.button26.TabIndex = 5;
            this.button26.Text = "设备管理器";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button22.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button22.Location = new System.Drawing.Point(19, 122);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(80, 25);
            this.button22.TabIndex = 1;
            this.button22.Text = "鼠标";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button24.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button24.Location = new System.Drawing.Point(19, 150);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(80, 28);
            this.button24.TabIndex = 3;
            this.button24.Text = "电源选项";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button21.ForeColor = System.Drawing.Color.Maroon;
            this.button21.Location = new System.Drawing.Point(28, 18);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(80, 28);
            this.button21.TabIndex = 0;
            this.button21.Text = "MyCMD";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 300;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // performanceCounter1
            // 
            this.performanceCounter1.CategoryName = "Memory";
            this.performanceCounter1.CounterName = "% Committed Bytes In Use";
            // 
            // performanceCounter2
            // 
            this.performanceCounter2.CategoryName = "Processor";
            this.performanceCounter2.CounterName = "% Processor Time";
            this.performanceCounter2.InstanceName = "_Total";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(41, 359);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 18);
            this.progressBar1.TabIndex = 7;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(281, 359);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(100, 18);
            this.progressBar2.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Sienna;
            this.label2.Location = new System.Drawing.Point(9, 364);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "CPU:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label4.Location = new System.Drawing.Point(240, 364);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "内存:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(157, 364);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(387, 364);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "label6";
            // 
            // timer2
            // 
            this.timer2.Interval = 500;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // performanceCounter3
            // 
            this.performanceCounter3.CategoryName = "Processor";
            this.performanceCounter3.CounterName = "% Processor Time";
            this.performanceCounter3.InstanceName = "0";
            // 
            // performanceCounter4
            // 
            this.performanceCounter4.CategoryName = "Processor";
            this.performanceCounter4.CounterName = "% Processor Time";
            this.performanceCounter4.InstanceName = "1";
            // 
            // performanceCounter5
            // 
            this.performanceCounter5.CategoryName = "Processor";
            this.performanceCounter5.CounterName = "% Processor Time";
            this.performanceCounter5.InstanceName = "2";
            // 
            // performanceCounter6
            // 
            this.performanceCounter6.CategoryName = "Processor";
            this.performanceCounter6.CounterName = "% Processor Time";
            this.performanceCounter6.InstanceName = "3";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.menuStrip1.BackgroundImage = global::Process.Properties.Resources.未标题_1;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开ToolStripMenuItem,
            this.编辑ToolStripMenuItem,
            this.帮助ToolStripMenuItem,
            this.作者ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(825, 25);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 打开ToolStripMenuItem
            // 
            this.打开ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myCMDToolStripMenuItem1,
            this.退出ToolStripMenuItem});
            this.打开ToolStripMenuItem.Name = "打开ToolStripMenuItem";
            this.打开ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.打开ToolStripMenuItem.Text = "打开";
            // 
            // myCMDToolStripMenuItem1
            // 
            this.myCMDToolStripMenuItem1.Name = "myCMDToolStripMenuItem1";
            this.myCMDToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.myCMDToolStripMenuItem1.Text = "My_CMD";
            this.myCMDToolStripMenuItem1.Click += new System.EventHandler(this.myCMDToolStripMenuItem1_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.退出ToolStripMenuItem.Text = "退出(Alt+F4)";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // 编辑ToolStripMenuItem
            // 
            this.编辑ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.马上屏保ToolStripMenuItem,
            this.打开或关闭windows功能ToolStripMenuItem,
            this.更改消息通知设置ToolStripMenuItem,
            this.防火墙ToolStripMenuItem,
            this.计算机管理ToolStripMenuItem,
            this.sql配置管理器ToolStripMenuItem,
            this.注册表ToolStripMenuItem});
            this.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem";
            this.编辑ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.编辑ToolStripMenuItem.Text = "设置";
            // 
            // 马上屏保ToolStripMenuItem
            // 
            this.马上屏保ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.气泡ToolStripMenuItem,
            this.旋转的射线ToolStripMenuItem,
            this.流光ToolStripMenuItem,
            this.图片ToolStripMenuItem,
            this.d文字ToolStripMenuItem});
            this.马上屏保ToolStripMenuItem.Name = "马上屏保ToolStripMenuItem";
            this.马上屏保ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.马上屏保ToolStripMenuItem.Text = "马上屏保";
            // 
            // 气泡ToolStripMenuItem
            // 
            this.气泡ToolStripMenuItem.Name = "气泡ToolStripMenuItem";
            this.气泡ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.气泡ToolStripMenuItem.Text = "气泡";
            this.气泡ToolStripMenuItem.Click += new System.EventHandler(this.气泡ToolStripMenuItem_Click);
            // 
            // 旋转的射线ToolStripMenuItem
            // 
            this.旋转的射线ToolStripMenuItem.Name = "旋转的射线ToolStripMenuItem";
            this.旋转的射线ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.旋转的射线ToolStripMenuItem.Text = "旋转的射线";
            this.旋转的射线ToolStripMenuItem.Click += new System.EventHandler(this.旋转的射线ToolStripMenuItem_Click);
            // 
            // 流光ToolStripMenuItem
            // 
            this.流光ToolStripMenuItem.Name = "流光ToolStripMenuItem";
            this.流光ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.流光ToolStripMenuItem.Text = "流光";
            this.流光ToolStripMenuItem.Click += new System.EventHandler(this.流光ToolStripMenuItem_Click);
            // 
            // 图片ToolStripMenuItem
            // 
            this.图片ToolStripMenuItem.Name = "图片ToolStripMenuItem";
            this.图片ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.图片ToolStripMenuItem.Text = "图片";
            this.图片ToolStripMenuItem.Click += new System.EventHandler(this.图片ToolStripMenuItem_Click);
            // 
            // d文字ToolStripMenuItem
            // 
            this.d文字ToolStripMenuItem.Name = "d文字ToolStripMenuItem";
            this.d文字ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.d文字ToolStripMenuItem.Text = "3D文字";
            this.d文字ToolStripMenuItem.Click += new System.EventHandler(this.d文字ToolStripMenuItem_Click);
            // 
            // 打开或关闭windows功能ToolStripMenuItem
            // 
            this.打开或关闭windows功能ToolStripMenuItem.Name = "打开或关闭windows功能ToolStripMenuItem";
            this.打开或关闭windows功能ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.打开或关闭windows功能ToolStripMenuItem.Text = "打开或关闭windows功能";
            this.打开或关闭windows功能ToolStripMenuItem.Click += new System.EventHandler(this.打开或关闭windows功能ToolStripMenuItem_Click);
            // 
            // 更改消息通知设置ToolStripMenuItem
            // 
            this.更改消息通知设置ToolStripMenuItem.Name = "更改消息通知设置ToolStripMenuItem";
            this.更改消息通知设置ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.更改消息通知设置ToolStripMenuItem.Text = "更改消息通知设置";
            this.更改消息通知设置ToolStripMenuItem.Click += new System.EventHandler(this.更改消息通知设置ToolStripMenuItem_Click);
            // 
            // 防火墙ToolStripMenuItem
            // 
            this.防火墙ToolStripMenuItem.Name = "防火墙ToolStripMenuItem";
            this.防火墙ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.防火墙ToolStripMenuItem.Text = "防火墙";
            this.防火墙ToolStripMenuItem.Click += new System.EventHandler(this.防火墙ToolStripMenuItem_Click);
            // 
            // 计算机管理ToolStripMenuItem
            // 
            this.计算机管理ToolStripMenuItem.Name = "计算机管理ToolStripMenuItem";
            this.计算机管理ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.计算机管理ToolStripMenuItem.Text = "计算机管理";
            this.计算机管理ToolStripMenuItem.Click += new System.EventHandler(this.计算机管理ToolStripMenuItem_Click);
            // 
            // sql配置管理器ToolStripMenuItem
            // 
            this.sql配置管理器ToolStripMenuItem.Name = "sql配置管理器ToolStripMenuItem";
            this.sql配置管理器ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.sql配置管理器ToolStripMenuItem.Text = "sql配置管理器";
            this.sql配置管理器ToolStripMenuItem.Click += new System.EventHandler(this.sql配置管理器ToolStripMenuItem_Click);
            // 
            // 注册表ToolStripMenuItem
            // 
            this.注册表ToolStripMenuItem.Name = "注册表ToolStripMenuItem";
            this.注册表ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.注册表ToolStripMenuItem.Text = "注册表";
            this.注册表ToolStripMenuItem.Click += new System.EventHandler(this.注册表ToolStripMenuItem_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.ShortcutKeyDisplayString = "F1";
            this.帮助ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(65, 21);
            this.帮助ToolStripMenuItem.Text = "帮助(F1)";
            this.帮助ToolStripMenuItem.Click += new System.EventHandler(this.帮助ToolStripMenuItem_Click);
            // 
            // 作者ToolStripMenuItem
            // 
            this.作者ToolStripMenuItem.Name = "作者ToolStripMenuItem";
            this.作者ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.作者ToolStripMenuItem.Text = "作者";
            this.作者ToolStripMenuItem.Click += new System.EventHandler(this.作者ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Process.Properties.Resources.未标题_1;
            this.ClientSize = new System.Drawing.Size(825, 380);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.progressBar2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "  My computer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.contextMenuStrip3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter6)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 查看详情ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kill杀死ToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.Timer timer1;
        private System.Diagnostics.PerformanceCounter performanceCounter1;
        private System.Diagnostics.PerformanceCounter performanceCounter2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem 禁止启动ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除删除启动慎用ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开程序位置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新建启动项ToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ToolStripMenuItem 直接运行该程序ToolStripMenuItem;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem 尝试开启此服务ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 尝试关闭此服务ToolStripMenuItem;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ToolStripMenuItem 打开程序所在位置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 程序文件属性ToolStripMenuItem;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.ToolStripMenuItem 强制结束该进程ToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ProgressBar progressBar7;
        private System.Windows.Forms.ProgressBar progressBar6;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar5;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.Timer timer2;
        private System.Diagnostics.PerformanceCounter performanceCounter3;
        private System.Diagnostics.PerformanceCounter performanceCounter4;
        private System.Diagnostics.PerformanceCounter performanceCounter5;
        private System.Diagnostics.PerformanceCounter performanceCounter6;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 打开ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem myCMDToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 编辑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 作者ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开或关闭windows功能ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 更改消息通知设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 防火墙ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 计算机管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sql配置管理器ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 注册表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 马上屏保ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 气泡ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 旋转的射线ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 流光ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图片ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem d文字ToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Label label22;

    }
}

