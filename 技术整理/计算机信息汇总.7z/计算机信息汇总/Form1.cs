﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Management;
using System.Threading;
using Microsoft.Win32;
using System.Net.NetworkInformation;


namespace Process
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private regedit rekey = new regedit();
        private RegistryKey hkml;
        private RegistryKey aimdir;
        private ManagementObjectSearcher sercher;
        private Wmi_restr restr;
        private string go = "选定某一功能面板。点击查看项，右键可操作此项，右上角可复制信息~~~~~~ 该程序的主要功能： \n  ◆进程控制：结束或查看详情，打开程序的实际位置,并且可以强行结束没有系统保护的进程！~ \n   \n ◆开机启动控制：查看卡机启动项，删除卡机启动项，自定义添加启动项~~~ \n   ◆网络连接：查看网络适配器信息，查看所有的网络通信协议（tcp/ip之类的）的详情，，，简单嗅探网络流量， \n   ◆硬件信息：查看基本所有硬件的详细情况，，，，， \n  ◆系统资源：硬盘利用，cpu核占用， \n   ◆服务：查看所有服务，尝试结束或启动该服务 \n   ◆工具：DIY-cmd，url转换，地址媒体播放，来电提醒，其他系统自带功能 \n   \n";
        private void Form1_Load(object sender, EventArgs e)
        {
            restr = new Wmi_restr();
            timer1.Start();
            CS();

        }
        private bool listviewselect()
        {
            if (listView1.SelectedItems.Count > 0)
            { return false; }
            else { return true; }

        }
        private bool listviewselect2()
        {
            if (listView2.SelectedItems.Count > 0)
            { return false; }
            else { return true; }

        }
        private bool listviewselect3()
        {
            if (listView3.SelectedItems.Count > 0)
            { return false; }
            else { return true; }

        }
        public void xx()
        {
            timer1.Start();
        }


        private void libox1Clear()
        { listBox1.Items.Clear(); }
        private string Win_pd(ManagementObject mo, string zhi)
        {
            try
            {
                if (mo[zhi] != null)
                { return mo[zhi].ToString(); }
                else
                { return "未知"; }
            }
            catch (Exception)
            { return "未知"; }
        }

        public void CS()
        {
            listView1.Items.Clear();
            //   System.Diagnostics.Process[] plist = System.Diagnostics.Process.GetProcesses();

            //    label3.Text=(plist.Length+1).ToString();
            //    foreach (System.Diagnostics.Process p in plist)
            //    {
            //        ListViewItem item = new ListViewItem();
            //        item.SubItems[0].Text = p.ProcessName + ".exe";
            //        item.SubItems.Add(GetProcessUserName(p.Id));
            //        item.SubItems.Add(p.Id.ToString());
            //        item.SubItems.Add(p.BasePriority.ToString());//优先级
            //        item.SubItems.Add(p.HandleCount.ToString());//句柄数                            
            //        item.SubItems.Add(p.NonpagedSystemMemorySize.ToString());//未分页物理大小
            //        item.SubItems.Add(p.PagedMemorySize.ToString());//分页物理大小
            //        item.SubItems.Add(p.PeakWorkingSet64.ToString());//最大物理类存 
            //        item.SubItems.Add(p.MainWindowTitle);//进程主窗口标题
            //        listView1.Items.Add(item);
            //    }

            //    plist.Clone();


            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_Process");
            int i = 0;
            foreach (ManagementObject mo in sercher.Get())
            {

                ListViewItem item = new ListViewItem();
                //item.SubItems[0].Text =Win_pd(mo, "Name");
                //item.SubItems.Add(Win_pd(mo, "Caption"));//标题
                string path = Win_pd(mo, "ExecutablePath");
                if (path == "未知")
                {
                    path = "系统主进程";
                }
                item.SubItems[0].Text = Win_pd(mo, "Caption");
                item.SubItems.Add(getP_user(mo));
                item.SubItems.Add(path);
                item.SubItems.Add(Win_pd(mo, "ParentProcessId"));//ID
                item.SubItems.Add(Win_pd(mo, "HandleCount"));//句柄数
                item.SubItems.Add(Win_pd(mo, "Description"));//描述

                item.SubItems.Add(Win_pd(mo, "CreationDate"));//执行时间


                item.SubItems.Add(Win_pd(mo, "Handle"));//进程表示符


                item.SubItems.Add(Win_pd(mo, "Priority"));//Y优先级

                item.SubItems.Add(Win_pd(mo, "PeakWorkingSetSize"));//峰值公作集
                item.SubItems.Add(Win_pd(mo, "VirtualSize"));//实际虚拟内存

                listView1.Items.Add(item);
                i++;
            }
            label3.Text = i.ToString();

        }
        private string getP_user(ManagementObject mo)
        {
            string name = "";
            try
            {

                ManagementBaseObject inPar = null;
                ManagementBaseObject outPar = null;

                inPar = mo.GetMethodParameters("GetOwner");

                outPar = mo.InvokeMethod("GetOwner", inPar, null);

                name = outPar["User"].ToString();


            }
            catch
            {
                name = "SYSTEM";
            }
            return name;
        }


        public float cpu()
        {

            //PerformanceCounter cpuPerformance = new PerformanceCounter();
            //cpuPerformance.CategoryName = "Processor";
            //cpuPerformance.CounterName = "% Processor Time";
            //cpuPerformance.InstanceName = "_Total";
            //return cpuPerformance.NextValue();
            return performanceCounter2.NextValue();
        }
        public float neic()
        {

            return performanceCounter1.NextValue();
        }
        //private static string GetProcessUserName(int processId)
        //{
        //    string name = "";

        //    SelectQuery query = new SelectQuery("select * from Win32_Process where processID=" + processId);
        //    ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
        //    try
        //    {
        //        foreach (ManagementObject disk in searcher.Get())
        //        {
        //            ManagementBaseObject inPar = null;
        //            ManagementBaseObject outPar = null;

        //            inPar = disk.GetMethodParameters("GetOwner");

        //            outPar = disk.InvokeMethod("GetOwner", inPar, null);

        //            name = outPar["User"].ToString();
        //            break;
        //        }
        //    }
        //    catch
        //    {
        //        name = "SYSTEM";
        //    }

        //    return name;
        //}
        private string GetRegistData(string name)
        {
            string registData;
            hkml = Registry.LocalMachine;
            aimdir = hkml.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
            registData = aimdir.GetValue(name).ToString();
            hkml.Close(); aimdir.Close();
            return registData;
        }

        private string[] GetRegistName()
        {

            hkml = Registry.LocalMachine;
            aimdir = hkml.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
            string[] f = aimdir.GetValueNames();
            hkml.Close(); aimdir.Close();
            return f;
        }
        private void SXlistvie()
        {
            listView2.Items.Clear();
            //  int i = 0;

            foreach (string name in GetRegistName())
            {

                ListViewItem item = new ListViewItem();
                item.SubItems[0].Text = name;
                item.SubItems.Add(GetRegistData(name));
                listView2.Items.Add(item);
            }

        }
        private void delkeys(string q)
        {

            if (MessageBox.Show("你要删除的启动项名称是:" + q + "  删除后无法恢复！！！ ", "★警告★", MessageBoxButtons.OKCancel, MessageBoxIcon.Error) == DialogResult.Cancel)
            {
                MessageBox.Show("你选择了取消", "返回消息");
            }
            else
            {
                MessageBox.Show(rekey.delkey(listView2.SelectedItems[0].SubItems[0].Text), "返回消息");
                SXlistvie();
            }
        }

        private void kill杀死ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listviewselect()) { return; }
            try
            {
                int id = 0;
                //  if (listView1.SelectedItems[0]== null) { return; }
                if (listView1.SelectedItems.Count == 0) { return; }
                id = int.Parse(listView1.SelectedItems[0].SubItems[3].Text);
                System.Diagnostics.Process s = System.Diagnostics.Process.GetProcessById(id);

                s.Kill();
                s.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("结束任务失败"); return;
            }
            CS();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CS();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int cp = (int)cpu();
            int ne = (int)neic();
            progressBar1.Value = cp;
            progressBar2.Value = ne;
            label5.Text = cp.ToString() + "%";
            label6.Text = ne.ToString() + "%";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SXlistvie();
        }

        private TJQD tjqd;
        private void button2_Click(object sender, EventArgs e)
        {
            if (tjqd == null || !tjqd.Created)
            {

                tjqd = new TJQD();
                tjqd.Show();
            }
            else { tjqd.Activate(); }
            SXlistvie();

        }

        private void 新建启动项ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tjqd == null || !tjqd.Created)
            {

                TJQD tj = new TJQD();
                tj.Show();
            }
            else { tjqd.Activate(); }
            SXlistvie();
        }


        private void button5_Click(object sender, EventArgs e)
        {
            libox1Clear();

            int i = 1;

            sercher = new ManagementObjectSearcher("select * from Win32_VideoController");
            foreach (ManagementObject mo in sercher.Get())
            {
                listBox1.Items.Add("_______________________________________________________");
                listBox1.Items.Add("◎名称：(" + "设备" + i.ToString() + ")" + mo["name"].ToString());
                listBox1.Items.Add("PNPDeviceID：" + mo["PNPDeviceID"].ToString());
                listBox1.Items.Add("驱动程序文件：" + mo["InstalledDisplayDrivers"].ToString());
                listBox1.Items.Add("驱动版本：" + mo["DriverVersion"].ToString());
                if (mo["VideoModeDescription"] != null)
                {
                    listBox1.Items.Add("显示模式：" + mo["VideoModeDescription"].ToString());
                }

                if (mo["MaxMemorySupported"] != null)
                {
                    listBox1.Items.Add("支持最大内存：" + mo["MaxMemorySupported"].ToString());
                }
                //  listBox1.Items.Add("支持最大内存：" + mo["MaxMemorySupported"].ToString());
                if (mo["MaxRefreshRate"] != null)
                {
                    listBox1.Items.Add("最大刷新率：" + mo["MaxRefreshRate"].ToString());
                }
                if (mo["MinRefreshRate"] != null)
                {
                    listBox1.Items.Add("最小刷新率：" + mo["MinRefreshRate"].ToString());
                }

                // listBox1.Items.Add("最大刷新率：" + mo["MaxRefreshRate"].ToString());
                // listBox1.Items.Add("最小刷新率：" + mo["MinRefreshRate"].ToString());
                listBox1.Items.Add("驱动最后修改时间：" + mo["DriverDate"].ToString());
                listBox1.Items.Add("VideoProcessor：" + mo["VideoProcessor"].ToString());



                i++;
            }

        }



        private void 删除删除启动慎用ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // MessageBox.Show(listView2.SelectedItems[0].SubItems[0].Text,"警告",MessageBoxButtons.OKCancel,MessageBoxIcon.Asterisk);
            //rekey.delkey(listView2.SelectedItems[0].SubItems[0].Text);
            if (listviewselect2()) { return; }
            try
            {

                delkeys(listView2.SelectedItems[0].SubItems[0].Text);
            }
            catch (Exception) { MessageBox.Show("无法完成此操作"); }
        }

        private void 打开程序位置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listviewselect2()) { return; }
            try
            {
                string v_OpenFilePath = listView2.SelectedItems[0].SubItems[1].Text;
                v_OpenFilePath = System.IO.Path.GetDirectoryName(v_OpenFilePath);

                System.Diagnostics.Process.Start("explorer.exe", v_OpenFilePath);
            }
            catch (Exception)
            { MessageBox.Show("打开错误，或被某些程序禁止了"); }
        }

        private void 直接运行该程序ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listviewselect2()) { return; }
            string v_OpenFilePath = listView2.SelectedItems[0].SubItems[1].Text;
            try
            {
                System.Diagnostics.Process.Start("explorer.exe", v_OpenFilePath);
            }
            catch (Exception)
            { MessageBox.Show("命令资源管理器失败，或者被操作某些程序禁止了"); }
        }



        private void button10_Click(object sender, EventArgs e)
        {

            NetworkInterface[] adapters = NetworkInterface.GetAllNetworkInterfaces();//获取本地计算机上网络接口的对象
            listBox2.Items.Add("网络适配器个数：" + adapters.Length);
            label8.Text = "适配器个数：" + adapters.Length;
            int g = 1;
            foreach (NetworkInterface adapter in adapters)
            {
                listBox2.Items.Add("_______________________________________________________");
                listBox2.Items.Add("名称：设备◎(" + g.ToString() + ")" + adapter.Name);
                listBox2.Items.Add("描述：" + adapter.Description);
                listBox2.Items.Add("标识符：" + adapter.Id);

                listBox2.Items.Add("类型：" + adapter.NetworkInterfaceType);
                listBox2.Items.Add("速度：" + adapter.Speed * 0.001 * 0.001 + "M");
                listBox2.Items.Add("操作状态：" + adapter.OperationalStatus);
                listBox2.Items.Add("MAC 地址：" + adapter.GetPhysicalAddress());

                // 格式化显示MAC地址                
                PhysicalAddress pa = adapter.GetPhysicalAddress();//获取适配器的媒体访问（MAC）地址
                byte[] bytes = pa.GetAddressBytes();//返回当前实例的地址
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    sb.Append(bytes[i].ToString("X2"));//以十六进制格式化
                    if (i != bytes.Length - 1)
                    {
                        sb.Append("-");
                    }
                }
                listBox2.Items.Add("MAC 地址：" + sb);
                g++;
            }

        }
        private WLljxz wl = null;
        private void button11_Click(object sender, EventArgs e)
        {
            if (wl == null || !wl.Created)
            {
                wl = new WLljxz();
                wl.Show();
            }
            else { wl.Activate(); }
            //WLljxz wl = new WLljxz();
            //wl.Show();

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("是否关闭?", "提示", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }




        private void button14_Click(object sender, EventArgs e)
        {
            try
            {
                sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_Service");
                foreach (ManagementObject mo in sercher.Get())
                {
                    string id = Win_pd(mo, "ProcessId");
                    ListViewItem item = new ListViewItem();
                    item.SubItems[0].Text = mo["Name"].ToString();
                    if (id == "0")
                    {
                        item.SubItems.Add("");
                    }
                    else { item.SubItems.Add(id); }
                    item.SubItems.Add(Win_pd(mo, "Caption"));
                    item.SubItems.Add(Win_pd(mo, "PathName"));
                    item.SubItems.Add(restr.pdState(Win_pd(mo, "State")));
                    item.SubItems.Add(restr.pdStateMode(Win_pd(mo, "StartMode")));

                    listView3.Items.Add(item);
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Error:   " + c.Message);
            }

        }
        private void button6_Click(object sender, EventArgs e)
        {
            libox1Clear();
            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_PhysicalMemory");
            foreach (ManagementObject mo in sercher.Get())
            {

                // ListViewItem item = new ListViewItem();
                listBox1.Items.Add("_______________________________________________________");
                listBox1.Items.Add("商标名称：" + Win_pd(mo, "Name"));
                //item.SubItems[0].Text = Win_pd(mo,"BankLabel");
                listBox1.Items.Add("标记字符串：" + Win_pd(mo, "BankLabel"));
                listBox1.Items.Add("容量：" + "(合" + (double.Parse(Win_pd(mo, "Capacity")) / 1024 / 1024 / 1034).ToString("f2") + "G)");
                listBox1.Items.Add("读取速度：" + Win_pd(mo, "Speed") + "Mhz");
                listBox1.Items.Add("简短说明：" + Win_pd(mo, "Caption"));
                listBox1.Items.Add("数据宽度：" + Win_pd(mo, "DataWidth"));
                listBox1.Items.Add("安装日期：" + Win_pd(mo, "InstallDate"));
                listBox1.Items.Add("物理类型：" + restr.ncwllx(Win_pd(mo, "MemoryType")));
                listBox1.Items.Add("当前状态：" + Win_pd(mo, "Status"));
                listBox1.Items.Add("硬件版本：" + Win_pd(mo, "Version"));


            }
        }

        private void gbfw(string caozuo)
        {
            ProcessStartInfo a = new ProcessStartInfo(@"c:/windows/system32/cmd.exe", "/c  net" + caozuo + listView3.SelectedItems[0].SubItems[0].Text);
            a.WindowStyle = ProcessWindowStyle.Hidden;
            System.Diagnostics.Process process = System.Diagnostics.Process.Start(a);
        }

        private void 尝试关闭此服务ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (listviewselect3())
            { return; }
            gbfw("start");
        }

        private void 尝试开启此服务ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listviewselect3())
            { return; }
            gbfw("stop");
        }

        private void button7_Click(object sender, EventArgs e)
        {

            libox1Clear();
            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_Processor");
            foreach (ManagementObject mo in sercher.Get())
            {
                listBox1.Items.Add("名称：" + Win_pd(mo, "Name"));
                listBox1.Items.Add("SystemName：" + Win_pd(mo, "SystemName"));
                listBox1.Items.Add("描述：" + Win_pd(mo, "Caption"));
                listBox1.Items.Add("处理速度：" + Win_pd(mo, "CurrentClockSpeed") + " Mhz");
                listBox1.Items.Add("最大的处理器速度：" + Win_pd(mo, "MaxClockSpeed") + " Mhz");
                listBox1.Items.Add("二级缓存：" + Win_pd(mo, "L2CacheSize"));
                listBox1.Items.Add("三级缓存：" + Win_pd(mo, "L3CacheSize"));
                listBox1.Items.Add("服务的系统位数：" + Win_pd(mo, "AddressWidth"));
                listBox1.Items.Add("构架模式：" + restr.cpugjms(Win_pd(mo, "Architecture")));
                listBox1.Items.Add("外部时钟频率：" + Win_pd(mo, "ExtClock") + " Mhz");
                listBox1.Items.Add("cpu的主要功能的类型：" + restr.cpugn(Win_pd(mo, "ProcessorType")));
                listBox1.Items.Add("生产厂家：" + Win_pd(mo, "Manufacturer"));



            }
        }

        private void button8_Click(object sender, EventArgs e)
        {

            listBox1.Items.Clear();
            listBox1.Items.Add("________________◎该信息是硬盘已分区和未分区的属性◎________________");
            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_DiskPartition");
            foreach (ManagementObject mo in sercher.Get())
            {
                listBox1.Items.Add("_______________________________________________________");
                listBox1.Items.Add("名称：" + Win_pd(mo, "Caption"));
                listBox1.Items.Add("访问：" + restr.YPdqsx(Win_pd(mo, "Access")));
                listBox1.Items.Add("存储程度的块大小：" + Win_pd(mo, "BlockSize") + "  字节");
                listBox1.Items.Add("计算机是否可以从此分区启动：" + Win_pd(mo, "Bootable"));
                listBox1.Items.Add("索引：" + Win_pd(mo, "DiskIndex"));
                listBox1.Items.Add("描述：" + Win_pd(mo, "Description"));
                listBox1.Items.Add("ID：" + Win_pd(mo, "DeviceID"));
                listBox1.Items.Add("支持此存储程度的误差检测和校正的类型：" + Win_pd(mo, "ErrorMethodology"));
                listBox1.Items.Add("在分区的隐藏扇区数：" + Win_pd(mo, "HiddenSectors"));
                listBox1.Items.Add("容量大小：" + (double.Parse(Win_pd(mo, "Size")) / 1024 / 1024 / 1024).ToString("f2") + "G)");
                listBox1.Items.Add("生产厂家：" + Win_pd(mo, "Manufacturer"));
                listBox1.Items.Add("起始偏移量（以字节为单位）的分区：" + Win_pd(mo, "StartingOffset"));
                listBox1.Items.Add("状态：" + Win_pd(mo, "Status"));
                listBox1.Items.Add("数据类型：" + Win_pd(mo, "Type"));
                listBox1.Items.Add("PNPDeviceID：" + Win_pd(mo, "PNPDeviceID"));
                listBox1.Items.Add("所服务系统用户：" + Win_pd(mo, "SystemName"));



            }

        }

        private void button16_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_NetworkProtocol");
            int i = 0;
            foreach (ManagementObject mo in sercher.Get())
            {
                listBox2.Items.Add("_______________________________________________________");
                listBox2.Items.Add("协议名称：" + Win_pd(mo, "Name"));
                listBox2.Items.Add("标题：" + Win_pd(mo, "Caption"));
                listBox2.Items.Add("描述：" + Win_pd(mo, "Description"));
                listBox2.Items.Add("安装日期：" + Win_pd(mo, "InstallDate"));
                listBox2.Items.Add("是否支持无连接发送服务：" + Win_pd(mo, " ConnectionlessService"));
                listBox2.Items.Add("支持最小套接字：" + Win_pd(mo, "MinimumAddressSize"));
                listBox2.Items.Add("支持最大套接字：" + Win_pd(mo, "MaximumAddressSize"));
                listBox2.Items.Add("是否支持加密传输：" + Win_pd(mo, "SupportsEncryption"));
                listBox2.Items.Add("是否支持多广播：" + Win_pd(mo, "SupportsMulticasting"));
                listBox2.Items.Add("是否支持网络广播：" + Win_pd(mo, "SupportsBroadcasting"));

                i++;
            }

            label8.Text = "已安装网络协议数量：  " + i.ToString();
        }

        private void 打开程序所在位置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listviewselect()) { return; }
            string posspath = listView1.SelectedItems[0].SubItems[2].Text;
            if (posspath == "系统主进程")
            { MessageBox.Show("系统主进程程序没有可打开位置", "提示"); return; }
            posspath = System.IO.Path.GetDirectoryName(posspath);
            System.Diagnostics.Process.Start("explorer.exe", posspath);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            libox1Clear();
            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_BaseBoard");
            foreach (ManagementObject mo in sercher.Get())
            {
                listBox1.Items.Add("_______________________________________________________");
                listBox1.Items.Add("名称：" + Win_pd(mo, "Name"));
                listBox1.Items.Add("标题：" + Win_pd(mo, "Caption"));
                listBox1.Items.Add("可更换：" + Win_pd(mo, "Replaceable"));
                listBox1.Items.Add("是否必须配套子卡或副卡：" + Win_pd(mo, "RequiresDaughterBoard"));
                listBox1.Items.Add("生产厂家：" + Win_pd(mo, "Manufacturer"));
                listBox1.Items.Add("序列号：" + Win_pd(mo, "SerialNumber"));
                listBox1.Items.Add("状态：" + Win_pd(mo, "Status"));
                listBox1.Items.Add("版本：" + Win_pd(mo, "Version"));
                listBox1.Items.Add("物理封装深度：" + Win_pd(mo, "Depth") + "  英寸");
                listBox1.Items.Add("物理封装高度：" + Win_pd(mo, "Height") + "  英寸");
                listBox1.Items.Add("模型：" + Win_pd(mo, "Model"));


            }
        }

        private void button17_Click(object sender, EventArgs e)
        {

            libox1Clear();
            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_Keyboard");
            foreach (ManagementObject mo in sercher.Get())
            {
                listBox1.Items.Add("_______________________________________________________");
                listBox1.Items.Add("名称：" + Win_pd(mo, "Name"));
                listBox1.Items.Add("是否在使用自定义配置：" + Win_pd(mo, "ConfigManagerUserConfig"));
                listBox1.Items.Add("描述：" + Win_pd(mo, "Description"));
                listBox1.Items.Add("ID：" + Win_pd(mo, "DeviceID"));
                listBox1.Items.Add("是否被锁定：" + Win_pd(mo, "IsLocked"));
                listBox1.Items.Add("键盘布局：" + Win_pd(mo, "Layout"));
                listBox1.Items.Add("键盘上的功能键数：" + Win_pd(mo, "NumberOfFunctionKeys"));
                listBox1.Items.Add("PNPDeviceID：" + Win_pd(mo, "PNPDeviceID"));
                listBox1.Items.Add("所服务系统用户：" + Win_pd(mo, "SystemName"));



            }
        }

        private void button18_Click(object sender, EventArgs e)
        {

            libox1Clear();
            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_PointingDevice");
            foreach (ManagementObject mo in sercher.Get())
            {
                listBox1.Items.Add("_______________________________________________________");
                listBox1.Items.Add("名称：" + Win_pd(mo, "Caption"));
                listBox1.Items.Add("是否在使用自定义配置：" + Win_pd(mo, "ConfigManagerUserConfig"));
                listBox1.Items.Add("描述：" + Win_pd(mo, "Description"));
                listBox1.Items.Add("ID：" + Win_pd(mo, "DeviceID"));
                listBox1.Items.Add("是否被锁定：" + Win_pd(mo, "IsLocked"));
                listBox1.Items.Add("设备接口类型：" + restr.DRjc(Win_pd(mo, "DeviceInterface")));
                listBox1.Items.Add("惯用手：" + Win_pd(mo, "Handedness"));
                listBox1.Items.Add("HardwareType：" + Win_pd(mo, "HardwareType"));
                listBox1.Items.Add("inf文件名称：" + Win_pd(mo, "InfFileName"));
                listBox1.Items.Add("inf文件类型：" + Win_pd(mo, "InfSection"));
                listBox1.Items.Add("生产厂家：" + Win_pd(mo, "Manufacturer"));
                listBox1.Items.Add("设备上的按钮数量：" + Win_pd(mo, "NumberOfButtons"));
                listBox1.Items.Add("设备实质传感类型：" + restr.DRcg(Win_pd(mo, "PointingType")));
                listBox1.Items.Add("跟踪分辨率：" + Win_pd(mo, "Resolution"));
                listBox1.Items.Add("PNPDeviceID：" + Win_pd(mo, "PNPDeviceID"));
                listBox1.Items.Add("所服务系统用户：" + Win_pd(mo, "SystemName"));



            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            libox1Clear();
            int width = Screen.PrimaryScreen.Bounds.Width;
            int height = Screen.PrimaryScreen.Bounds.Height;
            listBox1.Items.Add("用窗口口获得的当前分辨率(非指定硬件)≯  宽:" + width.ToString() + " 高:" + height.ToString());
            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_DesktopMonitor");
            foreach (ManagementObject mo in sercher.Get())
            {
                listBox1.Items.Add("_______________________________________________________");
                listBox1.Items.Add("名称：" + Win_pd(mo, "Caption"));
                listBox1.Items.Add("是否被锁定：" + Win_pd(mo, "IsLocked"));
                listBox1.Items.Add("生产厂家：" + Win_pd(mo, "MonitorManufacturer"));
                listBox1.Items.Add("是否在使用自定义配置：" + Win_pd(mo, "ConfigManagerUserConfig"));
                listBox1.Items.Add("描述：" + Win_pd(mo, "Description"));
                listBox1.Items.Add("ID：" + Win_pd(mo, "DeviceID"));

                listBox1.Items.Add("水平方向的显示器的分辨率(单位:每逻辑英寸的像素）：" + Win_pd(mo, "PixelsPerXLogicalInch"));
                listBox1.Items.Add("垂直方向的显示器的分辨率(单位:每逻辑英寸的像素）：" + Win_pd(mo, "PixelsPerYLogicalInch"));

                listBox1.Items.Add("状态：" + Win_pd(mo, "Status"));
                listBox1.Items.Add("高度：" + Win_pd(mo, "ScreenHeight"));
                listBox1.Items.Add("宽度：" + Win_pd(mo, "ScreenWidth"));
                listBox1.Items.Add("PNPDeviceID：" + Win_pd(mo, "PNPDeviceID"));
                listBox1.Items.Add("所服务系统用户：" + Win_pd(mo, "SystemName"));
                listBox1.Items.Add("安装日期：" + Win_pd(mo, "InstallDate"));






            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

            // Clipboard.SetDataObject(listBox1.Items[1].ToString()); 
            //   MessageBox.Show(listBox1.Items);
            if (listBox2.Items.Count == 0) { return; }
            string FZ = "";
            foreach (var item in listBox2.Items)
            {
                FZ += item.ToString() + "\r\n";
            }
            // MessageBox.Show(FZ);

            Clipboard.SetDataObject(FZ);
            MessageBox.Show("OK~");
        }

        private void label11_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0) { return; }
            string FZ = "";
            foreach (var item in listBox1.Items)
            {
                FZ += item.ToString() + "\r\n";
            }
            Clipboard.SetDataObject(FZ);
            MessageBox.Show("OK~");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            listBox3.Visible = false;
            timer2.Start();
            this.button13.Enabled = false;



        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            listBox3.Visible = true;
            listBox3.Items.Clear();


            sercher = new ManagementObjectSearcher("SELECT   *   FROM   Win32_LogicalDisk");
            foreach (ManagementObject mo in sercher.Get())
            {
                try
                {
                    listBox3.Items.Add("_______________________________________________________");
                    listBox3.Items.Add("名称：" + Win_pd(mo, "Name"));
                    listBox3.Items.Add("访问属性：" + restr.YPdqsx(Win_pd(mo, "Access")));
                    listBox3.Items.Add("类型：" + restr.YPlx(Win_pd(mo, "DriveType")));
                    listBox3.Items.Add("Size：" + (double.Parse(Win_pd(mo, "Size")) / 1024 / 1024 / 1034).ToString("f2") + "G)");
                    listBox3.Items.Add("可用大小：" + (double.Parse(Win_pd(mo, "FreeSpace")) / 1024 / 1024 / 1034).ToString("f2") + "G)");
                }
                catch (Exception)
                { continue; }
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            if (listBox3.Items.Count == 0) { return; }
            string FZ = "";
            foreach (var item in listBox3.Items)
            {
                FZ += item.ToString() + "\r\n";
            }
            Clipboard.SetDataObject(FZ);
            MessageBox.Show("OK~");
        }

        private void label13_Click(object sender, EventArgs e)
        {
            if (listView3.Items.Count == 0) { return; }
            string FZ = "";
            //foreach (var item in listView3.Items)
            //{
            //    for (int i = 1; i < 7;i++ )
            //    { FZ += item.ToString(); }
            //  //  FZ += item.ToString() + "\r\n";
            //}
            //for (int i = 0; i < listBox3.Items.Count; i++)
            //{
            //    for (int j = 0; j < 6; j++)
            //    {
            //        FZ += listView3.Items[i].SubItems[j].Text;
            //    }
            //    FZ += "\r\n";

            //}
            foreach (ListViewItem item in listView3.Items)
            {
                for (int i = 0; i < item.SubItems.Count; i++)
                {

                    FZ += item.SubItems[i].Text + "\r\n";
                }
                FZ += "_________________________________________\r\n";
            }
            Clipboard.SetDataObject(FZ);
            MessageBox.Show("OK~");
        }
        private ntsd_JS cp = null;

        private void button20_Click(object sender, EventArgs e)
        {
            //ntsd_JS js = new ntsd_JS();


            //js.Show();
            if (cp == null || !cp.Created)
            {
                cp = new ntsd_JS();
                cp.Show();
            }
            else { cp.Activate(); }


        }

        private void 强制结束该进程ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listviewselect()) { return; }
            if (MessageBox.Show("   ◎你确定真要强行结束该进程？" + " \n \n  对于系统进程或系统底层保护的进程可能无法结束！\n \n  对于某些正在运行的进程，结束会让它丢失临时数据！ \n \n  对于某些系统没有保护而与系统相关的进程，结束会导致位置后果！", "★警告★", MessageBoxButtons.OKCancel, MessageBoxIcon.Error) == DialogResult.OK)
            {
                ProcessStartInfo a = new ProcessStartInfo(@"c:/windows/system32/cmd.exe", "/c  taskkill /im  " + listView1.SelectedItems[0].SubItems[0].Text);
                a.WindowStyle = ProcessWindowStyle.Hidden;
                System.Diagnostics.Process process = System.Diagnostics.Process.Start(a);
            }

        }

        private void 程序文件属性ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private dos d;
        private void button21_Click(object sender, EventArgs e)
        {
            if (d == null || !d.Created)
            {
                d = new dos();
                d.Show();
            }
            else { d.Activate(); }


        }

        private void zx(string mc)
        {
            try
            {
                System.Diagnostics.Process.Start(@mc);
            }
            catch { MessageBox.Show("暂时没有你的电脑参数"); return; }
        }
        private void button25_Click(object sender, EventArgs e)
        {
            zx("inetcpl.cpl");
        }

        private void button24_Click(object sender, EventArgs e)
        {
            zx("powercfg.cpl");
        }

        private void button23_Click(object sender, EventArgs e)
        {
            zx("nusrmgr.cpl");
        }

        private void button22_Click(object sender, EventArgs e)
        {
            zx("main.cpl");
        }

        private void button29_Click(object sender, EventArgs e)
        {
            zx("appwiz.cpl");
        }
        private void button26_Click(object sender, EventArgs e)
        {
            zx("hdwwiz.cpl");
        }

        private void explorer(string path)
        {
            try
            {
                //System.Diagnostics.Process.Start("explorer.exe", @path);
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo.FileName = @path;
                process.Start();
            }
            catch (Exception)
            { MessageBox.Show("暂时没有你电脑的程序地址参数！"); }
        }
        private void button28_Click(object sender, EventArgs e)
        {

            explorer(@"C:\Windows\System32\Bubbles.scr");
        }

        private void button30_Click(object sender, EventArgs e)
        {

            explorer(@"C:\Windows\System32\ssText3d.scr ");
        }

        private void button31_Click(object sender, EventArgs e)
        {

            explorer(@"C:\Windows\System32\PhotoScreensaver.scr");
        }

        private void button32_Click(object sender, EventArgs e)
        {

            explorer(@"C:\Windows\System32\Mystify.scr");
        }

        private void button33_Click(object sender, EventArgs e)
        {

            explorer(@"C:\Windows\System32\Ribbons.scr");
        }

        private void button27_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\eventvwr.exe ");
        }

        private void button38_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\compmgmt.msc ");
        }

        private void button36_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\OptionalFeatures.exe ");
        }

        private void button40_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\WF.msc  ");
        }

        private void button37_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\regedt32.exe   ");
        }

        private void button35_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\SQLServerManager10.msc");
        }

        private void button39_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\UserAccountControlSettings.exe ");
        }

        private void button41_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\sdclt.exe");
        }

        private void button47_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\perfmon.exe ");
        }

        private void button45_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\resmon.exe");
        }

        private void button44_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\MdSched.exe");
        }

        private void button43_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\lusrmgr.msc  ");
        }

        private void button42_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\diskmgmt.msc ");
        }

        private void button34_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\SystemPropertiesComputerName.exe ");
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            progressBar3.Value = (int)performanceCounter2.NextValue();
            try
            {
                progressBar4.Value = (int)performanceCounter3.NextValue();
            }
            catch (Exception) { }
            try
            {
                progressBar5.Value = (int)performanceCounter4.NextValue();
            }
            catch (Exception) { }
            try
            {
                progressBar6.Value = (int)performanceCounter5.NextValue();
            }
            catch (Exception) { }
            try
            {
                progressBar7.Value = (int)performanceCounter6.NextValue();
            }
            catch (Exception) { }
            label21.Text = label5.Text;

        }
        private URL ur = null;
        private void button46_Click(object sender, EventArgs e)
        {
            if (ur == null || !ur.Created)
            {
                ur = new URL();
                ur.Show();
            }

            else { ur.Activate(); }
        }



        private void myCMDToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (d == null || !d.Created)
            {
                d = new dos();
                d.Show();
            }
            else { d.Activate(); }
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 打开或关闭windows功能ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\OptionalFeatures.exe ");
        }

        private void 更改消息通知设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\UserAccountControlSettings.exe ");
        }

        private void 防火墙ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\WF.msc  ");
        }

        private void 计算机管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\compmgmt.msc ");
        }

        private void sql配置管理器ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\SQLServerManager10.msc");
        }

        private void 注册表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\regedt32.exe   ");
        }

        private void 气泡ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\Bubbles.scr");
        }

        private void 旋转的射线ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\Mystify.scr");
        }

        private void d文字ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\PhotoScreensaver.scr");
        }

        private void 流光ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\Ribbons.scr");
        }

        private void 图片ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\PhotoScreensaver.scr");
        }
        private guanyu gy;
        private void 作者ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sichuan TOP IT Vocational Institute \n  软件微软一班 ");
            if (gy == null || !gy.Created)
            {
                gy = new guanyu();
                gy.Show();
            }
            else { gy.Activate(); }
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MessageBox.Show(go, "帮助");
        }

        private void button48_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\iexpress.exe");

        }

        private void button49_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\eudcedit.exe ");
        }

        private void button50_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\mstsc.exe ");
        }

        private void button51_Click(object sender, EventArgs e)
        {
            explorer(@"C:\Windows\System32\SnippingTool.exe ");

        }

        private void button52_Click(object sender, EventArgs e)
        {

            explorer(@"C:\Windows\System32\nslookup.exe");
        }

        private void button53_Click(object sender, EventArgs e)
        {
            MessageBox.Show("程序集.NET支持：4.0或更高~");
            explorer(Application.StartupPath + @"\Dy\DY.exe");
        }

        private void button54_Click(object sender, EventArgs e)
        {
            explorer(Application.StartupPath + @"\Mid\Mideo.exe");
        }







    }
}
