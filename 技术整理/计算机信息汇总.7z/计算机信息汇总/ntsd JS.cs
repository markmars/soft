﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Process
{
    public partial class ntsd_JS : Form
    {
        public ntsd_JS()
        {
            InitializeComponent();
        }
        public ntsd_JS(int id)
        { }
        public static bool IsInt(string value)
        {
            string str = @"^\d+$";
            Regex regex = new Regex(str);
            if (regex.IsMatch(value))
            { return true; }
            else
            { return false; }
        }
        private void button1_Click(object sender, EventArgs e)
        {
          
            string idname=textBox1.Text.Trim();
            if (idname == "dark89757") { MessageBox.Show("My computer该程序作者：QQ:292501067"); return; }
            string fs = " /im ";
            if (radioButton1.Checked == true)
            { }
            else if (radioButton2.Checked == true)
            {
                if (!IsInt(idname)) { MessageBox.Show("ID不合法"); return; }
                fs = " /pid  ";
            }
            else { MessageBox.Show("选择进程标示类型(名称/ID)"); }

            ProcessStartInfo a = new ProcessStartInfo(@"c:/windows/system32/cmd.exe", "/c  taskkill "+fs+textBox1.Text);
            a.WindowStyle = ProcessWindowStyle.Hidden;
            System.Diagnostics.Process process = System.Diagnostics.Process.Start(a);
        }
    }
}
