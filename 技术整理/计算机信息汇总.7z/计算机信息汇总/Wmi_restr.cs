﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Process
{
    class Wmi_restr
    {
        public string ncwllx(string str)
        {
            switch (str)
            {
                case "0": return "未知";
                case "1": return "其他";
                case "2": return "DRAM";
                case "3": return "Synchronous DRAM，同步动态随机存取记忆体";
                case "4": return "高速缓存DRAM";
                case "5": return "EDO";
                case "6": return "EDRAM";
                case "7": return "VRAM";

            }
            return "未知";
        
        }
       public string pdStateMode(string state)
        {
            switch (state)
            {
                case "Boot": return "驱动系统加载程序";
                case "System": return "驱动系统加载程序初始";
                case "Auto": return "自启动(管理启动)";
                case "Manual": return "自定义启动(通用StartService方法)";
                case "Disabled": return "已经禁用";

            }
            return "未知";
        }
       public string pdState(string state)
        {
            switch (state)
            {
                case "Stopped": return "停止";
                case "Start Pending": return "开始挂起";
                case "Stop Pending": return "停止挂起";
                case "Running": return "正在运行";
                case "Continue Pending": return "挂起";
                case "Pause Pending": return "暂停挂起";
                case "Paused": return "暂停";
                case "Unknown": return "未知";
            }
            return "未知";
        }
       public string cpugjms(string state)
       {
           switch (state)
           {
               case "0": return "x86的";
               case "1": return "MIPS";
               case "2": return "Alpha";
               case "3": return "PowerPC的";
               case "4": return "ARM";
               case "5": return "基于Itanium的系统";
               case "6": return "暂无资料";
               case "7": return "暂无资料";
               case "8": return "暂无资料";
               case "9": return "X64";
           }
           return "未知";
       }
       public string cpugn(string state)
       {
           switch (state)
           {
               case "0": return "其他";
               case "1": return "未知";
               case "2": return "无资料";
               case "3": return "中央处理器";
               case "4": return "数学处理器";
               case "5": return "DSP处理器";
               case "6": return "视频处理器";
               
           }
           return "未知";
       }
       public string YPdqsx(string state)
       {
           switch (state)
           {
               case "0": return "未知";
               case "1": return "可读";
               case "2": return "可写";
               case "3": return "读/写支持";
               case "4": return "一次写入";
               case "5": return "DSP处理器";

           }
           return "未知";
       }
       public string YPlx(string state)
       {
           switch (state)
           {
               case "0": return "未知";
               case "1": return "无根目录";
               case "2": return "可移动磁盘";                   
               case "3": return "本地磁盘";
               case "4": return "网络驱动器";
               case "5": return "光盘";
               case "6": return "RAM磁盘";

           }
           return "未知";
       }
       public string DRcg(string state)
       {
           switch (state)
           {
               case "2": return "未知";
               case "1": return "无根目录";             
               case "3": return "鼠标";
               case "4": return "滚球";
               case "5": return "跟踪点";
               case "6": return "滑翔点";
               case "7": return "触摸板";
               case "8": return "触摸屏";
               case "9": return "鼠标 - 光学传感器";

           }
           return "未知";
       }

       public string DRgys(string state)
       {
           switch (state)
           {
               case "0": return "未知";
               case "1": return "不适用";
               case "2": return "右手操作";
               case "3": return "左手操作";
          

           }
           return "未知";
       }
       public string DRjc(string state)
       {
           switch (state)
           {
               case "1": return "其他";
               case "2": return "未知";

               case "3": return "串行";
               case "4": return "PS / 2";
               case "5": return "红外线";
               case "6": return "HP-HIL";
               case "7": return "总线鼠标";
               case "8": return "ADB（苹果桌面总线）";
               case "160": return "总线鼠标DB-9";
               case "161": return "总线鼠标微型DIN";
               case "162": return "USB";

           }
           return "未知";
       }
    }

}
