﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SQLite;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com
 
 */
  //下载源码到51aspx
namespace FileCollector.DataAccess
{
    class Categrory
    {    /// <summary>
        /// 添加
        /// </summary>
        public static bool Add(Model.CategroryInfo model)
        {
            string sql = "insert into ArticleCategories(Cid,Cname,Pid,IndexTitle,isLeaf)values(@Cid,@Cname,@Pid,@IndexTitle,@isLeaf)";
            SQLiteParameter[] parameters = new SQLiteParameter[]
            {
                new SQLiteParameter("@Cid", DbType.String),
                new SQLiteParameter("@Cname", DbType.String),
                new SQLiteParameter("@Pid", DbType.String),
                new SQLiteParameter("@IndexTitle", DbType.String),
                new SQLiteParameter("@isLeaf", DbType.Boolean)
            };
            parameters[0].Value = model.Id;
            parameters[1].Value = model.Name;
            parameters[2].Value = model.ParentId;
            parameters[3].Value = model.IndexName;
            parameters[4].Value = model.IsLeaf;
            return SQLiteDBHelper.ExecuteNonQuery(sql, parameters) > 0;
        }



        /// <summary>
        /// 修改
        /// </summary>
        public static bool Modify(Model.CategroryInfo model)
        {
            SQLiteParameter[] parameters = null;
            StringBuilder sql = new StringBuilder();
            sql.Append("update ArticleCategories set ");
            sql.Append(GetSql(true, model, ref parameters));
            sql.Append(" where Cid=@Cid");
            return SQLiteDBHelper.ExecuteNonQuery(sql.ToString(), parameters) > 0;
        }

        /// <summary>
        /// 根据主键删除数据
        /// </summary>
        public static bool Delete(int id)
        {
            string sql = "delete from ArticleCategories where Cid=@Cid";

            SQLiteParameter[] parameters = new SQLiteParameter[]
            {
                new SQLiteParameter("@Cid", SqlDbType.Int)            
            };
            parameters[0].Value = id;
            return SQLiteDBHelper.ExecuteNonQuery(sql, parameters) > 0;
        }
        /// <summary>
        /// 根据主键删除数据
        /// </summary>
        public static bool DeleteAndContent(int id)
        {
            string sql = @"delete from ArticleCategories where Cid=@Cid;
                           delete from ArticleContent  where categoryid=@categoryid";

            SQLiteParameter[] parameters = new SQLiteParameter[]
            {
                new SQLiteParameter("@Cid", SqlDbType.Int),  
                new SQLiteParameter("@categoryid", SqlDbType.Int)
            };
            parameters[0].Value = id;
            parameters[1].Value = id;
            return SQLiteDBHelper.ExecuteNonQuery(sql, parameters) > 0;
        }



        /// <summary>
        /// 是否存在
        /// </summary>
        public static bool IsExists(Model.CategroryInfo model)
        {
            SQLiteParameter[] parameters = null;
            StringBuilder sql = new StringBuilder();
            sql.Append("select count(Cid) from ArticleCategories where 1=1 ");
            sql.Append(GetSql(false, model, ref parameters));
            object obj = SQLiteDBHelper.ExecuteScalar(sql.ToString(), parameters);
            return (obj == null ? false : (Convert.ToInt32(obj) == 1));
        }
        /// <summary>
        /// 获取新的ID
        /// </summary>
        public static int NewID()
        {
            SQLiteParameter[] parameters = null;
            StringBuilder sql = new StringBuilder();
            sql.Append("select Max(Cid) from ArticleCategories ");
            object obj = SQLiteDBHelper.ExecuteScalar(sql.ToString(), parameters);
            return (obj == DBNull.Value ? 1 : (Convert.ToInt32(obj) + 1));
        }
        /// <summary>
        /// 查找
        /// </summary>
        public static List<Model.CategroryInfo> Select(Model.CategroryInfo model)
        {
            List<Model.CategroryInfo> list = new List<Model.CategroryInfo>();
            SQLiteParameter[] parameters = null;
            StringBuilder sql = new StringBuilder();
            sql.Append("select Cid,Cname,Pid,IndexTitle,isLeaf from ArticleCategories where 1=1 ");
            sql.Append(GetSql(false, model, ref parameters));
            sql.Append(" order by IndexTitle");
            using (SQLiteDataReader dr = SQLiteDBHelper.ExecuteReader(sql.ToString(), parameters))
            {
                while (dr.Read())
                {
                    list.Add(GetModelByDr(dr));
                }
                dr.Close();
            }
            return list;
        }

    

        private static Model.CategroryInfo GetModelByDr(SQLiteDataReader dr)
        {
            Model.CategroryInfo model = new Model.CategroryInfo();
            try
            {
                if (dr["Cid"].ToString() != "")
                    model.Id =Convert.ToInt32(dr["Cid"]);
                model.Name = dr["Cname"].ToString();
                model.IndexName = dr["IndexTitle"].ToString();
                if (dr["Pid"].ToString() != "")
                    model.ParentId = Convert.ToInt32(dr["Pid"]);
                if (dr["isLeaf"].ToString() != "")
                    model.IsLeaf = Convert.ToBoolean(dr["isLeaf"]);
            }
            catch { model = null; }
            return model;
        }
        /// <summary>
        /// 获取局部SQL
        /// </summary>
        /// <param name="isModify">是否为修改SQL语句的SQL</param>
        /// <param name="model">实体</param>
        /// <param name="sqlParameters"></param>
        /// <returns></returns>
        private static string GetSql(bool isModify, Model.CategroryInfo model, ref SQLiteParameter[] sqlParameters)
        {
            if (model == null)
            {
                return null;
            }
            StringBuilder sql = new StringBuilder();
            List<SQLiteParameter> list = new List<SQLiteParameter>();
            SQLiteParameter sqlParameter;
            if (model.Id != Int32.MinValue)
            {
                sqlParameter = new SQLiteParameter("@CID", SqlDbType.Int);
                sqlParameter.Value = model.Id;
                list.Add(sqlParameter);
                if (!isModify)
                {
                    sql.Append("and CID=@CID ");
                }
            }
            if (model.Name != null)
            {
                sqlParameter = new SQLiteParameter("@Cname", DbType.String, 128);
                sqlParameter.Value = model.Name;
                if (isModify)
                {
                    sql.Append("Cname=@Cname,");
                }
                else
                {
                    sql.Append(" and Cname=@Cname");
                }
                list.Add(sqlParameter);
            }
            if (model.ParentId !=Int32.MinValue)
            {
                sqlParameter = new SQLiteParameter("@Pid", DbType.Int32);
                sqlParameter.Value = model.ParentId;
                if (isModify)
                {
                    sql.Append("Pid=@Pid,");
                }
                else
                {
                    sql.Append(" and Pid=@Pid");
                }
                list.Add(sqlParameter);
            }
            if (model.IndexName != null)
            {
                sqlParameter = new SQLiteParameter("@IndexTitle", DbType.String);
                sqlParameter.Value = model.IndexName;
                if (isModify)
                {
                    sql.Append("IndexTitle=@IndexTitle,");
                }
                else
                {
                    sql.Append(" and IndexTitle=@IndexTitle");
                }
                list.Add(sqlParameter);
            }

                sqlParameter = new SQLiteParameter("@isLeaf", DbType.Boolean);
                sqlParameter.Value = model.IsLeaf;
                if (isModify)
                {
                    sql.Append("isLeaf=@isLeaf,");
                }
                else
                {
                    sql.Append(" and isLeaf=@isLeaf");
                }
                list.Add(sqlParameter);
            sqlParameters = list.ToArray();
            if (isModify)
            {
                return sql.ToString().Trim().TrimEnd(',') + " ";
            }
            return sql.ToString();
        }
    }
}
