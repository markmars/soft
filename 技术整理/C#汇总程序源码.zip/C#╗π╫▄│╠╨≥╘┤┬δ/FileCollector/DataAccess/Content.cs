﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SQLite;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com
 
 */
  //下载源码到51aspx
namespace FileCollector.DataAccess
{
   public   class Content
    {
         /// <summary>
        /// 添加
        /// </summary>
        public static bool Add(Model.ContentInfo model)
        {
            string sql = "insert into ArticleContent(Aid,Content,keyword,CreateDate,title,categoryid)values(@Aid,@Content,@keyword,@CreateDate,@title,@categoryid)";
            SQLiteParameter[] parameters = new SQLiteParameter[]
            {
                new SQLiteParameter("@Aid", DbType.Int32),
                new SQLiteParameter("@Content", DbType.String),
                new SQLiteParameter("@keyword", DbType.String),
                new SQLiteParameter("@CreateDate", DbType.String),
                new SQLiteParameter("@title", DbType.String),
                new SQLiteParameter("@categoryid", DbType.Int32)  
            };
            parameters[0].Value = model.Id;
            parameters[1].Value = model.Content;
            parameters[2].Value = model.Keyword;
            parameters[3].Value = model.CreateDate;
            parameters[4].Value = model.Title;
            parameters[5].Value = model.Categoryid;
           return SQLiteDBHelper.ExecuteNonQuery(sql, parameters) > 0;
        }



        /// <summary>
        /// 修改
        /// </summary>
        public static bool Modify(Model.ContentInfo model)
        {
            SQLiteParameter[] parameters = null;
            StringBuilder sql = new StringBuilder();
            sql.Append("update ArticleContent set ");
            sql.Append(GetSql(true, model, ref parameters));
            sql.Append(" where Aid=@Aid");
            return SQLiteDBHelper.ExecuteNonQuery(sql.ToString(), parameters) > 0;
        }

        /// <summary>
        /// 根据主键删除数据
        /// </summary>
        public static bool Delete(int id)
        {
            string sql = "delete from ArticleContent where Aid=@Aid";

            SQLiteParameter[] parameters = new SQLiteParameter[]
            {
                new SQLiteParameter("@Aid", SqlDbType.Int)            
            };
            parameters[0].Value = id;
            return SQLiteDBHelper.ExecuteNonQuery( sql, parameters) > 0;
        }




        /// <summary>
        /// 是否存在
        /// </summary>
        public static bool IsExists(Model.ContentInfo model)
        {
            SQLiteParameter[] parameters = null;
            StringBuilder sql = new StringBuilder();
            sql.Append("select count(Aid) from ArticleContent where 1=1 ");
            sql.Append(GetSql(false, model, ref parameters));
            object obj=SQLiteDBHelper.ExecuteScalar(sql.ToString(), parameters);
            return (obj==null? false:(Convert.ToInt32(obj)==1));
        }

        /// <summary>
        /// 获取新的ID
        /// </summary>
        public static int NewID()
        {
            SQLiteParameter[] parameters = null;
            StringBuilder sql = new StringBuilder();
            sql.Append("select Max(Aid) from ArticleContent ");
            object obj = SQLiteDBHelper.ExecuteScalar(sql.ToString(), parameters);
            return (obj == null||obj==DBNull.Value) ? 1 : (Convert.ToInt32(obj)+1);
        }

        /// <summary>
        /// 查找
        /// </summary>
        public static List<Model.ContentInfo> Select(Model.ContentInfo model)
        {
            List<Model.ContentInfo> list = new List<Model.ContentInfo>();
            SQLiteParameter[] parameters = null;
            StringBuilder sql = new StringBuilder();
            sql.Append("select Aid,Content,keyword,CreateDate,title,categoryid from ArticleContent where 1=1 ");
            string strWhere = GetSql(false, model, ref parameters);
            if (model != null && model.OtherInfo != null)
            {
                if (!string.IsNullOrEmpty(model.OtherInfo.Get("searchkey")))
                strWhere += string.Format(" and keyword like '%{0}%'", model.OtherInfo.Get("searchkey"));

            }
            sql.Append(strWhere);
            using (SQLiteDataReader dr = SQLiteDBHelper.ExecuteReader(sql.ToString(), parameters))
            {
                while (dr.Read())
                {
                    Model.ContentInfo C = GetModelByDr(dr);
                    if(C!=null)
                    list.Add(C);
                }
                dr.Close();
            }
            return list;
        }

        private static Model.ContentInfo GetModelByDr(SQLiteDataReader dr)
        {
            Model.ContentInfo model = new Model.ContentInfo();
            try
            {
                if (dr["Aid"].ToString() != "")
                    model.Id =Convert.ToInt32(dr["Aid"]);
                model.Title = dr["title"].ToString();
                model.Content = dr["Content"].ToString();
                if (dr["keyword"].ToString() != "")
                    model.Keyword = dr["keyword"].ToString();

              //  Console.WriteLine(dr["CreateDate"].ToString());
                //DateTime t = DateTime.Now;
                //DateTime.TryParse(dr["CreateDate"].ToString(), out t);
                //model.CreateDate = t;
                if (dr["categoryid"] != null)
                    model.Categoryid = Convert.ToInt32(dr["categoryid"]);
            }
            catch { model = null; }
            return model;
        }
        /// <summary>
        /// 获取局部SQL
        /// </summary>
        /// <param name="isModify">是否为修改SQL语句的SQL</param>
        /// <param name="model">实体</param>
        /// <param name="sqlParameters"></param>
        /// <returns></returns>
        private static string GetSql(bool isModify, Model.ContentInfo model, ref SQLiteParameter[] sqlParameters)
        {
            if (model == null)
            {
                return null;
            }
            StringBuilder sql = new StringBuilder();
            List<SQLiteParameter> list = new List<SQLiteParameter>();
            SQLiteParameter sqlParameter;
            if (model.Id != Int32.MinValue)
            {
                sqlParameter = new SQLiteParameter("@Aid", SqlDbType.Int);
                sqlParameter.Value = model.Id;
                list.Add(sqlParameter);
                if (!isModify)
                {
                    sql.Append("and Aid=@Aid ");
                }
            }
            if (model.Title != null)
            {
                sqlParameter = new SQLiteParameter("@title", DbType.String, 128);
                sqlParameter.Value = model.Title;
                if (isModify)
                {
                    sql.Append("title=@title,");
                }
                else
                {
                    sql.Append(" and title=@title");
                }
                list.Add(sqlParameter);
            }
            if (model.Keyword != null)
            {
                sqlParameter = new SQLiteParameter("@keyword", DbType.String, 512);
                sqlParameter.Value = model.Keyword;
                if (isModify)
                {
                    sql.Append("keyword=@keyword,");
                }
                else
                {
                    sql.Append(" and keyword=@keyword");
                }
                list.Add(sqlParameter);
            }
            if (model.Content !=null)
            {
                sqlParameter = new SQLiteParameter("@Content", DbType.String);
                sqlParameter.Value = model.Content;
                if (isModify)
                {
                    sql.Append("Content=@Content,");
                }
                else
                {
                    sql.Append(" and Content=@Content");
                }
                list.Add(sqlParameter);
            }
            if (model.CreateDate != DateTime.MinValue)
            {
                sqlParameter = new SQLiteParameter("@CreateDate", DbType.DateTime);
                sqlParameter.Value = model.CreateDate;
                if (isModify)
                {
                    sql.Append("CreateDate=@CreateDate,");
                }
                else
                {
                    sql.Append(" and CreateDate=@CreateDate");
                }
                list.Add(sqlParameter);
            }
            if (model.Categoryid != int.MinValue)
            {
                sqlParameter = new SQLiteParameter("@categoryid", DbType.Int32);
                sqlParameter.Value = model.Categoryid;
                if (isModify)
                {
                    sql.Append("categoryid=@categoryid,");
                }
                else
                {
                    sql.Append(" and categoryid=@categoryid");
                }
                list.Add(sqlParameter);
            }
            
            sqlParameters = list.ToArray();
            if (isModify)
            {
                return sql.ToString().Trim().TrimEnd(',') + " ";
            }
            return sql.ToString();
        }
    }
}
