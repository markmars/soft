﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
 //下载源码到51aspx
namespace FileCollector
{
    public partial class HomeShow : WeifenLuo.WinFormsUI.Docking.DockContent
    {
        public HomeShow()
        {
            InitializeComponent();
        }

        private void HomeShow_FormClosing(object sender, FormClosingEventArgs e)
        {
            //e.Cancel = true;
        }
  
    }
}
