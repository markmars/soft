﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com
 
 */
namespace FileCollector.Model
{
   public class ContentInfo
    {
        private int _id=int.MinValue;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _keyword;

        public string Keyword
        {
            get { return _keyword; }
            set { _keyword = value; }
        }
        private string _title;

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
        private string _content;

        public string Content
        {
            get { return _content; }
            set { _content = value; }
        }
        private DateTime _CreateDate=DateTime.MinValue;

        public DateTime CreateDate
        {
            get { return _CreateDate; }
            set { _CreateDate = value; }
        }
        private int _categoryid=int.MinValue;

        public int Categoryid
        {
            get { return _categoryid; }
            set { _categoryid = value; }
        }
        private NameValueCollection _otherInfo=null;

        public NameValueCollection OtherInfo
        {
            get { return _otherInfo; }
            set { _otherInfo = value; }
        }

    }
}
