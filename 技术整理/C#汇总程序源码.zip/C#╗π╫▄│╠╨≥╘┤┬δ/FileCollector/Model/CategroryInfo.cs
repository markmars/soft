﻿using System;
using System.Collections.Generic;
using System.Text;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com
 
 */
namespace FileCollector.Model
{
   public class CategroryInfo
    {

        private int _id=int.MinValue;
        private int _parentId=int.MinValue;
        private string _name;
        private string _indexName;
        private bool _IsLeaf;

      

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }


        public int ParentId
        {
            get { return _parentId; }
            set { _parentId = value; }
        }


        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }


        public string IndexName
        {
            get { return _indexName; }
            set { _indexName = value; }
        }
        public bool IsLeaf
        {
            get { return _IsLeaf; }
            set { _IsLeaf = value; }
        }






    }
}
