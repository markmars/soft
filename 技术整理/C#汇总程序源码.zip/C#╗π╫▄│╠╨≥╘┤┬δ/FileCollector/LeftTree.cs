﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com
 
 */
  //下载源码到51aspx
namespace FileCollector
{
    public partial class LeftTree : WeifenLuo.WinFormsUI.Docking.DockContent
    {
        public LeftTree()
        {
            InitializeComponent();
        }
        private delegate void OperateTree();
        public delegate void ReturnTreeNode(Model.CategroryInfo model, TreeNode node);
        public delegate void DeleteTreeNode(List<int> list);
        public delegate void ReturnTreeId(int id);
        public event ReturnTreeNode ReturnEvent;
        public event ReturnTreeId IDEvent;
        public event DeleteTreeNode DelTreeNode;
        public delegate void Search(string key, int pageIndex);
        public event Search SearchEvent;
        private TreeNode stateTreeNode;
        void LeftTree_Load(object sender, System.EventArgs e)
        {
            LoadTree();
        }
        public void LoadTree()
        {
            Thread th = new Thread(new ThreadStart(delegate()
            {
                this.BeginInvoke(new OperateTree(delegate()
                {
                    //  if (treeView_index.InvokeRequired)
                    //  {
                    treeView_index.BeginUpdate();
                    treeView_index.Nodes.Clear();
                    //  }
                }));


                TreeNode RootNode = new TreeNode();
                RootNode.Text = "文件夹";
                RootNode.Name = "RootName";
                RootNode.Tag = null;
                TreeNode CurrentNode = RootNode;
                List<Model.CategroryInfo> list = DataAccess.Categrory.Select(null);
                if (list != null && list.Count > 0)
                {
                    foreach (Model.CategroryInfo m in list)
                    {
                        string[] strArray = m.IndexName.Split('/');
                        TreeNode nd = new TreeNode();
                        nd.Text = m.Name;
                        nd.Name = m.IndexName;
                        nd.Tag = m;
                        if (m.IsLeaf)
                            nd.ImageIndex = 3;
                        else
                            nd.ImageIndex = 2;
                        if (CurrentNode.Level >= strArray.Length)
                        {
                            int temp = CurrentNode.Level;
                            for (int i = 0; i <= temp - strArray.Length; i++)
                            {
                                CurrentNode = CurrentNode.Parent;
                            }
                        }
                        CurrentNode.Nodes.Add(nd);
                        CurrentNode = nd;
                    }
                }
                this.BeginInvoke(new OperateTree(delegate()
                {
                    //    if (treeView_index.InvokeRequired)
                    //   {
                    treeView_index.Nodes.Add(RootNode);
                    treeView_index.EndUpdate();
                    if (stateTreeNode != null)
                    {
                        GetNode(treeView_index.Nodes);
                    }
                    else
                        treeView_index.ExpandAll();

                }));

            }));
            th.Start();




        }

        public void GetNode(TreeNodeCollection tc)
        {
            foreach (TreeNode TNode in tc)
            {
                if (TNode.Text.Equals(stateTreeNode.Text))
                {
                    TNode.ExpandAll();
                    TreeNode nd = TNode;
                    while (nd.Level > 0)
                    {
                        nd = nd.Parent;
                        nd.Expand();
                    }
                    break;
                }
                GetNode(TNode.Nodes);
            }
        }
        private void AddNode(Model.CategroryInfo model, TreeNode nd)
        {
            if (ReturnEvent != null)
            {
                ReturnEvent(model, nd);
                stateTreeNode = treeView_index.SelectedNode;
            }
        }
        private void DoubleClickNode(int ID)
        {
            if (IDEvent != null)
            {
                IDEvent(ID);
                stateTreeNode = treeView_index.SelectedNode;
            }
        }
        private void DeleteNode(List<int> list)
        {
            if (DelTreeNode != null)
                DelTreeNode(list);
        }

        public void GetNode(TreeNodeCollection tc,ref List<int> list)
        {
            foreach (TreeNode TNode in tc)
            {
                Model.CategroryInfo model = (Model.CategroryInfo)TNode.Tag;
                list.Add(model.Id);
                GetNode(TNode.Nodes, ref list);
            }
        }
        private void SearchKey(string key, int pageIndex)
        {
            if (SearchEvent != null)
                SearchEvent(key, pageIndex);
        }
        private void treeView_index_MouseDown(object sender, MouseEventArgs e)
        {
            treeView_index.ContextMenuStrip = null;
            if (e.Button == MouseButtons.Right)
            {
                TreeNode node = treeView_index.GetNodeAt(e.X, e.Y);
                if (node != null)//右键未选中节点，不改变当前选中的节点
                {
                    this.treeView_index.SelectedNode = node;
                    treeView_index.ContextMenuStrip = contextMenuStrip1;

                    stateTreeNode = treeView_index.SelectedNode;
                }
            }

        }
        private void treeView_index_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            TreeNode node = treeView_index.GetNodeAt(e.X, e.Y);
            if (node != null)//右键未选中节点，不改变当前选中的节点
            {
                this.treeView_index.SelectedNode = node;
                if (node.Tag != null)
                {
                    Model.CategroryInfo model = (Model.CategroryInfo)node.Tag;
                    if (model.IsLeaf)
                        DoubleClickNode(model.Id);
                }
                stateTreeNode = treeView_index.SelectedNode;

            }
        }


        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (treeView_index.SelectedNode == null) return;
            TreeNode tree = treeView_index.SelectedNode;
            switch (e.ClickedItem.Name)
            {
                case "tsmAdd_bro":
                    if (tree.Parent != null)
                    {
                        AddNode(null, tree.Parent);
                    }
                    break;
                case "tsmDel_bro":
                    if (tree.Tag != null)
                    {
                        List<int> idList = new List<int>();
                        GetNode(tree.Nodes,ref idList);
                        idList.Add(((Model.CategroryInfo)tree.Tag).Id);
                        DeleteNode(idList);
                        stateTreeNode = tree.Parent;
                    }
                    break;
                case "tsmAdd_chi":
                    if (tree.Tag != null)
                    {
                        Model.CategroryInfo info = (Model.CategroryInfo)tree.Tag;
                        if (info.IsLeaf) { MessageBox.Show("叶子节点不能添加子节点！"); return; }
                    }
                    AddNode(null, tree);
                    break;
                case "tsmUpt":
                    if (tree.Tag != null)
                        AddNode((Model.CategroryInfo)tree.Tag, tree.Parent);
                    break;
                case "tsmRes": //刷新
                    this.LoadTree();
                    break;
            }
        }

        private void tabPageIndex_Click(object sender, EventArgs e)
        {

        }

        private void tIndex_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SearchKey(((TextBox)sender).Text, tabControl1.SelectedIndex);

            }
        }
        public void LoadSearch(string key, int page)
        {
            FileCollector.Model.ContentInfo cinfo = new FileCollector.Model.ContentInfo();
            cinfo.OtherInfo = new System.Collections.Specialized.NameValueCollection();

            if (!string.IsNullOrEmpty(key))
                cinfo.OtherInfo.Add("searchkey", key);
            List<FileCollector.Model.ContentInfo> contents = FileCollector.DataAccess.Content.Select(cinfo);
            //  contentInfoBindingSource.DataSource = null;
            if (contents != null && contents.Count > 0)
            {
                if (1 == page)
                {
                    lstb_index.DataSource = contents;
                    lstb_Search.DataSource = bindingSource1;
                }
                else
                {
                    lstb_Search.DataSource = contents;
                    lstb_index.DataSource = bindingSource1;
                }

            }
            else
                MessageBox.Show("对不起，没有相关信息！");

        }

        private void lstb_Search_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstb_Search.SelectedItem != null)
                DoubleClickNode(((FileCollector.Model.ContentInfo)lstb_Search.SelectedItem).Categoryid);
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 1)
            {
                Thread th = new Thread(new ThreadStart(delegate()
                {
                    List<FileCollector.Model.ContentInfo> contents = FileCollector.DataAccess.Content.Select(null);
                    if (contents != null && contents.Count > 0)
                    {
                        this.BeginInvoke(new OperateTree(delegate()
                        {
                            lstb_index.DataSource = contents;
                            lstb_Search.DataSource = bindingSource1;

                        }));

                    }
                }));
                th.Start();
                //    SearchKey("", 1); 
            }




        }

        private void lstb_index_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstb_index.SelectedItem != null)
                DoubleClickNode(((FileCollector.Model.ContentInfo)lstb_index.SelectedItem).Categoryid);
        }
    }


}
