﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Fer.MyFileTools
{
    class Class1
    {
        public static string ListTreeShow(DirectoryInfo theDir, int nLevel, string Rn)//递归目录 文件 
        { 
          DirectoryInfo[] subDirectories = theDir.GetDirectories();//获得目录 
          foreach (DirectoryInfo dirinfo in subDirectories) 
          { 
             if (nLevel == 0) 
              { 
                 Rn += "├"; 
              } 
              else 
             { 
                 string _s = ""; 
                 for (int i = 1; i <= nLevel; i++) 
                 { 
                    _s += "│ "; 
                 } 
                 Rn += _s + "├"; 
              } 
          Rn += "<b>" + dirinfo.Name.ToString() + "</b><br />"; 
          FileInfo[] fileInfo = dirinfo.GetFiles(); //目录下的文件 
        foreach (FileInfo fInfo in fileInfo) 
        { 
        if (nLevel == 0) 
        { 
          Rn += "│ ├"; 
        } 
        else 
        { 
          string _f = ""; 
        for (int i = 1; i <= nLevel; i++) 
        { 
        _f += "│ "; 
        } 
        Rn += _f + "│ ├"; 
        } 
        Rn += fInfo.Name.ToString() + " <br />"; 
        } 
        Rn = ListTreeShow(dirinfo, nLevel + 1, Rn); 

        } 
        return Rn; 
    }

        public static string GetFoldAll(string Path) 
        { 
            string str = ""; 
            DirectoryInfo thisOne = new DirectoryInfo(Path); 
            str = ListTreeShow(thisOne, 0, str); 
            return str; 
        } 

        public static string GetFoldAll(string Path, string DropName, string tplPath)
        {
            string strDrop = "<select name=\"" + DropName + "\" id=\"" + DropName + "\"><option value=\"\">--请选择详细模板--</option>";
            string str = "";
            DirectoryInfo thisOne = new DirectoryInfo(Path);
            str = ListTreeShow(thisOne, 0, str, tplPath);
            return strDrop + str + "</select>";
        } 
        public static string ListTreeShow(DirectoryInfo theDir, int nLevel, string Rn,string tplPath)//递归目录 文件 
{ 
DirectoryInfo[] subDirectories = theDir.GetDirectories();//获得目录 
foreach (DirectoryInfo dirinfo in subDirectories) 
{ 
Rn += "<option value=\"" + dirinfo.Name.ToString() + "\""; 
if (tplPath.ToLower() == dirinfo.Name.ToString().ToLower()) 
{ 
Rn += " selected "; 
} 
Rn += ">"; 
if (nLevel == 0) 
{ 
Rn += "┣"; 
} 
else 
{ 
string _s = ""; 
for (int i = 1; i <= nLevel; i++) 
{ 
_s += "│ "; 
} 
Rn += _s + "┣"; 
} 
Rn += "" + dirinfo.Name.ToString() + "</option>"; 

FileInfo[] fileInfo = dirinfo.GetFiles(); //目录下的文件 
foreach (FileInfo fInfo in fileInfo) 
{ 
Rn += "<option value=\"" + dirinfo.Name.ToString()+"/"+fInfo.Name.ToString() + "\""; 
if (tplPath.ToLower() == fInfo.Name.ToString().ToLower()) 
{ 
Rn += " selected "; 
} 
Rn += ">"; 
if (nLevel == 0) 
{ 
Rn += "│ ├"; 
} 
else 
{ 
string _f = ""; 
for (int i = 1; i <= nLevel; i++) 
{ 
_f += "│ "; 
} 
Rn += _f + "│ ├"; 
} 
Rn += fInfo.Name.ToString() + "</option>"; 
} 
Rn = ListTreeShow(dirinfo, nLevel + 1, Rn, tplPath); 

} 
return Rn; 
}


//private void PaintTreeView(string root)
//{
//    try
//    {
//        DirectoryInfo info = new DirectoryInfo(root);
//        foreach (DirectoryInfo info2 in info.GetDirectories())
//        {
//            this.FolderArray.Add(new Folder(info2.Name, info2.FullName));
//        }
//        foreach (Folder folder in this.FolderArray)
//        {
//            DirectoryInfo info3 = new DirectoryInfo(folder.PathName);
//            FileInfo[] files = info3.GetFiles();
//            DirectoryInfo[] directories = info3.GetDirectories();
//            foreach (FileInfo info4 in files)
//            {
//                 folder.FolderFiles.Add(new FileInfo(info4.Name));
//            }
//        }
//        Cursor.Current = Cursors.WaitCursor;
//        this.treeView1.BeginUpdate();
//        this.treeView1.Nodes.Clear();
//        foreach (Folder folder2 in this.FolderArray)
//        {
//            this.treeView1.Nodes.Add(new TreeNode(folder2.FolderName));
//            foreach (FileInfo file in folder2.FolderFiles)
//            {
//                this.treeView1.Nodes.Add(new TreeNode(file.FullName));
//            }
//        }
//        Cursor.Current=Cursors.Default;
//        this.treeView1.EndUpdate();
//    }
//    catch (Exception exception)
//    {
//        MessageBox.Show("Error:" + exception.Message);
//    }
//}

 }
}
