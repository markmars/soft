﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace Fer.MyFileTools
{
    public class Folder
{
    // Fields
    public ArrayList FolderFiles;
    private string folderName;
    private string pathName;

    // Methods
    public Folder()
    {
    }

    public Folder(string iFolderName, string iPathName)
    {
        this.folderName = iFolderName;
        this.pathName = iPathName;
        this.FolderFiles = new ArrayList();
    }

    // Properties
    public string FolderName
    {
        get
        {
            return this.folderName;
        }
        set
        {
            this.folderName = value;
        }
    }

    public string PathName
    {
        get
        {
            return this.pathName;
        }
        set
        {
            this.pathName = value;
        }
    }

    //public void  ReadText(string fileName)
    //{
    //    this.richTextBox1.Clear();
    //    if (fileName == null && fileName.Length < 1)
    //    {
    //        throw new Exception("文件名不能为空！");
    //    }
    //    string fstype = fileName.Substring(fileName.LastIndexOf('.')+1);
    //    Encoding ed = System.Text.Encoding.Default;
    //    if (fstype.ToLower() == "doc")
    //    {
    //        ed = System.Text.Encoding.Unicode;
    //    }
    //    try
    //    {
    //        StreamReader inStr = new StreamReader(fileName, ed);
    //        string textLine = inStr.ReadLine();
    //        while (textLine != null)
    //        {
    //            textLine = inStr.ReadLine();
    //            this.richTextBox1.Text += textLine + "\r\n";
    //        }
    //        inStr.Close();
    //    }
    //    catch (IOException ex)
    //    {
    //        System.Console.WriteLine(ex.ToString());
    //    }

    //}

        public void WriteText(string fileName, string Text)
        {
            if (fileName == null && fileName.Length < 1)
            {
                throw new Exception("文件名不能为空！");
            }
            StreamWriter sw = null;
            try
            {
                if (File.Exists(fileName))
                {
                    sw = File.AppendText(fileName);
                }
                else
                {
                    sw = File.CreateText(fileName);
                }
                sw.Write(Text);
                sw.Close();
            }
            catch (IOException ex)
            {
                System.Console.WriteLine(ex.ToString());
            }


        }
}

 
 

}
