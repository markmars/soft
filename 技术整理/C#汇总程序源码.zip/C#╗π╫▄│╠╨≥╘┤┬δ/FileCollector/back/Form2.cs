﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
namespace Fer.MyFileTools
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private System.Xml.XmlDocument doc;
        private System.Xml.XmlDocument mXmlDoc; 
        private void button1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "xml 文件|*.xml";//设置打开对话框的文件过滤条件                   
            saveFileDialog1.Title = "保存成 xml 文件";//设置打开对话框的标题                    
            saveFileDialog1.FileName = "";                   
            saveFileDialog1.ShowDialog();//打开对话框                   
            if (saveFileDialog1.FileName != "")//检测用户是否输入了保存文件名                  
            {
                mXmlDoc.Save(saveFileDialog1.FileName);//用私有对象mXmlDoc保存文件,mXmlDoc在前面声明过                      
                MessageBox.Show("保存成功");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //从私有对象dox里选取me节点,这里的一些对xml对象的操作详细说明可以参考msdn以获取更多信息                    
            XmlNode node = doc.DocumentElement.SelectSingleNode("me");
            XmlElement ele = (XmlElement)node;//获取一个xml元素                    
            string pic = ele.GetAttribute("aa");//获取ele元素的aa属性并报讯在一个临时字符串变量pic                   
            byte[] bytes = Convert.FromBase64String(pic);//声明一个byte[]用来存放Base64解码转换过来的数据流                    
            //从保存对话框里获取文件保存地址                    
            saveFileDialog1.Filter = "Office Documents(*.doc, *.xls, *.ppt)|*.doc;*.xls;*.ppt";
            saveFileDialog1.Title = "保存成 office 文件";
            saveFileDialog1.FileName = "";
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName != "")
            {                        //创建文件流并保存               
                FileStream outfile = new System.IO.FileStream(saveFileDialog1.FileName, System.IO.FileMode.CreateNew);
                outfile.Write(bytes, 0, (int)bytes.Length);
                MessageBox.Show("保存成功");
            }   
        }

        private void button3_Click(object sender, EventArgs e)
        {
             string strFileName;                  
            openFileDialog1.Filter = "Office Documents(*.doc, *.xls, *.ppt,*.mht)|*.doc;*.xls;*.ppt;*.mht";                   
            openFileDialog1.FilterIndex = 1;                   
            openFileDialog1.FileName = "";                   
            openFileDialog1.ShowDialog();                  
            strFileName = openFileDialog1.FileName;
            if (strFileName.Length != 0)
            {
                System.IO.FileStream inFile = new FileStream(strFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                byte[] binaryData = new byte[inFile.Length];
                inFile.Read(binaryData, 0, (int)inFile.Length);
                string mStr = Convert.ToBase64String(binaryData);
                string hh = mStr;
                mXmlDoc = new System.Xml.XmlDocument();
                mStr = string.Format("<wawa><me aa=\"{0}\"/></wawa>", mStr);
                mXmlDoc.LoadXml(mStr);
                MessageBox.Show("加载成功");
            }
        }
    }
}
