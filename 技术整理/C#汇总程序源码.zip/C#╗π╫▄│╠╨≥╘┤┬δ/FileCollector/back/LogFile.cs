
using System;
using System.IO;
using System.Text;
namespace ClearDLL
{
    public class LogFile
    {
        protected static string PathName = @"E:\CleanDll.log"; // �ļ�·��
        protected static int LogMaxContent = 2048*10; // �ļ���С
        public static void LogWrite(string InputContent)
        {
            if (!File.Exists(PathName))
            {
                File.Create(PathName);
            }
            FileInfo Finfo = new FileInfo(PathName);
        
            //if (Finfo.Exists && Finfo.Length > LogMaxContent) // ���������������
            //{
            //    Finfo.CopyTo(PathNameMove);
            //    Finfo.Delete();
            //}

            try
            {
                using (FileStream Fs = Finfo.OpenWrite())
                {
                    StreamWriter Sw = new StreamWriter(Fs);

                    Sw.BaseStream.Seek(0, SeekOrigin.End); //����д����������ʼλ��Ϊ�ļ�����ĩβ

                    StringBuilder StrInput = new StringBuilder(); // ��¼д�������
                    StrInput.Append(InputContent + "\r\n");
                    Sw.Write(StrInput);
                    Sw.Flush();
                    Sw.Close();
                }
            }
            catch (Exception ex)
            {
                System.Console.WriteLine("��־����ʧ��");
            }

        }
       

    }
}
