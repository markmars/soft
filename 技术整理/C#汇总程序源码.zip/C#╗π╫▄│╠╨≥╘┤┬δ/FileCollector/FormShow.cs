﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com
 
 */
  //下载源码到51aspx
namespace FileCollector
{
    public partial class FormShow : WeifenLuo.WinFormsUI.Docking.DockContent
    {
        public FormShow()
        {
            InitializeComponent();
        }
        private int? _id=null;
        private Model.ContentInfo _model = null;
        public FormShow(int? id):this()
        {
            _id = id;
            if (_id !=null)
                show();
        }    
        void show()
        {
            _model = new FileCollector.Model.ContentInfo();
            _model.Categoryid = (int)_id;
            List<Model.ContentInfo> list = DataAccess.Content.Select(_model);
            if (list == null || list.Count == 0)
                throw new Exception("读取数据出错！");
            _model = list[0];
            txtTitle.Text = _model.Title;
            txtKey.Text = _model.Keyword;
            editor_content.DocumentText =ImageDone.GetLocalImagesText(_model.Content);
            this.Text = _model.Title;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string url = "http://www.51aspx.com";
            Nagative(url);
        }
        
        private static void Nagative(string URL)
        {
            Process p = new Process();
            p.StartInfo.FileName = "IEXPLORE.EXE";
            p.StartInfo.Arguments = URL;
            p.Start();

        }
    }
}
