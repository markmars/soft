﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com
 
 */
 //下载源码到51aspx
namespace FileCollector
{
    public partial class CategroryAdd : WeifenLuo.WinFormsUI.Docking.DockContent
    {
        private Model.CategroryInfo _model = null;
        private Model.ContentInfo _tmodel = null;
        private TreeNode _parentNode = null;
        private int _height = 0;
        private bool _IsAdd = true;
        public CategroryAdd(Model.CategroryInfo model,TreeNode parent)
            : this()
        {
            _model = model;
            _parentNode = parent;
            ShowCate();
        }
        public delegate void SendMessage(WeifenLuo.WinFormsUI.Docking.DockContent form, DialogResult result);
        public event SendMessage EventMessage;
        public CategroryAdd()
        {

            InitializeComponent();
            _height = this.Height;
            this.Height = this.Height - panel_content.Height;
            panel_content.Visible = false;
        }
        private void Send(WeifenLuo.WinFormsUI.Docking.DockContent form, DialogResult result)
        {
            if (EventMessage != null)
                EventMessage(form,result);
        }
        private void btn_cancel_Click(object sender, EventArgs e)
        {
            Send(this,DialogResult.Cancel);
        }
        private void CategroryAdd_Load(object sender, EventArgs e)
        {

        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            if (_IsAdd)
                Add();
            else
                Modifiy();

            Send(this,DialogResult.OK);
        }

        void ShowCate()
        {
            if (_model != null)
            {
                txtNode.Text = _model.Name;
                if (_model.IsLeaf)
                {
                    _tmodel = new FileCollector.Model.ContentInfo();
                    _tmodel.Categoryid = _model.Id;
                    List<Model.ContentInfo> tlist = DataAccess.Content.Select(_tmodel);
                    if (tlist == null || tlist.Count == 0)
                        throw new Exception("读取内容出错");
                    _tmodel = tlist[0];
                    editor_content.DocumentText = _tmodel.Content;
                    txtKey.Text = _tmodel.Keyword;
                    cb_leaf.Checked = true;
                    cb_leaf_CheckedChanged(cb_leaf, null);
                }
                _IsAdd = false;
                txtParent.Enabled = false;
            }
            if (_parentNode != null)
            {
                txtParent.Text = _parentNode.Text;
            }
            
            
            
        }
        void Add()
        {
            Model.CategroryInfo model = new FileCollector.Model.CategroryInfo();
            if (_parentNode.Tag == null)
            {
                model.IndexName = txtNode.Text;
                model.ParentId = -1;
            }
            else
            {
                Model.CategroryInfo ParentModel = (Model.CategroryInfo)_parentNode.Tag;
                model.IndexName = ParentModel.IndexName +"/"+ txtNode.Text;
                model.ParentId = ParentModel.Id;
            }
           
            model.Id = DataAccess.Categrory.NewID();
            model.Name = txtNode.Text;
            model.IsLeaf = cb_leaf.Checked;
            if (DataAccess.Categrory.Add(model))
            {
                if (model.IsLeaf)
                {
                    Model.ContentInfo tmodel = new FileCollector.Model.ContentInfo();
                    tmodel.Categoryid = model.Id;
                    tmodel.Title = txtNode.Text;
                    tmodel.Keyword = txtKey.Text;
                    tmodel.Content =ImageDone.GetDocumentTextAndImg(editor_content.DocumentText);
                    tmodel.Id = DataAccess.Content.NewID();
                    tmodel.CreateDate = DateTime.Now;
                    if (!DataAccess.Content.Add(tmodel))
                    {
                        MessageBox.Show("添加不成功！");
                        return;
                    }
                }
            }
            else
            {
                MessageBox.Show("添加不成功！");
                return;
            }


        }

        void Modifiy()
        {
            if (_parentNode.Tag == null)
            {
                _model.IndexName = txtNode.Text;
                _model.ParentId = -1;
            }
            else
            {
                Model.CategroryInfo ParentModel = (Model.CategroryInfo)_parentNode.Tag;
                _model.IndexName = ParentModel.IndexName +"/"+ txtNode.Text;
                _model.ParentId = ParentModel.Id;
            }
            _model.Name = txtNode.Text;
            _model.IsLeaf = cb_leaf.Checked;
            if (DataAccess.Categrory.Modify(_model))
            {
                if (_model.IsLeaf)
                {
                    _tmodel.Title = txtNode.Text;
                    _tmodel.Keyword = txtKey.Text;
                    _tmodel.Content =ImageDone.GetDocumentTextAndImg(editor_content.DocumentText);
                    if (!DataAccess.Content.Modify(_tmodel))
                    {
                        MessageBox.Show("修改不成功！");
                        return;
                    }
                }
            }
            else
            {
                MessageBox.Show("修改不成功！");
                return;
            }
        }

        private void cb_leaf_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_leaf.Checked)
            {
                panel_content.Visible = true;
                this.Height = _height + panel_content.Height;
            }
            else
            {
                panel_content.Visible = false;
                this.Height = _height - panel_content.Height;

            }
        }

       
    }
}
