﻿namespace FileCollector
{
    partial class CategroryAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CategroryAdd));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtNode = new System.Windows.Forms.TextBox();
            this.txtParent = new System.Windows.Forms.TextBox();
            this.cb_leaf = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel_content = new System.Windows.Forms.Panel();
            this.editor_content = new HtmlEditor.Editor();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel_content.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtNode);
            this.panel1.Controls.Add(this.txtParent);
            this.panel1.Controls.Add(this.cb_leaf);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(696, 106);
            this.panel1.TabIndex = 0;
            // 
            // txtNode
            // 
            this.txtNode.Location = new System.Drawing.Point(81, 41);
            this.txtNode.Name = "txtNode";
            this.txtNode.Size = new System.Drawing.Size(483, 21);
            this.txtNode.TabIndex = 4;
            // 
            // txtParent
            // 
            this.txtParent.Enabled = false;
            this.txtParent.Location = new System.Drawing.Point(81, 14);
            this.txtParent.Name = "txtParent";
            this.txtParent.Size = new System.Drawing.Size(255, 21);
            this.txtParent.TabIndex = 3;
            // 
            // cb_leaf
            // 
            this.cb_leaf.AutoSize = true;
            this.cb_leaf.Location = new System.Drawing.Point(25, 76);
            this.cb_leaf.Name = "cb_leaf";
            this.cb_leaf.Size = new System.Drawing.Size(48, 16);
            this.cb_leaf.TabIndex = 2;
            this.cb_leaf.Text = "叶子";
            this.cb_leaf.UseVisualStyleBackColor = true;
            this.cb_leaf.CheckedChanged += new System.EventHandler(this.cb_leaf_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "节点名称：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "父节点：";
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(262, 12);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 1;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(374, 12);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_cancel.TabIndex = 2;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_OK);
            this.panel2.Controls.Add(this.btn_cancel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 545);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(696, 44);
            this.panel2.TabIndex = 3;
            // 
            // panel_content
            // 
            this.panel_content.Controls.Add(this.editor_content);
            this.panel_content.Controls.Add(this.panel4);
            this.panel_content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_content.Location = new System.Drawing.Point(0, 106);
            this.panel_content.Name = "panel_content";
            this.panel_content.Size = new System.Drawing.Size(696, 439);
            this.panel_content.TabIndex = 4;
            // 
            // editor_content
            // 
            this.editor_content.BodyHtml = null;
            this.editor_content.BodyText = null;
            this.editor_content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.editor_content.DocumentText = resources.GetString("editor_content.DocumentText");
            this.editor_content.EditorBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.editor_content.EditorForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.editor_content.FontSize = HtmlEditor.FontSize.Three;
            this.editor_content.Location = new System.Drawing.Point(0, 43);
            this.editor_content.Name = "editor_content";
            this.editor_content.Size = new System.Drawing.Size(696, 396);
            this.editor_content.TabIndex = 8;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtKey);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(696, 43);
            this.panel4.TabIndex = 7;
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(62, 11);
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(625, 21);
            this.txtKey.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "关键字：";
            // 
            // CategroryAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 589);
            this.Controls.Add(this.panel_content);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "CategroryAdd";
            this.Text = "CategroryAdd";
            this.Load += new System.EventHandler(this.CategroryAdd_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel_content.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cb_leaf;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNode;
        private System.Windows.Forms.TextBox txtParent;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel_content;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private HtmlEditor.Editor editor_content;
    }
}