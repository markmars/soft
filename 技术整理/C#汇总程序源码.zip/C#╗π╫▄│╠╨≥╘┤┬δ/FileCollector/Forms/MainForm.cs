﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.IO;

namespace Fer.MyFileTools
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
           Init();





        }
        string _path;
        float _fontSize = 9;
        void Init()
        {
            _path =System.Configuration.ConfigurationManager.AppSettings["PATH"];
            Text = System.Configuration.ConfigurationManager.AppSettings["AppName"];
            _fontSize =Convert.ToSingle(System.Configuration.ConfigurationManager.AppSettings["FontSize"]);
            if (_path.Trim().Length < 1)
            {
                _path = Application.StartupPath;
            }
            PaintTreeView(_path);


            ir = this.splitContainer1.SplitterDistance;
            this.richTextBox1.Visible = false;
            this.tscText.SelectedIndex = 0;
            this.tsColor.Visible = false;
            this.tsFont.Visible = false;


        }
        private void GetDir(FileSystemInfo[] myFavDir, TreeNode RootNode)
        {
            if (myFavDir == null)
            {
                throw new ArgumentNullException("空目录，请核对所在目录！");
            }
            foreach (FileSystemInfo filesysteminfo in myFavDir)
            {
                TreeNode tn = new TreeNode();
                //文件目录
                if (filesysteminfo.GetType() == typeof(DirectoryInfo))
                {
                    tn.Text = filesysteminfo.Name;
                    tn.Tag = filesysteminfo.FullName;
                    RootNode.Nodes.Add(tn);
                    //强制转化为文件目录格式
                    DirectoryInfo childfile = (DirectoryInfo)filesysteminfo;
                    //递归调用
                    GetDir(childfile.GetFileSystemInfos(), tn);
                }
                //文件格式
                else if (filesysteminfo.GetType() == typeof(FileInfo))
                {
                        TreeNode tnchild = new TreeNode();
                        tnchild.Text = filesysteminfo.Name;
                        tnchild.Tag = filesysteminfo.FullName;
                        RootNode.Nodes.Add(tnchild);              
                }
            }
        }
                
        private void PaintTreeView(string root)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.treeView1.BeginUpdate();
            this.treeView1.Nodes.Clear();

            string RootText = root.Substring(root.LastIndexOf('\\')+1);
            TreeNode RootNode = new TreeNode();
            RootNode.Text = RootText;
            TreeNode CurrentNode = RootNode;

            DirectoryInfo favfolder = new DirectoryInfo(root);
            FileSystemInfo[] myFileSystemInfo = favfolder.GetFileSystemInfos();
            this.treeView1.Nodes.Add(RootNode);
            this.treeView1.ExpandAll();
            GetDir(myFileSystemInfo, RootNode);
            this.treeView1.EndUpdate();
            Cursor.Current = Cursors.Default;
           
        }

        private void treeView1_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                string path = e.Node.Tag.ToString();
                currentNode = e.Node;
                if (path.LastIndexOf('.') > 0)
                {
                    result = (tscText.SelectedIndex == 0);
                    this.richTextBox1.Visible = !result;
                    this.webBrowser1.Visible = result;
                    this.tsColor.Visible = this.tsFont.Visible = !result;
                    if (!result) ReadText(path); else webBrowser1.Navigate(new Uri(path));
                }

            }
           
        }
        private void tsQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tsiBig_Click(object sender, EventArgs e)
        {
            if (result) return;
            ToolStripMenuItem oj = (ToolStripMenuItem)sender;
            Dictionary<ToolStripMenuItem, float> batchs = new Dictionary<ToolStripMenuItem, float>();
            batchs.Add(tsiBig,_fontSize+6);
            batchs.Add(tsiMid, _fontSize+3);
            batchs.Add(tsiSma, _fontSize);
            foreach (KeyValuePair<ToolStripMenuItem, float> i in batchs)
            {
                if (oj == i.Key)
                {
                    oj.Checked = true;
                    this.richTextBox1.Font = new
                        System.Drawing.Font("宋体", i.Value, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                }
                else
                {
                    i.Key.Checked = false;
                }
                this.richTextBox1.Refresh();
            }
       
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
           

        }

        private void tsColor_Click(object sender, EventArgs e)
        {
            if (result) return;
            ColorDialog dlg = new ColorDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                this.richTextBox1.BackColor = dlg.Color;
            }
        }
        int ir;
        int count=0;
        TreeNode currentNode = null;
        bool result=true;
        private void tsHide_Click(object sender, EventArgs e)
        {
            if (count % 2 == 0)
            {
               this.splitContainer1.FixedPanel = FixedPanel.None;
                this.splitContainer1.SplitterDistance =0;
            }
            else
            {
                this.splitContainer1.FixedPanel = FixedPanel.Panel1;
                this.splitContainer1.SplitterDistance = ir;
            }
            count++;
            
        }
        private void tsOptin_Click(object sender, EventArgs e)
        {
            //FolderBrowserDialog dlg = new FolderBrowserDialog();
            //dlg.ShowDialog();
            //try
            //{
            //    ConfigurationManager.AppSettings.Set(ConfigurationManager.AppSettings["PATH"], dlg.SelectedPath);
            //}
            //catch (IOException ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem == tsColor)
                tsColor_Click(null,null);
            if (e.ClickedItem == tsHide)
                tsHide_Click(null,null);
            if(e.ClickedItem==tsOptin)
                tsOptin_Click(null,null);
           
        }

        public void ReadText(string fileName)
        {
            this.richTextBox1.Clear();
            if (fileName == null && fileName.Length < 1)
            {
                throw new Exception("文件名不能为空！");
            }
            string fstype = fileName.Substring(fileName.LastIndexOf('.') + 1);
            Encoding ed = System.Text.Encoding.Default;
            if (fstype.ToLower() == "doc")
            {
                ed = System.Text.Encoding.Unicode;
            }
            try
            {
                StreamReader inStr = new StreamReader(fileName, ed);
                string textLine;
                StringBuilder output = new StringBuilder();
                while ((textLine=inStr.ReadLine()) != null)
                {
                    output.Append(textLine + "\r\n");
                }
                this.richTextBox1.Text = output.ToString();
                inStr.Close();
            }
            catch (IOException ex)
            {
                System.Console.WriteLine(ex.ToString());
            }

        }

        private void tscText_SelectedIndexChanged(object sender, EventArgs e)
        {
            result = (tscText.SelectedIndex == 0);
            this.richTextBox1.Visible = !result;
            this.webBrowser1.Visible = result;
            this.tsColor.Visible = this.tsFont.Visible = !result;
            if (currentNode != null)
            {
                if (!result) ReadText(currentNode.Tag.ToString()); else webBrowser1.Navigate(new Uri(currentNode.Tag.ToString()));
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void treeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
           
            if (treeView1.SelectedNode != null && e.Button == MouseButtons.Right)
            {
                treeView1.ContextMenuStrip = this.contextMenuStrip1;
            }
            else
            {
                treeView1.ContextMenuStrip = null;
            }
        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem == csiDelete)
                csiDelete_Click(null,null);
            if (e.ClickedItem == csiUpdate)
                csiUpdate_Click(null,null);
            if (e.ClickedItem == csiReflash)
            {
                PaintTreeView(_path);
                treeView1.Refresh();
            }
            if (e.ClickedItem == tsm_Add)
                tsm_Add_Click(null,null);

        }

        private void csiDelete_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                try
                {
                //    TreeNode currentNode = treeView1.SelectedNode; ;
                // //   File.Delete(treeView1.SelectedNode.Tag.ToString());
                ////    File.
                //    PaintTreeView(_path);
                //    treeView1.Refresh();
                //    treeView1.SelectedNode = currentNode.NextNode;
                }
                catch { }
                treeView1.Refresh();

            }

        }
        private void csiUpdate_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                treeView1.LabelEdit = true;
                treeView1.SelectedNode.BeginEdit();
   
            }

        }

        private void tsm_Add_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                try
                {
                    string path = treeView1.SelectedNode.Tag.ToString();
                    if (path.LastIndexOf('.') > 0)
                    {
                        MessageBox.Show("1");
                    }
                    else
                    {
                      //  ParentForm form = new ParentForm(new add_File(treeView1.SelectedNode.Tag.ToString()));
                      //  form.ShowDialog();
                        
                    }
                }
                catch { }
                treeView1.Refresh();

            }

        }
        private void treeView1_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                try
                {
                    string path = treeView1.SelectedNode.Tag.ToString();
                    File.Copy(path, path.Replace(treeView1.SelectedNode.Text, e.Label), false);
                    File.Delete(treeView1.SelectedNode.Tag.ToString());
                }
                catch { }
                treeView1.SelectedNode.EndEdit(false);
                treeView1.LabelEdit = false;


            }
        }

  
    }
}