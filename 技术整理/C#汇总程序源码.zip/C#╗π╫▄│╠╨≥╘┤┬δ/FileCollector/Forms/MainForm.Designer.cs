﻿namespace Fer.MyFileTools
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsOptin = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsFont = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsiBig = new System.Windows.Forms.ToolStripMenuItem();
            this.tsiMid = new System.Windows.Forms.ToolStripMenuItem();
            this.tsiSma = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsColor = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsHide = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tscText = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsHelp = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.tsQuit = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsm_Add = new System.Windows.Forms.ToolStripMenuItem();
            this.csiDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.csiUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.csiReflash = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsOptin,
            this.toolStripSeparator1,
            this.tsFont,
            this.toolStripSeparator2,
            this.tsColor,
            this.toolStripSeparator3,
            this.tsHide,
            this.toolStripSeparator4,
            this.tscText,
            this.toolStripSeparator5,
            this.tsHelp,
            this.toolStripSeparator7,
            this.tsQuit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(843, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // tsOptin
            // 
            this.tsOptin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsOptin.Image = ((System.Drawing.Image)(resources.GetObject("tsOptin.Image")));
            this.tsOptin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsOptin.Name = "tsOptin";
            this.tsOptin.Size = new System.Drawing.Size(23, 22);
            this.tsOptin.Text = "系统设置";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsFont
            // 
            this.tsFont.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsFont.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsiBig,
            this.tsiMid,
            this.tsiSma});
            this.tsFont.Image = ((System.Drawing.Image)(resources.GetObject("tsFont.Image")));
            this.tsFont.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsFont.Name = "tsFont";
            this.tsFont.Size = new System.Drawing.Size(29, 22);
            this.tsFont.Text = "字体大小";
            // 
            // tsiBig
            // 
            this.tsiBig.Name = "tsiBig";
            this.tsiBig.Size = new System.Drawing.Size(94, 22);
            this.tsiBig.Text = "较大";
            this.tsiBig.Click += new System.EventHandler(this.tsiBig_Click);
            // 
            // tsiMid
            // 
            this.tsiMid.Name = "tsiMid";
            this.tsiMid.Size = new System.Drawing.Size(94, 22);
            this.tsiMid.Text = "适中";
            this.tsiMid.Click += new System.EventHandler(this.tsiBig_Click);
            // 
            // tsiSma
            // 
            this.tsiSma.Name = "tsiSma";
            this.tsiSma.Size = new System.Drawing.Size(94, 22);
            this.tsiSma.Text = "较小";
            this.tsiSma.Click += new System.EventHandler(this.tsiBig_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsColor
            // 
            this.tsColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsColor.Image = ((System.Drawing.Image)(resources.GetObject("tsColor.Image")));
            this.tsColor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsColor.Name = "tsColor";
            this.tsColor.Size = new System.Drawing.Size(23, 22);
            this.tsColor.Text = "背景颜色";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // tsHide
            // 
            this.tsHide.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsHide.Image = ((System.Drawing.Image)(resources.GetObject("tsHide.Image")));
            this.tsHide.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsHide.Name = "tsHide";
            this.tsHide.Size = new System.Drawing.Size(23, 22);
            this.tsHide.Text = "隐藏";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // tscText
            // 
            this.tscText.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tscText.Items.AddRange(new object[] {
            "浏览器",
            "文本"});
            this.tscText.Name = "tscText";
            this.tscText.Size = new System.Drawing.Size(80, 25);
            this.tscText.SelectedIndexChanged += new System.EventHandler(this.tscText_SelectedIndexChanged);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // tsHelp
            // 
            this.tsHelp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsHelp.Image = ((System.Drawing.Image)(resources.GetObject("tsHelp.Image")));
            this.tsHelp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsHelp.Name = "tsHelp";
            this.tsHelp.Size = new System.Drawing.Size(23, 22);
            this.tsHelp.Text = "帮助";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // tsQuit
            // 
            this.tsQuit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsQuit.Image = ((System.Drawing.Image)(resources.GetObject("tsQuit.Image")));
            this.tsQuit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsQuit.Name = "tsQuit";
            this.tsQuit.Size = new System.Drawing.Size(23, 22);
            this.tsQuit.Text = "退出";
            this.tsQuit.Click += new System.EventHandler(this.tsQuit_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.richTextBox1);
            this.splitContainer1.Panel2.Controls.Add(this.webBrowser1);
            this.splitContainer1.Size = new System.Drawing.Size(843, 484);
            this.splitContainer1.SplitterDistance = 217;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 4;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(217, 484);
            this.treeView1.TabIndex = 0;
            this.treeView1.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseDoubleClick);
            this.treeView1.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.treeView1_AfterLabelEdit);
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(621, 484);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(621, 484);
            this.webBrowser1.TabIndex = 1;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsm_Add,
            this.csiDelete,
            this.csiUpdate,
            this.toolStripSeparator6,
            this.csiReflash});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(119, 98);
            this.contextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.contextMenuStrip1_ItemClicked);
            // 
            // tsm_Add
            // 
            this.tsm_Add.Name = "tsm_Add";
            this.tsm_Add.Size = new System.Drawing.Size(118, 22);
            this.tsm_Add.Text = "添加节点";
            // 
            // csiDelete
            // 
            this.csiDelete.Name = "csiDelete";
            this.csiDelete.Size = new System.Drawing.Size(118, 22);
            this.csiDelete.Text = "删除节点";
            // 
            // csiUpdate
            // 
            this.csiUpdate.Name = "csiUpdate";
            this.csiUpdate.Size = new System.Drawing.Size(118, 22);
            this.csiUpdate.Text = "重命名";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(115, 6);
            // 
            // csiReflash
            // 
            this.csiReflash.Name = "csiReflash";
            this.csiReflash.Size = new System.Drawing.Size(118, 22);
            this.csiReflash.Text = "刷新";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 509);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripButton tsOptin;
        private System.Windows.Forms.ToolStripButton tsQuit;
        private System.Windows.Forms.ToolStripDropDownButton tsFont;
        private System.Windows.Forms.ToolStripMenuItem tsiBig;
        private System.Windows.Forms.ToolStripMenuItem tsiMid;
        private System.Windows.Forms.ToolStripMenuItem tsiSma;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsColor;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.ToolStripButton tsHide;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ToolStripComboBox tscText;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem csiDelete;
        private System.Windows.Forms.ToolStripMenuItem csiUpdate;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem csiReflash;
        private System.Windows.Forms.ToolStripButton tsHelp;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem tsm_Add;
    }
}

