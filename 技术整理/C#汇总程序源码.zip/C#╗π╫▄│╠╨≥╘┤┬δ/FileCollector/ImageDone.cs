﻿using System;
using System.Collections.Generic;
using System.Text;
using mshtml;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Configuration;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com
 
 */
  //下载源码到51aspx
namespace FileCollector
{
    public class ImageDone
    {

        private readonly static string imagePath = ConfigurationManager.AppSettings["images"];

        public static Image GetRegCodePic(WebBrowser wbMail, string ImgName, string Src, string Alt)
        {
            HTMLDocument doc = (HTMLDocument)wbMail.Document.DomDocument;
            HTMLBody body = (HTMLBody)doc.body;
            IHTMLControlRange rang = (IHTMLControlRange)body.createControlRange();
            IHTMLControlElement Img;
            if (ImgName == "") //如果没有图片的名字,通过Src或Alt中的关键字来取
            {
                int ImgNum = GetPicIndex(wbMail, Src, Alt);
                if (ImgNum == -1) return null;
                Img = (IHTMLControlElement)wbMail.Document.Images[ImgNum].DomElement;
            }
            else
                Img = (IHTMLControlElement)wbMail.Document.All[ImgName].DomElement;

            rang.add(Img);
            rang.execCommand("Copy", false, null);
            Image RegImg = Clipboard.GetImage();
            Clipboard.Clear();
            return RegImg;
        }

        public static int GetPicIndex(WebBrowser wbMail, string Src, string Alt)
        {
            int imgnum = -1;
            for (int i = 0; i < wbMail.Document.Images.Count; i++)　//获取所有的Image元素
            {
                IHTMLImgElement img = (IHTMLImgElement)wbMail.Document.Images[i].DomElement;
                if (Alt == "")
                {
                    if (img.src.Contains(Src)) return i;
                }
                else
                {
                    if (!string.IsNullOrEmpty(img.alt))
                    {
                        if (img.alt.Contains(Alt)) return i;
                    }
                }
            }
            return imgnum;
        }
        public static byte[] GetImageBytes(string srcName)
        {
            try
            {
                Uri _ImageUri = new Uri(srcName);
                System.Net.WebClient _WebClinet = new System.Net.WebClient();
                return _WebClinet.DownloadData(_ImageUri);

            }
            catch
            { }
            return null;
        }

        public static string GetDocumentTextAndImg(string document)
        {
            string resultDoc = document;
            document = document.Replace("\t", "").Replace("\r", "").Replace("\n", "");
            Regex reg_src = new Regex("<img.*?src=['|\"](?<src>.*?)['|\"]", RegexOptions.IgnoreCase);
            MatchCollection mac = reg_src.Matches(document);
            if (mac == null || mac.Count < 1) return resultDoc;
            foreach (Match m in mac)
            {
                string imgPath = m.Groups["src"].Value;
                byte[] imageByte = GetImageBytes(imgPath);
                if (imageByte != null && imageByte.Length > 0)
                {
                    using (MemoryStream ms = new MemoryStream(imageByte))
                    {
                        try
                        {
                            string imgName = imgPath.Substring(imgPath.LastIndexOf("/") + 1);
                            Image img = Image.FromStream(ms);
                            img.Save(Environment.CurrentDirectory + "\\" + imagePath + imgName);
                            img.Dispose();
                            ms.Close();
                            resultDoc = resultDoc.Replace(m.Groups["src"].Value, imagePath + imgName);

                        }
                        catch
                        { }
                    }
                }
            }
            return resultDoc;

        }

        public static string GetLocalImagesText(string document)
        {
            string resultDoc = document;
            document = document.Replace("\t", "").Replace("\r", "").Replace("\n", "");
            Regex reg_src = new Regex("<img.*?src=['|\"](?<src>.*?)['|\"]", RegexOptions.IgnoreCase);
            MatchCollection mac = reg_src.Matches(document);
            if (mac == null || mac.Count < 1) return resultDoc;
            foreach (Match m in mac)
            {
                string imgPath = m.Groups["src"].Value;
                string newPath = (Environment.CurrentDirectory + "\\" + imgPath).Replace("\\", "/");
                resultDoc = resultDoc.Replace(imgPath, "file:///" + newPath);
            }
            return resultDoc;

        }

    }
}
