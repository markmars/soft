﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Threading;
using WeifenLuo.WinFormsUI.Docking;
/*
 作者：hyfly
 Email：fer_software@qq.com
 MSN:hyfly2006@hotmail.com

 */
  //下载源码到51aspx
namespace FileCollector
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
            LoadChildForm();
            this.Text = System.Configuration.ConfigurationManager.AppSettings["filename"];
 
        }

        LeftTree treeForm;
        CategroryAdd categrory;
        FormShow Content;
   
        private void LoadChildForm()
        {
            treeForm = new LeftTree();
            treeForm.Owner = this;
            treeForm.Show(this.dockPanel_content);
            treeForm.DockTo(this.dockPanel_content, DockStyle.Left);
            treeForm.ReturnEvent += new LeftTree.ReturnTreeNode(treeForm_ReturnEvent);
            treeForm.IDEvent += new LeftTree.ReturnTreeId(treeForm_IDEvent);
            treeForm.DelTreeNode += new LeftTree.DeleteTreeNode(treeForm_DelTreeNode);
           treeForm.SearchEvent += new LeftTree.Search(treeForm_SearchEvent);
            HomeShow home = new HomeShow();
            home.Text = "首页";
            home.Owner = this;
            home.Show(this.dockPanel_content);

        }

        void treeForm_SearchEvent(string key, int pageIndex)
        {
            treeForm.LoadSearch(key, pageIndex);
        }

       

        void treeForm_DelTreeNode(List<int> list)
        {
            if (MessageBox.Show("如果删除此节点，则其子节点将一并删除，是否要删除吗？", "删除提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (int id in list)
                {
                    DataAccess.Categrory.DeleteAndContent(id);
                }
                treeForm.LoadTree();
            }
        }

        void treeForm_ReturnEvent(FileCollector.Model.CategroryInfo model, TreeNode node)
        {
            categrory = new CategroryAdd(model, node);
            categrory.Text = "添加节点";
            categrory.EventMessage += new CategroryAdd.SendMessage(categrory_EventMessage);
            categrory.Show(this.dockPanel_content);
        }
        void treeForm_IDEvent(int id)
        {
            Content = new FormShow(id);
            Content.Show(this.dockPanel_content);
        }

      
        void categrory_EventMessage(DockContent form, DialogResult result)
        {
            if (result == DialogResult.OK)
            {
                if (treeForm != null)
                    treeForm.LoadTree();
            }
            form.Close();
        }

       

       
   

       
       
    }
}
