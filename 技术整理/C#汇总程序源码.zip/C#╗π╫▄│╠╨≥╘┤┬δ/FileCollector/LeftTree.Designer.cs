﻿namespace FileCollector
{
    partial class LeftTree
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LeftTree));
            this.treeView_index = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmAdd_bro = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmDel_bro = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmAdd_chi = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmUpt = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmRes = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageTree = new System.Windows.Forms.TabPage();
            this.tabPageIndex = new System.Windows.Forms.TabPage();
            this.lstb_index = new System.Windows.Forms.ListBox();
            this.tIndex = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPageSearch = new System.Windows.Forms.TabPage();
            this.lstb_Search = new System.Windows.Forms.ListBox();
            this.tSearch = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.contextMenuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageTree.SuspendLayout();
            this.tabPageIndex.SuspendLayout();
            this.tabPageSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // treeView_index
            // 
            this.treeView_index.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView_index.ImageIndex = 0;
            this.treeView_index.ImageList = this.imageList1;
            this.treeView_index.Location = new System.Drawing.Point(3, 3);
            this.treeView_index.Name = "treeView_index";
            this.treeView_index.SelectedImageIndex = 0;
            this.treeView_index.Size = new System.Drawing.Size(255, 494);
            this.treeView_index.TabIndex = 1;
            this.treeView_index.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.treeView_index_MouseDoubleClick);
            this.treeView_index.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView_index_MouseDown);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "blockdevice.png");
            this.imageList1.Images.SetKeyName(1, "folder_red.png");
            this.imageList1.Images.SetKeyName(2, "folder_yellow.png");
            this.imageList1.Images.SetKeyName(3, "folder_green.png");
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmAdd_bro,
            this.tsmDel_bro,
            this.toolStripMenuItem1,
            this.tsmAdd_chi,
            this.toolStripMenuItem2,
            this.tsmUpt,
            this.tsmRes});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(143, 126);
            this.contextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.contextMenuStrip1_ItemClicked);
            // 
            // tsmAdd_bro
            // 
            this.tsmAdd_bro.Name = "tsmAdd_bro";
            this.tsmAdd_bro.Size = new System.Drawing.Size(142, 22);
            this.tsmAdd_bro.Text = "添加兄弟节点";
            // 
            // tsmDel_bro
            // 
            this.tsmDel_bro.Name = "tsmDel_bro";
            this.tsmDel_bro.Size = new System.Drawing.Size(142, 22);
            this.tsmDel_bro.Text = "删除此节点";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(139, 6);
            // 
            // tsmAdd_chi
            // 
            this.tsmAdd_chi.Name = "tsmAdd_chi";
            this.tsmAdd_chi.Size = new System.Drawing.Size(142, 22);
            this.tsmAdd_chi.Text = "添加子节点";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(139, 6);
            // 
            // tsmUpt
            // 
            this.tsmUpt.Name = "tsmUpt";
            this.tsmUpt.Size = new System.Drawing.Size(142, 22);
            this.tsmUpt.Text = "修改节点";
            // 
            // tsmRes
            // 
            this.tsmRes.Name = "tsmRes";
            this.tsmRes.Size = new System.Drawing.Size(142, 22);
            this.tsmRes.Text = "刷新";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageTree);
            this.tabControl1.Controls.Add(this.tabPageIndex);
            this.tabControl1.Controls.Add(this.tabPageSearch);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(269, 525);
            this.tabControl1.TabIndex = 2;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPageTree
            // 
            this.tabPageTree.Controls.Add(this.treeView_index);
            this.tabPageTree.Location = new System.Drawing.Point(4, 21);
            this.tabPageTree.Name = "tabPageTree";
            this.tabPageTree.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTree.Size = new System.Drawing.Size(261, 500);
            this.tabPageTree.TabIndex = 0;
            this.tabPageTree.Text = "目录";
            this.tabPageTree.UseVisualStyleBackColor = true;
            // 
            // tabPageIndex
            // 
            this.tabPageIndex.Controls.Add(this.lstb_index);
            this.tabPageIndex.Controls.Add(this.tIndex);
            this.tabPageIndex.Controls.Add(this.label1);
            this.tabPageIndex.Location = new System.Drawing.Point(4, 21);
            this.tabPageIndex.Name = "tabPageIndex";
            this.tabPageIndex.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageIndex.Size = new System.Drawing.Size(261, 500);
            this.tabPageIndex.TabIndex = 1;
            this.tabPageIndex.Text = "索引";
            this.tabPageIndex.UseVisualStyleBackColor = true;
            this.tabPageIndex.Click += new System.EventHandler(this.tabPageIndex_Click);
            // 
            // lstb_index
            // 
            this.lstb_index.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstb_index.DataSource = this.bindingSource1;
            this.lstb_index.DisplayMember = "Keyword";
            this.lstb_index.FormattingEnabled = true;
            this.lstb_index.ItemHeight = 12;
            this.lstb_index.Location = new System.Drawing.Point(8, 54);
            this.lstb_index.Name = "lstb_index";
            this.lstb_index.Size = new System.Drawing.Size(244, 436);
            this.lstb_index.Sorted = true;
            this.lstb_index.TabIndex = 2;
            this.lstb_index.ValueMember = "Categoryid";
            this.lstb_index.SelectedIndexChanged += new System.EventHandler(this.lstb_index_SelectedIndexChanged);
            // 
            // tIndex
            // 
            this.tIndex.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tIndex.Location = new System.Drawing.Point(8, 27);
            this.tIndex.Name = "tIndex";
            this.tIndex.Size = new System.Drawing.Size(243, 21);
            this.tIndex.TabIndex = 1;
            this.tIndex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tIndex_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "键入关键字进行查找：";
            // 
            // tabPageSearch
            // 
            this.tabPageSearch.Controls.Add(this.lstb_Search);
            this.tabPageSearch.Controls.Add(this.tSearch);
            this.tabPageSearch.Controls.Add(this.label2);
            this.tabPageSearch.Location = new System.Drawing.Point(4, 21);
            this.tabPageSearch.Name = "tabPageSearch";
            this.tabPageSearch.Size = new System.Drawing.Size(261, 500);
            this.tabPageSearch.TabIndex = 2;
            this.tabPageSearch.Text = "搜索";
            this.tabPageSearch.UseVisualStyleBackColor = true;
            // 
            // lstb_Search
            // 
            this.lstb_Search.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstb_Search.DataSource = this.bindingSource1;
            this.lstb_Search.DisplayMember = "Keyword";
            this.lstb_Search.FormattingEnabled = true;
            this.lstb_Search.ItemHeight = 12;
            this.lstb_Search.Location = new System.Drawing.Point(8, 55);
            this.lstb_Search.Name = "lstb_Search";
            this.lstb_Search.Size = new System.Drawing.Size(244, 436);
            this.lstb_Search.TabIndex = 5;
            this.lstb_Search.ValueMember = "Categoryid";
            this.lstb_Search.SelectedIndexChanged += new System.EventHandler(this.lstb_Search_SelectedIndexChanged);
            // 
            // tSearch
            // 
            this.tSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tSearch.Location = new System.Drawing.Point(8, 28);
            this.tSearch.Name = "tSearch";
            this.tSearch.Size = new System.Drawing.Size(243, 21);
            this.tSearch.TabIndex = 4;
            this.tSearch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tIndex_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "键入关键字进行查找：";
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = typeof(FileCollector.Model.ContentInfo);
            // 
            // LeftTree
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(269, 525);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Name = "LeftTree";
            this.Text = "菜单";
            this.Load += new System.EventHandler(this.LeftTree_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPageTree.ResumeLayout(false);
            this.tabPageIndex.ResumeLayout(false);
            this.tabPageIndex.PerformLayout();
            this.tabPageSearch.ResumeLayout(false);
            this.tabPageSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

       

        #endregion

        public System.Windows.Forms.TreeView treeView_index;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmAdd_bro;
        private System.Windows.Forms.ToolStripMenuItem tsmDel_bro;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsmAdd_chi;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tsmUpt;
        private System.Windows.Forms.ToolStripMenuItem tsmRes;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageTree;
        private System.Windows.Forms.TabPage tabPageIndex;
        private System.Windows.Forms.TextBox tIndex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPageSearch;
        private System.Windows.Forms.ListBox lstb_index;
        private System.Windows.Forms.ListBox lstb_Search;
        private System.Windows.Forms.TextBox tSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource bindingSource1;

    }
}