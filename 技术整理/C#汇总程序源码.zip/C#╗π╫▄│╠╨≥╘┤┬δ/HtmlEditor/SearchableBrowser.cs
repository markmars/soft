﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HtmlEditor
{

    public interface SearchableBrowser
    {
        bool Search(string text, bool forward, bool matchWholeWord, bool matchCase);
    }
}
