﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;


//源码下载www.51aspx.com 
namespace WinAPI
{
    public class WinAPI
    {
        public static int PROCESS_ALL = (0x1F0FFF);//进程控制权
        public static int WM_KEYDOWN = 0x100; //键盘按下键
        public static int WM_KEYUP = 0x101;  //键盘弹起键

        #region //打开进程

        /// <summary>
        /// 打开进程
        /// </summary>
        /// <param name="dwDesiredAccess">打开后进程访问方式(权限)</param>
        /// <param name="bInheritHandle">进程中打开的窗口句柄</param>
        /// <param name="dwProcessId">进程ID</param>
        /// <returns></returns>
        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        #endregion

        #region //窗口更名
        [DllImport("user32.dll", EntryPoint = "SetWindowText")]
        public static extern int SetWindowText(
            IntPtr hwnd,
            string lpString
        );
        #endregion

        #region  //搜索窗口 (返回句柄)

        /// <summary>
        /// 搜索窗口 (返回句柄)
        /// </summary>
        /// <param name="lpClassName">窗口类型(一般用null)</param>
        /// <param name="lpWindowName">窗口名称</param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        #endregion

        #region //读取内存数据
        [DllImport("kernel32.dll", EntryPoint = "ReadProcessMemory")]
        public static extern int ReadProcessMemory(
            IntPtr hProcess,
            int lpBaseAddress,
            [In, Out] byte[] buffer,
            int nSize,
            int lpNumberOfBytesWritten
        );
        #endregion

        #region //将数据写进指定内存地址
        /// <summary>
        /// 将数据写进指定内存地址
        /// </summary>
        /// <param name="hProcess"></param>
        /// <param name="lpBaseAddress"></param>
        /// <param name="buffer"></param>
        /// <param name="size"></param>
        /// <param name="lpNumberOfBytesWritten"></param>
        /// <returns></returns>
        [DllImport("kernel32.dll")]
        public static extern Int32 WriteProcessMemory(
            IntPtr hProcess,
            int lpBaseAddress,
            [In, Out] byte[] buffer,
            UInt32 size,
            int lpNumberOfBytesWritten);

        #endregion

        #region  // 辅助按键实现

        [DllImport("user32.dll", EntryPoint = "SendMessage")]
        public static extern int SendMessage(
            IntPtr hwnd,
            int wMsg,
            int wParam,
            int lParam
        );

        #endregion

        #region  // 播放音乐

        [DllImport("winmm.dll")]
        public static extern long sndPlaySound(string lpszSoundName, long uFlags);
        #endregion
    }
}
