﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
   public class Coordinate:MemoryWork
    {
        /// <summary>
        /// 坐标类
        /// </summary>
        /// <param name="address">父精灵的信息基地址</param>
        /// <param name="EProcess">进程句柄</param>
        public Coordinate(int address, IntPtr EProcess) : base(EProcess)
        {
            this.address = address;
            this.EProcess = EProcess;
            
        }

        int address;

        IntPtr EProcess;

        public float X
        {
            get { return ReadMemoryFloat( address + 0x3C); }
        }

        public float Y
        {
            get { return ReadMemoryFloat( address + 0x44); }

        }

        public float Z
        {
            get { return ReadMemoryFloat( address + 0x40); }
        }
    }
}
