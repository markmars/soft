﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


namespace 完美世界国际版游戏外挂
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnhelp = new System.Windows.Forms.Button();
            this.btnSetCinty = new System.Windows.Forms.Button();
            this.lblShiJiZuoBiao = new System.Windows.Forms.Label();
            this.lblZuoBiao = new System.Windows.Forms.Label();
            this.btnLoadInfo = new System.Windows.Forms.Button();
            this.lblZhengQi = new System.Windows.Forms.Label();
            this.lblXueLiang = new System.Windows.Forms.Label();
            this.lblDengJi = new System.Windows.Forms.Label();
            this.lblJiaoShe = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radio1 = new System.Windows.Forms.RadioButton();
            this.radio2 = new System.Windows.Forms.RadioButton();
            this.cmbLan1 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtLan1 = new System.Windows.Forms.TextBox();
            this.chkLan1 = new System.Windows.Forms.CheckBox();
            this.cmbXue2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtXue2 = new System.Windows.Forms.TextBox();
            this.chkXue2 = new System.Windows.Forms.CheckBox();
            this.cmbXue1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtXue1 = new System.Windows.Forms.TextBox();
            this.chkXue1 = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDelSkills = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddSkills = new System.Windows.Forms.Button();
            this.listSelectSkills = new System.Windows.Forms.ListBox();
            this.listAllSkills = new System.Windows.Forms.ListBox();
            this.cmbReSkills = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPickUp = new System.Windows.Forms.TextBox();
            this.chkPickUp = new System.Windows.Forms.CheckBox();
            this.btnLianJiStart = new System.Windows.Forms.Button();
            this.cmbFrSkills = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.chkRuMo = new System.Windows.Forms.CheckBox();
            this.chkChuanQiang = new System.Windows.Forms.CheckBox();
            this.chkYinChang = new System.Windows.Forms.CheckBox();
            this.chkFly = new System.Windows.Forms.CheckBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnCaiJiStart = new System.Windows.Forms.Button();
            this.btnCaiJiPeiZhi = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.listCaiJi = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(9, 10);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(339, 267);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.btnhelp);
            this.tabPage1.Controls.Add(this.btnSetCinty);
            this.tabPage1.Controls.Add(this.lblShiJiZuoBiao);
            this.tabPage1.Controls.Add(this.lblZuoBiao);
            this.tabPage1.Controls.Add(this.btnLoadInfo);
            this.tabPage1.Controls.Add(this.lblZhengQi);
            this.tabPage1.Controls.Add(this.lblXueLiang);
            this.tabPage1.Controls.Add(this.lblDengJi);
            this.tabPage1.Controls.Add(this.lblJiaoShe);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(331, 242);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "基本信息";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnhelp
            // 
            this.btnhelp.Location = new System.Drawing.Point(210, 185);
            this.btnhelp.Name = "btnhelp";
            this.btnhelp.Size = new System.Drawing.Size(75, 23);
            this.btnhelp.TabIndex = 8;
            this.btnhelp.Text = "使用说明";
            this.btnhelp.UseVisualStyleBackColor = true;
            this.btnhelp.Click += new System.EventHandler(this.btnhelp_Click);
            // 
            // btnSetCinty
            // 
            this.btnSetCinty.Enabled = false;
            this.btnSetCinty.Location = new System.Drawing.Point(210, 130);
            this.btnSetCinty.Name = "btnSetCinty";
            this.btnSetCinty.Size = new System.Drawing.Size(75, 23);
            this.btnSetCinty.TabIndex = 7;
            this.btnSetCinty.Text = "设为回城点";
            this.btnSetCinty.UseVisualStyleBackColor = true;
            this.btnSetCinty.Click += new System.EventHandler(this.btnSetCinty_Click);
            // 
            // lblShiJiZuoBiao
            // 
            this.lblShiJiZuoBiao.AutoSize = true;
            this.lblShiJiZuoBiao.Location = new System.Drawing.Point(7, 135);
            this.lblShiJiZuoBiao.Name = "lblShiJiZuoBiao";
            this.lblShiJiZuoBiao.Size = new System.Drawing.Size(59, 12);
            this.lblShiJiZuoBiao.TabIndex = 6;
            this.lblShiJiZuoBiao.Text = "实际坐标:";
            // 
            // lblZuoBiao
            // 
            this.lblZuoBiao.AutoSize = true;
            this.lblZuoBiao.Location = new System.Drawing.Point(8, 108);
            this.lblZuoBiao.Name = "lblZuoBiao";
            this.lblZuoBiao.Size = new System.Drawing.Size(59, 12);
            this.lblZuoBiao.TabIndex = 5;
            this.lblZuoBiao.Text = "当前坐标:";
            // 
            // btnLoadInfo
            // 
            this.btnLoadInfo.Location = new System.Drawing.Point(32, 185);
            this.btnLoadInfo.Name = "btnLoadInfo";
            this.btnLoadInfo.Size = new System.Drawing.Size(102, 23);
            this.btnLoadInfo.TabIndex = 4;
            this.btnLoadInfo.Text = "读取游戏信息";
            this.btnLoadInfo.UseVisualStyleBackColor = true;
            this.btnLoadInfo.Click += new System.EventHandler(this.btnLoadInfo_Click);
            // 
            // lblZhengQi
            // 
            this.lblZhengQi.AutoSize = true;
            this.lblZhengQi.Location = new System.Drawing.Point(6, 77);
            this.lblZhengQi.Name = "lblZhengQi";
            this.lblZhengQi.Size = new System.Drawing.Size(35, 12);
            this.lblZhengQi.TabIndex = 3;
            this.lblZhengQi.Text = "真气:";
            // 
            // lblXueLiang
            // 
            this.lblXueLiang.AutoSize = true;
            this.lblXueLiang.Location = new System.Drawing.Point(6, 45);
            this.lblXueLiang.Name = "lblXueLiang";
            this.lblXueLiang.Size = new System.Drawing.Size(35, 12);
            this.lblXueLiang.TabIndex = 2;
            this.lblXueLiang.Text = "血量:";
            // 
            // lblDengJi
            // 
            this.lblDengJi.AutoSize = true;
            this.lblDengJi.Location = new System.Drawing.Point(147, 15);
            this.lblDengJi.Name = "lblDengJi";
            this.lblDengJi.Size = new System.Drawing.Size(35, 12);
            this.lblDengJi.TabIndex = 1;
            this.lblDengJi.Text = "等级:";
            // 
            // lblJiaoShe
            // 
            this.lblJiaoShe.AutoSize = true;
            this.lblJiaoShe.Location = new System.Drawing.Point(6, 15);
            this.lblJiaoShe.Name = "lblJiaoShe";
            this.lblJiaoShe.Size = new System.Drawing.Size(35, 12);
            this.lblJiaoShe.TabIndex = 0;
            this.lblJiaoShe.Text = "角色:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.cmbLan1);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtLan1);
            this.tabPage2.Controls.Add(this.chkLan1);
            this.tabPage2.Controls.Add(this.cmbXue2);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtXue2);
            this.tabPage2.Controls.Add(this.chkXue2);
            this.tabPage2.Controls.Add(this.cmbXue1);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtXue1);
            this.tabPage2.Controls.Add(this.chkXue1);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(331, 242);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "保护";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Location = new System.Drawing.Point(29, 184);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(210, 52);
            this.groupBox3.TabIndex = 25;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "答题报警";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(19, 20);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(161, 16);
            this.radioButton1.TabIndex = 22;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "启动答题报警 (无法取消)";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radio1);
            this.groupBox1.Controls.Add(this.radio2);
            this.groupBox1.Location = new System.Drawing.Point(29, 113);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 52);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "死亡处理";
            // 
            // radio1
            // 
            this.radio1.AutoSize = true;
            this.radio1.Checked = true;
            this.radio1.Location = new System.Drawing.Point(19, 20);
            this.radio1.Name = "radio1";
            this.radio1.Size = new System.Drawing.Size(71, 16);
            this.radio1.TabIndex = 22;
            this.radio1.TabStop = true;
            this.radio1.Text = "自动复活";
            this.radio1.UseVisualStyleBackColor = true;
            this.radio1.CheckedChanged += new System.EventHandler(this.radio2_CheckedChanged);
            // 
            // radio2
            // 
            this.radio2.AutoSize = true;
            this.radio2.Location = new System.Drawing.Point(114, 20);
            this.radio2.Name = "radio2";
            this.radio2.Size = new System.Drawing.Size(71, 16);
            this.radio2.TabIndex = 23;
            this.radio2.Text = "音乐报警";
            this.radio2.UseVisualStyleBackColor = true;
            this.radio2.CheckedChanged += new System.EventHandler(this.radio2_CheckedChanged);
            // 
            // cmbLan1
            // 
            this.cmbLan1.FormattingEnabled = true;
            this.cmbLan1.Location = new System.Drawing.Point(201, 77);
            this.cmbLan1.Name = "cmbLan1";
            this.cmbLan1.Size = new System.Drawing.Size(125, 20);
            this.cmbLan1.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(148, 82);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 20;
            this.label8.Text = "使用药品";
            // 
            // txtLan1
            // 
            this.txtLan1.Location = new System.Drawing.Point(101, 76);
            this.txtLan1.Name = "txtLan1";
            this.txtLan1.Size = new System.Drawing.Size(42, 21);
            this.txtLan1.TabIndex = 19;
            this.txtLan1.Text = "100";
            this.txtLan1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtXue1_KeyPress);
            // 
            // chkLan1
            // 
            this.chkLan1.AutoSize = true;
            this.chkLan1.Location = new System.Drawing.Point(16, 78);
            this.chkLan1.Name = "chkLan1";
            this.chkLan1.Size = new System.Drawing.Size(84, 16);
            this.chkLan1.TabIndex = 18;
            this.chkLan1.Text = "启动   蓝<";
            this.chkLan1.UseVisualStyleBackColor = true;
            this.chkLan1.CheckedChanged += new System.EventHandler(this.chkLan1_CheckedChanged_1);
            // 
            // cmbXue2
            // 
            this.cmbXue2.FormattingEnabled = true;
            this.cmbXue2.Location = new System.Drawing.Point(201, 49);
            this.cmbXue2.Name = "cmbXue2";
            this.cmbXue2.Size = new System.Drawing.Size(125, 20);
            this.cmbXue2.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(147, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 16;
            this.label6.Text = "使用技能";
            // 
            // txtXue2
            // 
            this.txtXue2.Location = new System.Drawing.Point(101, 49);
            this.txtXue2.Name = "txtXue2";
            this.txtXue2.Size = new System.Drawing.Size(42, 21);
            this.txtXue2.TabIndex = 15;
            this.txtXue2.Text = "70";
            this.txtXue2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtXue1_KeyPress);
            // 
            // chkXue2
            // 
            this.chkXue2.AutoSize = true;
            this.chkXue2.Location = new System.Drawing.Point(16, 51);
            this.chkXue2.Name = "chkXue2";
            this.chkXue2.Size = new System.Drawing.Size(84, 16);
            this.chkXue2.TabIndex = 14;
            this.chkXue2.Text = "启动   血<";
            this.chkXue2.UseVisualStyleBackColor = true;
            this.chkXue2.CheckedChanged += new System.EventHandler(this.chkLan1_CheckedChanged_1);
            // 
            // cmbXue1
            // 
            this.cmbXue1.FormattingEnabled = true;
            this.cmbXue1.Location = new System.Drawing.Point(201, 21);
            this.cmbXue1.Name = "cmbXue1";
            this.cmbXue1.Size = new System.Drawing.Size(125, 20);
            this.cmbXue1.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(147, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "使用药品";
            // 
            // txtXue1
            // 
            this.txtXue1.Location = new System.Drawing.Point(101, 20);
            this.txtXue1.Name = "txtXue1";
            this.txtXue1.Size = new System.Drawing.Size(42, 21);
            this.txtXue1.TabIndex = 11;
            this.txtXue1.Text = "50";
            this.txtXue1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtXue1_KeyPress);
            // 
            // chkXue1
            // 
            this.chkXue1.AutoSize = true;
            this.chkXue1.Location = new System.Drawing.Point(16, 23);
            this.chkXue1.Name = "chkXue1";
            this.chkXue1.Size = new System.Drawing.Size(84, 16);
            this.chkXue1.TabIndex = 10;
            this.chkXue1.Text = "启动   血<";
            this.chkXue1.UseVisualStyleBackColor = true;
            this.chkXue1.CheckedChanged += new System.EventHandler(this.chkLan1_CheckedChanged_1);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.cmbReSkills);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.txtPickUp);
            this.tabPage3.Controls.Add(this.chkPickUp);
            this.tabPage3.Controls.Add(this.btnLianJiStart);
            this.tabPage3.Controls.Add(this.cmbFrSkills);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(331, 242);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "练级";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDelSkills);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnAddSkills);
            this.groupBox2.Controls.Add(this.listSelectSkills);
            this.groupBox2.Controls.Add(this.listAllSkills);
            this.groupBox2.Location = new System.Drawing.Point(9, 52);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(269, 134);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "循环技能";
            // 
            // btnDelSkills
            // 
            this.btnDelSkills.Location = new System.Drawing.Point(228, 67);
            this.btnDelSkills.Name = "btnDelSkills";
            this.btnDelSkills.Size = new System.Drawing.Size(30, 23);
            this.btnDelSkills.TabIndex = 33;
            this.btnDelSkills.Text = ">>";
            this.btnDelSkills.UseVisualStyleBackColor = true;
            this.btnDelSkills.Click += new System.EventHandler(this.btnDelSkills_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(138, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 32;
            this.label3.Text = "循环列表";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 31;
            this.label1.Text = "技能列表:";
            // 
            // btnAddSkills
            // 
            this.btnAddSkills.Location = new System.Drawing.Point(99, 67);
            this.btnAddSkills.Name = "btnAddSkills";
            this.btnAddSkills.Size = new System.Drawing.Size(30, 23);
            this.btnAddSkills.TabIndex = 30;
            this.btnAddSkills.Text = ">>";
            this.btnAddSkills.UseVisualStyleBackColor = true;
            this.btnAddSkills.Click += new System.EventHandler(this.btnAddSkills_Click);
            // 
            // listSelectSkills
            // 
            this.listSelectSkills.FormattingEnabled = true;
            this.listSelectSkills.ItemHeight = 12;
            this.listSelectSkills.Location = new System.Drawing.Point(140, 40);
            this.listSelectSkills.Name = "listSelectSkills";
            this.listSelectSkills.Size = new System.Drawing.Size(82, 88);
            this.listSelectSkills.TabIndex = 1;
            // 
            // listAllSkills
            // 
            this.listAllSkills.FormattingEnabled = true;
            this.listAllSkills.ItemHeight = 12;
            this.listAllSkills.Location = new System.Drawing.Point(6, 40);
            this.listAllSkills.Name = "listAllSkills";
            this.listAllSkills.Size = new System.Drawing.Size(87, 88);
            this.listAllSkills.TabIndex = 0;
            // 
            // cmbReSkills
            // 
            this.cmbReSkills.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReSkills.FormattingEnabled = true;
            this.cmbReSkills.Location = new System.Drawing.Point(205, 24);
            this.cmbReSkills.Name = "cmbReSkills";
            this.cmbReSkills.Size = new System.Drawing.Size(64, 20);
            this.cmbReSkills.TabIndex = 36;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 12);
            this.label11.TabIndex = 35;
            this.label11.Text = "首发技能:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(225, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 33;
            this.label2.Text = "米";
            // 
            // txtPickUp
            // 
            this.txtPickUp.Location = new System.Drawing.Point(193, 192);
            this.txtPickUp.Name = "txtPickUp";
            this.txtPickUp.Size = new System.Drawing.Size(26, 21);
            this.txtPickUp.TabIndex = 32;
            this.txtPickUp.Text = "22";
            // 
            // chkPickUp
            // 
            this.chkPickUp.AutoSize = true;
            this.chkPickUp.Location = new System.Drawing.Point(11, 194);
            this.chkPickUp.Name = "chkPickUp";
            this.chkPickUp.Size = new System.Drawing.Size(186, 16);
            this.chkPickUp.TabIndex = 31;
            this.chkPickUp.Text = "启动 地面物品拾取　拾取范围";
            this.chkPickUp.UseVisualStyleBackColor = true;
            this.chkPickUp.CheckedChanged += new System.EventHandler(this.chkLan1_CheckedChanged_1);
            // 
            // btnLianJiStart
            // 
            this.btnLianJiStart.Enabled = false;
            this.btnLianJiStart.Location = new System.Drawing.Point(84, 216);
            this.btnLianJiStart.Name = "btnLianJiStart";
            this.btnLianJiStart.Size = new System.Drawing.Size(75, 23);
            this.btnLianJiStart.TabIndex = 29;
            this.btnLianJiStart.Text = "开始";
            this.btnLianJiStart.UseVisualStyleBackColor = true;
            this.btnLianJiStart.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbFrSkills
            // 
            this.cmbFrSkills.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFrSkills.FormattingEnabled = true;
            this.cmbFrSkills.Location = new System.Drawing.Point(64, 24);
            this.cmbFrSkills.Name = "cmbFrSkills";
            this.cmbFrSkills.Size = new System.Drawing.Size(63, 20);
            this.cmbFrSkills.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(147, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 12);
            this.label10.TabIndex = 14;
            this.label10.Text = "默认技能:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.chkRuMo);
            this.tabPage4.Controls.Add(this.chkChuanQiang);
            this.tabPage4.Controls.Add(this.chkYinChang);
            this.tabPage4.Controls.Add(this.chkFly);
            this.tabPage4.Location = new System.Drawing.Point(4, 21);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(331, 242);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "副本功能";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // chkRuMo
            // 
            this.chkRuMo.AutoSize = true;
            this.chkRuMo.Enabled = false;
            this.chkRuMo.Location = new System.Drawing.Point(133, 81);
            this.chkRuMo.Name = "chkRuMo";
            this.chkRuMo.Size = new System.Drawing.Size(72, 16);
            this.chkRuMo.TabIndex = 5;
            this.chkRuMo.Text = "小号入魔";
            this.chkRuMo.UseVisualStyleBackColor = true;
            this.chkRuMo.CheckedChanged += new System.EventHandler(this.chkRuMo_CheckedChanged);
            // 
            // chkChuanQiang
            // 
            this.chkChuanQiang.AutoSize = true;
            this.chkChuanQiang.Enabled = false;
            this.chkChuanQiang.Location = new System.Drawing.Point(43, 81);
            this.chkChuanQiang.Name = "chkChuanQiang";
            this.chkChuanQiang.Size = new System.Drawing.Size(48, 16);
            this.chkChuanQiang.TabIndex = 4;
            this.chkChuanQiang.Text = "穿墙";
            this.chkChuanQiang.UseVisualStyleBackColor = true;
            this.chkChuanQiang.CheckedChanged += new System.EventHandler(this.chkChuanQiang_CheckedChanged);
            // 
            // chkYinChang
            // 
            this.chkYinChang.AutoSize = true;
            this.chkYinChang.Enabled = false;
            this.chkYinChang.Location = new System.Drawing.Point(133, 31);
            this.chkYinChang.Name = "chkYinChang";
            this.chkYinChang.Size = new System.Drawing.Size(72, 16);
            this.chkYinChang.TabIndex = 3;
            this.chkYinChang.Text = "隐藏建筑";
            this.chkYinChang.UseVisualStyleBackColor = true;
            this.chkYinChang.CheckedChanged += new System.EventHandler(this.chkYinChang_CheckedChanged);
            // 
            // chkFly
            // 
            this.chkFly.AutoSize = true;
            this.chkFly.Enabled = false;
            this.chkFly.Location = new System.Drawing.Point(43, 31);
            this.chkFly.Name = "chkFly";
            this.chkFly.Size = new System.Drawing.Size(48, 16);
            this.chkFly.TabIndex = 2;
            this.chkFly.Text = "飞行";
            this.chkFly.UseVisualStyleBackColor = true;
            this.chkFly.CheckedChanged += new System.EventHandler(this.chkFly_CheckedChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnCaiJiStart);
            this.tabPage5.Controls.Add(this.btnCaiJiPeiZhi);
            this.tabPage5.Controls.Add(this.label4);
            this.tabPage5.Controls.Add(this.listCaiJi);
            this.tabPage5.Location = new System.Drawing.Point(4, 21);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(331, 242);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "采集材料";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnCaiJiStart
            // 
            this.btnCaiJiStart.Enabled = false;
            this.btnCaiJiStart.Location = new System.Drawing.Point(163, 125);
            this.btnCaiJiStart.Name = "btnCaiJiStart";
            this.btnCaiJiStart.Size = new System.Drawing.Size(102, 23);
            this.btnCaiJiStart.TabIndex = 3;
            this.btnCaiJiStart.Text = "开始";
            this.btnCaiJiStart.UseVisualStyleBackColor = true;
            this.btnCaiJiStart.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnCaiJiPeiZhi
            // 
            this.btnCaiJiPeiZhi.Enabled = false;
            this.btnCaiJiPeiZhi.Location = new System.Drawing.Point(163, 77);
            this.btnCaiJiPeiZhi.Name = "btnCaiJiPeiZhi";
            this.btnCaiJiPeiZhi.Size = new System.Drawing.Size(102, 22);
            this.btnCaiJiPeiZhi.TabIndex = 2;
            this.btnCaiJiPeiZhi.Text = "加载配置文件";
            this.btnCaiJiPeiZhi.UseVisualStyleBackColor = true;
            this.btnCaiJiPeiZhi.Click += new System.EventHandler(this.button5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "当前配置材料列表:";
            // 
            // listCaiJi
            // 
            this.listCaiJi.Enabled = false;
            this.listCaiJi.FormattingEnabled = true;
            this.listCaiJi.ItemHeight = 12;
            this.listCaiJi.Location = new System.Drawing.Point(11, 42);
            this.listCaiJi.Name = "listCaiJi";
            this.listCaiJi.Size = new System.Drawing.Size(127, 184);
            this.listCaiJi.TabIndex = 0;
            this.listCaiJi.Click += new System.EventHandler(this.listCaiJi_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "作者QQ：304826832";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 284);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "完美世界国际版外挂 联系QQ：304826832";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnLoadInfo;
        private System.Windows.Forms.Label lblZhengQi;
        private System.Windows.Forms.Label lblXueLiang;
        private System.Windows.Forms.Label lblDengJi;
        private System.Windows.Forms.Label lblJiaoShe;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox cmbLan1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtLan1;
        private System.Windows.Forms.CheckBox chkLan1;
        private System.Windows.Forms.ComboBox cmbXue2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtXue2;
        private System.Windows.Forms.CheckBox chkXue2;
        private System.Windows.Forms.ComboBox cmbXue1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtXue1;
        private System.Windows.Forms.CheckBox chkXue1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnLianJiStart;
        private System.Windows.Forms.ComboBox cmbFrSkills;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.CheckBox chkRuMo;
        private System.Windows.Forms.CheckBox chkChuanQiang;
        private System.Windows.Forms.CheckBox chkYinChang;
        private System.Windows.Forms.CheckBox chkFly;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radio1;
        private System.Windows.Forms.RadioButton radio2;
        private System.Windows.Forms.CheckBox chkPickUp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPickUp;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listAllSkills;
        private System.Windows.Forms.ComboBox cmbReSkills;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button btnDelSkills;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddSkills;
        private System.Windows.Forms.ListBox listSelectSkills;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnCaiJiStart;
        private System.Windows.Forms.Button btnCaiJiPeiZhi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox listCaiJi;
        private System.Windows.Forms.Label lblZuoBiao;
        private System.Windows.Forms.Label lblShiJiZuoBiao;
        private System.Windows.Forms.Button btnSetCinty;
        private System.Windows.Forms.Button btnhelp;
        private System.Windows.Forms.Label label7;
    }
}

