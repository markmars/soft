﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
    class MemoryAddress
    {
        public static int 总地址 = 0x9398EC;
        public static int 飞行地址 = 4556657;
        public static int 隐藏地址 = 4329816;
        public static int 穿墙地址 = 4215177;
        public static int DaTi = 0x93C324;
        public static int Call_Zong = 0x939274;
        public static int Call_FaBao_Address = 0x595110;

        public static int Call_普通攻击 = 0x5B30B0;
        public static int UseSkillsCall = 0x455E60;
        public static int MoveCall1 = 0x45DE80;
        public static int MoveCall2 = 0x4618E0;
        public static int MoveCall3 = 0x45E280;
        public static int MovePartial = 0xBD4;
        public static int RepairCall = 0x6E82D0;
        public static int BuyCall = 0x5B4BC0;
        public static int SellCall = 0x5B4C40;
        public static int CaiJiCall = 0x5B39D0;
       
    }
}
