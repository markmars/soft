﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
    class NPCOperation:MemoryWork
    {
        int address;

        IntPtr EProcess;

        /// <summary>
        /// 初始化NPC操作类
        /// </summary>
        /// <param name="address">总基址</param>
        /// <param name="EProcess">进程句柄</param>
        public NPCOperation(int address, IntPtr EProcess)
            : base(EProcess)
        {
            int 一级地址 = ReadMemoryInt(address);
            int 周围环境 = ReadMemoryInt(一级地址 + 0x8);
            this.address = ReadMemoryInt(周围环境 + 0x24);
            this.EProcess = EProcess;
        }

        public int NPC列表指针
        {
            get { return ReadMemoryInt(address + 0x18); }
        }

        /// <summary>
        /// 返回周围所有NPC
        /// </summary>
        /// <returns></returns>
        public IList<NPC> NPC列表()
        {
            IList<NPC> ilist = new List<NPC>();

            for (int i = 0; i < 768; i++)
            {
                NPC npc = new NPC(NPC列表指针 + 4 * i, EProcess);
                if (npc.Address != 0)
                {
                    ilist.Add(npc);
                }
            }

            return ilist;
        }


        /// <summary>
        /// 根据NPC名称在周围搜索同名NPC，返回找到的第一个
        /// </summary>
        /// <param name="NPC名称">NPC名称</param>
        /// <returns></returns>
        public NPC SelectByName(string NPC名称)
        {
            IList<NPC> ilist = NPC列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].名称.IndexOf(NPC名称) >= 0)
                {
                    return ilist[i];
                }
            }
            return null;
        }
    }
}
