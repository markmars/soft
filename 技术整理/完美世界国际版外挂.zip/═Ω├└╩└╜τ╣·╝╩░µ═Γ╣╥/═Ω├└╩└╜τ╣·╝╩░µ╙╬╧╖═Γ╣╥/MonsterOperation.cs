﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
    class MonsterOperation:MemoryWork
    {
        int address;

        IntPtr EProcess;

        /// <summary>
        /// 初始化怪物数组类
        /// </summary>
        /// <param name="address">总基址</param>
        /// <param name="EProcess">进程句柄</param>
        public MonsterOperation(int address, IntPtr EProcess)
            : base(EProcess)
        {
            int 一级地址 = ReadMemoryInt(address);
            int 周围环境 = ReadMemoryInt(一级地址 + 0x8);
            this.address = ReadMemoryInt(周围环境 + 0x24);
            this.EProcess = EProcess;
        }

        public int 怪物数量
        {
            get { return ReadMemoryInt(address + 0x14); }
        }

        public int 怪物列表指针
        {
            get { return ReadMemoryInt(address + 0x18); }
        }

        public Monster 选怪()
        {
            IList<Monster> ilist = 怪物列表();
            if (ilist.Count < 1)
            {
                return null;
            }

            Monster 选中怪物 = ilist[0];
            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].距离 < 选中怪物.距离)
                {
                    选中怪物 = ilist[i];
                }
            }
            return 选中怪物;
        }

        public IList<Monster> 怪物列表()
        {
            IList<Monster> ilist = new List<Monster>();

            for (int i = 0; i < 768; i++)
            {
                Monster 怪物 = new Monster(怪物列表指针 + 4 * i, EProcess);
                if (怪物.Address != 0)
                {
                    ilist.Add(怪物);
                }
            }

            return ilist;
        }

        /// <summary>
        /// 根据编号查找怪物
        /// </summary>
        /// <param name="怪物ID"></param>
        /// <returns></returns>
        public Monster SelectByID(int 怪物ID)
        {
            IList<Monster> ilist = 怪物列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].ID == 怪物ID)
                {
                    return ilist[i];
                }
            }
            return null;
        }

        /// <summary>
        /// 根据名称查找怪物，返回找到的第一个
        /// </summary>
        /// <param name="怪物名称"></param>
        /// <returns></returns>
        public Monster SelectByName(string 怪物名称)
        {
            IList<Monster> ilist = 怪物列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].名称.IndexOf(怪物名称) >= 0)
                {
                    return ilist[i];
                }
            }
            return null;
        }

        /// <summary>
        /// 根据名称查找怪物列表
        /// </summary>
        /// <param name="怪物名称">怪物名称</param>
        /// <returns></returns>
        public IList<Monster> SelectIlistByName(string 怪物名称)
        {
            IList<Monster> ilist = 怪物列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].名称.IndexOf(怪物名称) < 0)
                {
                    ilist.RemoveAt(i);
                }
            }
            return ilist;
        }
    }
}
