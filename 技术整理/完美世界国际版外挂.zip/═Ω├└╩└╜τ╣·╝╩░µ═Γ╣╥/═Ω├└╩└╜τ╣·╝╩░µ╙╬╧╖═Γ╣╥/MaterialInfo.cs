﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
   public class MaterialInfo
    {
       /// <summary>
       /// 读取材料信息
       /// </summary>
       /// <param name="name"></param>
       /// <param name="x"></param>
       /// <param name="y"></param>
       /// <param name="z"></param>
        public MaterialInfo(string name, float x, float y, float z)
        {
            this.name = name;
            this.x = (x-400)*10;
            this.y = (y - 550) * 10;
            this.z = z*10;
        }

        string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        float x;

        public float X
        {
            get { return x; }
            set { x = value; }
        }

        float y;

        public float Y
        {
            get { return y; }
            set { y = value; }
        }

        float z;

        public float Z
        {
            get { return z; }
            set { z = value; }
        }
    }
}
