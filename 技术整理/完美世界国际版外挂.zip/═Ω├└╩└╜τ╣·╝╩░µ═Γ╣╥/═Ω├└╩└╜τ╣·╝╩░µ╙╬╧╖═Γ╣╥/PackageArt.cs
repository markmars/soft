﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace 完美世界国际版游戏外挂
{
    class PackageArt:MemoryWork
    {
        /// <summary>
        /// 初始化包裹信息
        /// </summary>
        /// <param name="address">包裹内的格子指针地址</param>
        /// <param name="EProcess">游戏窗体句柄</param>
        public PackageArt(int address, IntPtr EProcess)
            : base(EProcess)
        {
            this.address = ReadMemoryInt(address);
            this.EProcess = EProcess;

        }


        int address = 0;

        IntPtr EProcess;

        int pos;

        public int Pos
        {
            get { return pos; }
            set { pos = value; }
        }

        public int Address
        {
            get { return address; }
        }

        public int 物品类型
        {
            get { return ReadMemoryInt(address + 4); }
        }

        public int ID
        {
            get { return ReadMemoryInt(address + 8); }
        }

        public int 物品数量
        {
            get { return ReadMemoryInt(address + 0x14); }
        }

        public string 名称
        {
            get
            {
                int name = ReadMemoryInt(address + 0x54);
                string NameStr = ReadMemoryString(name);
                //删除非中文字符
                for (int i = 0; i < NameStr.Length; i++)
                {
                    Regex regex = new Regex("^[\u4e00-\u9fa5]{0,}$");
                    string ss = NameStr[i].ToString();
                    if (!regex.IsMatch(NameStr[i].ToString()))
                    {
                        NameStr = NameStr.Remove(i, 1);
                        i--;
                    }
                }
                return NameStr.Trim(); ;
            }
        }
    }
}
