﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
    class Monster :MemoryWork
    {
        /// <summary>
        /// 初始化怪物类
        /// </summary>
        /// <param name="address"></param>
        /// <param name="EProcess"></param>
        public Monster(int address, IntPtr EProcess)
            : base(EProcess)
        {
            int 怪物偏移 = ReadMemoryInt(address);
            if (怪物偏移 <= 0)
            {
                return;
            }
            else
            {
                int 怪物指针 = ReadMemoryInt(怪物偏移 + 0x4);

                int 怪物种类 = ReadMemoryInt(怪物指针 + 0xB4);
                if (怪物种类 != 6)
                {
                    return;
                }
                else
                {
                    this.address = 怪物指针;
                    this.EProcess = EProcess;
                }
            }
        }


        int address = 0;

        IntPtr EProcess;

        public int Address
        {
            get { return address; }
        }

        public Coordinate 坐标
        {
            get { return new Coordinate(address, EProcess); }
        }

        public int ID
        {
            get { return ReadMemoryInt(address + 0x11C); }
        }

        public string 名称
        {
            get
            {
                int 名称指针 = ReadMemoryInt(address + 0x238);
                return ReadMemoryString(名称指针);
            }
        }

        public int 生命上限
        {
            get { return ReadMemoryInt(address + 0x154); }
        }

        public int 生命值
        {
            get { return ReadMemoryInt(address + 0x12C); }
        }

        public int 等级
        {
            get { return ReadMemoryInt(address + 0x124); }
        }

        public float 距离
        {
            get { return ReadMemoryFloat(address + 0x25C); }
        }

    }
}
