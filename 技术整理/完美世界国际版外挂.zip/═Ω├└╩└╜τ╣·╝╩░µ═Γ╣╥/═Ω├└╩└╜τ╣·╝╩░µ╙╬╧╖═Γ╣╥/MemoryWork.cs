﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;
using WinAPI;

namespace 完美世界国际版游戏外挂
{
    public class MemoryWork
    {
        IntPtr hwnd;

        /// <summary>
        /// 初始化内存读写类
        /// </summary>
        /// <param name="hwnd">进程句柄</param>
        public MemoryWork(IntPtr hwnd)
        {
            this.hwnd = hwnd;
        }

        /// <summary>
        /// 初始化内存读写类
        /// </summary>
        /// <param name="pid">进程ID</param>
        public MemoryWork(int pid)
        {
            this.hwnd= WinAPI.WinAPI.OpenProcess(WinAPI.WinAPI.PROCESS_ALL, false, pid);
        }

        public IntPtr Hwnd
        {
            get { return hwnd; }
        }


        #region //内存操作函数
        public void WriteMemoryInt( int address, int date)
        {
            byte[] info = System.BitConverter.GetBytes(date);
            WinAPI.WinAPI.WriteProcessMemory(hwnd, address, info, 4, 0);
        }

        public void WriteMemoryByte(int address, byte[] date)
        {
            WinAPI.WinAPI.WriteProcessMemory(hwnd, address, date,(uint)date.Length, 0);
        }

        public int ReadMemoryInt( int address)
        {
            byte[] info = new byte[4];
            WinAPI.WinAPI.ReadProcessMemory(hwnd, address, info, 4, 0);
            return System.BitConverter.ToInt32(info, 0);
        }

        public float ReadMemoryFloat( int address)
        {
            byte[] info = new byte[4];
            WinAPI.WinAPI.ReadProcessMemory(hwnd, address, info, 4, 0);
            return System.BitConverter.ToSingle(info, 0);

        }

        public float ReadMemoryFloat( int address, int lenght)
        {
            byte[] info = new byte[4];
            WinAPI.WinAPI.ReadProcessMemory(hwnd, address, info, lenght, 0);
            return System.BitConverter.ToSingle(info, 0);

        }

        public string ReadMemoryString( int address)
        {
            byte[] info = new byte[32];
            WinAPI.WinAPI.ReadProcessMemory(hwnd, address, info, 32, 0);
            return System.Text.Encoding.Unicode.GetString(info) ;
        }

        #endregion


        public static IntPtr OpenProcess(int pid)
        {
            return WinAPI.WinAPI.OpenProcess(WinAPI.WinAPI.PROCESS_ALL, false, pid);
        }

        public static void KeyPress(IntPtr EMform, int KeyCode)
        {
            WinAPI.WinAPI.SendMessage(EMform, WinAPI.WinAPI.WM_KEYDOWN, KeyCode, 0);
            WinAPI.WinAPI.SendMessage(EMform, WinAPI.WinAPI.WM_KEYUP, KeyCode, 0);
        }

        public static void sndPlaySound(string MusicFileName)
        {
            WinAPI.WinAPI.sndPlaySound(MusicFileName, 1);
        }

    }
}
