﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Reflection;

//源码下载 www.51aspx.com
namespace 完美世界国际版游戏外挂
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 设置ListBox控件当前选中项的委托
        /// </summary>
        /// <param name="li"></param>
        delegate void SetNextList(ListBox li);

        /// <summary>
        /// 设置Label标签显示内容的委托
        /// </summary>
        /// <param name="lbl">Label标签</param>
        /// <param name="text">显示内容</param>
        delegate void SetLabelText(Label lbl,string text);

        /// <summary>
        /// 使用ComboBox控件的委托
        /// </summary>
        /// <param name="cmb"></param>
        delegate void UseCmb(ComboBox cmb);

        #region //变量

        /// <summary>
        /// 游戏进程句柄
        /// </summary>
        IntPtr EProcess;

        /// <summary>
        /// 游戏主窗体句柄
        /// </summary>
        IntPtr EMform;  

        /// <summary>
        /// 游戏进程id
        /// </summary>
        int pid; 

        /// <summary>
        /// 选中的技能列表
        /// </summary>
        DataTable SkillsList = new DataTable(); 

        /// <summary>
        /// 当前使用的技能序号
        /// </summary>
        int SkillsNumber; 

        People 人物信息;

        /// <summary>
        /// 配置信息类
        /// </summary>
        ConfigClass configClass = new ConfigClass(); 

        /// <summary>
        /// 材料采集控制类
        /// </summary>
        MaterialOperation mOpera; 

        /// <summary>
        /// 打怪 进程
        /// </summary>
        Thread thread;

        /// <summary>
        /// 捡物进程
        /// </summary>
        Thread MaterialThread;

        /// <summary>
        /// 补给进程
        /// </summary>
        Thread BuJiThread;

        #endregion


        /// <summary>
        /// 初始化选择框内信息
        /// </summary>
        public void InitCmb()
        {
            SkillsOperation skillsOpera = new SkillsOperation(人物信息.Address, EProcess);
            IList<Skills> SkList = skillsOpera.技能列表();
            cmbFrSkills.DisplayMember = "名称";
            cmbFrSkills.ValueMember = "ID";
            cmbFrSkills.DataSource = SkList;
            cmbFrSkills.SelectedIndex = 1;

            if (人物信息.z职业 == 1 || 人物信息.z职业 == 3 || 人物信息.z职业 == 6 || 人物信息.z职业 == 7)
            {
                chkXue2.Enabled = true;
                cmbReSkills.DisplayMember = "名称";
                cmbReSkills.ValueMember = "ID";
                cmbReSkills.DataSource = skillsOpera.技能列表();
                cmbReSkills.SelectedIndex = 1;

                cmbXue2.DisplayMember = "名称";
                cmbXue2.ValueMember = "ID";
                cmbXue2.DataSource = skillsOpera.技能列表();
                cmbXue2.SelectedIndex = 1;
            }
            else
            {
                chkXue2.Enabled = false;
                cmbReSkills.Items.Add("普通攻击");
                cmbReSkills.SelectedIndex = 0;
            }
            listAllSkills.DisplayMember = "名称";
            listAllSkills.ValueMember = "ID";
            listAllSkills.DataSource = skillsOpera.技能列表();
            listAllSkills.SelectedIndex = 1;
            
            PackageArtOpera p包裹 = new PackageArtOpera(人物信息.Address, EProcess);
            IList<PackageArt> a包裹物品 = p包裹.物品列表();
          
            cmbXue1.DisplayMember = "名称";
            cmbXue1.ValueMember = "ID";
            cmbXue1.DataSource = p包裹.物品列表();
            cmbXue1.SelectedIndex = 1;

            cmbLan1.DisplayMember = "名称";
            cmbLan1.ValueMember = "ID";
            cmbLan1.DataSource = p包裹.物品列表();
            cmbLan1.SelectedIndex = 1;
        }

        /// <summary>
        /// 读取游戏
        /// </summary>
        /// <returns></returns>
        public bool LoadGame()
        {
            Process[] process = Process.GetProcessesByName("elementclient");
            if (process.Length > 0)
            {
                pid = process[0].Id;
                EMform = process[0].MainWindowHandle;
                EProcess = MemoryWork.OpenProcess(pid);
                Call.pid = pid;
                人物信息 = new People(MemoryAddress.总地址, EProcess);
                if (人物信息.Address == 0)
                {
                    return false;
                }
                else
                {
                    lblXueLiang.Text = "血量: " + 人物信息.生命值.ToString() + " / " + 人物信息.生命上限.ToString();
                    lblZhengQi.Text = "真气: " + 人物信息.魔法值.ToString() + " / " + 人物信息.魔法上限.ToString();
                    lblDengJi.Text = "等级: " + 人物信息.等级.ToString();//5~1-a-s-p-x
                    lblJiaoShe.Text = "角色: " + 人物信息.名称;
                    lblShiJiZuoBiao.Text = "实际坐标: " + 人物信息.坐标.X.ToString("0.0") + "，" + 人物信息.坐标.Y.ToString("0.0") + " ↑" + 人物信息.坐标.Z.ToString("0.0");
                    lblZuoBiao.Text = "当前坐标: " + ((int)人物信息.坐标.X / 10 + 400) + "，" + ((int)人物信息.坐标.Y / 10 + 550) + " ↑" + (int)人物信息.坐标.Z / 10; 
                    InitCmb();
                    人物信息.NoFly();
                    btnLoadInfo.Enabled = false;
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SkillsList.Columns.Add("SkillsID");
            SkillsList.Columns.Add("SkillsName");
        }

        private void txtXue1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsDigit(e.KeyChar))&&(char)Keys.Back!=e.KeyChar)
            {
                e.Handled = true;
            }
        }
      
        private void chkLan1_CheckedChanged_1(object sender, EventArgs e)
        {
            CheckBox ckb = sender as CheckBox;
            if (ckb==null)
            {
                return ;
            }
            try
            {
                #region //加血1
                if (ckb == chkXue1)
                {
                    if (ckb.Checked == true)
                    {

                        configClass.B_Xue = int.Parse(txtXue1.Text.Trim());
                        configClass.B_XueYaoName =cmbXue1.Text.Trim();
                        txtXue1.Enabled = false;
                        cmbXue1.Enabled = false;
                    }
                    else
                    {
                        txtXue1.Enabled = true ;
                        cmbXue1.Enabled = true;
                    }
                    return;
                }
                #endregion

                #region //加血2
                if (ckb == chkXue2)
                {
                    if (ckb.Checked == true)
                    {

                        configClass.B_XueSkills = int.Parse(cmbXue2.SelectedValue.ToString());
                        configClass.B_Xue2 = int.Parse(txtXue2.Text.Trim());
                         
                        txtXue2.Enabled = false;
                        cmbXue2.Enabled = false;
                    }
                    else
                    {
                        txtXue2.Enabled = true;
                        cmbXue2.Enabled = true;
                    }
                    return;
                }
                #endregion

                #region //补蓝1
                if (ckb == chkLan1)
                {
                    if (ckb.Checked == true)
                    {

                        configClass.B_Lan = int.Parse(txtLan1.Text.Trim());
                        configClass.B_LanYaoName = cmbLan1.Text.Trim();
                        txtLan1.Enabled = false;
                        cmbLan1.Enabled = false;
                    }
                    else
                    {
                        txtLan1.Enabled = true;
                        cmbLan1.Enabled = true;
                    }
                    return;
                }
                #endregion

                #region //捡物
                if (ckb == chkPickUp)
                {
                    if (ckb.Checked == true)
                    {

                        configClass.PickUpDistance = int.Parse(txtPickUp.Text.Trim());
                        //configClass.B_LanYaoName = cmbLan1.Text.Trim();
                        txtPickUp.Enabled = false;
                        //chkPickUp.Enabled = false;
                    }
                    else
                    {
                        configClass.PickUpDistance = 0;
                        txtPickUp.Enabled = true;
                        //chkPickUp.Enabled = true;
                    }
                    return;
                }
                #endregion

                #region //技能1
                //if (ckb == chkAnJian1)
                //{
                //    if (ckb.Checked == true)
                //    {
                //        技能Timer1 = int.Parse(txtAnJian1.Text.Trim());
                //        技能Key1 = int.Parse(cmbAnJian1.SelectedValue.ToString());
                //        txtAnJian1.Enabled = false;
                //        cmbAnJian1.Enabled = false;
                //    }
                //    else
                //    {
                //        txtAnJian1.Enabled = true;
                //        cmbAnJian1.Enabled = true;
                //    }
                //    return;
                //}
                //#endregion

                //#region //技能2
                //if (ckb == chkAnJian2)
                //{
                //    if (ckb.Checked == true)
                //    {
                //        技能Timer2 = int.Parse(txtAnJian2.Text.Trim());
                //        技能Key2 = int.Parse(cmbAnJian2.SelectedValue.ToString());
                //        txtAnJian2.Enabled = false;
                //        cmbAnJian2.Enabled = false;
                //    }
                //    else
                //    {
                //        txtAnJian2.Enabled = true;
                //        cmbAnJian2.Enabled = true;
                //    }
                //    return;
                //}
                //#endregion

                //#region //技能3
                //if (ckb == chkAnJian3)
                //{
                //    if (ckb.Checked == true)
                //    {
                //        技能Timer3 = int.Parse(txtAnJian3.Text.Trim());
                //        技能Key3 = int.Parse(cmbAnJian3.SelectedValue.ToString());
                //        txtAnJian3.Enabled = false;
                //        cmbAnJian3.Enabled = false;
                //    }
                //    else
                //    {
                //        txtAnJian3.Enabled = true;
                //        cmbAnJian3.Enabled = true;
                //    }
                //    return;
                //}
                //#endregion

                //#region //拾取物品按键
                //if (ckb == chkPickUp)
                //{
                //    if (ckb.Checked == true)
                //    {
                //        PickUpKey = int.Parse(cmbPickUp.SelectedValue.ToString());
                //        cmbPickUp.Enabled = false;
                //        PickUpDistance = int.Parse(txtPickUp.Text.Trim());
                //        if (PickUpDistance > 30)
                //        {
                //            if (MessageBox.Show("拾取物品过远会影响升级速度,建议在22米内,您确定设置较远的距离吗? 取消则设置为22米", "系统提示",
                //                MessageBoxButtons.OKCancel) == DialogResult.OK)
                //            {

                //            }
                //            else
                //            {
                //                PickUpDistance = 22;
                //                txtPickUp.Text = "22";
                //            }
                //        }
                //        txtPickUp.Enabled = false;
                //    }
                //    else
                //    {
                //        cmbPickUp.Enabled = true;
                //        txtPickUp.Enabled = true ;
                //        PickUpKey = 0;
                //        PickUpDistance = 0;
                //    }
                //    return;
                //}
                #endregion

            }
            catch
            {
                MessageBox.Show("您输入的数据不合法,文本框内只能输入整数数据!", "系统提示");
                ckb.Enabled = false;
            }
        }

        #region //补给和人物保护

        /// <summary>
        /// 补给进程入口
        /// </summary>
        private void StartBuJi()
        {
            while (true)
            {
                BuJi();
            }
        }

        /// <summary>
        /// 生命值  和 魔法值的补给
        /// </summary>
        private void BuJi()
        {
            SetLblText(lblXueLiang, "血量: " + 人物信息.生命值.ToString() + " / " + 人物信息.生命上限.ToString());
            SetLblText(lblZhengQi, "真气: " + 人物信息.魔法值.ToString() + " / " + 人物信息.魔法上限.ToString());
            SetLblText(lblDengJi, "等级: " + 人物信息.等级.ToString());
            SetLblText(lblZuoBiao, "当前坐标: " + ((int)人物信息.坐标.X / 10 + 400) + "，" + ((int)人物信息.坐标.Y / 10 + 550) + " ↑" + (int)人物信息.坐标.Z / 10); 
            SetLblText(lblShiJiZuoBiao, "当前坐标: " + 人物信息.坐标.X.ToString("0.0") + "，" + 人物信息.坐标.Y.ToString("0.0") + " ↑" + 人物信息.坐标.Z.ToString("0.0"));
            if (人物信息.生命值 <= 0)
            {
                IsDisd();
            }
            else
            { 
                int ID红药 = 0;
                int ID蓝药 = 0;
                int Pos红药 = 0;
                int Pos蓝药 = 0;
                int Number红药 = 0;
                int Number蓝药 = 0;
                SellWuPin(ref  ID红药,ref Pos红药, ref  Number红药, ref  ID蓝药,ref Pos蓝药 ,ref  Number蓝药);
                if (configClass.B_Xue2 > 0 && 人物信息.生命值 < configClass.B_Xue2)
                {
                        Call.UseSkills(configClass.B_XueSkills);
                }
                if (configClass.B_Xue > 0 && 人物信息.生命值 < configClass.B_Xue)
                {
                        ContractOperation.UseArticleOperation(Pos红药, ID红药);
                }
                if (configClass.B_Lan>0 && 人物信息.魔法值 < configClass.B_Lan)
                {
                        ContractOperation.UseArticleOperation(Pos蓝药, ID蓝药);
                }
            }
            DaTi();
            Thread.Sleep(2000);
        }

        /// <summary>
        /// 判断是否死亡
        /// </summary>
        public void IsDisd()
        {
            if (configClass.Is_Music_Did)
            {
                MemoryWork.sndPlaySound(configClass.Music_Did);
            }
            else
            {
                ContractOperation.GoCityByDid();
            }
            try
            {
                thread.Abort();
            }
            catch { }
            Thread.Sleep(5000);
            人物信息.Fly();
            Thread.Sleep(1000);
            人物信息.Move(configClass.X, configClass.Y, configClass.Z);
            while (!人物信息.IsArrive(configClass.X, configClass.Y, configClass.Z))
            {
                人物信息.Move(configClass.X, configClass.Y, configClass.Z);
                Thread.Sleep(5000);
            }
            人物信息.NoFly();
            try
            {
                thread = new Thread(new ThreadStart(Beginning));
                thread.Start();
            }
            catch{}
        }

        /// <summary>
        /// 购置药品
        /// </summary>
        /// <param name="ID红药"></param>
        /// <param name="Pos红药"></param>
        /// <param name="Number红药"></param>
        /// <param name="ID蓝药"></param>
        /// <param name="Pos蓝药"></param>
        /// <param name="Number蓝药"></param>
        public void SellWuPin(ref int ID红药,ref int Pos红药, ref int Number红药, ref int ID蓝药,ref int Pos蓝药, ref int Number蓝药)
        {
            PackageArtOpera p包裹 = new PackageArtOpera(人物信息.Address, EProcess);
            IList<PackageArt> a包裹物品 = p包裹.物品列表();
            for (int i = 0; i < a包裹物品.Count; i++)
            {
                if (a包裹物品[i].名称.IndexOf(configClass.B_XueYaoName) >= 0)
                {
                    ID红药 = a包裹物品[i].ID;
                    Pos红药 = a包裹物品[i].Pos;
                    Number红药 = Number红药 + a包裹物品[i].物品数量;
                }

                if (a包裹物品[i].名称.IndexOf(configClass.B_LanYaoName) >= 0)
                {
                    ID蓝药 = a包裹物品[i].ID;
                    Pos蓝药 = a包裹物品[i].Pos;
                    Number蓝药 = Number蓝药 + a包裹物品[i].物品数量;
                }
            }
            if (a包裹物品.Count>30 || Number蓝药 < 2 || Number红药 < 2)
            {
                thread.Abort();
                人物信息.Fly();
                Thread.Sleep(1000);
                人物信息.Move(configClass.CityNPC_X, configClass.CityNPC_Y, configClass.CityNPC_Z);
                while (!人物信息.IsArrive(configClass.CityNPC_X, configClass.CityNPC_Y, configClass.CityNPC_Z))
                {
                    人物信息.Move(configClass.CityNPC_X, configClass.CityNPC_Y, configClass.CityNPC_Z);
                    Thread.Sleep(5000);
                }
                NPCOperation npco = new NPCOperation(MemoryAddress.总地址, EProcess);

                NPC npc药师 = npco.SelectByName("药师");
                Thread.Sleep(3000);
                ContractOperation.SelectNPC(npc药师.ID);
                Thread.Sleep(2000);
                for (int ii = 0; ii < a包裹物品.Count; ii++)
                {
                    if (a包裹物品[ii].名称.IndexOf("矿铲") < 0 &&
                        a包裹物品[ii].名称.IndexOf(configClass.B_XueYaoName) < 0 &&
                        a包裹物品[ii].名称.IndexOf(configClass.B_LanYaoName) < 0
                        )
                    {
                        Call.Sell(a包裹物品[ii].ID, a包裹物品[ii].Pos, a包裹物品[ii].物品数量);
                    }
                }
                ContractOperation.Repair();
                Call.Buy(ID红药, 7, 100 - Number红药);
                Call.Buy(ID蓝药, 15, 100 - Number蓝药);
                Thread.Sleep(5000);

                人物信息.Move(configClass.X, configClass.Y, configClass.Z);
                while (!人物信息.IsArrive(configClass.X, configClass.Y, configClass.Z))
                {
                    人物信息.Move(configClass.X, configClass.Y, configClass.Z);
                    Thread.Sleep(5000);
                }
                人物信息.NoFly();
                thread = new Thread(new ThreadStart(Beginning));
                thread.Start();
                Thread.Sleep(6000);
            }
        }

        /// <summary>
        /// 答题报警
        /// </summary>
        public void DaTi()
        {
            MemoryWork mWork = new MemoryWork(EProcess);
            if (mWork.ReadMemoryInt(MemoryAddress.DaTi) != 0)
            {
                MemoryWork.sndPlaySound(configClass.Music_Q);
            }
        }

        public void SetLblText(Label lbl, string text)
        {
            if (lbl.InvokeRequired)
            {
                SetLabelText setLabelText = delegate(Label label,string txt)
                {
                    label.Text = txt;
                };
                lbl.Invoke(setLabelText, new object[] { lbl, text });
            }
            else
            {
                lbl.Text = text;
            }
        }

        #endregion

        #region // 选怪 打怪 捡物

        /// <summary>
        /// 拾取地面物品
        /// </summary>
        /// <param name="article"></param>
        /// <returns></returns>
        private bool PickUpArticle(Article article)
        {
            if (人物信息.IsArrive(article.坐标))
            {
                ContractOperation.PichUp(article.物品SN, article.ID);
                return true;
            }
            else
            {
                人物信息.Move(article.坐标);
                return false;
            }
        }

        /// <summary>
        /// 搜索周围地面物品
        /// </summary>
        private void PickUpArticle()
        {
            while (true)
            {
                ArticleOperation articleOperation = new ArticleOperation(MemoryAddress.总地址, EProcess);
                IList<Article> ilist = articleOperation.SelectIlistByDistance(configClass.PickUpDistance);
                if (ilist.Count > 0) 
                {
                    for (int i = 0; i < ilist.Count; i++)
                    {
                        while ((!PickUpArticle(ilist[i])) && 人物信息.MoveTimer < 10)
                        {
                            人物信息.MoveTimer++;
                            Thread.Sleep(500);
                        }
                        人物信息.MoveTimer = 0;
                    }
                }
                break;
            }
        }

        /// <summary>
        /// 选择怪物
        /// </summary>
        /// <returns></returns>
        private bool SelectMonster()
        {
            MonsterOperation monsterOpera = new MonsterOperation(MemoryAddress.总地址, EProcess);
            Monster monster = monsterOpera.选怪();
            if (monster != null)
            {
                人物信息.SelectMonsterID = monster.ID;
                人物信息.WaitTimer = 0;
                人物信息.MoveTimer = 0;
                ContractOperation.SelectByID(人物信息.SelectMonsterID);
                
                人物信息.Old_EXP = 人物信息.经验值;
                人物信息.Old_X = 人物信息.坐标.X;
                人物信息.Old_Y = 人物信息.坐标.Y;
                人物信息.Old_Z = 人物信息.坐标.Z;
                
                人物信息.SelectMonsterPH = monster.生命值;
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 验证怪物是否死亡
        /// </summary>
        /// <returns></returns>
        private bool MonsterIsDeath()
        {
            if (人物信息.Old_EXP != 人物信息.经验值)
            {
                人物信息.Old_EXP = 人物信息.经验值;
                人物信息.WaitTimer = 0;
                人物信息.MoveTimer = 0;
                return true;
            }
            if (人物信息.WaitTimer > 15 || 人物信息.MoveTimer > 20)
            {
                人物信息.WaitTimer = 0;
                人物信息.MoveTimer = 0;
                return true;
            }
            if (人物信息.IsMove())
            {
                人物信息.WaitTimer = 0;
                人物信息.MoveTimer++;
                return false;
            }
            else
            {
                人物信息.MoveTimer = 0;
                MonsterOperation mOpera = new MonsterOperation(MemoryAddress.总地址, EProcess);
                Monster monster = mOpera.SelectByID(人物信息.SelectMonsterID);
                if (monster == null)
                {
                    人物信息.WaitTimer = 0;
                    人物信息.MoveTimer = 0;
                    return true;
                }
                if (monster.Address == 0)
                {
                    人物信息.WaitTimer = 0;
                    人物信息.MoveTimer = 0;
                    return true;
                }
                else
                {
                    if (人物信息.SelectMonsterPH <= monster.生命值)
                    {
                        人物信息.WaitTimer++;
                    }
                    else
                    {
                        人物信息.WaitTimer = 0;
                        人物信息.SelectMonsterPH = monster.生命值;
                    }
                    return false;
                }
            }
        }

       /// <summary>
       /// 开始使用技能打怪
       /// </summary>
        private void KeyPressForSkills()
        {
            Thread.Sleep(400);
            SkillsOperation skillsOpera = new SkillsOperation(人物信息.Address, EProcess);
            Skills skills = skillsOpera.SelectByID(configClass.FrskillsID);
            Call.UseSkills(skills.ID);
            while (skills.冷却时间 <= 0 && (!MonsterIsDeath()))
            {
                Call.UseSkills(skills.ID);
                Thread.Sleep(300);
            }
            while (!MonsterIsDeath())
            {
                UseSkills();
                Thread.Sleep(300);
            }
        }

        /// <summary>
        /// 循环使用技能
        /// </summary>
        public void UseSkills()
        {
            SkillsOperation skillsOpera = new SkillsOperation(人物信息.Address, EProcess);
            Skills skills = skillsOpera.SelectByID(int.Parse(SkillsList.Rows[SkillsNumber]["SkillsID"].ToString()));
            IList<Skills> s = skillsOpera.技能列表();
            if (skills != null && skills.Address != 0 && skills.冷却时间<=0)
            {
                Call.UseSkills(skills.ID);
                //if (skills.冷却时间 > 0)
                {
                    if (SkillsNumber < SkillsList.Rows.Count - 1)
                    {
                        SkillsNumber++;
                    }
                    else
                    {
                        SkillsNumber = 0;
                    }
                    SelectListCaiJi(listSelectSkills, SkillsNumber);
                }
            }
            else
            {
                if (configClass.ReskillsID!=0)
                {
                    Call.UseSkills(configClass.ReskillsID);
                }
                else
                {
                    ContractOperation.PuTongGongJi();
                }
            }
        }

        /// <summary>
        /// 开始选怪打怪
        /// </summary>
        private void Beginning()
        {
            while (true)
            {
                if (SelectMonster())
                {
                    KeyPressForSkills();
                }
                if (configClass.PickUpDistance != 0)
                {
                    PickUpArticle();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (btnLianJiStart.Text == "开始")
            {
                configClass.FrskillsID = int.Parse(cmbFrSkills.SelectedValue.ToString());
                if (cmbReSkills.Text.Trim() != "普通攻击")
                {
                    configClass.ReskillsID = int.Parse(cmbReSkills.SelectedValue.ToString());
                }
                else
                {
                    configClass.ReskillsID = 0;
                }
                configClass.X = 人物信息.坐标.X;
                configClass.Y = 人物信息.坐标.Y;
                configClass.Z = 人物信息.坐标.Z;
                try
                {
                    thread = new Thread(new ThreadStart(Beginning));
                    BuJiThread = new Thread(new ThreadStart(StartBuJi));
                    BuJiThread.Start();
                    thread.Start();
                    人物信息.ChuanQiang();
                    btnLianJiStart.Text = "停止";
                    btnSetCinty.Enabled = false;
                }
                catch { }
            }
            else
            {
                try
                {
                    BuJiThread.Abort();
                    thread.Abort();
                    btnSetCinty.Enabled = true;
                    btnLianJiStart.Text = "开始";
                }catch { }
            }
        }
        #endregion

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                BuJiThread.Abort();
                thread.Abort();
                MaterialThread.Abort();
            }
            catch{}
            Application.ExitThread();
        }

        #region  //采集相关

        /// <summary>
        /// 采集材料
        /// </summary>
        private void CaiJi()
        {
            mOpera = new MaterialOperation(configClass.CaiJiFileName, EProcess);
            for (int i = 0; i < mOpera.InfoList.Count; i++)
            {
                listCaiJi.Items.Add(mOpera.InfoList[i].Name);
            }
        }

        /// <summary>
        /// 开始采集材料
        /// </summary>
        private void CaiJiStart()
        {
            mOpera.StartTag = true;
            SelectListCaiJi(listCaiJi, mOpera.Number);
            while (true)
            {
                mOpera.MoveToM();
                mOpera.CaiJi();
                mOpera.Next();
                SelectListCaiJi(listCaiJi, mOpera.Number);
            }
        }

        public void SelectListCaiJi( ListBox listSet,int listIndex)
        {
            if (listSet.InvokeRequired)
            {
                SetNextList list = delegate(ListBox li)
                {
                    li.SelectedIndex = listIndex;
                };
                listSet.Invoke(list, new object[] { listSet });
            }
            else
            {
                listSet.SelectedIndex = listIndex;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();
            if (openfile.ShowDialog(this) == DialogResult.OK)
            {
                configClass.CaiJiFileName = openfile.FileName;
                CaiJi();
                btnCaiJiStart.Enabled = true;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (btnCaiJiStart.Text == "开始")
            {
                人物信息.Fly();
                listCaiJi.Enabled = true;
                btnCaiJiPeiZhi.Enabled = false;
                MaterialThread = new Thread(new ThreadStart(CaiJiStart));
                MaterialThread.Start();
                btnCaiJiStart.Text = "结束";
            }
            else
            {
                listCaiJi.Enabled = false;
                btnCaiJiPeiZhi.Enabled = true;
                btnCaiJiStart.Text = "开始";
                MaterialThread.Abort();
            }
        }
        #endregion

        private void listCaiJi_Click(object sender, EventArgs e)
        {
            MaterialThread.Abort();
            mOpera.Number = listCaiJi.SelectedIndex;
            while (MaterialThread.ThreadState != System.Threading.ThreadState.Stopped)
            {
                Thread.Sleep(500);
            }
            MaterialThread = new Thread(new ThreadStart(CaiJiStart));
            MaterialThread.Start();
        }

        private void btnLoadInfo_Click(object sender, EventArgs e)
        {
            if (LoadGame())
            {
                btnSetCinty.Enabled = true;
                btnLianJiStart.Enabled = true;
                btnCaiJiPeiZhi.Enabled = true;
                chkChuanQiang.Enabled = true;
                chkFly.Enabled = true;
                chkRuMo.Enabled = true;
                chkYinChang.Enabled = true;
            }
            else
            {
                MessageBox.Show("加载游戏失败");
            }
        }

        
        private void btnAddSkills_Click(object sender, EventArgs e)
        {
            if (listAllSkills.Items.Count > 0)
            {
                SkillsList.Rows.Add(listAllSkills.SelectedValue.ToString(), listAllSkills.Text.Trim());
                listSelectSkills.DisplayMember = "SkillsName";
                listSelectSkills.ValueMember = "SkillsID";//5^1^a^s^p^x
                listSelectSkills.DataSource = SkillsList;
            }
        }

       
        private void btnDelSkills_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < SkillsList.Rows.Count; i++)
            {
                if (listSelectSkills.SelectedValue.ToString() == SkillsList.Rows[i]["SkillsID"].ToString())
                {
                    SkillsList.Rows.RemoveAt(i);
                }
            }
        }

        #region //副本功能

        private void chkFly_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFly.Checked)
            {
                人物信息.Fly();
            }
            else
            {
                人物信息.NoFly();
            }
        }

        private void chkYinChang_CheckedChanged(object sender, EventArgs e)
        {
            if (chkYinChang.Checked)
            {
                人物信息.YinCang();
            }
            else
            {
                人物信息.NoYinCang();
            }
        }

        private void chkChuanQiang_CheckedChanged(object sender, EventArgs e)
        {
            if (chkChuanQiang.Checked)
            {
                人物信息.ChuanQiang();
            }
            else
            {
                人物信息.NoChuanQiang();
            }
        }

        private void chkRuMo_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRuMo.Checked)
            {
                人物信息.ChuanQiang();
            }
            else
            {
                人物信息.NoChuanQiang();
            }
        }

        #endregion

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void radio2_CheckedChanged(object sender, EventArgs e)
        {
            configClass.Is_Music_Did = radio2.Checked;
        }

        /// <summary>
        /// 设置回城地点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSetCinty_Click(object sender, EventArgs e)
        {
            configClass.CityNPC_X = 人物信息.坐标.X;
            configClass.CityNPC_Y = 人物信息.坐标.Y;//5%1%a%s%p%x
            configClass.CityNPC_Z = 人物信息.坐标.Z;
        }

        private void btnhelp_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "help.chm");
        }

       
    }
}