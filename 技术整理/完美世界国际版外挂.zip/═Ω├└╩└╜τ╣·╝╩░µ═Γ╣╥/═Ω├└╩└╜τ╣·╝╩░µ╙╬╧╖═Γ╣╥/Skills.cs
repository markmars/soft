﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
   public class Skills:MemoryWork
    {
       /// <summary>
       /// 初始化技能信息
       /// </summary>
       /// <param name="address"></param>
       /// <param name="EProcess"></param>
        public Skills(int address, IntPtr EProcess)
            : base(EProcess)
        {
            this.address = ReadMemoryInt(address); ;

            this.EProcess = EProcess;

        }


        int address = 0;

        IntPtr EProcess;

        public int Address
        {
            get { return address; }
        }

        public int ID
        {
            get { return ReadMemoryInt(address + 8); }
        }

        public string 名称
        {
            get
            {
                int 名称指针 = ReadMemoryInt(address + 4);
                名称指针 = ReadMemoryInt(名称指针 + 4);
                名称指针 = ReadMemoryInt(名称指针 + 0xC);
                return ReadMemoryString(名称指针);
            }
        }

        public int 释放间隔
        {
            get { return ReadMemoryInt(address + 0x14); }
        }

       public int 冷却时间
       {
           get { return ReadMemoryInt(address + 0x10); }
       }


        public bool 是否可用
        {
            get
            {
                int i = ReadMemoryInt(address + 0x2C);
                if (i != 0)
                {
                    return true;//5%1%a%s%p%x
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
