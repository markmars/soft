﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;
using AsmCls;

namespace 完美世界国际版游戏外挂
{
    class Call
    {
        public static int pid;

        /// <summary>
        /// 移动
        /// </summary>
        /// <param name="IsFly">是否飞行</param>
        /// <param name="x">目的地X坐标</param>
        /// <param name="y">目的地Y坐标</param>
        /// <param name="z">目的地Z坐标</param>
        public static void 移动(bool IsFly, byte[] x, byte[] y, byte[] z)
        {
            Int32 X = System.BitConverter.ToInt32(x, 0);
            Int32 Y = System.BitConverter.ToInt32(y, 0);
            Int32 Z = System.BitConverter.ToInt32(z, 0);

            AsmClass asm = new AsmClass();
            asm.Pushad();

            asm.Mov_EAX_DWORD_Ptr(MemoryAddress.总地址);
            asm.Mov_EBX_DWORD_Ptr_EAX_Add(0x20);
            asm.Mov_ECX_DWORD_Ptr_EBX_Add(MemoryAddress.MovePartial);
            asm.Push(1);
            asm.Mov_EDX(MemoryAddress.MoveCall1);
            asm.Call_EDX();

            asm.Mov_EDI_EAX();
            asm.Lea_EAX_DWORD_Ptr_ESP_Add(0x18);
            asm.Push_EAX();
            asm.Push(IsFly ? 1 : 0);
            asm.Mov_ECX_EDI();
            asm.Mov_EDX(MemoryAddress.MoveCall2);
            asm.Call_EDX();

            asm.Push(0);
            asm.Push(1);
            asm.Push_EDI();
            asm.Mov_ECX_DWORD_Ptr_EBX_Add(MemoryAddress.MovePartial);
            asm.Push(1);
            asm.Mov_EDX(MemoryAddress.MoveCall3);
            asm.Call_EDX();

            asm.Mov_EAX_DWORD_Ptr(MemoryAddress.总地址);
            asm.Mov_EAX_DWORD_Ptr_EAX_Add(0x20);
            asm.Mov_EAX_DWORD_Ptr_EAX_Add(MemoryAddress.MovePartial);
            asm.Mov_EAX_DWORD_Ptr_EAX_Add(0x30);
            asm.Mov_ECX_DWORD_Ptr_EAX_Add(0x4);
            asm.Mov_EAX(X);
            asm.Mov_DWORD_Ptr_ECX_ADD_EAX(0x20);
            asm.Mov_EAX(Z);
            asm.Mov_DWORD_Ptr_ECX_ADD_EAX(0x24);
            asm.Mov_EAX(Y);
            asm.Mov_DWORD_Ptr_ECX_ADD_EAX(0x28);

            asm.Popad();
            asm.Ret();
            asm.RunAsm(pid);
        }

        /// <summary>
        /// 发包操作
        /// </summary>
        /// <param name="codeByte">发送的内容</param>
        public static void FaBao_Call( byte[] codeByte)
        {

            AsmClass asm = new AsmClass();
            int codeAddress = asm.WriterToMemory(codeByte, pid);
            if (codeAddress > 0)
            {
                asm.Pushad();
                asm.Mov_EAX_DWORD_Ptr(MemoryAddress.Call_Zong);
                asm.Mov_ECX_DWORD_Ptr_EAX_Add(0x20);
                asm.Push(codeByte.Length);
                asm.Push(codeAddress);
                asm.Mov_EAX(MemoryAddress.Call_FaBao_Address);
                asm.Call_EAX();
                asm.Popad();
                asm.Ret();
                asm.RunAsm(pid);
                asm.ReleaseMemory(codeAddress, codeByte.Length, pid);
            }
        }

        /// <summary>
        /// 普通攻击
        /// </summary>
        /// <param name="GID">攻击对象编号</param>
        public static void CallPuTongGongJi( int GID)
        {
            AsmClass asm = new AsmClass();
            asm.Pushad();
            asm.Push(GID);
            asm.Mov_EAX(MemoryAddress.Call_普通攻击);
            asm.Call_EAX();
            asm.Popad();
            asm.Ret();
            asm.RunAsm(pid);
        }
 
          /// <summary>
          /// 使用技能
          /// </summary>
          /// <param name="SkillsID">技能编号</param>
        public static void UseSkills(int SkillsID)
        {
            
            AsmClass asm = new AsmClass();
            
            asm.Pushad();
            asm.Mov_ECX(0x94CDB0);
            asm.Push(-1);
            asm.Push(0);
            asm.Mov_EDX_DWORD_Ptr_ECX_Add(0x1C);
            asm.Push(0);
            asm.Push(SkillsID);
            asm.Mov_ECX_DWORD_Ptr_EDX_Add(0x20);
            
            asm.Mov_EAX(MemoryAddress.UseSkillsCall);
            asm.Call_EAX();
            asm.Popad();
            asm.Ret();
            asm.RunAsm(pid);
        }

        /// <summary>
        /// 采集材料
        /// </summary>
        /// <param name="id"></param>
        public static void CaiJi(int id)
        {
            AsmClass asm = new AsmClass();
            asm.Pushad();
            asm.Push(0);
            asm.Push(0xC01);
            asm.Push(0);
            asm.Push(0);
            asm.Push(id);
            asm.Mov_EAX(MemoryAddress.CaiJiCall);
            asm.Call_EAX();
            asm.Add_ESP(0x14);
            asm.Popad();
            asm.Ret();
            asm.RunAsm(pid);
        }

        /// <summary>
        /// 全部修理
        /// </summary>
        public static void Repair()
        {
            AsmClass asm = new AsmClass();
            asm.Pushad();
            asm.Push(-1);
            asm.Push(0);
            asm.Push(0);
            asm.Mov_EAX(MemoryAddress.RepairCall);
            asm.Call_EAX();
            asm.Add_ESP(0x0c);
            asm.Popad();
            asm.Ret();
            asm.RunAsm(pid);

        }

        /// <summary>
        /// 出售物品
        /// </summary>
        /// <param name="SN">物品SN</param>
        /// <param name="pos">物品在包裹位置</param>
        /// <param name="number">数量</param>
        public static void Sell(int SN, int pos, int number)
        {
            SellOrBuy(SN, pos, number, MemoryAddress.SellCall);
        }

        /// <summary>
        /// 买物品
        /// </summary>
        /// <param name="SN">物品SN</param>
        /// <param name="pos">物品在NPC包裹位置</param>
        /// <param name="number">数量</param>
        public static void Buy(int SN, int pos, int number)
        {
            SellOrBuy(SN, pos, number, MemoryAddress.BuyCall);
        }

        /// <summary>
        /// 执行买卖操作
        /// </summary>
        /// <param name="SN">物品SN</param>
        /// <param name="pos">物品在包裹位置</param>
        /// <param name="number">数量</param>
        /// <param name="call">Call地址</param>
        private static void SellOrBuy(int SN,int pos,int number,int call)
        {
            AsmClass asm = new AsmClass();
            asm.Pushad();
            asm.SUB_ESP(0xC);
            asm.Mov_EAX(SN);
           // asm.Mov_EAX_DWORD_Ptr_ESP();
            asm.Mov_DWORD_Ptr_ESP_EAX();
            asm.Mov_EAX(pos);
            asm.Mov_DWORD_Ptr_ESP_ADD_EAX(4);
            //asm.Mov_EAX_DWORD_Ptr_ESP_Add(4);
            asm.Mov_EAX(number);
            asm.Mov_DWORD_Ptr_ESP_ADD_EAX(8);
           // asm.Mov_EAX_DWORD_Ptr_ESP_Add(8);
            asm.Push_ESP();
            asm.Push(1);
            asm.Mov_ECX(call);
            asm.Call_ECX();
            asm.Add_ESP(8);
            asm.Add_ESP(0xC);
            asm.Popad();
            asm.Ret();
            asm.RunAsm(pid);
        }
    }
}
