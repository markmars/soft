﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{

    class NPC : MemoryWork
    {

        /// <summary>
        /// 初始化NPC信息
        /// </summary>
        /// <param name="address"></param>
        /// <param name="EProcess"></param>
        public NPC(int address, IntPtr EProcess)
            : base(EProcess)
        {
            int NPC偏移 = ReadMemoryInt(address);
            if (NPC偏移 <= 0)
            {
                return;
            }
            else
            {
                int NPC指针 = ReadMemoryInt(NPC偏移 + 0x4);

                int NPC种类 = ReadMemoryInt(NPC指针 + 0xB4);
                if (NPC种类 != 7)
                {
                    return;
                }
                else
                {
                    this.address = NPC指针;//5~1-a-s-p-x
                    this.EProcess = EProcess;
                }
            }
        }


        int address = 0;

        IntPtr EProcess;

        public int Address
        {
            get { return address; }
        }

        public Coordinate 坐标
        {
            get { return new Coordinate(address, EProcess); }
        }

        public int ID
        {
            get { return ReadMemoryInt(address + 0x11C); }
        }

        public string 名称
        {
            get
            {
                int 名称指针 = ReadMemoryInt(address + 0x238);//5-1-a-s-p-x
                return ReadMemoryString(名称指针);
            }
        }
    }
}
