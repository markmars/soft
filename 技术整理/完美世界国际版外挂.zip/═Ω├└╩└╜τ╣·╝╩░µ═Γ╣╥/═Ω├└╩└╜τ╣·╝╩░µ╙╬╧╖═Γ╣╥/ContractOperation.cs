﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;
using AsmCls;

namespace 完美世界国际版游戏外挂
{
    class ContractOperation
    {

        #region //发包Call

        /// <summary>
        /// 死亡回城复活
        /// </summary>
        public static void GoCityByDid()
        {
            Call_ByString("0400");
        }

        /// <summary>
        /// 回城
        /// </summary>
        public static void GoCity()
        {
            Call_ByString("2900A7000000000100000000");
        }

        public static void SelectNPC(int NPC_ID)
        {
            Call_ByString("2300" + intTohex(NPC_ID, 8));
        }

        /// <summary>
        /// 选人或选怪
        /// </summary>
        /// <param name="ID"></param>
        public static void SelectByID(int ID)
        {
            Call_ByString("0200" + intTohex(ID, 8));
        }

        /// <summary>
        /// 离开队伍
        /// </summary>
        public static void LeaveATroops()
        {

            Call_ByString("1e00");
        }

        /// <summary>
        /// 邀请组队
        /// </summary>
        /// <param name="RenID"></param>
        public static void ZuDui(int RenID)
        {
            Call_ByString("1B00" + intTohex(RenID, 8));

        }

        /// <summary>
        /// 转让队长
        /// </summary>
        /// <param name="RenID"></param>
        public static void ZhuanRangDuiZhang(int RenID)
        {
            Call_ByString("4800" + intTohex(RenID, 8));

        }

        /// <summary>
        /// 接受组队
        /// </summary>
        /// <param name="RenID"></param>
        public static void JieShouZuDui(int RenID)
        {
            Call_ByString("1C00" + intTohex(RenID, 8));

        }

        /// <summary>
        /// 普通攻击
        /// </summary>
        public static void PuTongGongJi()
        {
            Call_ByString("030000");
        }

        /// <summary>
        /// 使用物品
        /// </summary>
        /// <param name="Position">包裹内的位置</param>
        /// <param name="ID">物品编号</param>
        public static void UseArticleOperation(int Position, int ID)
        {
            Call_ByString("28000001" + intTohex(Position, 4) + intTohex(ID, 8));
        }

        /// <summary>
        /// 拾取地面物品
        /// </summary>
        /// <param name="SN"></param>
        /// <param name="ID"></param>
        public static void PichUp(int SN, int ID)
        {
            Call_ByString("0600" + intTohex(SN, 8) + intTohex(ID, 8));
        }

        /// <summary>
        /// 采集材料
        /// </summary>
        /// <param name="SN">材料类型编号</param>
        /// <param name="ID">材料编号</param>
        public static void CaiJi(int SN, int ID)
        {
            Call_ByString("0600" + intTohex(SN, 8) + intTohex(ID, 8));
        }


        /// <summary>
        /// 修理装备
        /// </summary>
        public static void Repair()
        {
            Call_ByString("25000300000006000000FFFFFFFF0000");
        }

        /// <summary>
        /// 出售物品
        /// </summary>
        /// <param name="pos"></param>
        /// <param name="id"></param>
        /// <param name="number"></param>
        public static void Sell(int pos, int id, int number)
        {
            Call_ByString("2500020000001C00000002000000" + intTohex(id, 8) + intTohex(pos, 4) + "01000000");
        }

       /// <summary>
        /// 使用技能
       /// </summary>
       /// <param name="JiNengID"></param>
       /// <param name="MuBiaoID"></param>
        public static void UserJiNeng(int JiNengID, int MuBiaoID)
        {
            Call_ByString("2900" + intTohex(JiNengID, 8) + "0001" + intTohex(MuBiaoID, 8));

        }

        /// <summary>
        /// 中断技能
        /// </summary>
        public static void ZhongDuanJiNeng()
        {
            Call_ByString("2E00");
        }

        public static void Call_ByString(string codeStr)
        {
            Call.FaBao_Call(Changebytes(codeStr));
        }


        /// <summary>
        /// 整数转十六进制
        /// </summary>
        /// <param name="value"></param>
        /// <param name="num"></param>
        /// <returns></returns>
        public static string intTohex(int value, int num)
        {
            string str1;
            string str2 = "";
            str1 = "0000000" + value.ToString("X");
            str1 = str1.Substring(str1.Length - num, num);
            for (int i = 0; i < str1.Length / 2; i++)
            {
                str2 = str2 + str1.Substring(str1.Length - 2 - 2 * i, 2);
            }
            return str2;
        }

        public static byte[] Changebytes(string asmPram)
        {
            byte[] reAsmCode = new byte[asmPram.Length / 2];
            for (int i = 0; i < reAsmCode.Length; i++)
            {
                reAsmCode[i] = Convert.ToByte(Int32.Parse(asmPram.Substring(i * 2, 2), System.Globalization.NumberStyles.AllowHexSpecifier));

            }
            return reAsmCode;
        }

        #endregion
    }
}
