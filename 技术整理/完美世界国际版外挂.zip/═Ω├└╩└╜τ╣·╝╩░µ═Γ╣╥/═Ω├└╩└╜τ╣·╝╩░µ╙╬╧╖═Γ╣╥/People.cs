﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
    class People :MemoryWork
    {

        /// <summary>
        /// 初始化人物信息
        /// </summary>
        /// <param name="address">总基址</param>
        /// <param name="EProcess">进程句柄</param>
        public People(int address, IntPtr EProcess)
            : base(EProcess)
        {
            int 一级地址 = ReadMemoryInt(address); 
            this.address = ReadMemoryInt(一级地址 + 0x20);
            this.EProcess = EProcess;
            X实际修真等级 = this.x修真等级;
        }

        int address;

        IntPtr EProcess;

        public int Address
        {
            get { return address; }
        }

        #region //及时人物信息获取

        public Coordinate 坐标
        {
            get { return new Coordinate(address, EProcess); }
        }

        public int ID
        {
            get { return ReadMemoryInt(address + 0x10); }
        }

        public string 名称
        {
            get
            {
                int 名称指针 = ReadMemoryInt(address + 0x5E0);
                return ReadMemoryString(名称指针);
            }
        }

        public int 生命上限
        {
            get { return ReadMemoryInt(address + 0x484); }
        }

        public int 魔法上限
        {
            get { return ReadMemoryInt(address + 0x488); }
        }

        public int 生命值
        {
            get { return ReadMemoryInt(address + 0x454); }
        }

        public int 魔法值
        {
            get { return ReadMemoryInt(address + 0x458); }
        }

        public int 等级
        {
            get { return ReadMemoryInt(address + 0x44C); }
        }

        public int 经验值
        {
            get { return ReadMemoryInt(address + 0x45C); }
        }

        public int 飞行状态
        {
            get { return ReadMemoryInt(address + 0x640); }
        }

        public int s选中怪物ID
        {
            get { return ReadMemoryInt(address + 1116); }
            set { WriteMemoryInt(address + 1116, value); }
        }

        public int z职业
        {
            get { return ReadMemoryInt(address + 0x5E8); }
        }

        public int x修真等级
        {
            get { return ReadMemoryInt(address + 0x450); }
            set { WriteMemoryInt(address + 0x450, value); }
        }

        public bool u正在使用技能
        {
            get
            {
                if (ReadMemoryInt(address + 0x69A) != 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        #endregion

        #region //人物过去状态

        float old_X;

        public float Old_X
        {
            get { return old_X; }
            set { old_X = value; }
        }

        float old_Y;

        public float Old_Y
        {
            get { return old_Y; }
            set { old_Y = value; }
        }

        float old_Z;

        public float Old_Z
        {
            get { return old_Z; }
            set { old_Z = value; }
        }

        int old_EXP;

        public int Old_EXP
        {
            get { return old_EXP; }
            set { old_EXP = value; }
        }

        int selectMonsterID;

        public int SelectMonsterID
        {
            get { return selectMonsterID; }
            set { selectMonsterID = value; }
        }

        int selectMonsterPH;

        public int SelectMonsterPH
        {
            get { return selectMonsterPH; }
            set { selectMonsterPH = value; }
        }

        int waitTimer;

        public int WaitTimer
        {
            get { return waitTimer; }
            set { waitTimer = value; }
        }

        int moveTimer;

        public int MoveTimer
        {
            get { return moveTimer; }
            set { moveTimer = value; }
        }

        int x实际修真等级;

        public int X实际修真等级
        {
            get { return x实际修真等级; }
            set { x实际修真等级 = value; }
        }


        #endregion

        /// <summary>
        /// 移动到指定坐标
        /// </summary>
        /// <param name="coor">目的坐标</param>
        public void Move(Coordinate coor)
        {
            Move(coor.X, coor.Y, coor.Z);
        }

        /// <summary>
        /// 移动到指定坐标
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        public void Move(float x, float y, float z)
        {
            byte[] bx = System.BitConverter.GetBytes(x);//5*1*a*s*p*x
            byte[] by = System.BitConverter.GetBytes(y);
            byte[] bz = System.BitConverter.GetBytes(z);
            if (飞行状态 > 1)
            {
                Call.移动(true, bx, by, bz);
            }
            else
            {
                Call.移动(false, bx, by, bz);
            }
        }

        /// <summary>
        /// 判断人物是否在动
        /// </summary>
        /// <returns></returns>
        public bool IsMove()
        {
            if (Old_X == 坐标.X && Old_Y == 坐标.Y && Old_Z == 坐标.Z)
            {
                return false;
            }
            else
            {
                Old_X = 坐标.X; Old_Y = 坐标.Y; Old_Z = 坐标.Z;
                return true;
            }
        }

        public bool IsArrive(Coordinate coor)
        {
           return  IsArrive(coor.X, coor.Y, coor.Z);
        }

        /// <summary>
        /// 判断人物是否在走动
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        /// <returns></returns>
        public bool IsArrive(float x,float y,float z)
        {
            if (坐标.X < x + 10 && 坐标.Y < y + 10 && 坐标.Z < z + 10 && 坐标.X > x - 10 && 坐标.Y > y -10 && 坐标.Z > z - 10)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Fly()
        {
            WriteMemoryInt(address + 0x640, 16);
        }

        public void NoFly()
        {
            WriteMemoryInt(address + 0x640, 0);
        }

        public void ChuanQiang()
        {
            byte[] info = System.BitConverter.GetBytes(232311258);
            WriteMemoryByte(MemoryAddress.穿墙地址, info);
        }

        public void NoChuanQiang()
        {
            byte[] info = System.BitConverter.GetBytes(232311257);
            WriteMemoryByte(MemoryAddress.穿墙地址, info);
        }


        public void YinCang()
        {
            byte[] info = System.BitConverter.GetBytes(1155093370);
            WriteMemoryByte(MemoryAddress.隐藏地址, info);
        }

        public void NoYinCang()
        {
            byte[] info = System.BitConverter.GetBytes(1155093371);
            WriteMemoryByte(MemoryAddress.隐藏地址, info);
        }

        public void RuMo()
        {
            x修真等级 = 32;//5&1&a&s&p&x
        }

        public void NoRuMo()
        {
            x修真等级 = X实际修真等级;
        }
    }
}
