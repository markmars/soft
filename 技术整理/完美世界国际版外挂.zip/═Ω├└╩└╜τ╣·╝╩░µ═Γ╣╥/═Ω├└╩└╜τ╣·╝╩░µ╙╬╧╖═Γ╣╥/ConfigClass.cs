﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
   public class ConfigClass
    {
        #region //城里药师(NPC)

        float cityNPC_X=1357.5f;

        /// <summary>
        /// 城里药师(NPC) X坐标
        /// </summary>
        public float CityNPC_X
        {
            get { return cityNPC_X; }
            set { cityNPC_X = value; }
        }

        float cityNPC_Y=-1329.4f;

        /// <summary>
        /// 城里药师(NPC) Y坐标
        /// </summary>
        public float CityNPC_Y
        {
            get { return cityNPC_Y; }
            set { cityNPC_Y = value; }
        }

        float cityNPC_Z=218.9f;

        /// <summary>
        /// 城里药师(NPC) Z坐标
        /// </summary>
        public float CityNPC_Z
        {
            get { return cityNPC_Z; }
            set { cityNPC_Z = value; }
        }

        #endregion

        #region //挂机地点

        float x;

        /// <summary>
        /// 挂机点 X坐标
        /// </summary>
        public float X
        {
            get { return x; }
            set { x = value; }
        }

        float y;

        /// <summary>
        /// 挂机点 Y坐标
        /// </summary>
        public float Y
        {
            get { return y; }
            set { y = value; }
        }

        float z;

        /// <summary>
        /// 挂机点 Z坐标
        /// </summary>
        public float Z
        {
            get { return z; }
            set { z = value; }
        }

        #endregion

        int[] skillsList;

        /// <summary>
        /// 选用技能数组
        /// </summary>
        public int[] SkillsList
        {
            get { return skillsList; }
            set { skillsList = value; }
        }

        int skillsNumber;

        /// <summary>
        /// 技能序号
        /// </summary>
        public int SkillsNumber
        {
            get { return skillsNumber; }
            set { skillsNumber = value; }
        }

        int frskillsID;

        /// <summary>
        ///  首发技能
        /// </summary>
       public int FrskillsID
        {
            get { return frskillsID; }
            set { frskillsID = value; }
        }

        int reskillsID;

        /// <summary>
        ///  默认技能
        /// </summary>
        public int ReskillsID
        {
            get { return reskillsID; }
            set { reskillsID = value; }
        }

        int b_Xue;

        /// <summary>
        /// 血量补给点
        /// </summary>
        public int B_Xue
        {
            get { return b_Xue; }
            set { b_Xue = value; }
        }

        int b_Xue2;

        /// <summary>
        /// 血量补给点
        /// </summary>
        public int B_Xue2
        {
            get { return b_Xue2; }
            set { b_Xue2 = value; }
        }

        int b_Lan;

        /// <summary>
        /// 真气补给点
        /// </summary>
        public int B_Lan
        {
            get { return b_Lan; }
            set { b_Lan = value; }
        }

        bool is_Music_Did=false;

        public bool Is_Music_Did
        {
            get { return is_Music_Did; }
            set { is_Music_Did = value; }
        }

        string music_Did="did.wav";

        /// <summary>
        /// 死亡警报音乐
        /// </summary>
        public string Music_Did
        {
            get { return music_Did; }
            set { music_Did = value; }
        }

        string music_Q="dati.wav";

        /// <summary>
        /// 答题警报音乐
        /// </summary>
        public string Music_Q
        {
            get { return music_Q; }
            set { music_Q = value; }
        }

        string caiJiFileName;

        /// <summary>
        /// 采集配置文件
        /// </summary>
        public string CaiJiFileName
        {
            get { return caiJiFileName; }
            set { caiJiFileName = value; }
        }

        int pickUpDistance = 0;


        /// <summary>
        /// 物品拾取距离
        /// </summary>
        public int PickUpDistance
        {
            get { return pickUpDistance; }
            set { pickUpDistance = value; }
        }

        string b_XueYaoName;

        public string B_XueYaoName
        {
            get { return b_XueYaoName; }
            set { b_XueYaoName = value; }
        }

        int b_XueSkills;

        public int B_XueSkills
        {
            get { return b_XueSkills; }
            set { b_XueSkills = value; }
        }

       string b_LanYaoName;

        public string B_LanYaoName
        {
            get { return b_LanYaoName; }
            set { b_LanYaoName = value; }
        }
    }
}
