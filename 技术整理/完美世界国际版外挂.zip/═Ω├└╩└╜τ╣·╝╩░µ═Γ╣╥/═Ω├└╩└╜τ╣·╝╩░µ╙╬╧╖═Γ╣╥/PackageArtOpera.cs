﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
    class PackageArtOpera:MemoryWork
    {
        int address;

        IntPtr EProcess;

        /// <summary>
        /// 初始化包裹控制类
        /// </summary>
        /// <param name="address">人物信息</param>
        /// <param name="EProcess">进程句柄</param>
        public PackageArtOpera(int address, IntPtr EProcess)
            : base(EProcess)
        {
            this.address = ReadMemoryInt(address + 0xB60);
            this.EProcess = EProcess;
        }

        public int 包裹最大容量
        {
            get { return ReadMemoryInt(address + 0x10); }
        }

        public int 包裹物品基址
        {
            get { return ReadMemoryInt(address + 0xC); }
        }

        public IList<PackageArt> 物品列表()
        {
            IList<PackageArt> ilist = new List<PackageArt>();

            for (int i = 0; i < 50; i++)
            {
                PackageArt 物品 = new PackageArt(包裹物品基址 + 4 * i, EProcess);
                if (物品.Address != 0 && 物品.名称.Trim().Length > 0 && 物品.物品类型==9)
                {
                    物品.Pos = i;
                    ilist.Add(物品);
                }
            }

            return ilist;
        }

        public PackageArt SelectByID(int 物品ID)
        {
            IList<PackageArt> ilist = 物品列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].ID == 物品ID)
                {
                    return ilist[i];
                }
            }
            return null;
        }

        public PackageArt SelectByName(string 物品名称)
        {
            IList<PackageArt> ilist = 物品列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].名称.IndexOf(物品名称) >= 0)
                {
                    return ilist[i];
                }
            }
            return null;
        }

        public IList<PackageArt> SelectIlistByName(string 物品名称)
        {
            IList<PackageArt> ilist = 物品列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].名称.IndexOf(物品名称) < 0)
                {
                    ilist.RemoveAt(i);
                }
            }
            return ilist;
        }
    }
}
