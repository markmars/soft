﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;

namespace 完美世界国际版游戏外挂
{
    public class MaterialOperation
    {
        /// <summary>
        /// 初始化材料采集类，设计材料在游戏环境中的信息
        /// </summary>
        /// <param name="FileName"></param>
        /// <param name="EProcess"></param>
        public MaterialOperation(string FileName, IntPtr EProcess)
        {
            
            FileStream fileStream = new FileStream(FileName, FileMode.OpenOrCreate);
            StreamReader strReander = new StreamReader(fileStream);
            this.EProcess = EProcess;
            while (!strReander.EndOfStream)
            {
                string[] str = strReander.ReadLine().Split(' ');
                MaterialInfo info = new MaterialInfo(str[3], float.Parse(str[0]), float.Parse(str[1]), float.Parse(str[2]));
                infoList.Add(info);
            }
            strReander.Dispose();
            strReander.Close();
            fileStream.Close();
            this.artucleOpera = new ArticleOperation(MemoryAddress.总地址, EProcess);
            this.people = new People(MemoryAddress.总地址, EProcess);
            Materialinfo = infoList[0];
        }

        IntPtr EProcess;

        IList<MaterialInfo> infoList=new List<MaterialInfo>();

        ArticleOperation artucleOpera;

        People people;

        bool startTag = false;

        public bool StartTag
        {
            get { return startTag; }
            set { startTag = value; }
        }

        public IList<MaterialInfo> InfoList
        {
            get { return infoList; }
            set { infoList = value; }
        }

        int number = 0;

        public int Number
        {
            get { return number; }
            set { number = value; }
        }


        public MaterialInfo Materialinfo
        {
            get { return infoList[number]; }
            set { infoList[number] = value; }
        }

        public void Next()
        {
            if (number < infoList.Count - 1)
            {
                number++;
            }
            else
            {
                number = 0;
            }
            Thread.Sleep(100);
        }

        /// <summary>
        /// 移动到材料附近
        /// </summary>
        public void MoveToM()
        {
            while (true)
            {
                people.Move(Materialinfo.X, Materialinfo.Y, Materialinfo.Z+20);

                if (people.IsArrive(Materialinfo.X, Materialinfo.Y, Materialinfo.Z+20))
                {
                    while (true)
                    {
                        people.Move(Materialinfo.X, Materialinfo.Y, Materialinfo.Z);
                        if (people.IsArrive(Materialinfo.X, Materialinfo.Y, Materialinfo.Z))
                        {
                            break;
                        }
                        else
                        {
                            people.Move(Materialinfo.X, Materialinfo.Y, Materialinfo.Z);
                            Thread.Sleep(1000);
                        }
                    }
                    break;
                }
                else
                {
                    people.Move(Materialinfo.X, Materialinfo.Y, Materialinfo.Z+20);
                    Thread.Sleep(1000);
                }

            }
        }

        /// <summary>
        /// 移动到可采集点
        /// </summary>
        public void CaiJi()
        {
            int i = 0;
            
            while (i < 60)
            {
                
                Article art = artucleOpera.SelectByName(Materialinfo.Name);
                if (art!=null && art.Address != 0)
                {
                    CaiJi(art);
                    while (true)
                    {
                        people.Move(Materialinfo.X, Materialinfo.Y, Materialinfo.Z + 20);
                        if (people.IsArrive(Materialinfo.X, Materialinfo.Y, Materialinfo.Z + 20))
                        {
                            break;
                        }
                        else
                        {
                            people.Move(Materialinfo.X, Materialinfo.Y, Materialinfo.Z + 20);
                            Thread.Sleep(1000);
                        }
                    }
                    break;
                }
                else
                {
                    Thread.Sleep(1000);
                    i++;
                }
            }
        }

        /// <summary>
        /// 采集材料
        /// </summary>
        /// <param name="art">要采集的材料信息</param>
        public void CaiJi(Article art)
        {
            people.Move(art.坐标);
            while (art.坐标.X != 0.0f)
            {
                if (!people.IsArrive(art.坐标))
                {
                    people.Move(art.坐标);
                    Thread.Sleep(1000);

                }
                else
                {
                    Call.CaiJi(art.物品SN);
                    if (art.ID != 0 && artucleOpera.SelectByID(art.ID) != null && artucleOpera.SelectByID(art.ID).Address != 0)
                    {
                        Thread.Sleep(2000);
                    }
                    else
                    {
                        people.Move(Materialinfo.X, Materialinfo.Y, Materialinfo.Z + 20);
                        if (people.IsArrive(Materialinfo.X, Materialinfo.Y, Materialinfo.Z + 20))
                        {
                            break;
                        }
                        else
                        {
                            people.Move(Materialinfo.X, Materialinfo.Y, Materialinfo.Z + 20);
                            Thread.Sleep(1000);
                        }
                    }
                }
            }
        }

       

        public void Stop()
        {
            startTag = false;
        }
    }
}
