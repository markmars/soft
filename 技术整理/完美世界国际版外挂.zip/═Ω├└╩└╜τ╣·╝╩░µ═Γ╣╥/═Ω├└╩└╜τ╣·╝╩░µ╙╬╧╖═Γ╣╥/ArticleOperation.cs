﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
    class ArticleOperation : MemoryWork
    {
        int address;

        IntPtr EProcess;

        /// <summary>
        /// 初始化物品操作类
        /// </summary>
        /// <param name="address">总基址</param>
        /// <param name="EProcess">进程句柄</param>
        public ArticleOperation(int address, IntPtr EProcess)
            : base(EProcess)
        {
            int 一级地址 = ReadMemoryInt(address);
            int 周围环境 = ReadMemoryInt(一级地址 + 0x8);
            this.address = ReadMemoryInt(周围环境 + 0x28);
            this.EProcess = EProcess;
        }

        public int 物品数量
        {
            get { return ReadMemoryInt(address + 0x14); }
        }

        public int 物品列表指针
        {
            get { return ReadMemoryInt(address + 0x18); }
        }

        public IList<Article> SelectIlistByDistance(float Distance)
        {
            IList<Article> ilist = 物品列表();

            IList<Article> Newilist = new List<Article>();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].距离 <= Distance)
                {
                    Newilist.Add(ilist[i]);
                }
            }
            return Newilist;
        }

        public IList<Article> 物品列表()
        {
            IList<Article> ilist = new List<Article>();

            for (int i = 0; i < 768; i++)
            {
                Article 物品 = new Article(物品列表指针 + 4 * i, EProcess);
                if (物品.Address != 0)
                {
                    ilist.Add(物品);
                }
            }

            return ilist;
        }

        public Article SelectByID(int 物品ID)
        {
            IList<Article> ilist = 物品列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].ID == 物品ID)
                {
                    return ilist[i];
                }
            }
            return null;
        }

        public Article SelectByName(string 物品名称)
        {
            IList<Article> ilist = 物品列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].名称.IndexOf(物品名称) >= 0 && ilist[i].距离<60)
                {
                    return ilist[i];
                }
            }
            return null;
        }

        public IList<Article> SelectIlistByName(string 物品名称)
        {
            IList<Article> ilist = 物品列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].名称.IndexOf(物品名称) < 0)
                {
                    ilist.RemoveAt(i);
                }
            }
            return ilist;
        }
    }
}
