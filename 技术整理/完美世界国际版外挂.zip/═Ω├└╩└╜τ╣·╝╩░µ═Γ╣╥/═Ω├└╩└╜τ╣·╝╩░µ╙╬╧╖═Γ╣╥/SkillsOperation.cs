﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
   public class SkillsOperation:MemoryWork
    {        
        int address;

        IntPtr EProcess;

        /// <summary>
        /// 初始化技能控制信息
        /// </summary>
        /// <param name="address">人物信息地址</param>
        /// <param name="EProcess">进程句柄</param>
        public SkillsOperation(int address, IntPtr EProcess)
            : base(EProcess)
        { 
            this.address = address;
            this.EProcess = EProcess;
        }

        public int 技能数量
        {
            get { return ReadMemoryInt(address + 0xbFC); }
        }

        public int 技能列表指针
        {
            get { return ReadMemoryInt(address + 0xbF8); }
        }

        public IList<Skills> 技能列表()
        {
            IList<Skills> ilist = new List<Skills>();

            for (int i = 0; i < 技能数量; i++)
            {
                Skills 技能 = new Skills(技能列表指针 + 4 * i, EProcess);
                if (技能.Address != 0 )
                {
                    ilist.Add(技能);
                }
            }

            return ilist;
        }

        public Skills SelectByID(int 技能ID)
        {
            IList<Skills> ilist = 技能列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].ID == 技能ID)
                {
                    return ilist[i];
                }
            }
            return null;
        }

        public Skills SelectByName(string 技能名称)
        {
            IList<Skills> ilist = 技能列表();

            for (int i = 0; i < ilist.Count; i++)
            {
                if (ilist[i].名称.IndexOf(技能名称) >= 0)
                {
                    return ilist[i];
                }
            }
            return null;
        }
    }
}
