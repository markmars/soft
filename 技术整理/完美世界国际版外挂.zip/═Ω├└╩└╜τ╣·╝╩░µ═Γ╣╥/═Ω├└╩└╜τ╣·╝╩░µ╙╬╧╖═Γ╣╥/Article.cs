﻿//作者：孙中刚
//QQ：304826832
//声明：转载或使用此源码请先与作者联系

//******************************************************


using System;
using System.Collections.Generic;
using System.Text;

namespace 完美世界国际版游戏外挂
{
   public  class Article:MemoryWork
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="address">总基址</param>
        /// <param name="EProcess">进程句柄</param>
        public Article(int address, IntPtr EProcess)
            : base(EProcess)
        {
            int 物品偏移 = ReadMemoryInt(address);
            if (物品偏移 <= 0)
            {
                return;
            }
            else
            {
                this.address = ReadMemoryInt(物品偏移 + 0x4);
                this.EProcess = EProcess;

            }
        }

        int address=0;

        IntPtr EProcess;

        public int Address
        {
            get { return address; }
        }

        public Coordinate 坐标
        {
            get { return new Coordinate(address, EProcess); }
        }

        public int ID
        {
            get { return ReadMemoryInt(address + 0x110); }
        }

        //系统ID(类型ID)
        public int 物品SN
        {
            get { return ReadMemoryInt(address + 0x10C); }
        }

        public string 名称
        {
            get
            {
                int 名称指针 = ReadMemoryInt(address + 0x164);//5~1-a-s-p-x
                return ReadMemoryString(名称指针);
            }
        }

        public float 距离
        {
            get { return ReadMemoryFloat(address + 0x154); }
        }

    }
}
