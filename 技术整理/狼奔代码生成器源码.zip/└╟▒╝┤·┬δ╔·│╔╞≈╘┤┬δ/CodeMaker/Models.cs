﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{
    public class Models : BaseMain
    {
        /// <summary>
        /// 自定义属性     
        /// </summary>
        public string m_CustomEntity = "^CustomEntity^";
        /// <summary>
        /// 自定义元数据，非外键连接    
        /// </summary>
        public string m_CustomMetadataNotRef = @"
        [Display(Name = @主键@)]
        public string Id { get; set; }
        [Display(Name = @主键@)]
        public string IdOld { get; set; }
        ";
        /// <summary>
        /// 自定义元数据,外键连接 
        /// </summary>
        public string m_CustomMetadataRef = @"
        [Display(Name = @主键@)]
        public string IdOld { get; set; }
        ";

        /// <summary>
        /// 自定义元数据,外键连接 
        /// </summary>
        public string m_parentId = @"     
    public class ^ReplaceClassCode^Sef
    {    
            public string _parentId { get; set; }

        ";
        public bool DoModels(Table replaceClass, List<Reference> reference, ref List<string> fileName)
        {
            int order = 1;
            string customEntity = string.Empty;
            int parent = 0;
            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                //包含非外键的Id
                foreach (var item in replaceClass.refNotId)
                {
                    customEntity += m_CustomMetadataNotRef.Replace('@', '"')
                        .Replace("Id", item.RefTable + item.Id)
                        .Replace("主键", item.RefTableName);
                }
            }
            if (replaceClass.refId != null && replaceClass.refId.Count() > 0)
            {
                foreach (var item in replaceClass.refId)
                {
                    //查询自连接列                 
                    var myselfRef = from m in m_MyselfIdClass
                                    from f in replaceClass.Attribute
                                    where m.ParentTable == f.TableId
                                    where f.Code == item.Id
                                    select f;
                    if (myselfRef != null && myselfRef.Count() > 0 && item.RefTable == myselfRef.FirstOrDefault().BelongClass)
                    {//自连接列 
                        parent = 1;
                    }

                    //外连接
                    customEntity += m_CustomMetadataRef.Replace('@', '"')
                     .Replace("Id", item.Ref)
                     .Replace("主键", item.RefTableName);
                }
            }
            foreach (var item in replaceClass.Attribute)
            {
                //主键，并定义为Id的 或者定义为 CreateTime，不启用脚手架，数据库部分需要使用newid()或者自增
                if (!string.IsNullOrWhiteSpace(item.Code))
                {                //时间戳，等不生成代码
                    if (item.Code.Contains("Version"))
                    {
                        continue;
                    }

                    if (replaceClass.ZhuJianId != null && replaceClass.ZhuJianId.Contains(item.AttributeId))
                    {
                        m_Content.Append("\t\t\t[ScaffoldColumn(false)]\n");
                        m_Content.Append("\t\t\t[Display(Name = \"" + item.Name + "\", Order = " + order + ")]\n");
                        m_Content.Append("\t\t\tpublic string " + item.Code + " { get; set; }\n\n");
                        order++;
                        continue;
                    }
                    else if (item.Code == "CreateTime" || item.Code == "UpdateTime")
                    {
                        m_Content.Append("\t\t\t[ScaffoldColumn(false)]\n");
                        m_Content.Append("\t\t\t[Display(Name = \"" + item.Name + "\", Order = " + order + ")]\n");
                        m_Content.Append("\t\t\tpublic DateTime? " + item.Code + " { get; set; }\n\n");
                        order++;
                        continue;
                    }
                    else
                    {
                        if (!string.IsNullOrWhiteSpace(item.Mandatory) && item.Mandatory.Trim() == "1")
                        {
                            m_Content.Append("\t\t\t[Required(ErrorMessage = @不能为空@)]\n".Replace('@', '"'));
                        }
                        m_Content.Append("\t\t\t[ScaffoldColumn(true)]\n");
                    }
                }
                else
                {
                    continue;
                }

                if (!string.IsNullOrEmpty(item.Length))
                {
                    if (!item.DataType.Contains("numeric"))
                    {
                        m_Content.Append("\t\t\t[StringLength(" + item.Length + ", ErrorMessage = \"长度不可超过" + item.Length + "\")]\n");
                    }
                }

                switch (item.Code)
                {
                    case "Html":
                        m_Content.Append("\t\t\t[DataType(DataType.Html,ErrorMessage=\"Html格式不正确\")]\n");
                        break;
                    case "EmailAddress":
                        m_Content.Append("\t\t\t[DataType(DataType.EmailAddress,ErrorMessage=\"邮箱地址格式不正确\")]\n");
                        break;

                    case "Url":
                        m_Content.Append("\t\t\t[DataType(DataType.Url,ErrorMessage=\"网址格式不正确\")]\n");
                        break;
                    case "ImageUrl":
                        m_Content.Append("\t\t\t[DataType(DataType.ImageUrl,ErrorMessage=\"图片地址格式不正确\")]\n");
                        break;
                    case "Custom":
                        m_Content.Append("\t\t\t[DataType(DataType.Custom,ErrorMessage=\"格式不正确\")]\n");
                        break;
                    case "Duration":
                        m_Content.Append("\t\t\t[DataType(DataType.Duration,ErrorMessage=\"时间段格式不正确\")]\n");
                        break;
                    case "Currency":
                        m_Content.Append("\t\t\t[DataType(DataType.Currency,ErrorMessage=\"货币格式不正确\")]\n");
                        break;
                    case "Text":
                        m_Content.Append("\t\t\t[DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                        break;
                    case "MultilineText":
                        m_Content.Append("\t\t\t[DataType(DataType.MultilineText,ErrorMessage=\"字符格式不正确\")]\n");
                        break;
                    default:
                        SetAttributeName(item);
                        break;
                }
                m_Content.Append("\t\t\t[Display(Name = \"" + item.Name + "\", Order = " + order + ")]\n");
                if (item.DataType.Contains("smallint") || item.DataType.Contains("int") || item.DataType.Contains("numeric"))
                {
                    m_Content.Append("\t\t\tpublic int? " + item.Code + " { get; set; }\n\n");
                }
                else if (item.DataType.Contains("datetime") || item.DataType.Contains("date") || item.DataType.Contains("time"))
                {//
                    m_Content.Append("\t\t\t[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = \"{0:d}\")]\n\n");
                    m_Content.Append("\t\t\tpublic DateTime? " + item.Code + " { get; set; }\n\n");
                }
                else
                {
                    m_Content.Append("\t\t\tpublic object " + item.Code + " { get; set; }\n\n");
                }


                order++;
            }


            var contentIndex = Common.Read(m_DempDirectory + @"/Model.cs")
                .Replace(m_CustomEntity, customEntity)
                .Replace(m_ReplaceClassCode, replaceClass.Code)
                .Replace(m_ReplaceAttribute, m_Content.ToString());
            if (parent == 1)
            {
                contentIndex += m_parentId.Replace(m_ReplaceClassCode, replaceClass.Code) + m_Content.ToString() + "}";     //treegrid父节点   

            }
            string path = m_RootDirectory + "/" + m_DAL  + "/";
            Directory.CreateDirectory(path);
            Common.Write(path + replaceClass.Code + ".cs", contentIndex);
            fileName.Add(replaceClass.Code);//生成的文件路径和名称
            m_Content.Clear();
            return true;
        }
        /// <summary>
        /// ms sql server中设定所有的类型的名称
        /// </summary>
        /// <param name="attributeName"></param>
        /// <returns></returns>
        public bool SetAttributeName(Attribu attribute)
        {
            string attributeName = attribute.DataType;
            string low = "0", heigh = "2147483646";
            if (attributeName.Contains("(") && attributeName.Contains(")"))
            {
                attributeName = attributeName.Substring(0, attributeName.IndexOf("("));
            }
            if (attribute.Code.Contains("Password") && attribute.Code.Trim().Length > 8)
            {
                m_Content.Append("\t\t\t[DataType(DataType.Password)]\n\t\t\t[System.Web.Mvc.Compare(\"Password\", ErrorMessage = \"两次密码不一致\")]\n");
                return true;
            }
            if (attribute.Code.Contains("Password"))
            {
                m_Content.Append("\t\t\t[DataType(DataType.Password)]\n");
                return true;
            }
            if (attribute.Code.Contains("PhoneNumber"))
            {
                m_Content.Append("\t\t\t[DataType(DataType.PhoneNumber,ErrorMessage=\"号码格式不正确\")]\n");

                return true;
            }
            switch (attributeName)
            {
                case "nvarchar"://       <Property Name="nvarchar(50)" Type="nvarchar" MaxLength="50" />
                case "varchar"://       <Property Name="varchar(50)" Type="varchar" MaxLength="50" />
                    m_Content.Append("\t\t\t[DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "date"://    <Property Name="date" Type="date" />
                case "datetime2"://  <Property Name="datetime2(7)" Type="datetime2" />
                case "smalldatetime"://  <Property Name="smalldatetime" Type="smalldatetime" />
                //case "timestamp"://       <Property Name="timestamp" Type="timestamp" StoreGeneratedPattern="Computed" />
                case "time"://    <Property Name="time(7)" Type="time" />
                case "datetime":// <Property Name="datetime" Type="datetime" />
                    m_Content.Append("\t\t\t[DataType(DataType.DateTime,ErrorMessage=\"时间格式不正确\")]\n");
                    return true;

                case "smallmoney"://   <Property Name="smallmoney" Type="smallmoney" />
                case "money"://      <Property Name="money" Type="money" />
                    m_Content.Append("\t\t\t[DataType(DataType.Currency,ErrorMessage=\"货币格式不正确\")]\n");
                    return true;

                case "ntext"://<Property Name="ntext" Type="ntext" />
                case "nvarchar(max)"://    <Property Name="nvarchar(MAX)" Type="nvarchar(max)" /> 
                case "varchar(max)"://        <Property Name="varchar(MAX)" Type="varchar(max)" />
                case "varbinary(max)"://<Property Name="varbinary(MAX)" Type="varbinary(max)" />
                case "text"://        <Property Name="text" Type="text" />
                    m_Content.Append("\t\t\t[DataType(DataType.MultilineText,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "nchar":// <Property Name="nchar(10)" Type="nchar" MaxLength="10" />
                    m_Content.Append("\t\t\t[DataType(DataType.Text),ErrorMessage=\"字符格式不正确\"]\n");
                    return true;

                case "varbinary"://    <Property Name="varbinary(50)" Type="varbinary" MaxLength="50" />
                    m_Content.Append("\t\t\t[DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "char"://     <Property Name="char(10)" Type="char" MaxLength="10" />
                    m_Content.Append("\t\t\t[DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "tinyint"://     <Property Name="tinyint" Type="tinyint" Nullable="false" />
                case "int"://      <Property Name="int" Type="int" />
                case "bigint"://   <Property Name="bigint" Type="bigint" Nullable="false" />
                case "smallint"://   <Property Name="smallint" Type="smallint" />
                case "numeric"://       <Property Name="numeric(18, 0)" Type="numeric" />
                    if (!string.IsNullOrEmpty(attribute.LowValue))
                    {
                        low = attribute.LowValue;
                    }
                    if (!string.IsNullOrEmpty(attribute.HeighValue))
                    {
                        heigh = attribute.HeighValue;
                    }
                    m_Content.Append("\t\t\t[Range(" + low + "," + heigh + ", ErrorMessage=\"数值超出范围\")]\n");
                    return true;

                case "binary"://  <Property Name="binary(50)" Type="binary" Nullable="false" MaxLength="50" />
                    m_Content.Append("\t\t\t// [DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "bit"://   <Property Name="bit" Type="bit" />
                    m_Content.Append("\t\t\t// [DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "datetimeoffset"://     <Property Name="datetimeoffset(7)" Type="datetimeoffset" />
                    m_Content.Append("\t\t\t// [DataType(DataType.DateTime,ErrorMessage=\"时间格式不正确\")]\n");
                    return true;

                case "decimal"://        <Property Name="decimal(18, 0)" Type="decimal" />
                    m_Content.Append("\t\t\t// [DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "float":// <Property Name="float" Type="float" />
                    m_Content.Append("\t\t// [DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "image"://        <Property Name="image" Type="image" />
                    m_Content.Append("\t\t\t// [DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "uniqueidentifier"://  <Property Name="uniqueidentifier" Type="uniqueidentifier" />
                    m_Content.Append("\t\t\t// [DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "real"://       <Property Name="real" Type="real" />
                    m_Content.Append("\t\t\t//[DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                case "xml"://      <Property Name="xml" Type="xml" Nullable="false" />     
                    m_Content.Append("\t\t\t// [DataType(DataType.Text,ErrorMessage=\"字符格式不正确\")]\n");
                    return true;

                default:
                    return false;
            }
            /*Custom 表示自定义的数据类型。 
DateTime 表示时间上的一刻，以日期和当天的时间表示。 
Date 表示日期值。 
Time 表示时间值。 
Duration 表示对象存在的一段连续时间。 
PhoneNumber 表示电话号码值。 
Currency 表示货币值。 
Text 表示所显示的文本。 
Html 表示一个 HTML 文件。 
MultilineText 表示多行文本。 
EmailAddress 表示电子邮件地址。 
Password 表示密码值。 
Url 表示 URL 值。 
ImageUrl 表示图像的 URL。                        
                    
            */
        }

    }
}
