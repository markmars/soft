﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{
    public class BLL : BaseMain
    {
        /// <summary>
        /// 生成目的地 BLL     
        /// </summary>
        public string m_BLL = "BLL";
        /// <summary>
        /// 生成访问数据库层单表或者一对多模版
        /// </summary>
        public string m_DanMoban = @"\ReplaceClassBLLDan.cs";
        /// <summary>
        /// 生成访问数据库层多对多或者一对多模版
        /// </summary>
        public string m_DuoMoban = @"\ReplaceClassBLLDuo.cs";
        /// <summary>
        /// 创建多对多或者一对多模版
        /// </summary>
        public string m_CreateDown = @"
            foreach (var item in entity.^ReplaceAttribute^.GetIdSort())
            {
                ^ReplaceClassCode^ sys = new ^ReplaceClassCode^ { ^m_Id^ = item };
                db.^ReplaceClassCode^.Attach(sys);
                entity.^ReplaceClassCode^.Add(sys);
                count++;
            }
";

        /// <summary>
        /// 多对多表的创建方法
        /// </summary>
        public string m_DuoRefCreateDown = "^m_DuoRefCreateDown^";
        /// <summary>
        /// 编辑多对多或者一对多模版
        /// </summary>
        public string m_EditDown = @"
            List<string> add^ReplaceAttribute^ = new List<string>();
            List<string> delete^ReplaceAttribute^ = new List<string>();
            GetDiffrent(entity.^ReplaceAttribute^.GetIdSort(), entity.^ReplaceAttribute^Old.GetIdSort(), ref add^ReplaceAttribute^, ref delete^ReplaceAttribute^);
            if (add^ReplaceAttribute^ != null && add^ReplaceAttribute^.Count() > 0)
            {
                foreach (string item in add^ReplaceAttribute^)
                {
                    ^ReplaceClassCode^ sys = new ^ReplaceClassCode^ { ^m_Id^ = item };
                    db.^ReplaceClassCode^.Attach(sys);
                    editEntity.^ReplaceClassCode^.Add(sys);
                    count++;
                }
            }
            if (delete^ReplaceAttribute^ != null && delete^ReplaceAttribute^.Count() > 0)
            {
                List<^ReplaceClassCode^> listEntity = new List<^ReplaceClassCode^>();
                foreach (string item in delete^ReplaceAttribute^)
                {
                    ^ReplaceClassCode^ sys = new ^ReplaceClassCode^ { ^m_Id^ = item };
                    listEntity.Add(sys);
                    db.^ReplaceClassCode^.Attach(sys);
                }
                foreach (^ReplaceClassCode^ item in listEntity)
                {
                    editEntity.^ReplaceClassCode^.Remove(item);//查询数据库
                    count++;
                }
            } 
";
        /// <summary>
        /// 多对多表的编辑方法
        /// </summary>
        public string m_DuoRefEditDown = "^m_DuoRefEditDown^";
        /// <summary>
        /// Flexigrid控件中非外连接和外连接需要显示的地方
        /// </summary>
        public string m_ReplaceFlexigrid = @"^m_ReplaceFlexigrid^";
        /// <summary>
        /// Flexigrid外连接
        /// </summary>
        public string m_FlexigridSelfRef = @"
                        if (param.Cols.Contains(@^ReplaceAttribute^@))
                        {
                            if (item.^ReplaceAttribute^ != null && item.^ReplaceAttribute^.Length == 36 && item.^ReplaceClassCode^2 != null)
                            {
                                item.^ReplaceAttribute^ = item.^ReplaceClassCode^2.^m_Name^;//可以做成超链接
                            }   
                        }                    
";
        /// <summary>
        /// Flexigrid外连接
        /// </summary>
        public string m_FlexigridRef = @"
                        if (param.Cols.Contains(@^ReplaceAttribute^@))
                        {
                            if (item.^ReplaceAttribute^ != null && item.^ReplaceAttribute^.Length == 36 && item.^ReplaceClassCode^ != null)
                            {
                                item.^ReplaceAttribute^ = item.^ReplaceClassCode^.^m_Name^;//可以做成超链接
                            }   
                        }                    
";
        /// <summary>
        /// Flexigrid非外连接
        /// </summary>
        public string m_FlexigridNotRef = @" 
                        if (param.Cols.Contains(@^ReplaceAttribute^@) && item.^ReplaceClassCode^ != null)
                        {
                            item.^ReplaceAttribute^ = string.Empty;
                            foreach (var it in item.^ReplaceClassCode^)
                            {
                                item.^ReplaceAttribute^ += it.^m_Name^ + ' ';
                            }                         
                        } 
";
        /// <summary>
        /// 选择所有元数据的方法
        /// </summary>
        public string m_CopyMetadata = "^m_CopyMetadata^";
        /// <summary>
        /// 选择所有元数据的方法
        /// </summary>
        public string m_CopyMetadata2 = @"
        public List<^ReplaceClassCode^Sef> GetAllMetadata()
        {
            SysEntities db = new SysEntities();
            return repository.GetAll(db).Select(s =>
                new ^ReplaceClassCode^Sef
                {
                   ^m_CopyMetadata^
                }).OrderBy(o => o.Sort).ToList();
        }
            ";
        /// <summary>
        /// 该表的外连接是自连接
        /// </summary>
        string m_ReplaceFlexigridSef = "^m_ReplaceFlexigridSef^";
        /// <summary>
        /// 该表的外连接是自连接，内容
        /// </summary>
        string m_ReplaceFlexigridSefContent = @"
            if (!string.IsNullOrWhiteSpace(id) && id.Length == 36)
            {
                param.Query += @^ReplaceClassCode^&@ + id + @^@;
            }
            ";
        public string m_RefGetSelectDuo = @"
        /// <summary>
        /// 获取在该表一条数据中，出现的所有外键实体
        /// </summary>
        /// <param name=@id@>主键</param>
        /// <returns>外键实体集合</returns>
        public List<^ReplaceClassCode^> GetRef^ReplaceClassCode^(string id)
        {
            using (SysEntities db = new SysEntities())
            {
                return repository.GetRef^ReplaceClassCode^(db, id).ToList();
            }
        }
        /// <summary>
        /// 获取在该表中出现的所有外键实体
        /// </summary>
        /// <param name=@id@>主键</param>
        /// <returns>外键实体集合</returns>
        public List<^ReplaceClassCode^> GetRef^ReplaceClassCode^()
        {
            using (SysEntities db = new SysEntities())
            {
                return repository.GetRef^ReplaceClassCode^(db).ToList();
            }
        }
";
        public string m_RefGetSelectList = @"^m_RefGetSelectList^";// 方法中 外键
        public bool DoBLL(Table replaceClass, List<Reference> reference, ref List<string> fileName)
        {
            string refGetSelect = string.Empty;
            string sefRefMetadata = string.Empty;
            string duodanFlexigridNotRef = string.Empty;
            string contentIndex = string.Empty;
            //包含外键的Id
            if (replaceClass.refId != null && replaceClass.refId.Count() > 0)
            {
                foreach (var item in replaceClass.refId)
                {
                    //查询自连接列                 
                    var myselfRef = from m in m_MyselfIdClass
                                    from f in replaceClass.Attribute
                                    where m.ParentTable == f.TableId
                                    where f.Code == item.Id
                                    select f;
                    if (myselfRef != null && myselfRef.Count() > 0 && item.RefTable == myselfRef.FirstOrDefault().BelongClass)
                    {//自连接列  
                        if (string.IsNullOrWhiteSpace(duodanFlexigridNotRef))
                        {

                            duodanFlexigridNotRef += @"
                    foreach (var item in queryData)
                    {";
                        }

                        duodanFlexigridNotRef += m_FlexigridSelfRef.Replace(m_ReplaceClassCode, item.RefTable)
                                                               .Replace(m_ReplaceAttribute, item.Ref)
                                                               .Replace(m_Name, item.Name).Replace('@', '"');

                        int i = 0;
                        foreach (var it in replaceClass.Attribute)
                        {

                            i++;
                            //开始和更新时间，开始和更新人，时间戳，等不生成代码
                            if (it.Code.Contains("CreatePerson") || it.Code.Contains("CreateTime") || it.Code.Contains("UpdatePerson") || it.Code.Contains("UpdateTime") || it.Code.Contains("Version") || it.Code.Contains("Remark"))
                            {
                                continue;
                            }
                            var re = replaceClass.refId.Where(s => s.Ref == it.Code).FirstOrDefault();
                            if (it.Code == item.Ref)
                            {
                                sefRefMetadata += ",_parentId = s." + it.Code + "\n\t\t\t\t\t";
                                continue;
                            }
                            else if (re != null && !string.IsNullOrWhiteSpace(re.Id))
                            {
                                sefRefMetadata += "," + it.Code + " =  (s." + it.Code + " == null) ? string.Empty : s." + re.RefTable + "." + re.Name + "\n\t\t\t\t\t";
                                continue;
                            }

                            if (i == 1)
                            {
                                sefRefMetadata += it.Code + " = s." + it.Code + "\n\t\t\t\t\t";
                            }
                            else
                            {
                                sefRefMetadata += "," + it.Code + " = s." + it.Code + "\n\t\t\t\t\t";
                            }
                        }
                    }
                    else
                    {//外连接
                        if (string.IsNullOrWhiteSpace(duodanFlexigridNotRef))
                        {
                            duodanFlexigridNotRef += @"
                    foreach (var item in queryData)
                    {";
                        }
                        duodanFlexigridNotRef += m_FlexigridRef.Replace(m_ReplaceClassCode, item.RefTable)
                                                               .Replace(m_ReplaceAttribute, item.Ref)
                                                               .Replace(m_Name, item.Name).Replace('@', '"');
                    }

                }
            }
            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                //非外键连接，包含非外键的Id
                string editDown = string.Empty;
                string createDown = string.Empty;
                string replaceFlexigridSefContent = string.Empty;
                foreach (var item in replaceClass.refNotId)
                {
                    if (string.IsNullOrWhiteSpace(duodanFlexigridNotRef))
                    {
                        duodanFlexigridNotRef += @"
                    foreach (var item in queryData) 
                    {";
                    }

                    duodanFlexigridNotRef += m_FlexigridNotRef.Replace(m_ReplaceClassCode, item.RefTable)
                           .Replace(m_ReplaceAttribute, item.RefTable + item.Id).Replace(m_Name, item.Name).Replace('@', '"');
                    createDown += m_CreateDown.Replace(m_ReplaceClassCode, item.RefTable)
                       .Replace(m_ReplaceAttribute, item.RefTable + item.Id).Replace(m_Id, item.Id);
                    editDown += m_EditDown.Replace(m_ReplaceClassCode, item.RefTable)
                       .Replace(m_ReplaceAttribute, item.RefTable + item.Id).Replace(m_Id, item.Id);
                    if (!string.IsNullOrWhiteSpace(item.Ref))
                    {
                        replaceFlexigridSefContent += m_ReplaceFlexigridSefContent.Replace(m_ReplaceClassCode, item.Ref).Replace('@', '"');
                    }
                    refGetSelect += m_RefGetSelectDuo
              .Replace(m_ReplaceClassCode, item.RefTable)
              .Replace('@', '"');

                }
                if (!string.IsNullOrWhiteSpace(duodanFlexigridNotRef))
                {
                    duodanFlexigridNotRef += @"
                    }
";
                }

                contentIndex = Common.Read(m_DempDirectory + m_DuoMoban)
                    .Replace(m_RefGetSelectList, refGetSelect)
                      .Replace(m_ReplaceFlexigridSef, replaceFlexigridSefContent)
                      .Replace(m_CopyMetadata, string.IsNullOrWhiteSpace(sefRefMetadata) ? "" : m_CopyMetadata2.Replace(m_CopyMetadata, sefRefMetadata))
                      .Replace(m_ReplaceFlexigrid, duodanFlexigridNotRef)
                      .Replace(m_DuoRefCreateDown, createDown)
                      .Replace(m_DuoRefEditDown, editDown)
                      .Replace(m_ReplaceClassName, replaceClass.Name)
                      .Replace(m_ReplaceClassCode, replaceClass.Code)
                      .Replace(m_Id, replaceClass.ZhuJianName[0])
                    ;
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(duodanFlexigridNotRef))
                {
                    duodanFlexigridNotRef += @"
                    }
";
                }
                contentIndex = Common.Read(m_DempDirectory + m_DanMoban)
                  .Replace(m_CopyMetadata, string.IsNullOrWhiteSpace(sefRefMetadata) ? "" : m_CopyMetadata2.Replace(m_CopyMetadata, sefRefMetadata))
                  .Replace(m_ReplaceFlexigrid, duodanFlexigridNotRef).Replace(m_RefGetSelectList, refGetSelect)
                  .Replace(m_ReplaceClassName, replaceClass.Name)
                  .Replace(m_ReplaceClassCode, replaceClass.Code)
                  .Replace(m_Id, replaceClass.ZhuJianName[0])
                  ;
            }

            string path = m_RootDirectory + "/" + m_BLL + "/";
            Directory.CreateDirectory(path);
            Common.Write(path + replaceClass.Code + m_BLL + ".cs", contentIndex);
            fileName.Add(replaceClass.Code);//生成的文件路径和名称
            m_Content.Clear();
            return true;

        }
    }
}
