﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace CodeMaker
{
    /// <summary>
    /// 操作文件ini
    /// </summary>
    /// <remarks>创建人员(日期): ★Clark★(100128 10:51)</remarks>
    public static class OprateFileClass
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        private static string inipath =Application.StartupPath+ "/SystemConfig.ini";
        private static string section = "section";
        /// <summary>
        /// 写入INI文件 
        /// </summary>
        /// <param name="Section">项目名称(如[TypeName])</param>
        /// <param name="Key">键 </param>
        /// <param name="Value">值</param>
        /// <remarks>创建人员(日期): ★Clark★(100128 10:51)</remarks>
        public static void IniWriteValue(string Key, string Value)
        {
            long l = 0;
          l=  WritePrivateProfileString(section, Key, Value, inipath);
          string s = l.ToString();
        }
        /// <summary>
        /// 读出INI文件 
        /// </summary>
        /// <param name="Section">项目名称(如[TypeName])</param>
        /// <param name="Key">键</param>
        /// <returns></returns>
        /// <remarks>创建人员(日期): ★Clark★(100128 10:51)</remarks>
        public static string IniReadValue(string Key)
        {
            StringBuilder temp = new StringBuilder(500);
            int i = GetPrivateProfileString(section, Key, string.Empty, temp, 500, inipath);
            return temp.ToString();
        }

    }
}
