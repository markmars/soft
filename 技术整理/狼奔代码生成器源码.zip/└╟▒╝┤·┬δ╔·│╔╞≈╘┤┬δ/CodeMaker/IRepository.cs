﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{
    public class IRepository : BaseMain
    {
        public string m_IRefGetSelectDuo = @"/// <summary>
        /// 获取在该表中出现的所有外键实体
        /// </summary>
        /// <param name=@id@></param>
        /// <returns></returns>
        List<^ReplaceAttribute^> GetRef^ReplaceAttribute^();
        ";
        public string m_RefByDuoId = @"  /// <summary>
        /// 根据外键获取关联表
        /// </summary>
        /// <param name='id'></param>
        /// <returns></returns>
        ^ReplaceClassCodeRef^ GetBy^ReplaceAttribute^(string id);
      
          ";
        public string m_ReplaceClassCodeRef = "^ReplaceClassCodeRef^";//外键的类名

        public string m_AreasIRepository = @"\IReplaceClassDuo.cs";//生成访问数据库层单表或者一对多或者多对多模版
        public string m_IRefGetSelectList = @"^m_IRefGetSelectList^";// 方法中 外键
        public string m_RefById = @"^m_RefById^";//外键

        public string m_IBusinessRules = "IBLL";



        public void DoIRepository(Table replaceClass, List<Reference> reference, ref List<string> fileName)
        {
            string create = string.Empty;
            string contentIndex = string.Empty;
            string duo = string.Empty;
            string iRef = string.Empty;
            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                foreach (var item in replaceClass.refNotId)
                {

                    iRef += m_IRefGetSelectDuo.Replace(m_ReplaceAttribute, item.RefTable).Replace('@', '"');
                    //duo += m_RefByDuoId.Replace(m_ReplaceClassCodeRef, item.RefTable).Replace(m_ReplaceAttribute, item.RefTable);

                }
            }
            if (replaceClass.refId != null && replaceClass.refId.Count() > 0)
            {

                //foreach (var item in replaceClass.refId)
                //{
                //    var myselfRef = from m in m_MyselfIdClass
                //                    from f in replaceClass.Attribute
                //                    where m.ParentTable == f.TableId
                //                    where f.Code == item.Id
                //                    select f;
                //    if (myselfRef != null && myselfRef.Count() > 0 && item.RefTable == myselfRef.FirstOrDefault().BelongClass)
                //    {//自连接列
                       
                //    }
                //    //else
                //        //iRef += m_IRefGetSelectDuo.Replace(m_ReplaceAttribute, item.RefTable);

                //}
            }
            contentIndex = Common.Read(m_DempDirectory + m_AreasIRepository)
                  .Replace(m_IRefGetSelectList, iRef)
                   .Replace(m_RefById, duo)
                  .Replace(m_ReplaceClassName, replaceClass.Name)
                  .Replace(m_ReplaceClassCode, replaceClass.Code);
            string path = m_RootDirectory + @"/" + m_IBusinessRules + @"/";
            Directory.CreateDirectory(path);
            Common.Write(path + "I" + replaceClass.Code + @"BLL.cs", contentIndex);
            return;
        }
    }
}
