﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using ICSharpCode;
using System.Xml.Linq;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Checksums;
namespace CodeMaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //FilesZip();
           // Test1();
        }
        /// <summary>
        /// 压缩文件
        /// </summary>
        /// <remarks>创建人员(日期):★ben★(100301 15:00)</remarks>
        //private bool FilesZip()
        //{
        //    string m_zipFileName = @"D:/crebas.zip";
        //    string  file="D:/crebas.sql";
        //    string m_zipFilePath = @"D:/";
        //    if (!Directory.Exists(m_zipFilePath))
        //        Directory.CreateDirectory(m_zipFilePath);
        //    try
        //    {
        //        Crc32 crc = new Crc32();
        //        using (ZipOutputStream zip = new ZipOutputStream(File.Create(m_zipFileName)))
        //        {
        //            zip.SetLevel(6);

        //            FileStream fs;
        //            byte[] buffer;
        //            ZipEntry entry;
        //          // foreach (string file in openFiles.FileNames)
        //            {
        //                fs = File.OpenRead(file);
        //                buffer = new byte[fs.Length];
        //                fs.Read(buffer, 0, buffer.Length);

        //                entry = new ZipEntry(file.Substring(file.LastIndexOf(@"\") + 1));
        //                entry.DateTime = DateTime.Now;
        //                entry.Size = fs.Length;

        //                crc.Reset();
        //                crc.Update(buffer);
        //                entry.Crc = crc.Value;

        //                zip.PutNextEntry(entry);
        //                zip.Write(buffer, 0, buffer.Length);

        //                fs.Close();
        //            }
        //        }

        //        if (File.Exists(m_zipFileName))
        //            return true;

        //        return false;
        //    }
        //    catch (Exception ex)
        //    {
        //        RegisterLog.ExceptionsStack.RegisterError(ex);
        //        return false;
        //    }
        //}

        /// <summary>
        /// 测试解压文件
        /// </summary>
        private void Test1()
        {
            string zipPath = @"D:\a.zip";
            string unzipPath = @"D:\";


            if (!Directory.Exists(unzipPath))
                Directory.CreateDirectory(unzipPath);

            using (ZipInputStream zip = new ZipInputStream(File.OpenRead(zipPath)))
            {
                ZipEntry theEntry;
                string fileName;
                FileStream streamWriter;
                while ((theEntry = zip.GetNextEntry()) != null)
                {
                    fileName = Path.GetFileName(theEntry.Name);

                    if (fileName != String.Empty)
                    {
                        streamWriter = new FileStream(unzipPath + fileName, FileMode.Create, FileAccess.Write, FileShare.Read | FileShare.Write);

                        int size = 2048;
                        byte[] data = new byte[2048];
                        while (true)
                        {
                            size = zip.Read(data, 0, data.Length);
                            if (size > 0)
                            {
                                streamWriter.Write(data, 0, size);
                            }
                            else
                            {
                                break;
                            }
                        }
                        streamWriter.Close();
                    }

                }
            }
        }
    }


}
