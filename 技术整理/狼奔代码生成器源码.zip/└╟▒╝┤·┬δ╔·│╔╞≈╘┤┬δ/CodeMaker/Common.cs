﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ICSharpCode;
using System.Xml.Linq;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Checksums;

namespace CodeMaker
{
    public class Common
    {
        /// <summary>
        /// 解压文件
        /// </summary>
        public static void Zip(string unzipPath, Stream sr)
        {
            if (string.IsNullOrWhiteSpace(unzipPath))
                return;
            if (!Directory.Exists(unzipPath))
                Directory.CreateDirectory(unzipPath);
            //sr = new MemoryStream(CodeMaker.Properties.Resources.Solution2011812);
            using (ZipInputStream zip = new ZipInputStream(sr))
            {
                ZipEntry theEntry;
                string fileName;
                FileStream streamWriter;
                string dirPath = string.Empty;
                while ((theEntry = zip.GetNextEntry()) != null)
                {
                    fileName = Path.GetFileName(theEntry.Name);
                    dirPath = unzipPath + theEntry.Name;
                    if (fileName != String.Empty)
                    {
                        streamWriter = new FileStream(dirPath, FileMode.Create, FileAccess.Write, FileShare.Read | FileShare.Write);
                        int size = 2048;
                        byte[] data = new byte[2048];
                        while (true)
                        {
                            size = zip.Read(data, 0, data.Length);
                            if (size > 0)
                            {
                                streamWriter.Write(data, 0, size);
                            }
                            else
                            {
                                break;
                            }
                        }
                        streamWriter.Close();
                    }
                    else
                    {
                        if (!Directory.Exists(dirPath))
                            Directory.CreateDirectory(dirPath);
                    }

                }
            }
        }
        static string m_Line = string.Empty;
        /// <summary>
        /// 读取模版
        /// </summary>
        /// <param name="attProperty"></param>
        /// <returns></returns>
        public static string Read(string path)
        {
            using (StreamReader sr = new StreamReader(path, System.Text.Encoding.Default))
            {
                StringBuilder index = new StringBuilder();
                while ((m_Line = sr.ReadLine()) != null)
                {
                    index.Append(m_Line).Append("\r\n");
                }
                sr.Close();
                return index.ToString();
            }
        }
        /// <summary>
        /// 读取模版
        /// </summary>
        /// <param name="attProperty"></param>
        /// <returns></returns>
        public static void Write(string path, string content)
        {
            using (StreamWriter sw = new StreamWriter(path, false, Encoding.UTF8))
            {
                sw.WriteLine(content);
                sw.Close();
            }
        }

    }
    public class RefIdName
    {
        /// <summary>
        /// 非外键Id不包含
        /// </summary>
        public string Ref { get; set; }// Ref
        public string RefTable { get; set; }// Ref
        public string RefTableName { get; set; }// Ref
        public string Id { get; set; }// Id
        public string Name { get; set; }//Name
    }
    public class Ref
    {
        public string ParentId { get; set; }// Ref
        public string ChildId { get; set; }// Id        
    }
    public class Reference
    {
        public string ReferenceId { get; set; }//关联的Id
        public string ParentTable { get; set; }//父表Id
        public string ChildTable { get; set; }//子表Id
        public string ColumnParentTable { get; set; }//父表Id列
        public string ColumnChildTable { get; set; }//子表Id列

    }
    public static class ExpansionString
    {
        public static string FirstWordToLower(this string toLower)
        {
            string firstWord = toLower.Substring(0, 1).ToLower();
            return firstWord + toLower.Substring(1);
        }
    }
    public class Table
    {
        public string[] ZhuJianId { get; set; }//主键
        public string[] ZhuJianName { get; set; }//主键
        public List<RefIdName> refId { get; set; }//外键名称，就是外键的第二个属性
        public List<RefIdName> refNotId { get; set; }//外键名称，就是外键的第二个属性
        public string Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public List<Attribu> Attribute { get; set; }
    }
    public class Attribu
    {

        public string Code { get; set; }
        public string Comment { get; set; }//表的说明，标注需要查询的字段
        public string[] ZhuJian { get; set; }//主键/////////////////////////////////
        public string TableId { get; set; }//表Id
        public string AttributeId { get; set; }//属性Id
        public string LowValue { get; set; }//最小值
        public string HeighValue { get; set; }//最大值
        public string TableRelation { get; set; }//单独一张表，外键表，存储表外键的关联表
        public string BelongClass { get; set; }//属于哪个类
        public string ObjectID { get; set; }
        public string Name { get; set; }

        public string CreationDate { get; set; }
        public string Creator { get; set; }
        public string ModificationDate { get; set; }
        public string Modifier { get; set; }
        public string Mandatory { get; set; }
        public string Length { get; set; }
        public string DataType { get; set; }
    }

}
