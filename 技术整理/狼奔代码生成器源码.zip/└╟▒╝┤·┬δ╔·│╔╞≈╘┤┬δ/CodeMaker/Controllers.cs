﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{
    class Controllers : BaseMain
    {
        /// <summary>
        /// 生成控制器Controller 树形模版
        /// </summary>
        public string m_TreeController = @"\TreeController.cs";
        public string m_TreeModel = @"\TreeModel.cs";// 
        public string m_Models = "Models";
        public string m_TreeIndex = @"\TreeIndex.aspx";// 
        /// <summary>
        /// Controllers路径
        /// </summary>
        public string m_Controllers = "Controllers";
        /// <summary>
        /// 生成控制器Controller单表或者一对多模版
        /// </summary>
        public string m_DanMoban = @"\ReplaceClassControllerDan.cs";
        /// <summary>
        /// 生成控制器Controller多对多表或者一对多模版
        /// </summary>
        public string m_DuoMoban = @"\ReplaceClassControllerDan.cs";
        /// <summary>
        /// 生成控制器Controller中的Create方法，当外键中有自连接的
        /// </summary>
        public string m_Create = @"         
            if (!string.IsNullOrWhiteSpace(id))
            {
                using (^ReplaceClassName^BLL bll = new ^ReplaceClassName^BLL())
                {
                    ^ReplaceClassName^ entityId = bll.GetById(id);
                    if (entityId != null)
                    { 
                        ^ReplaceClassCode^ entity = new ^ReplaceClassCode^();  
                        entity.^ReplaceClassName^Id = id + '&' + entityId.^Name^;
                        return View(entity);
                    }
                }
            }
";
        /// <summary>
        /// 生成控制器Controller中的Create方法，当外键中有自连接的
        /// </summary>
        public string m_GetTreesSef = @"^m_GetTreesSef^";
        /// <summary>
        /// 生成控制器Controller中的Create方法，当外键中有自连接的
        /// </summary>
        public string m_CreateSef = @"^m_CreateSef^";
        /// <summary>
        /// 生成控制器Controller中的方法，当外键中有自连接的
        /// </summary>
        public string m_TreeSef = @"^m_TreeSef^";

        /// <summary>
        /// 生成控制器Controller中的Create方法，当外键中有自连接的
        /// </summary>
        public string m_GetTrees = @"         
        [SupportFilter]
        public ActionResult IndexSef()
        {
            return View();
        }
        [SupportFilter]
        public ActionResult GetTrees(string id)
        {
            using (^ReplaceClassName^BLL db = new ^ReplaceClassName^BLL())
            {
                var trees = db.GetAll().OrderBy(o => o.Sort).AsQueryable();
                if (trees != null)
                {
                    ^ReplaceClassName^Tree tree = new ^ReplaceClassName^Tree();
                    tree.Bind(trees, string.Empty);
                    ViewData[@tree@] = tree.sb.ToString();
                }

                if (!string.IsNullOrWhiteSpace(id))
                {
                    using (^ReplaceClassCode^BLL entity = new ^ReplaceClassCode^BLL())
                    {
                        var r = entity.GetById(id);
                        ViewData[@myname@] = r.Name;
                        ViewData[@myid@] = id;
                    }
                }
            }
            return View();
        }
        [SupportFilter]
        public ActionResult GetIds(string id)
        {
            if (!string.IsNullOrWhiteSpace(id))
            {
                ^ReplaceClassCode^BLL bll = new ^ReplaceClassCode^BLL();
                var entitys = bll.GetRef^ReplaceClassName^(id);
                if (entitys != null && entitys.Any())
                {
                    List<string> ids = new List<string>();
                    foreach (var it in entitys)
                    {
                        if (!string.IsNullOrEmpty(it.Id) && it.Id.Length == 36)
                        {
                            ids.Add(it.Id);
                        }
                    }
                    return Json(ids, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(string.Empty);
        }
";
        public void DoControllers(Table replaceClass, List<Reference> reference, ref List<string> fileName)
        {
            string treeCreate = string.Empty;
            string refGetSelect = string.Empty;
            string contentIndex = string.Empty;
            string contentCreate = string.Empty;
            if (replaceClass.refId != null && replaceClass.refId.Count() > 0)
            {
                foreach (var item in replaceClass.refId)
                {
                    var myselfRef = from m in m_MyselfIdClass
                                    from f in replaceClass.Attribute
                                    where m.ParentTable == f.TableId
                                    where f.Code == item.Id
                                    select f;
                    if (myselfRef != null && myselfRef.Count() > 0 && item.RefTable == myselfRef.FirstOrDefault().BelongClass)
                    {//自连接列

                        var mycontentIndex = Common.Read(m_DempDirectory + m_TreeController)
                    .Replace(m_ReplaceClassName, replaceClass.Name)
                    .Replace(m_Application, m_App)
                    .Replace(m_ReplaceClassCode, replaceClass.Code);
                        string path = m_RootDirectory + @"/" + m_App + @"/" + m_Controllers + @"/";
                        Common.Write(path + replaceClass.Code + @"TreeController.cs", mycontentIndex);
                        fileName.Add("Controllers\\" + replaceClass.Code + @"TreeController.cs");//生成的文件路径和名称

                        var modlemycontentIndex = Common.Read(m_DempDirectory + m_TreeModel)
              .Replace(m_ReplaceClassName, replaceClass.Name)
              .Replace(m_ReplaceAttribute, item.Ref)
              .Replace(m_Application, m_App)
              .Replace(m_ReplaceClassCode, replaceClass.Code);
                        string modlepath = m_RootDirectory + @"/" + m_App + @"/" + m_Models + @"/";
                        Common.Write(modlepath + replaceClass.Code + @"TreeModel.cs", modlemycontentIndex);
                        fileName.Add("Models\\" + replaceClass.Code + @"TreeModel.cs");//生成的文件路径和名称


                        var indexmycontentIndex = Common.Read(m_DempDirectory + m_TreeIndex)
   .Replace(m_ReplaceClassName, replaceClass.Name)
   .Replace(m_Application, m_App)
   .Replace(m_ReplaceClassCode, replaceClass.Code);

                        string indexpath = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code + "Tree";
                        Directory.CreateDirectory(indexpath);
                        Common.Write(indexpath + "/Index.aspx", indexmycontentIndex);
                        fileName.Add("Views\\" + replaceClass.Code + "\\Index.aspx");//生成的文件路径和名称

                    }
                    else
                    {//外连接                         

                    }
                }
            }
            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                foreach (var item in replaceClass.refNotId)
                {
                    if (!string.IsNullOrWhiteSpace(item.Ref))
                    {
                        contentCreate += m_Create
                            .Replace(m_ReplaceClassCode, replaceClass.Code)
                            .Replace(m_ReplaceClassName, item.Ref)
                            .Replace("^Name^", item.Name);
                        treeCreate += m_GetTrees
                                 .Replace(m_ReplaceClassCode, replaceClass.Code)
                                 .Replace(m_ReplaceClassName, item.RefTable)
                                 .Replace("^Name^", item.Name)
                                 .Replace('@', '"');

                    }

                }
                contentIndex = Common.Read(m_DempDirectory + m_DuoMoban)
                  .Replace(m_TreeSef, treeCreate)
                    .Replace(m_CreateSef, contentCreate)
                    .Replace(m_ReplaceClassName, replaceClass.Name)
                    .Replace(m_ReplaceClassCode, replaceClass.Code)
                    .Replace(m_Id, replaceClass.ZhuJianName[0])
                    .Replace(m_Application, m_App);
            }
            else
            {
                contentIndex = Common.Read(m_DempDirectory + m_DanMoban)
                     .Replace(m_CreateSef, contentCreate)
                      .Replace(m_TreeSef, treeCreate)
                  .Replace(m_Application, m_App)
                  .Replace(m_ReplaceClassName, replaceClass.Name)
                  .Replace(m_ReplaceClassCode, replaceClass.Code)
                  .Replace(m_Id, replaceClass.ZhuJianName[0]);
            }
            string mypath = m_RootDirectory + @"/" + m_App + @"/" + m_Controllers + @"/";
            Directory.CreateDirectory(mypath);
            Common.Write(mypath + replaceClass.Code + @"Controller.cs", contentIndex);
            fileName.Add("Controllers\\" + replaceClass.Code + @"Controller.cs");//生成的文件路径和名称
            return;
        }
    }
}
