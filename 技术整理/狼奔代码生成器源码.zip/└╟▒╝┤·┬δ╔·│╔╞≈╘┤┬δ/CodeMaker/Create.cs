﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{
    class Create : BaseMain
    {
        public string m_Password = @" 
        <div class=@editor-label@>
            <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
        </div>
        <div class=@editor-field@>
            <%: Html.PasswordFor(model => model.Password) %>
        </div>";
        public string m_PickTimeCreate = @"
  $('#^ReplaceAttribute^').datepicker();            
";

        string replaceInt = string.Empty;
    
        public string m_SelfEdit = @"
        <div class=@editor-label@>
            <a class=@anUnderLine@ onclick=@showModalOnly('^ReplaceAttribute^','../../^ReplaceClassCode^');@>
                <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </a>
        </div>
        <div class=@editor-field@>
            <div id=@check^ReplaceAttribute^@>               
            </div>
            <%: Html.HiddenFor(model => model.^ReplaceAttribute^)%>
        </div>";
        public string m_EditRef = @"
        <div class=@editor-label@>
            <a class=@anUnderLine@ onclick=@showModalOnly('^ReplaceAttribute^','../../^ReplaceClassCode^');@>
                <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </a>
        </div>
        <div class=@editor-field@>
            <div id=@check^ReplaceAttribute^@>            
            </div>
            <%: Html.HiddenFor(model => model.^ReplaceAttribute^)%>
        </div>";
        public string m_EditNotRef = @"   <div class=@editor-label@>
            <a class=@anUnderLine@ onclick=@showModalMany('^ReplaceAttribute^','../../^ReplaceClassCode^');@>
                <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </a>
        </div>
        <div class=@editor-field@>
            <div id=@check^ReplaceAttribute^@>
                <% 
                if (Model != null && !string.IsNullOrWhiteSpace(Model.^ReplaceAttribute^))
                {
                   foreach (var item in Model.^ReplaceAttribute^.Split('^'))
                   {
                        string[] it = item.Split('&');
                        if (it != null && it.Length == 2 && !string.IsNullOrWhiteSpace(it[0]) && !string.IsNullOrWhiteSpace(it[1]))
                        {                        
                %>
                <table id=@<%: item %>@
                    class=@deleteStyle@>
                    <tr>
                        <td>
                            <img  alt=@删除@ title=@点击删除@ onclick=@deleteTable('<%: item  %>','^ReplaceAttribute^');@  src=@../../../Images/deleteimge.png@ />
                        </td>
                        <td>
                            <%: it[1] %>
                        </td>
                    </tr>
                </table>
                <%}}}%>
               <%: Html.HiddenFor(model => model.^ReplaceAttribute^) %>
            </div>
        </div>";

        public string m_UpLode = @"           
            <div class=@editor-label@>
                <input id=@file_upload@ name=@file_upload@ type=@file@ />
            </div>
            <div id=@up@ class=@editor-field@>
                <div id=@fileQueue@>
                </div>
                <%: Html.HiddenFor(model => model.^ReplaceAttribute^) %>                
            </div> ";
        public string m_UpLodeJs = @" 
                $('#file_upload').uploadify({
                    'uploader': '../../Res/jquery.uploadify-v2.1.4/uploadify.swf',
                    'script': '../../Res/jquery.uploadify-v2.1.4/FileUploader.ashx',
                    'cancelImg': '../../Res/jquery.uploadify-v2.1.4/cancel.png',
                    'folder': '/up',
                    'queueID': 'fileQueue',
                    'auto': true,
                    'multi': true,
                    'simUploadLimit': 5,                
                    'onComplete': function (event, queueId, fileObj, response, data) {
 
                    var content = @@; //需要添加的内容
                    var hidden = document.getElementById('^ReplaceAttribute^'); //获取隐藏的控件
                    hidden.value += (response+','); //为隐藏控件赋值
                    content += '<table  id=@' + response + '@ class=@deleteStyle@><tr><td><img src=@../../../Images/deleteimge.png@ title=@点击删除@  alt=@删除@    onclick=@ deleteTable(' + @'@ + response + @',@ + @'@ + '^ReplaceAttribute^' + @'@ + ');@ /></td><td>' + fileObj.name + '</td></tr></table>';
                     if (content!=null) {   
                         $(@up@).append(content); 
                    }
                           
                    }                
                });
";
        public string m_CreatePage = @"^m_CreatePage^";
        public string m_PickTimeCrea = @"^m_PickTimeCrea^";

        public void DoCreate(Table replaceClass, List<Reference> reference, ref List<string> fileName)
        {
            StringBuilder index = new StringBuilder();
            string pickTimeCreate = string.Empty;
            string replaceInt = string.Empty;
            int flag = 0;
            bool flagInt = false;

            foreach (var item in replaceClass.Attribute)
            {
                flag++;
                if (item.Code == "Password")
                {
                    replaceInt += m_Password.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                    continue;
                }

                //主键
                if (!string.IsNullOrWhiteSpace(item.Code) && replaceClass.ZhuJianId != null && replaceClass.ZhuJianId.Contains(item.AttributeId))
                {
                    continue;
                }
                //开始和更新时间，开始和更新人，时间戳，等不生成代码
                if (item.Code.Contains("CreatePerson") || item.Code.Contains("UpdatePerson") || item.Code.Contains("Version") || item.Code.Contains("Remark") || item.Code.Contains("UpdateTime") || item.Code.Contains("CreateTime"))
                {
                    continue;
                }
                //数值和时间类型
                if (!string.IsNullOrWhiteSpace(item.Code) && !string.IsNullOrWhiteSpace(item.DataType))
                {
                    switch (item.DataType)
                    {
                        case "int":
                        case "smallint":
                            replaceInt += m_EditorFor.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                            flagInt = true;
                            break;
                        case "datetime":
                        case "date":
                            pickTimeCreate += m_PickTimeCreate.Replace(m_ReplaceAttribute, item.Code);
                            replaceInt += m_EditorFor.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                            flagInt = true;
                            break;
                        default:
                            break;
                    }
                    if (flagInt)
                    {
                        flagInt = false;
                        continue;
                    }

                }
                //包含外键的Id
                if (replaceClass.refId != null && replaceClass.refId.Count() > 0)
                {
                    bool flag2 = false;
                    foreach (var items in replaceClass.refId)
                    {
                        if (item.Code == items.Ref)
                        {
                            //查询自连接列                 
                            var myselfRef = from m in m_MyselfIdClass
                                            from f in replaceClass.Attribute
                                            where m.ParentTable == f.TableId
                                            where f.Code == items.Id
                                            select f;
                            if (myselfRef != null && myselfRef.Count() > 0 && items.RefTable == myselfRef.FirstOrDefault().BelongClass)
                            {//自连接列  
                                replaceInt += m_SelfEdit.Replace(m_ReplaceAttribute, items.Ref)
                                .Replace(m_ReplaceClassCode, items.RefTable).Replace('@', '"');
                            }
                            else
                            {//外连接
                                replaceInt += m_EditRef.Replace(m_ReplaceAttribute, items.Ref )
                                    .Replace(m_ReplaceClassCode, items.RefTable).Replace('@', '"');
                            }
                            flag2 = true;
                            break;
                        }
                    }
                    if (flag2)
                    {
                        continue;
                    }
                }

                //string等其他类型 大
                if (!string.IsNullOrWhiteSpace(item.Length) && Convert.ToInt32(item.Length) >= 2000)
                {
                    if (item.Comment.Contains("上传"))
                    {
                        replaceInt += m_UpLode.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                        pickTimeCreate += m_UpLodeJs.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                        continue;
                    }//后期修改的，可能有错误
                    replaceInt += m_TextAreaFor.Replace(m_ReplaceAttribute, item.Code).Replace('\'', '"');
                }
                else
                {
                    if (item.Comment.Contains("状态"))
                    {
                        replaceInt += m_CreateEditorFor.Replace(m_ReplaceClassCode, item.BelongClass).Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                    }
                    else
                    {
                        if (item.Code != "State")
                        {
                            replaceInt += m_EditorFor.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                        }
                    }
                }
            }

            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                //非外键连接，包含非外键的Id
                foreach (var item in replaceClass.refNotId)
                {
                    flag++;
                    replaceInt += m_EditNotRef.Replace(m_ReplaceAttribute, item.RefTable + item.Id)
                        .Replace(m_ReplaceClassCode, item.RefTable)
                        .Replace(m_Id, item.Id).Replace(m_Name, item.Name)
                        .Replace("ids", "ids" + flag.ToString())
                        .Replace("item", "item" + flag.ToString())
                        .Replace('@', '"');

                }
            }

            var contentIndex = Common.Read(m_DempDirectory + "/Create.aspx")

                .Replace(m_CreatePage, replaceInt)
                .Replace(m_PickTimeCrea, pickTimeCreate)
                .Replace(m_ReplaceClassCode, replaceClass.Code)
                .Replace(m_ReplaceClassName, replaceClass.Name);
            string path = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
            Directory.CreateDirectory(path);
            Common.Write(path + "/Create.aspx", contentIndex);
            fileName.Add(replaceClass.Code + "/Create.aspx");//生成的文件路径和名称
        }
    }
}
