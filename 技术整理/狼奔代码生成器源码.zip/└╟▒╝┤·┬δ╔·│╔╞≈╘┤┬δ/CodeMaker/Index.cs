﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{

    public class Index : BaseMain
    {
        /// <summary>
        /// 数字类型的查询
        /// </summary>
        public string m_SearchInt = @"
            <div class='editor-label'>
            <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </div>
            <div class='editor-field-Search'>
                <input type='text' id='^ReplaceAttribute^Start_Int' onkeyup = 'isInt(this)' />
                到
                <input type='text' id='^ReplaceAttribute^End_Int' onkeyup = 'isInt(this)'  />
            </div>
            <br style=' clear:both;' />";//查询int
        /// <summary>
        /// 查询时间,脚本
        /// </summary>
        public string m_PickTime = @"
                                $('#^ReplaceAttribute^Start_Time').datepicker();
                                $('#^ReplaceAttribute^End_Time').datepicker();
                                 ";
        /// <summary>
        /// 查询时间,html
        /// </summary>
        public string m_SearchDateTime = @" 
            <div class='editor-label'>
             <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </div>
            <div class='editor-field-Search'>
                <input type='text' id='^ReplaceAttribute^Start_Time'   />
                到
                <input type='text' id='^ReplaceAttribute^End_Time'   />
            </div>
            <br style=' clear:both;' />"
            ;//
        /// <summary>
        /// 查询状态，下拉框形式展示
        /// </summary>
        public string m_SearchZhuangtai = @"
            <div class=@input@>
                <div class=@editor-label@>
                    <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </div>
                <div class=@editor-field@>
                    <%=Html.DropDownListFor(model => model.^ReplaceAttribute^,App.Models.SysFieldsDDL.GetSysFields(@^ReplaceClassCode^@,@^ReplaceAttribute^@),@请选择@)%>  
                </div>
            </div>
            <br style=@clear:both;@ />";
        /// <summary>
        /// 查询字符串
        /// </summary>
        public string m_SearchString = @" 
            <div class=@input@>
                <div class=@editor-label@>
                    <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </div>
                <div class=@editor-field@>
                    <%: Html.EditorFor(model => model.^ReplaceAttribute^) %>
                </div>
            </div>
            <br style=@clear:both;@ />";
        /// <summary>
        /// 自动搜索，前5个
        /// </summary>   
        public string m_SearchAuto = @" $(@#^ReplaceAttribute^@).autocomplete({
                                    source: @../^ReplaceClassCode^/SearchAutoComplete/^ReplaceAttribute^@,
                                    minLength: 1,
                                    select: function (event, ui) {
                                        //  alert(ui.item.value);
                                    }
                                });";
        /// <summary>
        /// 自动搜索，前5个
        /// </summary>        
        public string m_SearchAutoComplete = @"^m_SearchAutoComplete^";
        public string m_SearchRefDuo = @"    
               <div class=@editor-label@>
                   <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
               </div>
               <div class=@editor-field@>
                   <%=Html.DropDownListFor(model => model.^ReplaceAttribute^,App.Models.SysFieldsDDL.GetSysFields(@^ReplaceClassCode^@,@^ReplaceAttribute^@),@请选择@)%>  
               </div>             
           <br style=' clear:both;' />";//查询外键

        public string m_TreeIndexMain = @"\IndexMainTree.aspx";

        public string m_PickTimeReplace = @"^m_PickTimeReplace^";
        /// <summary>
        /// 总查询字符串
        /// </summary>
        public string m_Search = @"^m_Search^";

        public void DoIndex(Table replaceClass, List<Reference> reference, ref List<string> fileName)
        {

            string displayAttribute = string.Empty;
            string displayId = string.Empty;
            string searchauto = string.Empty;
            string replaceSearch = string.Empty, m_PickTimeReplaceAtt = string.Empty;
            int zhujiangengduo = 0;
            int count = replaceClass.Attribute.Count - 4;
            int whdth = 760 / count;
            int whdthSef = 680 / count;
            int mySeq = 0;
            string sefTree = string.Empty;
            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                //非外键连接，包含非外键的Id
                foreach (var item in replaceClass.refNotId)
                {
                    if (!string.IsNullOrWhiteSpace(item.Ref))
                    {
                        whdth = 500 / count;
                    }
                }
            }
            foreach (var item in replaceClass.Attribute)
            {
                //更新时间，开始和更新人，时间戳，等不生成代码
                if (item.Code.Contains("CreatePerson") || item.Code.Contains("CreateTime") || item.Code.Contains("UpdatePerson") || item.Code.Contains("Version") || item.Code.Contains("Remark") || item.Code.Contains("UpdateTime"))
                {
                    continue;
                }
                mySeq++;

                if (mySeq == 4)
                {
                    sefTree += "\n\t\t\t\t\t{ field: '" + item.Code + "', title: '" + item.Name + "', width: " + whdth + " }";
                }
                else if (mySeq > 4)
                {
                    sefTree += "\n\t\t\t\t\t,{ field: '" + item.Code + "', title: '" + item.Name + "', width: " + whdth + " }";
                }
                if (mySeq == 2)//序号
                {
                    displayAttribute += ("\t\t\t\t\t, { display: '序号', name: 'MySeq', width: 26, sortable: false, align: 'left' }\n");
                }
                if (!string.IsNullOrWhiteSpace(item.Comment) && item.Comment.Contains("查询"))
                {
                    switch (item.DataType)
                    {
                        case "int":
                        case "smallint":
                            replaceSearch += m_SearchInt.Replace(m_ReplaceAttribute, item.Code).Replace('\'', '"');
                            break;
                        case "datetime":
                        case "date":
                            m_PickTimeReplaceAtt += m_PickTime.Replace(m_ReplaceAttribute, item.Code);
                            replaceSearch += m_SearchDateTime.Replace(m_ReplaceAttribute, item.Code).Replace('\'', '"');
                            break;

                        default:
                            if (item.Comment.Contains("状态"))
                            {
                                replaceSearch += m_SearchZhuangtai.Replace(m_ReplaceClassCode, item.BelongClass).Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');

                            }
                            else
                            {
                                replaceSearch += m_SearchString.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                                searchauto += m_SearchAuto.Replace(m_ReplaceAttribute, item.Code)
                                    .Replace('@', '"');
                            }
                            break;
                    }

                }
                else
                {
                    //非外键Id列
                    if (replaceClass.refNotId != null)
                    {
                        var renot = replaceClass.refNotId.Where(a => item.Code.Contains(a.RefTable) && item.Code.Contains(a.Id)).FirstOrDefault();
                        if (renot != null)
                        {
                            replaceSearch += m_SearchRefDuo.Replace(m_ReplaceClassCode, item.BelongClass).Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');

                        }
                    }
                }
                //主键 第一个主键 
                if (!string.IsNullOrWhiteSpace(item.Code) && replaceClass.ZhuJianId != null && replaceClass.ZhuJianId.Contains(item.AttributeId))
                {
                    if (zhujiangengduo == 0)
                    {
                        displayId += ("{ display: '<%: Html.LabelFor(model => model." + item.Code + ") %>', name: '" + item.Code + "', width: 205, hide: true, sortable: false, align: 'left' }\n");

                    }
                    else
                    {

                        if ((item.Code == "State") && !item.Comment.Contains("状态"))
                        {

                        }
                        else
                        {
                            displayAttribute += ("\t\t\t\t\t, { display: '<%: Html.LabelFor(model => model." + item.Code + ") %>', name: '" + item.Code + "', width: " + whdth + ", sortable: true, align: 'left' }\n");

                        }

                    }
                    zhujiangengduo++;
                }
                else
                {
                    if ((item.Code == "State") && !item.Comment.Contains("状态"))
                    {

                    }
                    else
                    {

                        displayAttribute += ("\t\t\t\t\t, { display: '<%: Html.LabelFor(model => model." + item.Code + ") %>', name: '" + item.Code + "', width: " + whdth + ", sortable: true, align: 'left' }\n");

                    }

                }
            }
            displayAttribute = displayId + displayAttribute;
            string fla = m_DempDirectory + "/Index.aspx";
            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                //非外键连接，包含非外键的Id
                foreach (var item in replaceClass.refNotId)
                {
                    displayAttribute += ("\t\t\t\t\t//, { display: '<%: Html.LabelFor(model => model." + item.RefTable + ") %>', name: '" + item.RefTable + item.Id + "', width: " + whdth + ", sortable: false, align: 'left' }\n");

                    if (!string.IsNullOrWhiteSpace(item.Ref))
                    {
                        fla = m_DempDirectory + "/TreeIndexWai.aspx";
                        var contentIndexSet = Common.Read(fla)
                             .Replace("^m_RefTableName^", item.RefTableName)
                             .Replace("^m_Wai^", item.Ref)
                             .Replace("flexigridData", "flexigridDataSef")
                             .Replace(m_PickTimeReplace, m_PickTimeReplaceAtt)
                             .Replace(m_Search, replaceSearch)
                             .Replace(m_ReplaceAttribute, displayAttribute)
                             .Replace(m_Name, replaceClass.Attribute[1].Code)
                             .Replace(m_ReplaceClassCode, replaceClass.Code)
                             .Replace(m_ReplaceClassName, replaceClass.Name);

                        string pathSet = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
                        Directory.CreateDirectory(pathSet);
                        Common.Write(pathSet + "/Index.aspx", contentIndexSet);

                        fla = m_DempDirectory + "/Index.aspx";
                        var contentIndex3 = Common.Read(fla)
                                               .Replace(m_SearchAutoComplete, searchauto)
                                               .Replace(m_PickTimeReplace, m_PickTimeReplaceAtt)
                                               .Replace(m_Search, replaceSearch)
                                               .Replace(m_ReplaceAttribute, displayAttribute)
                                               .Replace(m_Name, replaceClass.Attribute[1].Code)
                                               .Replace(m_ReplaceClassCode, replaceClass.Code)
                                               .Replace(m_ReplaceClassName, replaceClass.Name);

                        string path3 = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
                        Directory.CreateDirectory(path3);
                        Common.Write(path3 + "/IndexSef.aspx", contentIndex3);

                        fla = m_DempDirectory + "/Set.aspx";
                        var contentIndexSet2 = Common.Read(fla)
                       
                             .Replace(m_ReplaceClassCode, replaceClass.Code)
                             .Replace(m_ReplaceClassName, replaceClass.Name);

                        string pathSet2 = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
                        Directory.CreateDirectory(pathSet2);
                        Common.Write(pathSet + "/Set.aspx", contentIndexSet2);
                        return;
                    }
                }
            }
            //包含外键的Id
            if (replaceClass.refId != null && replaceClass.refId.Count() > 0)
            {
                foreach (var item in replaceClass.refId)
                {
                    //查询自连接列                 
                    var myselfRef = from m in m_MyselfIdClass
                                    from f in replaceClass.Attribute
                                    where m.ParentTable == f.TableId
                                    where f.Code == item.Id
                                    select f;
                    if (myselfRef != null && myselfRef.Count() > 0 && item.RefTable == myselfRef.FirstOrDefault().BelongClass)
                    {//自连接列  
                        //replaceInt += m_SelfEdit.Replace(m_ReplaceAttribute, item.Name)
                        //           .Replace(m_ReplaceClassCode, replaceClass.Code).Replace(m_Name, re.Name).Replace('@', '"');
                        var contentIndexSef = Common.Read(m_DempDirectory + "/TreeIndexSys.aspx")
                           .Replace(m_ReplaceAttribute, sefTree)
                           .Replace(m_Name, replaceClass.Attribute[1].Code)
                           .Replace(m_ReplaceClassCode, replaceClass.Code)
                           .Replace(m_ReplaceClassName, replaceClass.Name);

                        string pathSef = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
                        Directory.CreateDirectory(pathSef);
                        Common.Write(pathSef + "/Index.aspx", contentIndexSef);


                        var contentIndexMy = Common.Read(fla)
                           .Replace(m_SearchAutoComplete, searchauto)
                           .Replace(m_PickTimeReplace, m_PickTimeReplaceAtt)
                           .Replace(m_Search, replaceSearch)
                           .Replace(m_ReplaceAttribute, displayAttribute)
                           .Replace(m_Name, replaceClass.Attribute[1].Code)
                           .Replace(m_ReplaceClassCode, replaceClass.Code)
                           .Replace(m_ReplaceClassName, replaceClass.Name);

                        string pathMy = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
                        Directory.CreateDirectory(pathMy);
                        Common.Write(pathMy + "/IndexSef.aspx", contentIndexMy);
                        return;

                    }
                    else
                    {//外连接

                    }
                }
            }
            var contentIndex = Common.Read(fla)
               .Replace(m_SearchAutoComplete, searchauto)
               .Replace(m_PickTimeReplace, m_PickTimeReplaceAtt)
               .Replace(m_Search, replaceSearch)
               .Replace(m_ReplaceAttribute, displayAttribute)
               .Replace(m_Name, replaceClass.Attribute[1].Code)
               .Replace(m_ReplaceClassCode, replaceClass.Code)
               .Replace(m_ReplaceClassName, replaceClass.Name);

            string path = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
            Directory.CreateDirectory(path);
            Common.Write(path + "/Index.aspx", contentIndex);
            fileName.Add(replaceClass.Code + "/Index.aspx");//生成的文件路径和名称
        }
    }
}
