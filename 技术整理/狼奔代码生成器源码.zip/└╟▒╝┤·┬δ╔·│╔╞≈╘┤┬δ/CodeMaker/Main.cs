﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;
using System.Windows.Forms;
namespace CodeMaker
{
    public partial class Main : BaseMain
    {
        string startupPath = Application.StartupPath + "/SystemConfig.ini";
        private void Main_Load(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists(startupPath))
                {
                    Common.Zip("D:/", new MemoryStream(CodeMaker.Properties.Resources.Moban));

                    Common.Write(startupPath, txbMoBan.Text.Trim() + "," + txbPDM.Text.Trim() + "," + txbMuDiDI.Text.Trim());

                    if (MessageBox.Show("模版和PowerDesigner文件创建成功，请在Sys.PDM文件上设计数据库结构。", "第一次运行成功", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.OK)
                        System.Diagnostics.Process.Start("Explorer", "/select," + txbPDM.Text.Trim());//打开文件夹,并选择文件夹内的一个文件 open folder and select file：
                }
                else
                {
                    var config = Common.Read(startupPath).Split(',');
                    txbMoBan.Text = config[0];
                    txbPDM.Text = config[1];
                    txbMuDiDI.Text = config[2];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("权限不足", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
        }

        public Main()
        {
            InitializeComponent();
        }

        private void btn_CreateTime_Click(object sender, EventArgs e)
        {
            string path = m_RootDirectory + @"/" + m_DAL + @"/";
            string p = path + @"Model1.edmx";
            using (StreamReader sr = new StreamReader(p, System.Text.Encoding.Default))
            {
                StringBuilder index = new StringBuilder();
                while ((m_Line = sr.ReadLine()) != null)
                {
                    index.Append(m_Line
                        .Replace("<Property Type=@Binary@ Name=@Version@ MaxLength=".Replace('@', '"'), "<Property Type=@Binary@ Name=@Version@ ConcurrencyMode=@Fixed@ MaxLength=".Replace('@', '"'))
                        //.Replace("<Property Name=@CreateTime@ Type=".Replace('@', '"'), "<Property Name=@CreateTime@ StoreGeneratedPattern=@Computed@ Type=").Replace('@', '"')
                        //.Replace("<Property Name=@UpdateTime@ Type=".Replace('@', '"'), "<Property Name=@UpdateTime@ StoreGeneratedPattern=@Identity@ Type=").Replace('@', '"')
                        ).Append("\r\n"
                        );
                }
                sr.Close();
                m_Line = index.ToString();
            }
            Common.Write(p, m_Line);
            m_Line = string.Empty;
        }

        private void btnShengChengXiTong_Click(object sender, EventArgs e)
        {
            //验证模版文件路径是否存在
            if (Directory.Exists(txbMoBan.Text.Trim()))
            {
                m_DempDirectory = txbMoBan.Text.Trim();
            }
            else
            {
                MessageBox.Show("模版文件路径不存在", "操作失败！", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
            //验证生成目的地路径是否存在
            if (Directory.Exists(txbMuDiDI.Text.Trim()))
            {
                string mudidi = txbMuDiDI.Text.Trim() + "Solution/"; //生成目的地
                if (Directory.Exists(mudidi))
                    Directory.Delete(mudidi, true);//如果生成目的地存在Solution文件夹，则删除
                m_RootDirectory = mudidi;
            }
            else
            {
                MessageBox.Show("目的地文件路径不存在", "操作失败！", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
            //验证生成pdm文件路径是否存在
            if (File.Exists(txbPDM.Text.Trim()))
            {
                m_Pdm = txbPDM.Text.Trim();//pdm路径
            }
            else
            {
                MessageBox.Show("PowerDesigner文件不存在", "操作失败！", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
            Common.Write(startupPath, txbMoBan.Text.Trim() + "," + txbPDM.Text.Trim() + "," + txbMuDiDI.Text.Trim());
            Common.Zip(txbMuDiDI.Text.Trim(), new MemoryStream(CodeMaker.Properties.Resources.Solution));

            #region
            var listTable = new List<Table>();
            var listReference = new List<Reference>();
            ReadTableReference.TableReference(out listTable, out listReference);
            //自连接
            m_MyselfIdClass = (from l in listReference
                               where
                               l.ParentTable == l.ChildTable
                               select l
                           ).Distinct().ToList();

            m_refIdClass = (from l in listReference//大于等于一个外键，多于2列，主键列，外键列，名称列
                            where
                            (
                                from f in listReference
                                group f by f.ChildTable into g
                                where g.Count() >= 1
                                select g.Key
                             ).Contains(l.ChildTable)

                            where
                            (
                                from f in listTable
                                where f.Attribute.Count > 2
                                select f.Id
                            ).Contains(l.ChildTable)

                            where !m_refNotIdClass.Contains(l.ChildTable)
                            select l.ChildTable
                 ).Distinct().ToList();

            var refNotIdClassId = (from l in listReference
                                   where
                                   (
                                       from f in listReference
                                       group f by f.ChildTable into g
                                       where g.Count() == 2
                                       select g.Key
                                    ).Contains(l.ChildTable)

                                   where
                                   (
                                       from f in listTable
                                       where f.Attribute.Count == 2
                                       select f.Id
                                   ).Contains(l.ChildTable)

                                   select l
                              ).Distinct().ToList();

            var refIdClassId = (from l in listReference//大于等于一个外键，多于2列，主键列，外键列，名称列
                                where
                                (
                                    from f in listReference
                                    group f by f.ChildTable into g
                                    where g.Count() >= 1
                                    select g.Key
                                 ).Contains(l.ChildTable)

                                where
                                (
                                    from f in listTable
                                    where f.Attribute.Count > 2
                                    select f.Id
                                ).Contains(l.ChildTable)

                                where !m_refNotIdClass.Contains(l.ChildTable)
                                select l//new Ref{ ParentId= l.ColumnParentTable, ChildId= l.ColumnChildTable }
                 ).Distinct().ToList();

            var notShow = (from l in listReference
                           where
                           (
                               from f in listReference
                               group f by f.ChildTable into g
                               where g.Count() == 2
                               select g.Key
                            ).Contains(l.ChildTable)

                           where
                           (
                               from f in listTable
                               where f.Attribute.Count == 2
                               select f.Id
                           ).Contains(l.ChildTable)

                           select l.ChildTable
                             ).Distinct().ToList();

            List<string> fileNameRepository = new List<string>();
            List<string> fileNameBLL = new List<string>();
            List<string> fileNameControllers = new List<string>();
            List<string> fileNameCreate = new List<string>();
            List<string> fileNameIndex = new List<string>();
            List<string> fileNameDetails = new List<string>();
            List<string> fileNameEdit = new List<string>();
            List<string> fileNameModels = new List<string>();
            foreach (var item in listTable)
            {

                List<RefIdName> listAttributes = new List<RefIdName>();
                var refId = refIdClassId.Where(w => w.ChildTable == item.Id);
                foreach (var it in refId)
                {
                    listAttributes.Add(new RefIdName
                    {

                        RefTable = (from i in listTable
                                    where i.Id == it.ParentTable
                                    select i.Code).FirstOrDefault(),
                        Ref = (from i in item.Attribute
                               where i.AttributeId == it.ColumnChildTable
                               select i.Code).FirstOrDefault(),
                        Id = (from i in listTable
                              from a in i.Attribute
                              where a.AttributeId == it.ColumnParentTable
                              select i.Attribute[0].Code).FirstOrDefault(),
                        Name = (from i in listTable
                                from a in i.Attribute
                                where a.AttributeId == it.ColumnParentTable
                                select i.Attribute[1].Code).FirstOrDefault(),
                        RefTableName = (from i in listTable
                                        where i.Id == it.ParentTable
                                        select i.Name).FirstOrDefault()
                    });
                }
                if (listAttributes != null && listAttributes.Count > 0)
                {
                    item.refId = listAttributes;
                }
                List<RefIdName> listAttributesNot = new List<RefIdName>();
                var refNotId = from n in refNotIdClassId
                               from o in refNotIdClassId
                               where n.ParentTable != o.ParentTable
                               where n.ChildTable == o.ChildTable
                               where n.ParentTable == item.Id
                               select o;
                foreach (var it in refNotId)
                {
                    listAttributesNot.Add(new RefIdName
                    {
                        Ref = (from i in listTable
                               from f in i.Attribute
                               where i.Id == it.ParentTable
                               where f.Code.Contains("ParentId")
                               where i.Code == f.BelongClass
                               select i.Code).FirstOrDefault(),
                        RefTableName = (from i in listTable
                                        where i.Id == it.ParentTable
                                        select i.Name).FirstOrDefault(),
                        RefTable = (from i in listTable
                                    where i.Id == it.ParentTable
                                    select i.Code).FirstOrDefault(),
                        Id = (from i in listTable
                              from a in i.Attribute
                              where a.AttributeId == it.ColumnParentTable
                              select a.Code).FirstOrDefault(),
                        Name = (from i in listTable
                                from a in i.Attribute
                                where a.AttributeId == it.ColumnParentTable
                                select i.Attribute[1].Code).FirstOrDefault()

                    });
                }
                if (listAttributesNot != null && listAttributesNot.Count > 0)
                {
                    item.refNotId = listAttributesNot;
                }
                if (notShow.Contains(item.Id))
                {
                    continue;
                }
            #endregion


                repository.DoRepository(item, listReference, ref fileNameRepository);
                bll.DoBLL(item, listReference, ref fileNameBLL);
                controllers.DoControllers(item, listReference, ref fileNameControllers);
                create.DoCreate(item, listReference, ref fileNameCreate);
                index.DoIndex(item, listReference, ref fileNameIndex);
                details.DoDetails(item, item.Attribute, ref fileNameDetails);
                edit.DoEdit(item, item.Attribute, ref fileNameEdit);
                models.DoModels(item, listReference, ref fileNameModels);
                //irepositoty.DoIRepository(item, listReference, ref fileNameModels);

            }

            #region 将文件路径添加到解决方案

            StringBuilder compileBuilder = new StringBuilder();
            //将文件路径添加到解决方案
            string compile = @"<Compile Include=@Properties\AssemblyInfo.cs@ />
".Replace('@', '"');
            //    <Compile Include="Framework\BaseRepository.cs" />
            string compileReplace = @"    <Compile Include=@Framework.cs@ />
    <Compile Include=@FrameworkRepository.cs@ />
".Replace('@', '"');
            string pathDAL = m_RootDirectory + @"/" + m_DAL + @"/" + m_DAL + ".csproj";
            compileBuilder.Append(compile);
            foreach (string item in fileNameRepository)
            {
                compileBuilder.Append(compileReplace.Replace("Framework", item));
            }
            Common.Write(pathDAL, Common.Read(pathDAL).Replace(compile, compileBuilder.ToString()));
            compileBuilder.Clear();

            // BLL
            string compileBLL = @"    <Compile Include=@FrameworkBLL.cs@ />
".Replace('@', '"');
            string pathBLL = m_RootDirectory + @"/BLL/BLL.csproj";
            compileBuilder.Append(compile);
            foreach (string item in fileNameBLL)
            {
                compileBuilder.Append(compileBLL.Replace("Framework", item));
            }
            Common.Write(pathBLL, Common.Read(pathBLL).Replace(compile, compileBuilder.ToString()));
            compileBuilder.Clear();
            // IBLL
//            string compileIBLL = @"    <Compile Include=@IFrameworkBLL.cs@ />
//".Replace('@', '"');
//            string pathIBLL = m_RootDirectory + @"/IBLL/IBLL.csproj";
//            compileBuilder.Append(compile);
//            foreach (string item in fileNameBLL)
//            {
//                compileBuilder.Append(compileIBLL.Replace("Framework", item));
//            }
//            Common.Write(pathIBLL, Common.Read(pathIBLL).Replace(compile, compileBuilder.ToString()));
//            compileBuilder.Clear();
            // Controlers

            List<string> fileControllers = GetFileControllers(m_RootDirectory + @"/" + m_App + @"/Controllers", @"Controllers");
            List<string> fileViews = GetFileViews(m_RootDirectory + @"/" + m_App + @"/Views", "Views");
            List<string> fileModels = GetFileControllers(m_RootDirectory + @"/" + m_App + @"/Models", "Models");
            string pathControlers = m_RootDirectory + @"/" + m_App + @"/" + m_App + ".csproj";
            string compileControlers = "    \n<Compile Include=@Framework@ />\n".Replace('@', '"');
            string content = "<ItemGroup />";
            string compileaspx = "    \n<Content Include=@Framework@ />\n".Replace('@', '"');

            compileBuilder.Append("     <ItemGroup>");
            foreach (string item in fileViews)
            {
                if (item.Contains(@"\Account\")
                    || item.Contains(@"\Shared\") || item.Contains(@"\NotFound\")
                    || item.Contains(@"\Home\"))
                {
                    continue;
                }
                compileBuilder.Append(compileaspx.Replace("Framework", item.Replace('/', '\\')));
            }
            compileBuilder.Append("     </ItemGroup>");

            compileBuilder.Append("     <ItemGroup>");
            foreach (string item in fileControllers)
            {
                if (item.Contains(@"\Account") || item.Contains(@"\Home"))
                {
                    continue;
                }
                compileBuilder.Append(compileControlers.Replace("Framework", item.Replace('/', '\\')));
            }
            foreach (string item in fileModels)
            {
                if (item.Contains(@"Tree"))
                {
                    compileBuilder.Append(compileControlers.Replace("Framework", item.Replace('/', '\\')));
                }
            }
            compileBuilder.Append("     </ItemGroup>");
            var dd = compileBuilder.ToString();
            Common.Write(pathControlers, Common.Read(pathControlers).Replace(content, compileBuilder.ToString()));
            compileBuilder.Clear();

            #endregion

            btn_CreateTime_Click(sender, e);
            if (MessageBox.Show("生成成功。", "操作成功！", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.OK)
                System.Diagnostics.Process.Start("Explorer", "/select," + txbMuDiDI.Text.Trim() + @"Solution\Solution.sln");
            //打开文件夹,并选择文件夹内的一个文件
            //Application.Exit();
        }

       
        private List<string> GetFileControllers(string directory, string value)
        {
            List<string> list = new List<string>();
            //遍历文件夹中的文件
            if (Directory.Exists(directory))
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(directory);
                foreach (FileInfo file in directoryInfo.GetFiles())
                {
                    list.Add(file.FullName.Substring(file.FullName.LastIndexOf(@"\" + value) + 1));
                }
            }

            return list;
        }
        private List<string> GetFileViews(string directory, string value)
        {
            List<string> list = new List<string>();
            //遍历文件夹中的文件
            if (Directory.Exists(directory))
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(directory);
                foreach (DirectoryInfo dir in directoryInfo.GetDirectories())
                {
                    //遍历文件夹中的文件
                    foreach (FileInfo file in dir.GetFiles())
                    {
                        list.Add(file.FullName.Substring(file.FullName.LastIndexOf(@"\" + value) + 1));
                    }
                }

            }

            return list;
        }


        private void btnPathOfpdm_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txbPDM.Text))
            {
                openFileDialog1pdm.InitialDirectory = txbPDM.Text.Substring(0, txbPDM.Text.LastIndexOf('\\')) + @"\";
                openFileDialog1pdm.FileName = txbPDM.Text.Substring(txbPDM.Text.LastIndexOf('\\') + 1);
            }
            openFileDialog1pdm.Filter = "PowerDesigner文件|*.PDM|所有文件|*.*";
            openFileDialog1pdm.DefaultExt = "*.PDM";

            if (openFileDialog1pdm.ShowDialog() == DialogResult.OK)
            {
                if (openFileDialog1pdm.FileName != "openFileDialog1")
                {
                    txbPDM.Text = openFileDialog1pdm.FileName;
                }
            }
        }

        private void btnShengChengMuDiDi_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txbMuDiDI.Text))
            {
                folderBrowserDialog1shengcheng.SelectedPath = txbMuDiDI.Text;
            }

            if (folderBrowserDialog1shengcheng.ShowDialog() == DialogResult.OK)
            {
                if (!string.IsNullOrWhiteSpace(folderBrowserDialog1shengcheng.SelectedPath))
                {
                    txbMuDiDI.Text = folderBrowserDialog1shengcheng.SelectedPath;
                }
            }
        }

        private void btnMoBan_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txbMoBan.Text))
            {
                folderBrowserDialog1MoBan.SelectedPath = txbMoBan.Text;
            }

            if (folderBrowserDialog1MoBan.ShowDialog() == DialogResult.OK)
            {
                if (!string.IsNullOrWhiteSpace(folderBrowserDialog1MoBan.SelectedPath))
                {
                    txbMoBan.Text = folderBrowserDialog1MoBan.SelectedPath;
                }
            }
        }
        Models models = new Models();
        Repository repository = new Repository();
        BLL bll = new BLL();
        Controllers controllers = new Controllers();
        Index index = new Index();
        Create create = new Create();
        Details details = new Details();
        Edit edit = new Edit();
        IRepository irepositoty = new IRepository();
    }
}
