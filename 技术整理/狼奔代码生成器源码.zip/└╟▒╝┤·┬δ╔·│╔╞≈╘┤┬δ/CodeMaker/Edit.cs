﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{
    class Edit : BaseMain
    {
        public string m_PickTimeCreate = @"
  $('#^ReplaceAttribute^').datepicker();            
";

        public string m_SelfEdit = @"       
            <div class=@editor-label@>
                <a class=@anUnderLine@ onclick=@showModalOnly('^ReplaceAttribute^','../../^ReplaceClassCode^');@>
                    <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </a>
            </div>
            <div class=@editor-field@>
                <div id=@check^ReplaceAttribute^@>
                    <% if(Model!=null)
                        {
                        if (!string.IsNullOrWhiteSpace(Model.^ReplaceAttribute^))
                        {%>
                    <table  id=@<%: Model.^ReplaceAttribute^ %>@
                        class=@deleteStyle@>
                        <tr>
                            <td>
                                <img  alt=@删除@  title=@点击删除@ src=@../../../Images/deleteimge.png@ onclick=@deleteTable('<%: Model.^ReplaceAttribute^ %>','^ReplaceAttribute^');@/>
                            </td>
                            <td>
                                <%: Model.^ReplaceClassCode^2.^m_Name^%>
                            </td>
                        </tr>
                    </table>
                    <%}}%>
                </div>
                <%: Html.HiddenFor(model => model.^ReplaceAttribute^)%>
            </div>";
        /// <summary>
        /// 外连接
        /// </summary>
        public string m_EditRef = @"      
            <div class=@editor-label@>
                <a class=@anUnderLine@ onclick=@showModalOnly('^ReplaceAttribute^','../../^ReplaceClassCode^');@>
                    <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </a>
            </div>
            <div class=@editor-field@>
                <div id=@check^ReplaceAttribute^@>
                    <%  if(Model!=null)
                        {
                        if (!string.IsNullOrWhiteSpace(Model.^ReplaceAttribute^))
                        {%>
                    <table id=@<%: Model.^ReplaceAttribute^ %>@
                        class=@deleteStyle@>
                        <tr>
                            <td>
                                <img alt=@删除@  title=@点击删除@ onclick=@deleteTable('<%: Model.^ReplaceAttribute^ %>','^ReplaceAttribute^');@ src=@../../../Images/deleteimge.png@ />
                            </td>
                            <td>
                                <%: Model.^ReplaceClassCode^.^m_Name^%>
                            </td>
                        </tr>
                    </table>
                    <%}}%>
                </div>
                <%: Html.HiddenFor(model => model.^ReplaceAttribute^)%>
            </div>";
   
        public string m_EditNotRefUp = @"   
                <div class=@editor-label@>
                    <input id=@file_upload@ name=@file_upload@ type=@file@ />
                </div>
                <div id=@up@ class=@editor-field@> <div id=@fileQueue@>
                    </div>
                <div id=@check^ReplaceAttribute^@>
                    <% string ids = string.Empty;
                    if(Model!=null)
                        {
                       foreach (var item in Model.^ReplaceClassCode^)
                       {
                           string it = string.Empty;
                           it += item.^m_Id^ + @&@ + item.^m_Name^;
                           if (ids.Length > 0)
                           {
                               ids += @^@ + it;
                           }
                           else
                           {
                               ids += it;
                           }
 
                    %>
                    <table id=@<%: it %>@
                        class=@deleteStyle@>
                        <tr>
                            <td>
                                <img  alt=@删除@ title=@点击删除@ onclick=@deleteTable('<%: it %>','^ReplaceAttribute^');@  src=@../../../Images/deleteimge.png@ />
                            </td>
                            <td>
                                <%: item.^m_Name^ %>
                            </td>
                        </tr>
                    </table>
                    <%}}%>
                    <input type=@hidden@ value=@<%= ids %>@ name=@^ReplaceAttribute^@ id=@^ReplaceAttribute^@ />
                    <input type=@hidden@ value=@<%= ids %>@ name=@^ReplaceAttribute^Old@ id=@^ReplaceAttribute^Old@ />
                </div>
            </div>";

        public string m_UpLodeJsEdit = @" 
                $('#file_upload').uploadify({
                    'uploader': '../../../Res/jquery.uploadify-v2.1.4/uploadify.swf',
                    'script': '../../../Res/jquery.uploadify-v2.1.4/FileUploader.ashx',
                    'cancelImg': '../../../Res/jquery.uploadify-v2.1.4/cancel.png',
                    'folder': '/up',
                    'queueID': 'fileQueue',
                    'auto': true,
                    'multi': true,
                    'simUploadLimit': 5,                
                    'onComplete': function (event, queueId, fileObj, response, data) {
 
                    var content = @@; //需要添加的内容
                    var hidden = document.getElementById('^ReplaceAttribute^'); //获取隐藏的控件
                    hidden.value += (response+','); //为隐藏控件赋值
                    content += '<table  id=@' + response + '@ class=@deleteStyle@><tr><td><img src=@../../../Images/deleteimge.png@ title=@点击删除@  alt=@删除@    onclick=@ deleteTable(' + @'@ + response + @',@ + @'@ + '^ReplaceAttribute^' + @'@ + ');@ /></td><td>' + fileObj.name + '</td></tr></table>';
                    if (content!=null) {   
                         $(@up@).append(content); 
                    }    
                    }                
                });
";
        public string m_EditNotRef = @"  
        <div class=@editor-label@>
            <a class=@anUnderLine@ onclick=@showModalMany('^ReplaceAttribute^','../../^ReplaceClassCode^');@>
                <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </a>
        </div>
        <div class=@editor-field@>
            <div id=@check^ReplaceAttribute^@>
                <% string ids = string.Empty;
                if(Model!=null)
                {
                   foreach (var item in Model.^ReplaceClassCode^)
                   {
                       string item1 = string.Empty;
                       item1 += item.^m_Id^ + @&@ + item.^m_Name^;
                       if (ids.Length > 0)
                       {
                           ids += @^@ + item1;
                       }
                       else
                       {
                           ids += item1;
                       }
                %>
                <table id=@<%: item1 %>@
                    class=@deleteStyle@>
                    <tr>
                        <td>
                            <img  alt=@删除@ title=@点击删除@ onclick=@deleteTable('<%: item1 %>','^ReplaceAttribute^');@  src=@../../../Images/deleteimge.png@ />
                        </td>
                        <td>
                            <%: item.^m_Name^ %>
                        </td>
                    </tr>
                </table>
                <%}}%>
                <input type=@hidden@ value=@<%= ids %>@ name=@^ReplaceAttribute^Old@ id=@^ReplaceAttribute^Old@ />
                <input type=@hidden@ value=@<%= ids %>@ name=@^ReplaceAttribute^@ id=@^ReplaceAttribute^@ />
            </div>
        </div>";


        public string m_CreatePage = @"^m_CreatePage^";
        public string m_PickTimeCrea = @"^m_PickTimeCrea^";

        public void DoEdit(Table replaceClass, List<Attribu> attProperty, ref List<string> fileName)
        {
            StringBuilder index = new StringBuilder();
            string pickTimeCreate = string.Empty;
            string replaceInt = string.Empty; ;
            int flag = 0;
            bool flagInt = false;
            foreach (var item in replaceClass.Attribute)
            {
                flag += 1;

                //主键
                if (!string.IsNullOrWhiteSpace(item.Code) && replaceClass.ZhuJianId != null && replaceClass.ZhuJianId.Contains(item.AttributeId))
                {
                    continue;
                }
                //开始和更新时间，开始和更新人，时间戳，等不生成代码
                if (item.Code.Contains("CreatePerson") || item.Code.Contains("UpdatePerson") || item.Code.Contains("Version") || item.Code.Contains("Remark") || item.Code.Contains("UpdateTime") || item.Code.Contains("CreateTime"))
                {
                    continue;
                }
                //数值和时间类型
                if (!string.IsNullOrWhiteSpace(item.Code) && !string.IsNullOrWhiteSpace(item.DataType))
                {
                    switch (item.DataType)
                    {
                        case "int":
                        case "smallint":
                            replaceInt += m_EditorFor.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                            flagInt = true;
                            break;
                        case "datetime":
                        case "date":

                            pickTimeCreate += m_PickTimeCreate.Replace(m_ReplaceAttribute, item.Code);
                            replaceInt += m_EditorFor.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                            flagInt = true;
                            break;
                        default:
                            break;
                    }
                    if (flagInt)
                    {
                        flagInt = false;
                        continue;
                    }
                }
                //包含外键的Id
                if (replaceClass.refId != null && replaceClass.refId.Count() > 0)
                {
                    bool flag2 = false;
                    foreach (var items in replaceClass.refId)
                    {
                        if (item.Code == items.Ref)
                        {
                            //查询自连接列                 
                            var myselfRef = from m in m_MyselfIdClass
                                            from f in replaceClass.Attribute
                                            where m.ParentTable == f.TableId
                                            where f.Code == items.Id
                                            select f;
                            if (myselfRef != null && myselfRef.Count() > 0 && items.RefTable == myselfRef.FirstOrDefault().BelongClass)
                            {//自连接列  
                                replaceInt += m_SelfEdit.Replace(m_ReplaceAttribute, items.Ref)
                                           .Replace(m_ReplaceClassCode, replaceClass.Code).Replace(m_Name, items.Name).Replace('@', '"');
                            }
                            else
                            {//外连接
                                replaceInt += m_EditRef.Replace(m_ReplaceAttribute, items.Ref)
                                    .Replace(m_ReplaceClassCode, items.RefTable).Replace(m_Name, items.Name).Replace('@', '"');
                            }
                            flag2 = true;
                            break;
                        }
                    }
                    if (flag2)
                    {
                        continue;
                    }
                }
                //string等其他类型
                if (!string.IsNullOrWhiteSpace(item.Length) && Convert.ToInt32(item.Length) >= 2000)
                {
                    replaceInt += m_TextAreaFor.Replace(m_ReplaceAttribute, item.Code).Replace('\'', '"');
                }
                else
                {
                    if (item.Comment.Contains("状态"))
                    {
                        replaceInt += m_CreateEditorFor.Replace(m_ReplaceClassCode, item.BelongClass).Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                    }
                    else
                    {
                        if (item.Code != "State")
                        {
                            replaceInt += m_EditorFor.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');

                        }
                    }
                }
            }

            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                //非外键连接，包含非外键的Id
                foreach (var item in replaceClass.refNotId)
                {
                    flag++;
                    replaceInt += m_EditNotRef.Replace(m_ReplaceAttribute, item.RefTable + item.Id)
                        .Replace(m_ReplaceClassCode, item.RefTable)
                        .Replace(m_Id, item.Id).Replace(m_Name, item.Name)
                        .Replace("ids", "ids" + flag.ToString())
                        .Replace("item", "item" + flag.ToString())
                        .Replace('@', '"');

                }
            }
            var contentIndex = Common.Read(m_DempDirectory + "/Edit.aspx")
                .Replace(m_CreatePage, replaceInt)
                .Replace(m_PickTimeCrea, pickTimeCreate)
                .Replace(m_ReplaceClassCode, replaceClass.Code)
                .Replace(m_ReplaceClassName, replaceClass.Name);
            string path = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
            Directory.CreateDirectory(path);
            Common.Write(path + "/Edit.aspx", contentIndex);
            fileName.Add(replaceClass.Code + "/Edit.aspx");//生成的文件路径和名称
        }
    }
}
