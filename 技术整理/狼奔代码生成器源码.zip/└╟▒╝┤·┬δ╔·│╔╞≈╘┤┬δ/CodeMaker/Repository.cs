﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{
    class Repository : BaseMain
    {
        /// <summary>
        /// 生成访问数据库层单表或者一对多模版
        /// </summary>
        public string m_DanMoban = @"\ReplaceClassRepositoryDan.cs";
        /// <summary>
        /// 生成访问数据库层多对多或者一对多模版
        /// </summary>
        public string m_DuoMoban = @"\ReplaceClassRepositoryDuo.cs";
        public string m_ReposDan = @"^m_ReposDan^";
        public string m_ReposLocalDan = @"
                    if (queryDic.ContainsKey(@^ReplaceAttribute^@) && !string.IsNullOrWhiteSpace(item.Key) && !string.IsNullOrWhiteSpace(item.Value) && item.Value == @noway@ && item.Key == @^ReplaceAttribute^@)
                    {//查询一对多关系的列名
                        where += @it.^ReplaceAttribute^ is null@;
                        continue;
                    }";
        public string m_Repos = @"^m_Repos^";
        public string m_ReposLocal = @"
                    if (queryDic.ContainsKey(@^ReplaceClassCode^@)&& !string.IsNullOrWhiteSpace(item.Key) && !string.IsNullOrWhiteSpace(item.Value) && item.Key == @^ReplaceClassCode^@)
                    {//查询多对多关系的列名
                        where += @EXISTS(select p from it.^ReplaceClassCode^ as p where p.^m_Id^='@ + item.Value + @')@;
                        continue;
                    }";
        public string m_RefGetSelectDuo = @"
        /// <summary>
        /// 获取在该表一条数据中，出现的所有外键实体
        /// </summary>
        /// <param name=@id@>主键</param>
        /// <returns>外键实体集合</returns>
        public IQueryable<^ReplaceClassCode^> GetRef^ReplaceClassCode^(string id)
        {
            using (SysEntities db = new SysEntities())
            {
                return GetRef^ReplaceClassCode^(db, id);
            }
        }
        /// <summary>
        /// 获取在该表一条数据中，出现的所有外键实体
        /// </summary>
        /// <param name=@id@>主键</param>
        /// <returns>外键实体集合</returns>
        public IQueryable<^ReplaceClassCode^> GetRef^ReplaceClassCode^(SysEntities db, string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                return from m in db.^SysRole^
                       from f in m.^ReplaceClassCode^
                       where m.^m_Id^ == id
                       select f;
            }
            return null;
        }
        /// <summary>
        /// 获取在该表中出现的所有外键实体
        /// </summary>
        /// <param name=@id@>主键</param>
        /// <returns>外键实体集合</returns>
        public IQueryable<^ReplaceClassCode^> GetRef^ReplaceClassCode^(SysEntities db)
        {
            return from m in db.^SysRole^
                   from f in m.^ReplaceClassCode^
                   select f;
        }
        /// <summary>
        /// 获取在该表中出现的所有外键实体
        /// </summary>
        /// <param name=@id@>主键</param>
        /// <returns>外键实体集合</returns>
        public IQueryable<^ReplaceClassCode^> GetRef^ReplaceClassCode^()
        {
            using (SysEntities db = new SysEntities())
            {
                return GetRef^ReplaceClassCode^(db);
            }
        }
";
        public string m_RefGetSelectList = @"^m_RefGetSelectList^";// 方法中 外键
        public void DoRepository(Table replaceClass, List<Reference> reference, ref List<string> fileName)
        {
            string refGetSelect = string.Empty;
            string reposEmpty = string.Empty;
            string reposEmptyDan = string.Empty;         
            string contentIndex = string.Empty;
            //包含外键的Id
            if (replaceClass.refId != null && replaceClass.refId.Count() > 0)
            {
                foreach (var item in replaceClass.refId)
                {                    
                    //查询自连接列                 
                    var myselfRef = from m in m_MyselfIdClass
                                    from f in replaceClass.Attribute
                                    where m.ParentTable == f.TableId
                                    where f.Code == item.Id
                                    select f;
                    if (myselfRef != null && myselfRef.Count() > 0 && item.RefTable == myselfRef.FirstOrDefault().BelongClass)
                    {//自连接列  
                  
                    }
                    else
                    {//外连接
                      
                    }
                    reposEmptyDan += m_ReposLocalDan.Replace(m_ReplaceAttribute, item.Ref).Replace('@', '"');

                }
            }
            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                //非外键连接，包含非外键的Id
                foreach (var item in replaceClass.refNotId)
                {
                    reposEmpty += m_ReposLocal.Replace(m_ReplaceClassCode, item.RefTable).Replace(m_Id, item.Id).Replace('@', '"');
                  
                    refGetSelect += m_RefGetSelectDuo.Replace(m_ReplaceClassCode, item.RefTable)                 
                      .Replace(m_Id, item.Id).Replace('@', '"')
                      .Replace("^SysRole^", replaceClass.Code);                  
                  
                }
                contentIndex = Common.Read(m_DempDirectory + m_DuoMoban)               
                  .Replace(m_ReplaceClassName, replaceClass.Name)
                  .Replace(m_ReplaceClassCode, replaceClass.Code)
                  .Replace(m_Id, replaceClass.ZhuJianName[0])
                             .Replace(m_ReposDan, reposEmptyDan).Replace(m_RefGetSelectList, refGetSelect)
                  .Replace(m_Repos, reposEmpty)
                  ;
            }
            else
            {
                contentIndex = Common.Read(m_DempDirectory + m_DanMoban)          
                  .Replace(m_ReplaceClassName, replaceClass.Name)
                  .Replace(m_ReplaceClassCode, replaceClass.Code)
                   .Replace(m_Id, replaceClass.ZhuJianName[0])
                    .Replace(m_ReposDan, reposEmptyDan)
                  ;
            }
            string path = m_RootDirectory + @"/" + m_DAL  + @"/";
            Directory.CreateDirectory(path);
            Common.Write(path + replaceClass.Code + @"Repository.cs", contentIndex);
            fileName.Add(replaceClass.Code);//生成的文件路径和名称
            return;
        }
    }
}
