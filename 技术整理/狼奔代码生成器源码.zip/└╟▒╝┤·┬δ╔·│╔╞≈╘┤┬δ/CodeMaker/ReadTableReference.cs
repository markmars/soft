﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;

namespace CodeMaker
{
    public class ReadTableReference : BaseMain
    {
        public static void TableReference(out List<Table> listTable, out List<Reference> listReference)
        {
            XNamespace xNamespaceAttribute = "attribute";
            XNamespace xNamespaceCollection = "collection";
            XNamespace xNamespaceObject = "object";
            XElement edmx = XElement.Load(m_Pdm);
            listTable = new List<Table>();
            listReference = new List<Reference>();
            Table table;
            IEnumerable<XElement> xElements = from x in edmx.Elements().Elements().Elements()
                                                   .Elements(xNamespaceCollection + "Tables")
                                                  .Elements(xNamespaceObject + "Table")
                                              select x;
            IEnumerable<XElement> referencexElements = from r in
                                                           edmx.Elements().Elements().Elements()
                                                           .Elements(xNamespaceCollection + "References")
                                                           .Elements(xNamespaceObject + "Reference")
                                                       select r;

            foreach (XElement p in referencexElements)
            {
                Reference reference = new Reference()
                {
                    ChildTable = (from t in p.Element(xNamespaceCollection + "ChildTable")
                                      .Element(xNamespaceObject + "Table")
                                      .Attributes("Ref")
                                  select t.Value).FirstOrDefault(),

                    ColumnParentTable = (from t in p.Element(xNamespaceCollection + "Joins")
                                           .Element(xNamespaceObject + "ReferenceJoin")
                                             .Element(xNamespaceCollection + "Object1")
                                              .Element(xNamespaceObject + "Column")
                                               .Attributes("Ref")
                                         select t.Value).FirstOrDefault(),

                    ColumnChildTable = (from t in p.Element(xNamespaceCollection + "Joins")
                                         .Element(xNamespaceObject + "ReferenceJoin")
                                    .Element(xNamespaceCollection + "Object2")
                                     .Element(xNamespaceObject + "Column")
                                      .Attributes("Ref")
                                        select t.Value).FirstOrDefault(),

                    ReferenceId = (from t in p.Attributes("Id") select t.Value).FirstOrDefault(),
                    ParentTable = (from t in p.Element(xNamespaceCollection + "ParentTable")
                                       .Element(xNamespaceObject + "Table")
                                       .Attributes("Ref")
                                   select t.Value).FirstOrDefault()
                };
                listReference.Add(reference);
            }

            foreach (XElement element in xElements)
            {
                table = new Table();
                table.Name = (from t in element.Elements(xNamespaceAttribute + "Name") select t.Value).FirstOrDefault();
                table.Code = (from t in element.Elements(xNamespaceAttribute + "Code") select t.Value).FirstOrDefault();
                table.Id = (from t in element.Attributes("Id") select t.Value).FirstOrDefault();
                var ZhuJians = element.Elements(xNamespaceCollection + "Keys")
                    .Elements(xNamespaceObject + "Key")
                    .Elements(xNamespaceCollection + "Key.Columns")
                     .Elements(xNamespaceObject + "Column").Attributes("Ref").ToList();
                table.ZhuJianId = (from z in ZhuJians select z.Value.ToString()).ToArray();
                table.ZhuJianName = (from p in element.Elements(xNamespaceCollection + "Columns").Elements(xNamespaceObject + "Column")//.Elements(xNamespaceAttribute + "Code")
                                     where table.ZhuJianId.Contains((from t in p.Attributes("Id") select t.Value).FirstOrDefault())
                                     select p.Element(xNamespaceAttribute + "Code").Value).ToArray();
                var attProperty = (from p in element.Elements(xNamespaceCollection + "Columns").Elements(xNamespaceObject + "Column")//.Elements(xNamespaceAttribute + "Code")
                                   select new Attribu
                                   {
                                       Code = p.Element(xNamespaceAttribute + "Code").Value,
                                       TableId = table.Id,
                                       AttributeId = (from t in p.Attributes("Id") select t.Value).FirstOrDefault(),
                                       BelongClass = table.Code,
                                       ObjectID = p.Element(xNamespaceAttribute + "ObjectID").Value,
                                       Name = p.Element(xNamespaceAttribute + "Name").Value,

                                       CreationDate = p.Element(xNamespaceAttribute + "CreationDate").Value,
                                       Creator = p.Element(xNamespaceAttribute + "Creator").Value,
                                       ModificationDate = p.Element(xNamespaceAttribute + "ModificationDate").Value,
                                       Modifier = p.Element(xNamespaceAttribute + "Modifier").Value,
                                       Mandatory = (null == (p.Element(xNamespaceAttribute + "Mandatory"))) ? string.Empty : p.Element(xNamespaceAttribute + "Mandatory").Value,
                                       Length = (null == (p.Element(xNamespaceAttribute + "Length"))) ? string.Empty : p.Element(xNamespaceAttribute + "Length").Value,
                                       LowValue = (null == (p.Element(xNamespaceAttribute + "LowValue"))) ? string.Empty : p.Element(xNamespaceAttribute + "LowValue").Value,
                                       HeighValue = (null == (p.Element(xNamespaceAttribute + "HighValue"))) ? string.Empty : p.Element(xNamespaceAttribute + "HighValue").Value,
                                       Comment = (null == (p.Element(xNamespaceAttribute + "Comment"))) ? string.Empty : p.Element(xNamespaceAttribute + "Comment").Value,
                                       DataType = p.Element(xNamespaceAttribute + "DataType").Value
                                   }).ToList();
                table.Attribute = attProperty;
                listTable.Add(table);
            }
        }

    }
}
