﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CodeMaker
{
    public class BaseMain : Form
    {
        #region 公共变量
        /// <summary>
        /// 类的中文名称
        /// </summary>
        public string m_ReplaceClassName = "^ReplaceClassName^";//
        /// <summary>
        /// 类英文名称
        /// </summary>
        public string m_ReplaceClassCode = "^ReplaceClassCode^";//
        /// <summary>
        /// 表的列名
        /// </summary>
        public string m_ReplaceAttribute = "^ReplaceAttribute^";//
        /// <summary>
        /// 主键列
        /// </summary>
        public string m_Id = @"^m_Id^";
        /// <summary>
        /// 名称列
        /// </summary>
        public string m_Name = @"^m_Name^";
        /// <summary>
        /// 系统文件目录
        /// </summary>
        //public string m_FrameworkDirectory = @"\Framework";//
        /// <summary>
        /// 模板所在
        /// </summary>
        public static string m_DempDirectory ;//
        /// <summary>
        /// pdm路径
        /// </summary>
        public static string m_Pdm = string.Empty;//
        /// <summary>
        /// 生成目的地
        /// </summary>
        public static string m_RootDirectory = string.Empty;//
        /// <summary>
        /// 读取文件中的数据的中间变量
        /// </summary>
        public string m_Line = string.Empty;//
        /// <summary>
        /// 拼接到一起的字符串,注意使用完毕后需要清理clear
        /// </summary>
        public StringBuilder m_Content = new StringBuilder();//
        /// <summary>
        /// 一对多关系
        /// </summary>
        public static List<string> m_refIdClass = new List<string>();
        /// <summary>
        /// 多对多关系
        /// </summary>
        public static List<string> m_refNotIdClass = new List<string>();
        /// <summary>
        /// 自连接关系
        /// </summary>
        public static List<Reference> m_MyselfIdClass = new List<Reference>();
        /// <summary>
        /// Web项目名称
        /// </summary>
        public string m_App = "App";
        /// <summary>
        /// Web项目名称
        /// </summary>
        public string m_Application = "^m_Application^";
        /// <summary>
        /// 视图所在文件夹
        /// </summary>
        public string m_Views = @"/Views";
        /// <summary>
        /// 数据访问层生成目的地 DAL     
        /// </summary>
        public string m_DAL = "DAL";
        /// <summary>
        /// 创建状态，下拉框，Create Edit Index页面使用
        /// </summary>
        public string m_CreateEditorFor = @"        
            <div class=@editor-label@>
                <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </div>
            <div class=@editor-field@>
                <%=Html.DropDownListFor(model => model.^ReplaceAttribute^,App.Models.SysFieldsDDL.GetSysFields(@^ReplaceClassCode^@,@^ReplaceAttribute^@),@请选择@)%>  
            </div>";
        /// <summary>
        /// 大文本，Create Edit 页面使用
        /// </summary>
        public string m_TextAreaFor = @"
            <div class='editor-label'>
                <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </div>
            <div class='editor-field'>
                <%: Html.TextAreaFor(model => model.^ReplaceAttribute^) %>
                <%: Html.ValidationMessageFor(model => model.^ReplaceAttribute^) %>
            </div>";
        /// <summary>
        /// EditorFor普遍的使用方法，Create Edit Index页面使用
        /// </summary>
        public string m_EditorFor = @"     
            <div class=@editor-label@>
                <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
            </div>
            <div class=@editor-field@>
                <%: Html.EditorFor(model => model.^ReplaceAttribute^) %>
                <%: Html.ValidationMessageFor(model => model.^ReplaceAttribute^) %>
            </div>";
        #endregion
    }
}
