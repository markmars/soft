﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeMaker
{
    class Details : BaseMain
    {
        public string m_DetailsDateTimeg = @"        
                <div class=@display-label@>
                    <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </div>
                <div class=@display-field@>
                    <%: String.Format(@{0:g}@, Model.^ReplaceAttribute^) %>
                </div>";
        public string m_DetailsDateTimed = @"        
                <div class=@display-label@>
                    <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </div>
                <div class=@display-field@>
                    <%: String.Format(@{0:d}@, Model.^ReplaceAttribute^) %>
                </div>";
        public string m_DetailsRef = @"        
                <div class=@display-label@>
                      <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </div>
                <div class=@display-field@>
                    <% if (Model.^ReplaceClassCode^ != null && !string.IsNullOrEmpty(Model.^ReplaceClassCode^.^m_Name^))
                       { %>
                    <%: Model.^ReplaceClassCode^.^m_Name^%>
                    <%} %>
                </div>";

        public string m_DetailsNotRef = @"    
                <div class=@display-label@>
                      <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </div>
                <div class=@display-field@>            
                    <% string ids = string.Empty;
                       foreach (var item in Model.^ReplaceClassCode^)
                       {
                           ids += item.^m_Name^;
                           ids += @ , @;
                    %>               
                    <%}%>
                    <div class=@display-field@>
                        <%= ids %>   
                    </div>
                </div>";
        public string m_TextAreaForDetails = @"
                <div class='display-label'>
                    <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </div>
                <div class='display-field'>
                    <%: Html.TextAreaFor(model => model.^ReplaceAttribute^, new {  @readonly=true}) %>
                    <%: Html.ValidationMessageFor(model => model.^ReplaceAttribute^) %>
                </div>";
        public string m_DetailsString = @"      
                <div class=@display-label@>
                      <%: Html.LabelFor(model => model.^ReplaceAttribute^) %>
                </div>
                <div class=@display-field@>
                    <%: Model.^ReplaceAttribute^ %>
                </div>";

        public string m_PickTimeCrea = @"^m_PickTimeCrea^";
        public string m_Details = @"^m_Details^";
        public string m_DetailsmMster = @"^m_DetailsmMster^";
        public string m_DetailsSmall = @"/Small";

        public void DoDetails(Table replaceClass, List<Attribu> attProperty, ref List<string> fileName)
        {
            StringBuilder index = new StringBuilder();
            string pickTimeCreate = string.Empty;
            string replaceInt = string.Empty; ;
            string myid = replaceClass.Attribute[0].Code;//默认第一个是主键
            string myname = replaceClass.Attribute[1].Code;
            int flag = 0;//ids item  

            foreach (var item in replaceClass.Attribute)
            {
                //更新时间，更新人，时间戳，等不生成代码
                if (item.Code.Contains("UpdatePerson") || item.Code.Contains("UpdateTime") || item.Code.Contains("Remark") || item.Code.Contains("Version"))
                {
                    continue;
                }
                flag++;
                //主键
                if (!string.IsNullOrWhiteSpace(item.Code) && replaceClass.ZhuJianId != null && replaceClass.ZhuJianId.Contains(item.AttributeId))
                {
                    continue;
                }
                //数值和时间类型
                if (!string.IsNullOrWhiteSpace(item.Code) && !string.IsNullOrWhiteSpace(item.DataType))
                {
                    switch (item.DataType)
                    {
                        case "date":
                        case "datetime":
                            //更新时间，更新人，时间戳，等不生成代码
                            if (item.Code.Contains("CreateTime"))
                            {
                                replaceInt += m_DetailsDateTimeg.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                            }
                            else
                            {
                                replaceInt += m_DetailsDateTimed.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');
                            }
                            
                            continue;
                        default:
                            break;
                    }
                }
                //外键列
                if (replaceClass.refId != null)
                {

                    var re = replaceClass.refId.Where(a => a.Ref == item.Code).FirstOrDefault();
                    if (re != null)
                    { //自连接列
                        if (m_MyselfIdClass != null)
                        {
                            var myselfRef = from f in m_MyselfIdClass
                                            where item.TableId == f.ParentTable
                                            where item.AttributeId == f.ColumnChildTable
                                            select f;
                            if (myselfRef != null && myselfRef.Count() > 0)
                            {
                                replaceInt += m_DetailsRef.Replace(m_ReplaceAttribute, item.Code)
                                    .Replace(m_ReplaceClassCode, replaceClass.Code + "2")
                                    .Replace(m_Name, re.Name)
                                    .Replace('@', '"');

                                continue;
                            }
                        }
                        replaceInt += m_DetailsRef.Replace(m_ReplaceAttribute, item.Code)
                            .Replace(m_ReplaceClassCode, re.RefTable)
                            .Replace(m_Id, re.Id)
                            .Replace(m_Name, re.Name)
                            .Replace('@', '"');
                        continue;
                    }
                }

                //string等其他类型
                if (!string.IsNullOrWhiteSpace(item.Length) && Convert.ToInt32(item.Length) >= 2000)
                {
                    replaceInt += m_TextAreaForDetails.Replace(m_ReplaceAttribute, item.Code).Replace('\'', '"');
                }
                else
                {
                    replaceInt += m_DetailsString.Replace(m_ReplaceAttribute, item.Code).Replace('@', '"');

                }
            }

            if (replaceClass.refNotId != null && replaceClass.refNotId.Count() > 0)
            {
                //非外键连接，包含非外键的Id
                foreach (var item in replaceClass.refNotId)
                {
                    flag++;
                    replaceInt += m_DetailsNotRef.Replace(m_ReplaceAttribute, item.RefTable + item.Id)
                           .Replace(m_ReplaceClassCode, item.RefTable)
                           .Replace(m_Id, item.Id)
                           .Replace(m_Name, item.Name)
                           .Replace("ids", "ids" + flag.ToString())
                           .Replace("item", "item" + flag.ToString()).Replace('@', '"');

                }
            }
            var contentIndex = Common.Read(m_DempDirectory + "/Details.aspx")
                .Replace(m_PickTimeCrea, pickTimeCreate)

                .Replace(m_Details, replaceInt)   //
                .Replace(m_DetailsmMster, m_DetailsSmall)
                .Replace(m_ReplaceClassCode, replaceClass.Code)
                .Replace(m_ReplaceClassName, replaceClass.Name);

            string path = m_RootDirectory + "/" + m_App + m_Views + "/" + replaceClass.Code;
            Directory.CreateDirectory(path);
            Common.Write(path + "/Details.aspx", contentIndex);
            fileName.Add(replaceClass.Code + "/Details.aspx");//生成的文件路径和名称
        }
    }
}
