﻿namespace CodeMaker
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnShengChengXiTong = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txbPDM = new System.Windows.Forms.TextBox();
            this.txbMuDiDI = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_CreateTime = new System.Windows.Forms.Button();
            this.btnPathOfpdm = new System.Windows.Forms.Button();
            this.btnShengChengMuDiDi = new System.Windows.Forms.Button();
            this.folderBrowserDialog1shengcheng = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1pdm = new System.Windows.Forms.OpenFileDialog();
            this.btnMoBan = new System.Windows.Forms.Button();
            this.txbMoBan = new System.Windows.Forms.TextBox();
            this.labMoBan = new System.Windows.Forms.Label();
            this.folderBrowserDialog1MoBan = new System.Windows.Forms.FolderBrowserDialog();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 130);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(499, 245);
            this.textBox1.TabIndex = 0;
            // 
            // btnShengChengXiTong
            // 
            this.btnShengChengXiTong.Location = new System.Drawing.Point(62, 390);
            this.btnShengChengXiTong.Name = "btnShengChengXiTong";
            this.btnShengChengXiTong.Size = new System.Drawing.Size(75, 23);
            this.btnShengChengXiTong.TabIndex = 1;
            this.btnShengChengXiTong.Text = "生成系统";
            this.btnShengChengXiTong.UseVisualStyleBackColor = true;
            this.btnShengChengXiTong.Click += new System.EventHandler(this.btnShengChengXiTong_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "PowerDesigner文件";
            // 
            // txbPDM
            // 
            this.txbPDM.Location = new System.Drawing.Point(126, 53);
            this.txbPDM.Name = "txbPDM";
            this.txbPDM.Size = new System.Drawing.Size(298, 21);
            this.txbPDM.TabIndex = 3;
            this.txbPDM.Text = "D:\\Moban\\Sys.PDM";
            // 
            // txbMuDiDI
            // 
            this.txbMuDiDI.Location = new System.Drawing.Point(126, 93);
            this.txbMuDiDI.Name = "txbMuDiDI";
            this.txbMuDiDI.Size = new System.Drawing.Size(298, 21);
            this.txbMuDiDI.TabIndex = 5;
            this.txbMuDiDI.Text = "D:\\";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "生成到哪个文件夹";
            // 
            // btn_CreateTime
            // 
            this.btn_CreateTime.Location = new System.Drawing.Point(235, 390);
            this.btn_CreateTime.Name = "btn_CreateTime";
            this.btn_CreateTime.Size = new System.Drawing.Size(276, 23);
            this.btn_CreateTime.TabIndex = 6;
            this.btn_CreateTime.Text = "重新生成Model1.edmx后使用";
            this.btn_CreateTime.UseVisualStyleBackColor = true;
            this.btn_CreateTime.Click += new System.EventHandler(this.btn_CreateTime_Click);
            // 
            // btnPathOfpdm
            // 
            this.btnPathOfpdm.Location = new System.Drawing.Point(436, 53);
            this.btnPathOfpdm.Name = "btnPathOfpdm";
            this.btnPathOfpdm.Size = new System.Drawing.Size(75, 23);
            this.btnPathOfpdm.TabIndex = 9;
            this.btnPathOfpdm.Text = "选择";
            this.btnPathOfpdm.UseVisualStyleBackColor = true;
            this.btnPathOfpdm.Click += new System.EventHandler(this.btnPathOfpdm_Click);
            // 
            // btnShengChengMuDiDi
            // 
            this.btnShengChengMuDiDi.Location = new System.Drawing.Point(436, 93);
            this.btnShengChengMuDiDi.Name = "btnShengChengMuDiDi";
            this.btnShengChengMuDiDi.Size = new System.Drawing.Size(75, 23);
            this.btnShengChengMuDiDi.TabIndex = 10;
            this.btnShengChengMuDiDi.Text = "选择";
            this.btnShengChengMuDiDi.UseVisualStyleBackColor = true;
            this.btnShengChengMuDiDi.Click += new System.EventHandler(this.btnShengChengMuDiDi_Click);
            // 
            // openFileDialog1pdm
            // 
            this.openFileDialog1pdm.FileName = "openFileDialog1";
            // 
            // btnMoBan
            // 
            this.btnMoBan.Location = new System.Drawing.Point(436, 12);
            this.btnMoBan.Name = "btnMoBan";
            this.btnMoBan.Size = new System.Drawing.Size(75, 23);
            this.btnMoBan.TabIndex = 13;
            this.btnMoBan.Text = "选择";
            this.btnMoBan.UseVisualStyleBackColor = true;
            this.btnMoBan.Click += new System.EventHandler(this.btnMoBan_Click);
            // 
            // txbMoBan
            // 
            this.txbMoBan.Location = new System.Drawing.Point(127, 12);
            this.txbMoBan.Name = "txbMoBan";
            this.txbMoBan.Size = new System.Drawing.Size(298, 21);
            this.txbMoBan.TabIndex = 12;
            this.txbMoBan.Text = "D:\\Moban";
            // 
            // labMoBan
            // 
            this.labMoBan.AutoSize = true;
            this.labMoBan.Location = new System.Drawing.Point(18, 12);
            this.labMoBan.Name = "labMoBan";
            this.labMoBan.Size = new System.Drawing.Size(89, 12);
            this.labMoBan.TabIndex = 11;
            this.labMoBan.Text = "模板所在文件夹";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 464);
            this.Controls.Add(this.btnMoBan);
            this.Controls.Add(this.txbMoBan);
            this.Controls.Add(this.labMoBan);
            this.Controls.Add(this.btnShengChengMuDiDi);
            this.Controls.Add(this.btnPathOfpdm);
            this.Controls.Add(this.btn_CreateTime);
            this.Controls.Add(this.txbMuDiDI);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txbPDM);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnShengChengXiTong);
            this.Controls.Add(this.textBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main";
            this.Text = "狼奔代码生成器";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnShengChengXiTong;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbPDM;
        private System.Windows.Forms.TextBox txbMuDiDI;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_CreateTime;
        private System.Windows.Forms.Button btnPathOfpdm;
        private System.Windows.Forms.Button btnShengChengMuDiDi;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1shengcheng;
        private System.Windows.Forms.OpenFileDialog openFileDialog1pdm;
        private System.Windows.Forms.Button btnMoBan;
        private System.Windows.Forms.TextBox txbMoBan;
        private System.Windows.Forms.Label labMoBan;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1MoBan;
    }
}