﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace QQ群发
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll ")]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll ")]
        static extern IntPtr GetDlgItem(IntPtr hDlg, int nIDDlgItem);
        [DllImport("user32.dll ", SetLastError = true)]
        public static extern IntPtr FindWindowEx(IntPtr parentHandle, int childAfter, string className, int windowTitle);
        [DllImport("user32.dll ", EntryPoint = "SendMessage ")]
        static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, int wParam, string lParam);
        [DllImport("kernel32.dll ", CharSet = CharSet.Auto)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);
        IntPtr hwndQQ, hwnd1, hwnd2, hwnd3, hwnd4;

        public Form1()
        {
            InitializeComponent();
        }
        void MySendMessage()
        {
            string machinename = System.Environment.MachineName;//获得计算机名
            Process[] processlist = Process.GetProcesses(machinename);//得到所有进程
            foreach (Process p in processlist)//列举每个进程
            {
                if (p.MainWindowTitle != " ")//标题是否为空，不为空执行下面代码
                {
                    if (p.MainWindowTitle.ToString().Substring(0, 1) == "与 ")//查看窗口标题第一个字是否是“与”。如果是的，说明是QQ窗口
                    {
                        hwndQQ = FindWindow("#32770 ", p.MainWindowTitle.ToString());
                        hwnd1 = GetDlgItem(hwndQQ, 0);
                        hwnd2 = GetDlgItem(hwnd1, 0);
                        hwnd3 = GetDlgItem(hwnd2, 894);
                        SendMessage(hwnd3, 194, 0, "此处暂时不知道填什么");//向QQ输入框粘贴字符，this.textBox1.Text是要发送的文字信息
                        hwnd4 = GetDlgItem(hwnd1, 1);
                        SendMessage(hwnd4, 245, 0, Convert.ToString(0));
                    }
                }
            }
        }
        /// <summary>
        /// 单个用户发送消息
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void btnSend_Click(object sender, EventArgs e)
        {
            MySendMessage();//发送信息,向单个用户发送。
        }
        /// <summary>
        /// 循环发送消息
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void btnSSend_Click(object sender, EventArgs e)
        {
            this.Qtimer.Enabled = true;
        }
        /// <summary>
        /// 停止发送消息
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void btnSStop_Click(object sender, EventArgs e)
        {
            this.Qtimer.Enabled = false;
        }
        /// <summary>
        /// 计时器开始发送消息
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void Qtimer_Tick(object sender, EventArgs e)
        {
            this.MySendMessage();
        }
        void QunSendMessage()//针对群的消息发送过程
        {
            string machinename = System.Environment.MachineName;
            Process[] processlist = Process.GetProcesses(machinename);
            foreach (Process p in processlist)
            {
                if (p.MainWindowTitle != " ")
                {
                    if (p.MainWindowTitle.ToString().Substring(p.MainWindowTitle.Length - 1, 1) == "群 ")
                    {
                        hwndQQ = FindWindow("#32770 ", p.MainWindowTitle.ToString());
                        hwnd1 = GetDlgItem(hwndQQ, 0);
                        hwnd2 = GetDlgItem(hwnd1, 0);
                        hwnd3 = GetDlgItem(hwnd2, 894);
                        SendMessage(hwnd3, 194, 0, "***********************");//向QQ输入框粘贴字符
                        hwnd4 = GetDlgItem(hwnd1, 1);
                        SendMessage(hwnd4, 245, 0, Convert.ToString(0));
                    }
                }
            }
        }
        /// <summary>
        /// 向群组发消息
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void btnGXSend_Click(object sender, EventArgs e)
        {
            this.QunSendMessage();//向群发送单条信息
        }
        /// <summary>
        /// 循环向群组发送消息
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void btnGSend_Click(object sender, EventArgs e)
        {
            this.QGtimer.Enabled = true;
        }
        /// <summary>
        /// 停止向群组发送消息
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void btnGStop_Click(object sender, EventArgs e)
        {
            this.QGtimer.Enabled = false;
        }
        /// <summary>
        /// 计时器发送消息
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void QGtimer_Tick(object sender, EventArgs e)
        {
            this.QunSendMessage();//连续发送信息，多少秒发送一次，自己设定。
        }
        /// <summary>
        /// 利用tencent协议，打开临时对话框 ;
        /// </summary>
        /// <param name= "sender "> </param>
        /// <param name= "e "> </param>
        void btnQQ_Click(object sender, EventArgs e)
        {
            string s = "tencent://message/?uin= " + "************************" + "&Site=im.qq.com&Menu=yes ";//是对方的QQ号 比如疯狂代码和傲博知识库的qq
            Process.Start(s);
        }
    }
}
