using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace FlashTransparentLib
{
	/// <summary>
	/// StreamBasedOnIStream ��ժҪ˵����
	/// </summary>
	internal class StreamBasedOnIStream:System.IO.Stream
	{
		private Control control;
		private int stream;
		private const int STREAM_SEEK_CUR = 1;
		private const int STREAM_SEEK_END = 2;
		private const int STREAM_SEEK_SET = 0;

		public StreamBasedOnIStream(int stream, bool bAddRef)
		{
			this.stream = stream;
			if (bAddRef)
			{
				Wrapper.FPC_IStream_AddRef(stream);
			}
			this.control = new Control();
		}

		public override void Close()
		{
			if (this.control.InvokeRequired)
			{
				this.control.Invoke(new Call_Close(this.Close_));
			}
			else
			{
				this.Close_();
			}
		}

		private void Close_()
		{
			if (this.stream != 0)
			{
				Wrapper.FPC_IStream_Release(this.stream);
				this.stream = 0;
			}
		}

		~StreamBasedOnIStream()
		{
			this.Close();
		}

		public override void Flush()
		{
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			return 0;
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			return 0L;
		}

		public override void SetLength(long value)
		{
		}

		private void Write(byte[] buffer, int count)
		{
			uint num;
			IntPtr destination = Marshal.AllocCoTaskMem(count);
			Marshal.Copy(buffer, 0, destination, count);
			Wrapper.FPC_IStream_Write(this.stream, destination.ToInt32(), count, out num);
			Marshal.FreeCoTaskMem(destination);
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			if (offset != 0)
			{
				throw new ArgumentException();
			}
			if (this.control.InvokeRequired)
			{
				this.control.Invoke(new Call_Write(this.Write), new object[] { buffer, count });
			}
			else
			{
				this.Write(buffer, count);
			}
		}

		public override bool CanRead
		{
			get
			{
				return false;
			}
		}

		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		public override bool CanWrite
		{
			get
			{
				return true;
			}
		}

		public override long Length
		{
			get
			{
				return 0L;
			}
		}

		public override long Position
		{
			get
			{
				return -1L;
			}
			set
			{
			}
		}

		private delegate void Call_Close();

		private delegate void Call_Write(byte[] buffer, int count);
		
	}
}
