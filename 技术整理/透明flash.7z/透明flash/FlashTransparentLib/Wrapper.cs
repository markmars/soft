using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace FlashTransparentLib
{
	public class Wrapper
	{
		private const int FPCM_FIRST = 0x1400;
		internal const int FPCM_GET_FRAME_BITMAP = 0x1404;
		internal const int FPCM_GET_OVERALL_OPAQUE = 0x1409;
		internal const int FPCM_PUT_OVERALL_OPAQUE = 0x1408;
		private const int FPCN_FIRST = 0x13ff;
		internal const int FPCN_FLASHCALLW = 0x13fa;
		internal const int FPCN_FSCOMMANDW = 0x12fd;
		internal const int FPCN_LOADEXTERNALRESOURCEEXW = 0x13f8;
		internal const int FPCN_LOADEXTERNALRESOURCEW = 0x13fc;
		internal const int FPCN_ONPROGRESS = 0x12ff;
		internal const int FPCN_ONREADYSTATECHANGE = 0x1300;
		internal const int VARIANT_FALSE = 0;
		internal const int VARIANT_TRUE = -1;
		private const int WM_USER = 0x400;

		static Wrapper()
		{
			string path =System.Environment.SystemDirectory+"\\FlashTransparent.dll";
			if (!File.Exists(path))
			{
				string [] str=Assembly.GetCallingAssembly().GetManifestResourceNames();
				foreach(string s in str)
				{
					Console.WriteLine(s);
				}
				Stream manifestResourceStream= Assembly.GetCallingAssembly().GetManifestResourceStream("FlashTransparentLib.ft.dll");

				Stream stream2 = File.OpenWrite(path);
				byte[] buffer = new byte[manifestResourceStream.Length];
				manifestResourceStream.Read(buffer, 0, (int) manifestResourceStream.Length);
				stream2.Write(buffer, 0, (int) manifestResourceStream.Length);
				stream2.Close();
			}
		}

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_AddOnLoadExternalResourceHandlerW(uint hFPC, LoadExternalResourceHandler pHandler, int lParam);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_Back(int hWnd);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_CurrentFrame(int hWnd, ref int Result);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern void FPC_EnableSound(uint hFPC, int bEnable);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_FlashVersion(int hWnd, ref int Result);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_Forward(int hWnd);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_FrameLoaded(int hWnd, int FrameNum, ref int Result);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetAlignMode(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetAllowScriptAccessW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetAllowScriptAccess(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_GetAxHWND(int hWnd);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetBackgroundColor(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetBaseW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetBase(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetBGColorW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetBGColor(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_GetClassNameA(uint hFPC);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetDeviceFont(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetEmbedMovie(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetFlashVarsW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetFlashVars(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetFrameNum(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetLoop(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetMenu(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetMovieW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetMovie(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetMovieDataW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetMovieData(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetPlaying(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetQuality(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetQuality2W", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetQuality2(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetReadyState(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetSAlignW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetSAlign(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetScaleW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetScale(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetScaleMode(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_GetSoundVolume(uint hFPC);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetStackingW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetStacking(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_GetStandardMenu(int hWnd, out int bEnabled);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetSWRemoteW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetSWRemote(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetTotalFrames(int hWnd, ref int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetVariableW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetVariable(int hWnd, string name, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_GetVersion(uint hFPC);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_GetWModeW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GetWMode(int hWnd, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_GotoFrame(int hWnd, int FrameNum);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_IsPlaying(int hWnd, ref int Result);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_IsSoundEnabled(uint hFPC);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_IStream_AddRef(int pStream);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_IStream_Release(int pStream);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_IStream_Write(int pStream, int pBuffer, int Size, out uint WrittenBytes);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_LoadMovie(int hWnd, int layer, string url);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern uint FPC_LoadOCXCodeFromMemory(uint pData, uint dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern uint FPC_LoadRegisteredOCX();

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_Pan(int hWnd, int x, int y, int mode);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PercentLoaded(int hWnd, ref int Result);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_Play(int hWnd);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutAlignMode(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutAllowScriptAccessW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutAllowScriptAccess(int hWnd, string AllowScriptAccess);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutBackgroundColor(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutBaseW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutBase(int hWnd, string Base);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutBGColorW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutBGColor(int hWnd, string BGColor);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutDeviceFont(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutEmbedMovie(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutFlashVarsW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutFlashVars(int hWnd, string FlashVars);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutFrameNum(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutLoop(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutMenu(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutMovieW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutMovie(int hWnd, string Movie);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutMovieDataW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutMovieData(int hWnd, string MovieData);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutPlaying(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutQuality(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutQuality2W", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutQuality2(int hWnd, string Quality2);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutSAlignW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutSAlign(int hWnd, string SAlign);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutScaleW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutScale(int hWnd, string Scale);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutScaleMode(int hWnd, int Value);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutStackingW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutStacking(int hWnd, string Stacking);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_PutStandardMenu(int hWnd, int bEnable);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutSWRemoteW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutSWRemote(int hWnd, string SWRemote);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_PutWModeW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_PutWMode(int hWnd, string WMode);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_Rewind(int hWnd);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Ansi)]
		public static extern void FPC_SetContext(int hWnd, string Context);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_SetSoundVolume(uint hFPC, int nVolume);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_SetVariable(int hWnd, string name, string value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_SetZoomRect(int hWnd, int left, int top, int right, int bottom);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_Stop(int hWnd);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_StopPlay(int hWnd);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TCallFrame(int hWnd, string target, int FrameNum);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TCallLabel(int hWnd, string target, string label);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TCurrentFrame(int hWnd, string target, ref int Result);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_TCurrentLabelW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TCurrentLabel(int hWnd, string target, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", EntryPoint="FPC_TGetPropertyW", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TGetProperty(int hWnd, string target, int Property, int pBuffer, ref int dwSize);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TGetPropertyAsNumber(int hWnd, string target, int Property, ref double Result);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TGetPropertyNum(int hWnd, string target, int Property, ref double Result);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TGotoFrame(int hWnd, string target, int FrameNum);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TGotoLabel(int hWnd, string target, string label);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TPlay(int hWnd, string target);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TSetProperty(int hWnd, string target, int Property, string value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TSetPropertyNum(int hWnd, string target, int Property, double value);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_TStopPlay(int hWnd, string target);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPC_UnloadCode(uint hFPC);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0, CharSet=CharSet.Unicode)]
		internal static extern int FPC_Zoom(int hWnd, int factor);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPCCallFunctionBSTR(int hWnd, int bstrRequest, ref int bstrResponse);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPCIsFlashInstalled();

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPCIsTransparentAvailable();

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPCLoadMovieUsingStream(int hWnd, int layer, out int stream);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPCPutMovieUsingStream(int hWnd, out int stream);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int FPCSetEventListener(int hWnd, EventsListener pEventsListener, int lParam);

		[DllImport("FlashTransparent.dll", EntryPoint="FPCSetReturnValueW", CallingConvention=(CallingConvention) 0)]
		public static extern int FPCSetReturnValue(int hWnd, int strValue);

		[DllImport("FlashTransparent.dll", CallingConvention=(CallingConvention) 0)]
		public static extern int GetInstalledFlashVersion();


		public delegate int EventsListener(int hWnd, int lParam, int pNMHDR);

		public delegate int LoadExternalResourceHandler(int lpszURL, ref int stream, uint hFPC, int lParam);

		[StructLayout(LayoutKind.Sequential)]
			internal struct NMHDR
		{
			public int hwndFrom;
			public uint idFrom;
			public uint code;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCFlashCallInfoStructW
		{
			public Wrapper.NMHDR hdr;
			public int request;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCFSCommandInfoStructW
		{
			public Wrapper.NMHDR hdr;
			public int command;
			public int args;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCGetFrameBitmap
		{
			public int hBitmap;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCGetOverallOpaque
		{
			public int Value;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCLoadExternalResourceExW
		{
			public Wrapper.NMHDR hdr;
			public int lpszRelativePath;
			public int lpStream;
			public int bHandled;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCLoadExternalResourceW
		{
			public Wrapper.NMHDR hdr;
			public int lpszRelativePath;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCOnProgressInfoStruct
		{
			public Wrapper.NMHDR hdr;
			public int percentDone;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCOnReadyStateChangeInfoStruct
		{
			public Wrapper.NMHDR hdr;
			public int newState;
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct SFPCPutOverallOpaque
		{
			public int Value;
		}
	}
}
