using System;

namespace FlashTransparentLib
{
	/// <summary>
	/// Global ��ժҪ˵����
	/// </summary>
	public class Global
	{
		/// <summary>
		/// ��װ��FLASH�汾
		/// </summary>
		public static Version InstalledFlashVersion
		{
			get
			{
				return new Version(Wrapper.GetInstalledFlashVersion());
			}
		}

		/// <summary>
		/// �Ƿ�װ��FLASH���
		/// </summary>
		public static bool IsFlashInstalled
		{
			get
			{
				return (0 != Wrapper.FPCIsFlashInstalled());
			}
		}

		/// <summary>
		/// �Ƿ�����Ч��͸��ģʽ
		/// </summary>
		public static bool IsTransparentModeAvailable
		{
			get
			{
				return (0 != Wrapper.FPCIsTransparentAvailable());
			}
		}
	}
}
