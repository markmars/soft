using System;
using System.Reflection;

namespace FlashTransparentLib
{
	/// <summary>
	/// Version ��ժҪ˵����
	/// </summary>
	public class Version
	{
 
		private byte[] parts = new byte[4];
		private int version;

		public Version(int nVersion)
		{
			this.version = nVersion;
			for (int i = 0; i < 4; i++)
			{
				this.parts[i] = (byte) (this.version & 0xff);
				this.version = this.version >> 8;
			}
		}
		public override string ToString()
		{
			string str = "";
			for (int i = this.parts.Length - 1; i >= 0; i--)
			{
				if (str.Length != 0)
				{
					str = str + ".";
				}
				str = str + this.parts[i].ToString();
			}
			return str;
		}

		public byte this[int index]
		{
			get
			{
				return this.parts[index];
			}
		}

		public byte MajorPart
		{
			get
			{
				return this.parts[3];
			}
		}
	}
}

