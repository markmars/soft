using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace FlashTransparentLib
{
	/// <summary>
	/// FTForm ��ժҪ˵����
	/// </summary>
	public class FTForm : Form, IMessageFilter
	{
		private AxCode m_AxCode;
		private string m_Context;
		private Wrapper.EventsListener pEventsListener;

		private const int WM_RBUTTONUP = 0x205;

		public event OnFlashCallEventHandler OnFlashCall;

		public event OnFSCommandEventHandler OnFSCommand;

		public event OnLoadExternalResourceByRelativePathEventHandler OnLoadExternalResourceByRelativePath;

		public event OnProgressEventHandler OnProgress;

		public event OnReadyStateChangeEventHandler OnReadyStateChange;

		private int m_nX = 0, m_nY = 0;
		private int m_nLeft = 0, m_nTop = 0;
		private bool cMove=false;
		public bool CanMove
		{
			get
			{
				return this.cMove;
			}
			set
			{
				this.cMove=value;
			}
		}
		public FTForm()
		{
			this.m_AxCode = null;
			this.m_AxCode = new AxCode();
			base.RecreateHandle();
			InitializeComponent();
		}

		public FTForm(AxCode code)
		{
			this.m_AxCode = null;
			this.m_AxCode = code;
			base.RecreateHandle();
			InitializeComponent();
		}

		private void InitializeComponent()
		{
			base.MouseDown+=new MouseEventHandler(FTForm_MouseDown);
			base.MouseMove+=new MouseEventHandler(FTForm_MouseMove);
			base.MouseUp+=new MouseEventHandler(FTForm_MouseUp);
		}

		[DllImport("gdi32.dll", CallingConvention=(CallingConvention) 0)]
		internal static extern int DeleteObject(int hObject);

		private int EventsListener(int hWnd, int lParam, int pNMHDR)
		{
			Wrapper.NMHDR nmhdr = (Wrapper.NMHDR) Marshal.PtrToStructure(new IntPtr(pNMHDR), typeof(Wrapper.NMHDR));
			switch (nmhdr.code)
			{
				case 0x12fd:
				{
					Wrapper.SFPCFSCommandInfoStructW tw = (Wrapper.SFPCFSCommandInfoStructW) Marshal.PtrToStructure(new IntPtr(pNMHDR), typeof(Wrapper.SFPCFSCommandInfoStructW));
					if (this.OnFSCommand != null)
					{
						this.OnFSCommand(this, Marshal.PtrToStringUni(new IntPtr(tw.command)), Marshal.PtrToStringUni(new IntPtr(tw.args)));
					}
					break;
				}
				case 0x12ff:
				{
					Wrapper.SFPCOnProgressInfoStruct struct2 = (Wrapper.SFPCOnProgressInfoStruct) Marshal.PtrToStructure(new IntPtr(pNMHDR), typeof(Wrapper.SFPCOnProgressInfoStruct));
					if (this.OnProgress != null)
					{
						this.OnProgress(this, struct2.percentDone);
					}
					break;
				}
				case 0x1300:
				{
					Wrapper.SFPCOnReadyStateChangeInfoStruct struct3 = (Wrapper.SFPCOnReadyStateChangeInfoStruct) Marshal.PtrToStructure(new IntPtr(pNMHDR), typeof(Wrapper.SFPCOnReadyStateChangeInfoStruct));
					if (this.OnReadyStateChange != null)
					{
						this.OnReadyStateChange(this, (ReadyState) struct3.newState);
					}
					break;
				}
				case 0x13f8:
				{
					Wrapper.SFPCLoadExternalResourceExW structure = (Wrapper.SFPCLoadExternalResourceExW) Marshal.PtrToStructure(new IntPtr(pNMHDR), typeof(Wrapper.SFPCLoadExternalResourceExW));
					if (this.OnLoadExternalResourceByRelativePath != null)
					{
						bool handled = false;
						Stream contentStream = new StreamBasedOnIStream(structure.lpStream, true);
						this.OnLoadExternalResourceByRelativePath(this, Marshal.PtrToStringUni(new IntPtr(structure.lpszRelativePath)), contentStream, ref handled);
						if (!handled)
						{
							contentStream.Close();
						}
						structure.bHandled = handled ? 1 : 0;
					}
					Marshal.StructureToPtr(structure, new IntPtr(pNMHDR), true);
					break;
				}
				case 0x13fa:
				{
					Wrapper.SFPCFlashCallInfoStructW tw2 = (Wrapper.SFPCFlashCallInfoStructW) Marshal.PtrToStructure(new IntPtr(pNMHDR), typeof(Wrapper.SFPCFlashCallInfoStructW));
					if (this.OnFlashCall != null)
					{
						this.OnFlashCall(this, Marshal.PtrToStringUni(new IntPtr(tw2.request)));
					}
					break;
				}
			}
			return 0;
		}


		/// <summary>
		/// FLASH����,����
		/// </summary>
		public void FlashMethod_Back()
		{
			Wrapper.FPC_Back(base.Handle.ToInt32());
		}
		/// <summary>
		/// FLASH���� ���÷���
		/// </summary>
		/// <param name="Request">����</param>
		/// <returns>���ؽ��</returns>
		public string FlashMethod_CallFunction(string Request)
		{
			string str = "";
			IntPtr ptr = Marshal.StringToBSTR(Request);
			int bstrResponse = 0;
			Wrapper.FPCCallFunctionBSTR(base.Handle.ToInt32(), ptr.ToInt32(), ref bstrResponse);
			if (bstrResponse != 0)
			{
				str = Marshal.PtrToStringUni(new IntPtr(bstrResponse));
				Marshal.FreeBSTR(new IntPtr(bstrResponse));
			}
			Marshal.FreeBSTR(ptr);
			return str;
		}
		/// <summary>
		/// ��ȡ��ǰ֡
		/// </summary>
		/// <returns></returns>
		public int FlashMethod_CurrentFrame()
		{
			int result = 0;
			Wrapper.FPC_CurrentFrame(base.Handle.ToInt32(), ref result);
			return result;
		}

		/// <summary>
		/// ��ȡFLASH�汾��Ϣ
		/// </summary>
		/// <returns></returns>
		public int FlashMethod_FlashVersion()
		{
			int result = 0;
			Wrapper.FPC_FlashVersion(base.Handle.ToInt32(), ref result);
			return result;
		}

		/// <summary>
		/// FLASH����,ǰ��
		/// </summary>
		public void FlashMethod_Forward()
		{
			Wrapper.FPC_Forward(base.Handle.ToInt32());
		}
		/// <summary>
		///  FLASH����,�Ƿ񼺼��ص�֡
		/// </summary>
		/// <param name="FrameNum">֡</param>
		/// <returns>�����Ƿ�ɹ�</returns>
		public bool FlashMethod_FrameLoaded(int FrameNum)
		{
			int result = 0;
			Wrapper.FPC_FrameLoaded(base.Handle.ToInt32(), FrameNum, ref result);
			return (result != 0);
		}

		/// <summary>
		/// FLASH����,��ȡ����
		/// </summary>
		/// <param name="name">��������</param>
		/// <returns>��ȡ��ֵ</returns>
		public string FlashMethod_GetVariable(string name)
		{
			string str = "";
			int dwSize = 0;
			if (Wrapper.FPC_GetVariable(base.Handle.ToInt32(), name, 0, ref dwSize) == 0)
			{
				dwSize++;
				IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
				Marshal.WriteInt32(ptr, 0);
				Wrapper.FPC_GetVariable(base.Handle.ToInt32(), name, ptr.ToInt32(), ref dwSize);
				str = Marshal.PtrToStringUni(ptr);
				Marshal.FreeCoTaskMem(ptr);
			}
			return str;
		}

		/// <summary>
		///  FLASH����,��ת��֡
		/// </summary>
		/// <param name="FrameNum">֡</param>
		public void FlashMethod_GotoFrame(int FrameNum)
		{
			Wrapper.FPC_GotoFrame(base.Handle.ToInt32(), FrameNum);
		}

		/// <summary>
		/// FLASH����,��ȡ��ǰ�Ƿ����ڲ�����
		/// </summary>
		/// <returns></returns>
		public bool FlashMethod_IsPlaying()
		{
			int result = 0;
			Wrapper.FPC_IsPlaying(base.Handle.ToInt32(), ref result);
			return (result != 0);
		}

		/// <summary>
		/// FLASH����,װ��ӰƬ
		/// </summary>
		/// <param name="layer">��</param>
		/// <param name="url">ӰƬ��ַ</param>
		public void FlashMethod_LoadMovie(int layer, string url)
		{
			Wrapper.FPC_LoadMovie(base.Handle.ToInt32(), layer, url);
		}

		/// <summary>
		/// FLASH����,ƽ��
		/// </summary>
		/// <param name="x">X����</param>
		/// <param name="y">Y����</param>
		/// <param name="mode">ģʽ</param>
		public void FlashMethod_Pan(int x, int y, int mode)
		{
			Wrapper.FPC_Pan(base.Handle.ToInt32(), x, y, mode);
		}

		/// <summary>
		/// ��ȡӰƬװ�ذٷֱ�
		/// </summary>
		/// <returns></returns>
		public int FlashMethod_PercentLoaded()
		{
			int result = 0;
			Wrapper.FPC_PercentLoaded(base.Handle.ToInt32(), ref result);
			return result;
		}

		/// <summary>
		/// FLASH����,,����FLASH
		/// </summary>
		public void FlashMethod_Play()
		{
			Wrapper.FPC_Play(base.Handle.ToInt32());
		}

		/// <summary>
		/// FLASH����,�ز�
		/// </summary>
		public void FlashMethod_Rewind()
		{
			Wrapper.FPC_Rewind(base.Handle.ToInt32());
		}

		/// <summary>
		///���÷���ֵ
		/// </summary>
		/// <param name="strValue">ֵ</param>
		public void FlashMethod_SetReturnValue(string strValue)
		{
				IntPtr ptr = Marshal.StringToBSTR(strValue);
				Wrapper.FPCSetReturnValue(base.Handle.ToInt32(), ptr.ToInt32());
				Marshal.FreeBSTR(ptr);
		}

		/// <summary>
		/// ���ñ���ֵ
		/// </summary>
		/// <param name="name">��������</param>
		/// <param name="value">ֵ</param>
		public void FlashMethod_SetVariable(string name, string value)
		{
			Wrapper.FPC_SetVariable(base.Handle.ToInt32(), name, value);
		}

		/// <summary>
		/// ��������λ��
		/// </summary>
		/// <param name="left">��߾�</param>
		/// <param name="top">�ϱ߾�</param>
		/// <param name="right">�ұ߾�</param>
		/// <param name="bottom">�±߾�</param>
		public void FlashMethod_SetZoomRect(int left, int top, int right, int bottom)
		{
			Wrapper.FPC_SetZoomRect(base.Handle.ToInt32(), left, top, right, bottom);
		}

		/// <summary>
		/// FLASH����,, ��ͣ
		/// </summary>
		public void FlashMethod_Stop()
		{
			Wrapper.FPC_Stop(base.Handle.ToInt32());
		}

		/// <summary>
		/// FLASH����,,ֹͣ����
		/// </summary>
		public void FlashMethod_StopPlay()
		{
			Wrapper.FPC_StopPlay(base.Handle.ToInt32());
		}

		public void FlashMethod_TCallFrame(string target, int FrameNum)
		{
			Wrapper.FPC_TCallFrame(base.Handle.ToInt32(), target, FrameNum);
		}

		public void FlashMethod_TCallLabel(string target, string label)
		{
			Wrapper.FPC_TCallLabel(base.Handle.ToInt32(), target, label);
		}

		public int FlashMethod_TCurrentFrame(string target)
		{
			int result = 0;
			Wrapper.FPC_TCurrentFrame(base.Handle.ToInt32(), target, ref result);
			return result;
		}

		public string FlashMethod_TCurrentLabel(string target)
		{
			string str = "";
			int dwSize = 0;
			if (Wrapper.FPC_TCurrentLabel(base.Handle.ToInt32(), target, 0, ref dwSize) == 0)
			{
				dwSize++;
				IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
				Marshal.WriteInt32(ptr, 0);
				Wrapper.FPC_TCurrentLabel(base.Handle.ToInt32(), target, ptr.ToInt32(), ref dwSize);
				str = Marshal.PtrToStringUni(ptr);
				Marshal.FreeCoTaskMem(ptr);
			}
			return str;
		}

		public string FlashMethod_TGetProperty(string target, int Property)
		{
			string str = "";
			int dwSize = 0;
			if (Wrapper.FPC_TGetProperty(base.Handle.ToInt32(), target, Property, 0, ref dwSize) == 0)
			{
				dwSize++;
				IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
				Marshal.WriteInt32(ptr, 0);
				Wrapper.FPC_TGetProperty(base.Handle.ToInt32(), target, Property, ptr.ToInt32(), ref dwSize);
				str = Marshal.PtrToStringUni(ptr);
				Marshal.FreeCoTaskMem(ptr);
			}
			return str;
		}

		public double FlashMethod_TGetPropertyAsNumber(string target, int Property)
		{
			double result = 0.0;
			Wrapper.FPC_TGetPropertyAsNumber(base.Handle.ToInt32(), target, Property, ref result);
			return result;
		}

		public double FlashMethod_TGetPropertyNum(string target, int Property)
		{
			double result = 0.0;
			Wrapper.FPC_TGetPropertyNum(base.Handle.ToInt32(), target, Property, ref result);
			return result;
		}

		public void FlashMethod_TGotoFrame(string target, int FrameNum)
		{
			Wrapper.FPC_TGotoFrame(base.Handle.ToInt32(), target, FrameNum);
		}

		public void FlashMethod_TGotoLabel(string target, string label)
		{
			Wrapper.FPC_TGotoLabel(base.Handle.ToInt32(), target, label);
		}

		public void FlashMethod_TPlay(string target)
		{
			Wrapper.FPC_TPlay(base.Handle.ToInt32(), target);
		}

		public void FlashMethod_TSetProperty(string target, int Property, string value)
		{
			Wrapper.FPC_TSetProperty(base.Handle.ToInt32(), target, Property, value);
		}

		public void FlashMethod_TSetPropertyNum(string target, int Property, double value)
		{
			Wrapper.FPC_TSetPropertyNum(base.Handle.ToInt32(), target, Property, value);
		}

		public void FlashMethod_TStopPlay(string target)
		{
			Wrapper.FPC_TStopPlay(base.Handle.ToInt32(), target);
		}

		public void FlashMethod_Zoom(int factor)
		{
			Wrapper.FPC_Zoom(base.Handle.ToInt32(), factor);
		}

		public Bitmap GetBitmap()
		{
			Wrapper.SFPCGetFrameBitmap structure = new Wrapper.SFPCGetFrameBitmap();
			IntPtr ptr = Marshal.AllocCoTaskMem(Marshal.SizeOf(structure));
			Marshal.StructureToPtr(structure, ptr, false);
			SendMessage(base.Handle.ToInt32(), 0x1404, 0, ptr.ToInt32());
			structure = (Wrapper.SFPCGetFrameBitmap) Marshal.PtrToStructure(ptr, typeof(Wrapper.SFPCGetFrameBitmap));
			Marshal.FreeCoTaskMem(ptr);
			int hBitmap = structure.hBitmap;
			int cb = Marshal.SizeOf(typeof(BITMAP));
			IntPtr ptr2 = Marshal.AllocCoTaskMem(cb);
			GetObject(hBitmap, cb, ptr2.ToInt32());
			BITMAP bitmap2 = (BITMAP) Marshal.PtrToStructure(ptr2, typeof(BITMAP));
			Marshal.FreeCoTaskMem(ptr2);
			Bitmap bitmap3 = new Bitmap(bitmap2.bmWidth, bitmap2.bmHeight, PixelFormat.Format32bppPArgb);
			BitmapData bitmapdata = bitmap3.LockBits(new Rectangle(new Point(0, 0), bitmap3.Size), ImageLockMode.WriteOnly, bitmap3.PixelFormat);
			int num3 = 0;
			int num4 = bitmap2.bmWidthBytes * (bitmap2.bmHeight - 1);
			byte[] destination = new byte[bitmap2.bmWidthBytes * bitmap2.bmHeight];
			int num5 = 0;
			while (num5 < bitmap2.bmHeight)
			{
				Marshal.Copy(new IntPtr(bitmap2.bmBits + num3), destination, 0, bitmap2.bmWidthBytes);
				Marshal.Copy(destination, 0, new IntPtr(bitmapdata.Scan0.ToInt32() + num4), bitmap2.bmWidthBytes);
				num5++;
				num3 += bitmap2.bmWidthBytes;
				num4 -= bitmap2.bmWidthBytes;
			}
			bitmap3.UnlockBits(bitmapdata);
			DeleteObject(hBitmap);
			return bitmap3;
		}

		[DllImport("gdi32.dll", CallingConvention=(CallingConvention) 0)]
		internal static extern int GetObject(int hObject, int BufferSize, int pInfo);
		public void LoadMovieFromStream(int layer, Stream Stream)
		{
			int num;
			Stream stream = this.LoadMovieUsingStream(layer);
			byte[] buffer = new byte[0x100000];
			while ((num = Stream.Read(buffer, 0, 0x100000)) > 0)
			{
				stream.Write(buffer, 0, num);
			}
			stream.Close();
		}

		public Stream LoadMovieUsingStream(int layer)
		{
			int num;
			Wrapper.FPCLoadMovieUsingStream(base.Handle.ToInt32(), layer, out num);
			return new StreamBasedOnIStream(num, false);
		}

		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			this.pEventsListener = new Wrapper.EventsListener(this.EventsListener);
			Wrapper.FPCSetEventListener(base.Handle.ToInt32(), this.pEventsListener, 0);
			Application.AddMessageFilter(this);
		}

		protected override void OnHandleDestroyed(EventArgs e)
		{
			Application.RemoveMessageFilter(this);
			base.OnHandleDestroyed(e);
		}

		public bool PreFilterMessage(ref Message msg)
		{
			if ((msg.Msg == 0x205) && (this.ContextMenu != null))
			{
				this.ContextMenu.Show(this, new Point(msg.LParam.ToInt32()));
			}
			//Console.WriteLine(msg.Msg.ToString()+","+msg.LParam.ToString()+","+msg.WParam.ToString());
			return false;
		}

		public void PutMovieFromStream(Stream Stream)
		{
			int num;
			Stream stream = this.PutMovieUsingStream();
			byte[] buffer = new byte[0x100000];
			while ((num = Stream.Read(buffer, 0, 0x100000)) > 0)
			{
				stream.Write(buffer, 0, num);
			}
			stream.Close();
		}

		public Stream PutMovieUsingStream()
		{
			int num;
			Wrapper.FPCPutMovieUsingStream(base.Handle.ToInt32(), out num);
			return new StreamBasedOnIStream(num, false);
		}

		[DllImport("user32.dll", CallingConvention=(CallingConvention) 0)]
		internal static extern int SendMessage(int hWnd, uint msg, int wParam, int lParam);

		public AxCode AxCode
		{
			get
			{
				return this.m_AxCode;
			}
		}

		public string Context
		{
			get
			{
				return this.m_Context;
			}
			set
			{
				Wrapper.FPC_SetContext(base.Handle.ToInt32(), value);
				this.m_Context = value;
			}
		}

		protected override System.Windows.Forms.CreateParams CreateParams
		{
			get
			{
				System.Windows.Forms.CreateParams createParams = base.CreateParams;
				if (this.m_AxCode != null)
				{
					createParams.ExStyle = 0x80000;
					createParams.Style = -1878392832;
					createParams.ClassName = Marshal.PtrToStringAnsi(new IntPtr(Wrapper.FPC_GetClassNameA(this.m_AxCode.Handle)));
				}
				return createParams;
			}
		}

		public int FlashProperty_AlignMode
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetAlignMode(base.Handle.ToInt32(), ref num);
				return num;
			}
			set
			{
				Wrapper.FPC_PutAlignMode(base.Handle.ToInt32(), value);
			}
		}

		public string FlashProperty_AllowScriptAccess
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetAllowScriptAccess(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetAllowScriptAccess(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutAllowScriptAccess(base.Handle.ToInt32(), value);
			}
		}

		public int FlashProperty_BackgroundColor
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetBackgroundColor(base.Handle.ToInt32(), ref num);
				return num;
			}
			set
			{
				Wrapper.FPC_PutBackgroundColor(base.Handle.ToInt32(), value);
			}
		}

		public string FlashProperty_Base
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetBase(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetBase(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutBase(base.Handle.ToInt32(), value);
			}
		}

		public string FlashProperty_BGColor
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetBGColor(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetBGColor(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutBGColor(base.Handle.ToInt32(), value);
			}
		}

		public bool FlashProperty_DeviceFont
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetDeviceFont(base.Handle.ToInt32(), ref num);
				return (0 != num);
			}
			set
			{
				Wrapper.FPC_PutDeviceFont(base.Handle.ToInt32(), value ? -1 : 0);
			}
		}

		public bool FlashProperty_EmbedMovie
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetEmbedMovie(base.Handle.ToInt32(), ref num);
				return (0 != num);
			}
			set
			{
				Wrapper.FPC_PutEmbedMovie(base.Handle.ToInt32(), value ? -1 : 0);
			}
		}

		public string FlashProperty_FlashVars
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetFlashVars(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetFlashVars(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutFlashVars(base.Handle.ToInt32(), value);
			}
		}

		public int FlashProperty_FrameNum
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetFrameNum(base.Handle.ToInt32(), ref num);
				return num;
			}
			set
			{
				Wrapper.FPC_PutFrameNum(base.Handle.ToInt32(), value);
			}
		}

		public bool FlashProperty_Loop
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetLoop(base.Handle.ToInt32(), ref num);
				return (0 != num);
			}
			set
			{
				Wrapper.FPC_PutLoop(base.Handle.ToInt32(), value ? -1 : 0);
			}
		}

		public bool FlashProperty_Menu
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetMenu(base.Handle.ToInt32(), ref num);
				return (0 != num);
			}
			set
			{
				Wrapper.FPC_PutMenu(base.Handle.ToInt32(), value ? -1 : 0);
			}
		}

		public string FlashProperty_Movie
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetMovie(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetMovie(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutMovie(base.Handle.ToInt32(), value);
			}
		}

		public string FlashProperty_MovieData
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetMovieData(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetMovieData(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutMovieData(base.Handle.ToInt32(), value);
			}
		}

		public bool FlashProperty_Playing
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetPlaying(base.Handle.ToInt32(), ref num);
				return (0 != num);
			}
			set
			{
				Wrapper.FPC_PutPlaying(base.Handle.ToInt32(), value ? -1 : 0);
			}
		}

		public int FlashProperty_Quality
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetQuality(base.Handle.ToInt32(), ref num);
				return num;
			}
			set
			{
				Wrapper.FPC_PutQuality(base.Handle.ToInt32(), value);
			}
		}

		public string FlashProperty_Quality2
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetQuality2(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetQuality2(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutQuality2(base.Handle.ToInt32(), value);
			}
		}

		public int FlashProperty_ReadyState
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetReadyState(base.Handle.ToInt32(), ref num);
				return num;
			}
		}

		public string FlashProperty_SAlign
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetSAlign(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetSAlign(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutSAlign(base.Handle.ToInt32(), value);
			}
		}

		public string FlashProperty_Scale
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetScale(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetScale(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutScale(base.Handle.ToInt32(), value);
			}
		}

		public int FlashProperty_ScaleMode
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetScaleMode(base.Handle.ToInt32(), ref num);
				return num;
			}
			set
			{
				Wrapper.FPC_PutScaleMode(base.Handle.ToInt32(), value);
			}
		}

		public string FlashProperty_Stacking
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetStacking(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetStacking(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutStacking(base.Handle.ToInt32(), value);
			}
		}

		public string FlashProperty_SWRemote
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetSWRemote(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetSWRemote(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutSWRemote(base.Handle.ToInt32(), value);
			}
		}

		public int FlashProperty_TotalFrames
		{
			get
			{
				int num = 0;
				Wrapper.FPC_GetTotalFrames(base.Handle.ToInt32(), ref num);
				return num;
			}
		}

		public string FlashProperty_WMode
		{
			get
			{
				string str = "";
				int dwSize = 0;
				if (Wrapper.FPC_GetWMode(base.Handle.ToInt32(), 0, ref dwSize) == 0)
				{
					dwSize++;
					IntPtr ptr = Marshal.AllocCoTaskMem(dwSize * 2);
					Marshal.WriteInt32(ptr, 0);
					Wrapper.FPC_GetWMode(base.Handle.ToInt32(), ptr.ToInt32(), ref dwSize);
					str = Marshal.PtrToStringUni(ptr);
					Marshal.FreeCoTaskMem(ptr);
				}
				return str;
			}
			set
			{
				Wrapper.FPC_PutWMode(base.Handle.ToInt32(), value);
			}
		}

		public byte OverallOpaque
		{
			get
			{
				Wrapper.SFPCGetOverallOpaque structure = new Wrapper.SFPCGetOverallOpaque();
				IntPtr ptr = Marshal.AllocCoTaskMem(Marshal.SizeOf(structure));
				Marshal.StructureToPtr(structure, ptr, false);
				SendMessage(base.Handle.ToInt32(), 0x1409, 0, ptr.ToInt32());
				structure = (Wrapper.SFPCGetOverallOpaque) Marshal.PtrToStructure(ptr, typeof(Wrapper.SFPCGetOverallOpaque));
				Marshal.FreeCoTaskMem(ptr);
				return (byte) structure.Value;
			}
			set
			{
				Wrapper.SFPCPutOverallOpaque structure = new Wrapper.SFPCPutOverallOpaque();
				structure.Value=value;
				IntPtr ptr = Marshal.AllocCoTaskMem(Marshal.SizeOf(structure));
				Marshal.StructureToPtr(structure, ptr, false);
				SendMessage(base.Handle.ToInt32(), 0x1408, 0, ptr.ToInt32());
				Marshal.FreeCoTaskMem(ptr);
			}
		}

		public bool StandardMenu
		{
			get
			{
				int num;
				Wrapper.FPC_GetStandardMenu(base.Handle.ToInt32(), out num);
				return (0 != num);
			}
			set
			{
				Wrapper.FPC_PutStandardMenu(base.Handle.ToInt32(), value ? 1 : 0);
			}
		}

		[StructLayout(LayoutKind.Sequential)]
			internal struct BITMAP
		{
			public int bmType;
			public int bmWidth;
			public int bmHeight;
			public int bmWidthBytes;
			public short bmPlanes;
			public short bmBitsPixel;
			public int bmBits;
		}

		public delegate void OnFlashCallEventHandler(object sender, string request);

		public delegate void OnFSCommandEventHandler(object sender, string command, string args);

		public delegate void OnLoadExternalResourceByRelativePathEventHandler(object sender, string RelativePath, Stream ContentStream, ref bool Handled);

		public delegate void OnProgressEventHandler(object sender, int percentDone);

		public delegate void OnReadyStateChangeEventHandler(object sender, FTForm.ReadyState state);

		public enum ReadyState
		{
			Loading,
			Uninitialized,
			Loaded,
			Interactive,
			Complete
		}

		private void FTForm_MouseDown(object sender, MouseEventArgs e)
		{
			m_nX = Left + e.X;
			m_nY = Top + e.Y;

			m_nLeft = Left;
			m_nTop = Top;

			Capture = true;
		}

		private void FTForm_MouseMove(object sender, MouseEventArgs e)
		{
			if (Capture&&cMove)
			{
				Left = m_nLeft + (Left + e.X - m_nX);
				Top = m_nTop + (Top + e.Y - m_nY);
			}
		}

		private void FTForm_MouseUp(object sender, MouseEventArgs e)
		{
			Capture = false;
		}
	}
}
