using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
namespace FlashTransparentLib
{
    public class AxCode
    {
        private Wrapper.LoadExternalResourceHandler FLoadExternalResourceHandler;
        private uint handle;
        public static int MaxSoundVolume = 0xffff;

        public event OnLoadExternalResourceByFullPathEventHandler OnLoadExternalResourceByFullPath;

        public AxCode()
        {
            this.handle = 0;
            this.handle = Wrapper.FPC_LoadRegisteredOCX();
            if (this.handle != 0)
            {
                this.Init();
            }
        }

        public AxCode(Stream StreamWithOCXCode)
        {
            int num;
            this.handle = 0;
            MemoryStream stream = new MemoryStream();
            byte[] buffer = new byte[0x10000];
            while ((num = StreamWithOCXCode.Read(buffer, 0, 0x10000)) > 0)
            {
                stream.Write(buffer, 0, num);
            }
            uint length = (uint)stream.Length;
            IntPtr destination = Marshal.AllocHGlobal(new IntPtr(stream.Length));
            buffer = new byte[length];
            stream.Position = 0L;
            stream.Read(buffer, 0, (int)stream.Length);
            Marshal.Copy(buffer, 0, destination, (int)length);
            this.handle = Wrapper.FPC_LoadOCXCodeFromMemory((uint)((int)destination), length);
            Marshal.FreeHGlobal(destination);
            if (this.handle != 0)
            {
                this.Init();
            }
        }

        ~AxCode()
        {
            if (this.handle != 0)
            {
                Wrapper.FPC_UnloadCode(this.handle);
                this.handle = 0;
            }
        }

        private void Init()
        {
            this.FLoadExternalResourceHandler = new Wrapper.LoadExternalResourceHandler(this.OnLoadExternalResourceHandler);
            Wrapper.FPC_AddOnLoadExternalResourceHandlerW(this.handle, this.FLoadExternalResourceHandler, 0);
        }

        private int OnLoadExternalResourceHandler(int lpszURL, ref int stream, uint hFPC, int lParam)
        {
            bool handled = false;
            if (this.OnLoadExternalResourceByFullPath != null)
            {
                Stream stream2 = new StreamBasedOnIStream(stream, true);
                this.OnLoadExternalResourceByFullPath(this, Marshal.PtrToStringUni(new IntPtr(lpszURL)), stream2, ref handled);
                if (!handled)
                {
                    stream2.Close();
                }
            }
            return (handled ? 0 : -1);
        }

        public uint Handle
        {
            get
            {
                return this.handle;
            }
        }

        public bool SoundEnabled
        {
            get
            {
                return (0 != Wrapper.FPC_IsSoundEnabled(this.Handle));
            }
            set
            {
                Wrapper.FPC_EnableSound(this.Handle, value ? 1 : 0);
            }
        }

        public int SoundVolume
        {
            get
            {
                return Wrapper.FPC_GetSoundVolume(this.Handle);
            }
            set
            {
                Wrapper.FPC_SetSoundVolume(this.Handle, value);
            }
        }

        public Version Version
        {
            get
            {
                return new Version(Wrapper.FPC_GetVersion(this.Handle));
            }
        }

        public delegate void OnLoadExternalResourceByFullPathEventHandler(object sender, string URL, Stream Stream, ref bool Handled);
    }
}
