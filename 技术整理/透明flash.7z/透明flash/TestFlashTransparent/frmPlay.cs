using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TestFlashTransparent
{
    public class frmPlay : FlashTransparentLib.FTForm
    {
        #region ������ƴ���
        private System.ComponentModel.Container components = null;
        private System.Windows.Forms.ContextMenu contextMenu1;
        private System.Windows.Forms.MenuItem miClose;
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }
        #region Windows ������������ɵĴ���
        /// <summary>
        /// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
        /// �˷��������ݡ�
        /// </summary>
        private void InitializeComponent()
        {
            this.contextMenu1 = new System.Windows.Forms.ContextMenu();
            this.miClose = new System.Windows.Forms.MenuItem();
            // 
            // contextMenu1
            // 
            this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.miClose});
            // 
            // miClose
            // 
            this.miClose.Index = 0;
            this.miClose.Text = "�ر�(&C)";
            this.miClose.Click += new System.EventHandler(this.miClose_Click);
            // 
            // frmPlay
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
            this.ClientSize = new System.Drawing.Size(408, 234);
            this.ContextMenu = this.contextMenu1;
            this.Name = "frmPlay";
            this.ShowInTaskbar = false;
            this.Text = "frmPlay";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmPlay_Load);

        }
        #endregion
        #endregion

        string playFile = "";
        public frmPlay(string file)
        {
            InitializeComponent();
            playFile = file;
        }
        private void frmPlay_Load(object sender, System.EventArgs e)
        {
            if (!FlashTransparentLib.Global.IsTransparentModeAvailable)
            {
                System.Windows.Forms.MessageBox.Show("͸��ģʽδ����");
                return;
            }
            this.WindowState = FormWindowState.Maximized;
            this.CanMove = true;
            this.Left = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width / 2 - this.Width / 2;
            this.Top = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height / 2 - this.Height / 2;
            this.StandardMenu = false;
            this.PutMovieFromStream(new System.IO.FileStream(playFile, System.IO.FileMode.Open));
            this.FlashProperty_Loop = false;
            this.FlashMethod_Play();
            //this.Show();
        }
        private void miClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
