using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;

namespace TestFlashTransparent
{
    /// <summary>
    /// Launcher ��ժҪ˵����
    /// </summary>
    public class Launcher : FlashTransparentLib.FTForm
    {
        #region ������ƴ���
        /// <summary>
        /// ����������������
        /// </summary>
        private System.ComponentModel.Container components = null;

        /// <summary>
        /// ������������ʹ�õ���Դ��
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows ������������ɵĴ���
        /// <summary>
        /// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
        /// �˷��������ݡ�
        /// </summary>
        private void InitializeComponent()
        {
            // 
            // Launcher
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
            this.ClientSize = new System.Drawing.Size(392, 166);
            this.Name = "Launcher";
            this.Text = "Launcher";
            this.Load += new System.EventHandler(this.Launcher_Load);

        }
        #endregion
        #endregion

        public Launcher()
        {
            InitializeComponent();
        }
        private void Launcher_Load(object sender, System.EventArgs e)
        {
            if (!FlashTransparentLib.Global.IsTransparentModeAvailable)
            {
                System.Windows.Forms.MessageBox.Show("͸��ģʽδ����");
                return;
            }
            //this.CanMove=true;
            this.Left = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width / 2 - this.Width / 2;
            this.Top = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height / 2 - this.Height / 2;
            this.StandardMenu = false;
            this.PutMovieFromStream(this.GetType().Assembly.GetManifestResourceStream("TestFlashTransparent.Launcher.swf"));
            this.FlashMethod_Play();
            this.OnFSCommand += new OnFSCommandEventHandler(Launcher_OnFSCommand);
            this.OnFlashCall += new OnFlashCallEventHandler(Launcher_OnFlashCall);
        }
        private void Launcher_OnFSCommand(object sender, string command, string args)
        {
            switch (command)
            {
                case "close":
                    Application.Exit();
                    break;
                case "exec":
                    System.Diagnostics.Process.Start(args);
                    break;
            }
        }
        private void Launcher_OnFlashCall(object sender, string request)
        {
            this.FlashMethod_SetReturnValue("<string> </string>");

            Thread th = new Thread(new ThreadStart(showForm));
            th.Start();
        }
        private void showForm()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                this.FlashMethod_CallFunction("<invoke name=\"AppValue\" returntype=\"xml\"><arguments><string>" + ofd.FileName + "</string></arguments></invoke>");
            }
        }
    }
}
