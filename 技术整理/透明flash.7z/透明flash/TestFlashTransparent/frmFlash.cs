using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace TestFlashTransparent
{
    public class frmFlash : System.Windows.Forms.Form
    {
        #region ������ƴ���
        private System.Windows.Forms.Label label1;
        private System.ComponentModel.Container components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }
        #region Windows ������������ɵĴ���
        /// <summary>
        /// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
        /// �˷��������ݡ�
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("����", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(96, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 104);
            this.label1.TabIndex = 0;
            this.label1.Text = "��FLASH�ļ����������м���ʵ��͸��FLASH����";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.DragEnter += new System.Windows.Forms.DragEventHandler(this.frmFlash_DragEnter);
            this.label1.DragDrop += new System.Windows.Forms.DragEventHandler(this.frmFlash_DragDrop);
            // 
            // frmFlash
            // 
            this.AllowDrop = true;
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
            this.ClientSize = new System.Drawing.Size(424, 278);
            this.Controls.Add(this.label1);
            this.Name = "frmFlash";
            this.Text = "FLASH͸������";
            this.TopMost = true;
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.frmFlash_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.frmFlash_DragEnter);
            this.ResumeLayout(false);

        }
        #endregion
        #endregion

        /// <summary>
        /// Ӧ�ó��������ڵ㡣
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new frmFlash());
        }

        public frmFlash()
        {
            InitializeComponent();
            Launcher l = new Launcher();
        }
        private void frmFlash_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }
        private void frmFlash_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] MyFiles = (string[])(e.Data.GetData(DataFormats.FileDrop));
                if (MyFiles.Length > 0)
                {
                    frmPlay frmP = new frmPlay(MyFiles[0]);
                    frmP.Show();
                }
            }
        }
    }
}
