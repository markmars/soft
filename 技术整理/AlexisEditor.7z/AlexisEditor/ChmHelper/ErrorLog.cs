﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ChmHelper
{
    public static class ErrorLog
    {
        
    }
}
