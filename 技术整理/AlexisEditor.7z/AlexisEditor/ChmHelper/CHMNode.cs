﻿/*
 * 文件名：CHM帮助文件 CHMNode.cs
 * 项目名：AlexisEditor
 * 创建时间：20101002
 * 创建人：Alexis
 * 作者主页：http://www.cnblogs.com/alexis/
 * 联系方式：shuifengxu@gmail.com
 * 说明：转载请保留作者说明
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace ChmHelper
{

    /// <summary>
    /// 节点类
    /// </summary>
    public class CHMNode
    {
        //本地名
        private string _local;
        public string Local
        {
            get { return this._local; }
            set { _local = value; }
        }

        //名称
        private string _name;
        public string Name
        {
            get { return this._name; }
            set { _name = value; }
        }

        //图标索引
        private string _imageNo;
        public string ImageNo
        {
            get { return this._imageNo; }
            set { _imageNo = value; }
        }

        private string _keyWords;
        public string KeyWords
        {
            get { return this._keyWords; }
            set { _keyWords = value; }
        }

        //该节点的所有子节点集合
        private CHMNodeList _nodes = new CHMNodeList();
        public CHMNodeList Nodes
        {
            get { return this._nodes; }
            set { _nodes = value; }
        }

    }
}
