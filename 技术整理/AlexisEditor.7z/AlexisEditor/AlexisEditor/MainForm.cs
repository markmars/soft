﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ChmHelper;
using System.IO;
using WeifenLuo.WinFormsUI.Docking;

namespace AlexisEditor
{
    public partial class MainForm : Form
    {
        #region member

        ToWordForm frmToWord;
        private EditForm frmEdit = EditForm.CreateEditForm();
        private BookIndexForm frmIndex = new BookIndexForm();
        private ListForm frmList = new ListForm();
        private OutPutForm frmOutPut = new OutPutForm();
        private CHMDocument chmDocument = new CHMDocument();

        #endregion

        public MainForm()
        {
            InitializeComponent();
            frmIndex.Show(dockPanel);//显示目录窗体
            frmIndex.DockTo(dockPanel, DockStyle.Left);
            frmList.Show(dockPanel);//显示搜索窗体
            frmList.DockTo(dockPanel, DockStyle.Fill);
            this.frmIndex.TreeIndex.NodeMouseDoubleClick += new TreeNodeMouseClickEventHandler(TreeIndex_NodeMouseDoubleClick);//注册编辑文章事件
        }

        #region 事件

        void TreeIndex_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            //判断双击的是不是子节点，即是不是文章
            TreeNode node = this.frmIndex.TreeIndex.SelectedNode;
            if (node.Tag is CHMDocument)
            {
                return;
            }
            else if(node.Tag is CHMNode)
            {
                //是文章节点
                if (((CHMNode)node.Tag).Nodes == null || ((CHMNode)node.Tag).Nodes.Count == 0)
                {
                    //找到html文件路径
                    string filePath = ((CHMNode)node.Tag).Local;
                    if (!File.Exists(filePath))
                    {
                        MessageBox.Show("文件不存在");
                        return;
                    }
                    //if (frmEdit.IsDisposed)
                    //{
                    //    frmEdit = new EditForm();
                    //}
                    ////显示编辑窗体
                    //if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
                    //{
                    //    frmEdit.MdiParent = this;
                    //    frmEdit.Show();
                    //}
                    //else
                    //    frmEdit.Show(dockPanel);

                    EditForm form = new EditForm();
                    form.Edit((CHMNode)node.Tag);
                    form.ShowDialog();
                    this.frmIndex.TreeIndex.SelectedNode.Text = form.Node.Name;
                    //frmEdit.Edit((CHMNode)node.Tag);
                }
            }

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            chmDocument.Load("index.xml");//加载目录
            RefreshView(chmDocument, frmIndex.TreeIndex);
            frmList.Nodes = chmDocument.Nodes;
        }

        private void toolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
            if (e.ClickedItem.Name == "saveToolStripButton")
            {
                Save();//保存
            }
            else if (e.ClickedItem.Name == "newToolStripButton")
            {
                this.New();
            }
            else if (e.ClickedItem.Name == "compileToolStripButton")
            {
                this.Compile();
            }
            else if (e.ClickedItem.Name == "addPageToolStripButton")
            {
                this.AddPage();
            }
            else if (e.ClickedItem.Name == "toWordToolStripButton")
            {
                this.ToWord();
            }
            else if (e.ClickedItem.Name == "configToolStripButton")
            {
                ConfigForm form = new ConfigForm();
                form.ShowDialog();
            }
            else if (e.ClickedItem.Name == "helpToolStripButton")
            {
                AboutForm frmAbout = new AboutForm();
                frmAbout.ShowDialog();
            }
            else if (e.ClickedItem.Name == "openToolStripButton")
            {
                Open();
            }
            else if (e.ClickedItem.Name == "printToolStripButton")
            {
                MessageBox.Show("Sorry,the funtion is not support yet");
                return;
            }
            else if (e.ClickedItem.Name == "indexToolStripButton")
            {
                //if (this.frmIndex.IsDisposed)
                //{
                //    frmIndex = new BookIndexForm();
                //    frmIndex.Show(dockPanel);
                //    frmIndex.DockTo(this.dockPanel, DockStyle.Left);
                //}
                frmIndex.Show(dockPanel);
            }
            else if (e.ClickedItem.Name == "deCompileToolStripButton")
            {
                DeCompileForm form = new DeCompileForm();
                form.ShowDialog();
            }
            else if (e.ClickedItem.Name=="dirToolStripButton")
            {
                DirectoryForm form = new DirectoryForm();
                form.ShowDialog();
            }
        }

        

        /// <summary>
        /// 右击新建文章事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newArtcileAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.New();   
        }

        
        #endregion

        #region 方法

        private void RefreshView(CHMDocument doc, System.Windows.Forms.TreeView tvw)
        {
            tvw.BeginUpdate();
            tvw.Nodes.Clear();
            System.Windows.Forms.TreeNode node = tvw.Nodes.Add(doc.Title);
            node.Tag = doc;
            node.ImageIndex = 0;
            node.SelectedImageIndex = 0;
            AddNodes(doc.Nodes, node);
            tvw.EndUpdate();
            tvw.SelectedNode = node;
            node.Expand();

        }

        private void AddNodes(CHMNodeList list, System.Windows.Forms.TreeNode RootNode)
        {
            if (list == null || list.Count == 0)
                return;

            foreach (CHMNode node in list)
            {
                System.Windows.Forms.TreeNode n = new TreeNode(node.Name);
                n.Tag = node;
                if (node.Nodes.Count > 0)
                    n.ImageIndex = 0;
                else
                    n.ImageIndex = 1;
                n.SelectedImageIndex = n.ImageIndex;
                RootNode.Nodes.Add(n);
                if (node.Nodes.Count > 0)
                    AddNodes(node.Nodes, n);
            }
        }

        //保存方法
        private void Save()
        {
            chmDocument.Save("index.xml");
        }

        /// <summary>
        /// 打开xml目录
        /// </summary>
        private void Open()
        {

        }

        private void New()
        {
            TreeNode node = this.frmIndex.TreeIndex.SelectedNode;
            CHMNodeList list = this.GetNodeList(node);
            if (list == null)
            {
                MessageBox.Show("请选择根节点或是目录节点");
                return;
            }
            EditForm frmEdit = new EditForm();
            //frmEdit.ChmDocument = this.chmDocument;
            frmEdit.ShowDialog(this);

            CHMNode NewNode = frmEdit.Node;
            if (NewNode == null)
            {
                return;
            }
            list.Add(NewNode);
            System.Windows.Forms.TreeNode node2 = new TreeNode(NewNode.Name);
            node2.Tag = NewNode;
            node2.ImageIndex = 1;
            node2.SelectedImageIndex = 1;
            node.Nodes.Add(node2);//将新节点添加到树中
            node.ImageIndex = 0;
            node.SelectedImageIndex = 0;
            this.frmIndex.TreeIndex.SelectedNode = node2;
            this.Save();//保存到xml文件中
        }

        //编译方法
        private void Compile()
        {
            frmOutPut.Show(dockPanel);
            frmOutPut.DockTo(dockPanel, DockStyle.Bottom);
            chmDocument.FileName = "index.xml";
            ToolStripStatusLabel tsl = new ToolStripStatusLabel();
            
            tsl.Text = "正在编译....";
            ToolStripStatusLabel tslBuilding = new ToolStripStatusLabel();
            tsl.Image = IconHelper.GetBuildImage();
            tsl.Dock = DockStyle.Right;
            this.statusStrip.Items.AddRange(new ToolStripItem[] { tsl,tslBuilding });
            this.statusStrip.Text = "正在编译...";
            chmDocument.Compile();
            frmOutPut.TxtOutput.Text = chmDocument.OutPutText;
            this.statusStrip.Items.Remove(tsl);
            this.statusStrip.Items.Remove(tslBuilding);
        }

        //添加页面，此处只是将路径存入，并没有将文件考到相应的路径下（可用性待分析）
        private void AddPage()
        {
            TreeNode node = this.frmIndex.TreeIndex.SelectedNode;//选中的节点
            //查看是否是根节点或是目录节点
            CHMNodeList list = this.GetNodeList(node);
            if (list == null)
            {
                MessageBox.Show("请选择根节点或是目录节点");
                return;
            }
            using (OpenFileDialog ofd = new OpenFileDialog())//可以批量选择
            {
                ofd.Filter = "HTML Files|*.html;*.htm";
                ofd.Multiselect = true;//设置可以选择多个文件
                ofd.ShowDialog();
                if (ofd.FileNames.Length > 0)
                {
                    for (int i = 0; i < ofd.FileNames.Length; i++)
                    {
                        CHMNode newNode = new CHMNode();//创建新的节点
                        newNode.Name = ofd.SafeFileNames[i].ToString();
                        newNode.ImageNo = "1";                        
                        newNode.Local = ofd.FileNames[i].ToString();
                        newNode.Nodes = null;
                        list.Add(newNode);
                        System.Windows.Forms.TreeNode node2 = new TreeNode(newNode.Name);
                        node2.Tag = newNode;
                        node2.ImageIndex = 1;
                        node2.SelectedImageIndex = 1;
                        node.Nodes.Add(node2);//将新节点添加到树中
                        node.ImageIndex = 0;
                        node.SelectedImageIndex = 0;
                    }
                }
            }
        }

        private CHMNodeList GetNodeList(System.Windows.Forms.TreeNode node)
        {
            if (node == null)
                return null;
            if (node.Tag is CHMDocument)
            {
                return ((CHMDocument)node.Tag).Nodes;
            }
            if (node.Tag is CHMNode)
            {
                return ((CHMNode)node.Tag).Nodes;
            }
            return null;
        }

        //转换为word
        private void ToWord()
        {
            frmToWord = new ToWordForm();
            frmToWord.ShowDialog();
        }
        #endregion

    }
}
