﻿namespace AlexisEditor
{
    partial class ListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListForm));
            this.tcList = new System.Windows.Forms.TabControl();
            this.tpSearch = new System.Windows.Forms.TabPage();
            this.rbByAll = new System.Windows.Forms.RadioButton();
            this.rbByKeywords = new System.Windows.Forms.RadioButton();
            this.rbByTitle = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtKeyWords = new System.Windows.Forms.TextBox();
            this.tpResult = new System.Windows.Forms.TabPage();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.Title = new System.Windows.Forms.DataGridViewLinkColumn();
            this.FilePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KeyWords = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Content = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tcList.SuspendLayout();
            this.tpSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tpResult.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcList
            // 
            this.tcList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tcList.Controls.Add(this.tpSearch);
            this.tcList.Controls.Add(this.tpResult);
            this.tcList.Location = new System.Drawing.Point(3, -9);
            this.tcList.Name = "tcList";
            this.tcList.SelectedIndex = 0;
            this.tcList.Size = new System.Drawing.Size(748, 447);
            this.tcList.TabIndex = 6;
            // 
            // tpSearch
            // 
            this.tpSearch.Controls.Add(this.rbByAll);
            this.tpSearch.Controls.Add(this.rbByKeywords);
            this.tpSearch.Controls.Add(this.rbByTitle);
            this.tpSearch.Controls.Add(this.pictureBox1);
            this.tpSearch.Controls.Add(this.btnSearch);
            this.tpSearch.Controls.Add(this.txtKeyWords);
            this.tpSearch.Location = new System.Drawing.Point(4, 22);
            this.tpSearch.Name = "tpSearch";
            this.tpSearch.Padding = new System.Windows.Forms.Padding(3);
            this.tpSearch.Size = new System.Drawing.Size(740, 421);
            this.tpSearch.TabIndex = 0;
            this.tpSearch.Text = "tabPage1";
            this.tpSearch.UseVisualStyleBackColor = true;
            // 
            // rbByAll
            // 
            this.rbByAll.AutoSize = true;
            this.rbByAll.Location = new System.Drawing.Point(418, 255);
            this.rbByAll.Name = "rbByAll";
            this.rbByAll.Size = new System.Drawing.Size(73, 17);
            this.rbByAll.TabIndex = 16;
            this.rbByAll.TabStop = true;
            this.rbByAll.Text = "检索全文";
            this.rbByAll.UseVisualStyleBackColor = true;
            // 
            // rbByKeywords
            // 
            this.rbByKeywords.AutoSize = true;
            this.rbByKeywords.Location = new System.Drawing.Point(301, 255);
            this.rbByKeywords.Name = "rbByKeywords";
            this.rbByKeywords.Size = new System.Drawing.Size(85, 17);
            this.rbByKeywords.TabIndex = 15;
            this.rbByKeywords.TabStop = true;
            this.rbByKeywords.Text = "检索关键字";
            this.rbByKeywords.UseVisualStyleBackColor = true;
            // 
            // rbByTitle
            // 
            this.rbByTitle.AutoSize = true;
            this.rbByTitle.Location = new System.Drawing.Point(179, 255);
            this.rbByTitle.Name = "rbByTitle";
            this.rbByTitle.Size = new System.Drawing.Size(73, 17);
            this.rbByTitle.TabIndex = 14;
            this.rbByTitle.TabStop = true;
            this.rbByTitle.Text = "检索标题";
            this.rbByTitle.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(205, 102);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(261, 110);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(542, 218);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "搜索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtKeyWords
            // 
            this.txtKeyWords.Location = new System.Drawing.Point(144, 218);
            this.txtKeyWords.Name = "txtKeyWords";
            this.txtKeyWords.Size = new System.Drawing.Size(379, 20);
            this.txtKeyWords.TabIndex = 0;
            // 
            // tpResult
            // 
            this.tpResult.Controls.Add(this.linkLabel1);
            this.tpResult.Controls.Add(this.panel1);
            this.tpResult.Location = new System.Drawing.Point(4, 22);
            this.tpResult.Name = "tpResult";
            this.tpResult.Padding = new System.Windows.Forms.Padding(3);
            this.tpResult.Size = new System.Drawing.Size(740, 421);
            this.tpResult.TabIndex = 1;
            this.tpResult.Text = "tabPage2";
            this.tpResult.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(48, 20);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(79, 13);
            this.linkLabel1.TabIndex = 2;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "返回搜索界面";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvResult);
            this.panel1.Location = new System.Drawing.Point(6, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(728, 366);
            this.panel1.TabIndex = 1;
            // 
            // dgvResult
            // 
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Title,
            this.FilePath,
            this.KeyWords,
            this.Content});
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResult.Location = new System.Drawing.Point(0, 0);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.Size = new System.Drawing.Size(728, 366);
            this.dgvResult.TabIndex = 0;
            this.dgvResult.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResult_CellContentClick);
            // 
            // Title
            // 
            this.Title.DataPropertyName = "Title";
            this.Title.HeaderText = "标题";
            this.Title.Name = "Title";
            this.Title.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Title.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // FilePath
            // 
            this.FilePath.DataPropertyName = "FilePath";
            this.FilePath.HeaderText = "文件名";
            this.FilePath.Name = "FilePath";
            // 
            // KeyWords
            // 
            this.KeyWords.DataPropertyName = "KeyWords";
            this.KeyWords.HeaderText = "关键字";
            this.KeyWords.Name = "KeyWords";
            // 
            // Content
            // 
            this.Content.DataPropertyName = "Content";
            this.Content.HeaderText = "内容";
            this.Content.Name = "Content";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tcList);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(750, 441);
            this.panel2.TabIndex = 7;
            // 
            // ListForm
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 441);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ListForm";
            this.Text = "主界面";
            this.Load += new System.EventHandler(this.ListForm_Load);
            this.tcList.ResumeLayout(false);
            this.tpSearch.ResumeLayout(false);
            this.tpSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tpResult.ResumeLayout(false);
            this.tpResult.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcList;
        private System.Windows.Forms.TabPage tpSearch;
        private System.Windows.Forms.RadioButton rbByAll;
        private System.Windows.Forms.RadioButton rbByKeywords;
        private System.Windows.Forms.RadioButton rbByTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtKeyWords;
        private System.Windows.Forms.TabPage tpResult;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridViewLinkColumn Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn KeyWords;
        private System.Windows.Forms.DataGridViewTextBoxColumn Content;

    }
}