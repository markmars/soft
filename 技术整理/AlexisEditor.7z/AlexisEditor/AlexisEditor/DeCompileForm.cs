﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CHM2Word;

namespace AlexisEditor
{
    public partial class DeCompileForm : Form
    {
        public DeCompileForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 浏览文件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd=new OpenFileDialog())
            {
                ofd.FileName = "";
                ofd.Filter = "CHM文件(*.chm)|*.chm";
                ofd.ShowDialog();
                if (ofd.FileName!="")
                {
                    this.txtFilePath.Text = ofd.FileName;
                }
            }
        }

        /// <summary>
        /// 反编译
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeCompile_Click(object sender, EventArgs e)
        {
            if (this.txtFilePath.Text.ToString()!="")
            {
                CHM2Word.Decompile de = new Decompile();
                de.DecompileChm(this.txtFilePath.Text);

                if (MessageBox.Show("反编译成功!是否打开目标文件夹?", "提示信息", MessageBoxButtons.YesNo)== System.Windows.Forms.DialogResult.Yes)
                {
                    string path = this.txtFilePath.Text.Substring(0,this.txtFilePath.Text.LastIndexOf('.'));
                    System.Diagnostics.Process.Start("explorer.exe", path);
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("请选择CHM文件");
                return;

            }
        }
    }
}
