﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace AlexisEditor
{
    public partial class OutPutForm : BaseDockForm
    {
        public OutPutForm()
        {
            InitializeComponent();
        }

        public RichTextBox RtbOutput
        {
            get { return this.richTextBox; }
        }

        public TextBox TxtOutput
        {
            get { return this.txtOutput; }
        }
    }
}
