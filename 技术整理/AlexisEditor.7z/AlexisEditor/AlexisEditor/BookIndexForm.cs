﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using ChmHelper;

namespace AlexisEditor
{
    public partial class BookIndexForm:BaseDockForm
    {
        public BookIndexForm()
        {
            InitializeComponent();
        }

        public TreeView TreeIndex
        {
            get { return this.tvIndex; }
        }

        private void BookIndexForm_Load(object sender, EventArgs e)
        {
            this.Icon = (Icon)IconHelper.BookIcon;
            ImageList imageList = new ImageList();
            imageList.Images.Add(IconHelper.FolderIcon);
            imageList.Images.Add(IconHelper.ArticleIcon);
            this.tvIndex.ImageList = imageList;
        }

        /// <summary>
        /// 添加文件夹
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode node = this.tvIndex.SelectedNode;//选中的节点
            
            //查看是否是根节点或是目录节点
            CHMNodeList list = this.GetNodeList(node);
            if (list == null || list.Count==0)
            {
                MessageBox.Show("请选择根节点或是目录节点");
                return;
            }
            //创建新的节点
            CHMNode newNode = new CHMNode();
            newNode.Name = "新建文件夹";
            newNode.ImageNo = "0";
            //newNode.Nodes = new CHMNodeList();
            list.Add(newNode);
            System.Windows.Forms.TreeNode node2 = new TreeNode(newNode.Name);
            node2.Tag = newNode;
            node2.ImageIndex = 0;
            node2.SelectedImageIndex = 0;
            node.Nodes.Add(node2);//将新节点添加到树中
            node.ImageIndex = 0;
            node.SelectedImageIndex = 0;
            this.tvIndex.SelectedNode = node2;
        }

        /// <summary>
        /// 添加文章
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddArticleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode node = this.tvIndex.SelectedNode;
            CHMNodeList list = this.GetNodeList(node);
            if (list == null)
            {
                MessageBox.Show("请选择根节点或是目录节点");
                return;
            }
            EditForm frmEdit = new EditForm();
            frmEdit.ShowDialog(this);

            CHMNode NewNode = frmEdit.Node;
            if(NewNode==null)
            {
                return;
            }
            list.Add(NewNode);
            System.Windows.Forms.TreeNode node2 = new TreeNode(NewNode.Name);
            node2.Tag = NewNode;
            node2.ImageIndex = 1;
            node2.SelectedImageIndex = 1;
            node.Nodes.Add(node2);//将新节点添加到树中
            node.ImageIndex = 0;
            node.SelectedImageIndex = 0;
            this.tvIndex.SelectedNode = node2;
            
        }

        private CHMNodeList GetNodeList(System.Windows.Forms.TreeNode node)
        {
            if (node == null)
                return null;
            if (node.Tag is CHMDocument)
            {
                return ((CHMDocument)node.Tag).Nodes;
            }
            if (node.Tag is CHMNode)
            {
                return ((CHMNode)node.Tag).Nodes;
            }
            return null;
        }

        /// <summary>
        /// 删除节点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeleteDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.TreeNode node = this.tvIndex.SelectedNode;//获取要删除的节点
            if (node == null)
            {
                MessageBox.Show("请选择一个节点");
                return;
            }
            System.Windows.Forms.TreeNode parent = node.Parent;//获取该节点的父节点
            if (parent == null)
            {
                MessageBox.Show("请选择目录或页面节点");
                return;
            }
            CHMNodeList list = GetNodeList(parent);
            if (MessageBox.Show("是否删除文章（删除同时删除本地文件）?","确认", MessageBoxButtons.YesNo)== System.Windows.Forms.DialogResult.Yes)
            {
                list.Remove((CHMNode)node.Tag);
                //同时删除文件
                if (System.IO.File.Exists(((CHMNode)node.Tag).Local))
                {
                    System.IO.File.Delete(((CHMNode)node.Tag).Local);
                }
                node.Remove();//移除该节点    
            }
        }

        private void ReNameMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.tvIndex.SelectedNode.BeginEdit();
        }

        private void tvIndex_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            this.tvIndex.SelectedNode.Name = e.Label;
            TreeNode node = this.tvIndex.SelectedNode;
            if (node.Tag is CHMDocument)
            {
                ((CHMDocument)node.Tag).Title = e.Label;
            }
            if (node.Tag is CHMNode)
            {
                ((CHMNode)node.Tag).Name = e.Label;
            }
        }

        //双击节点,编辑文件
        private void tvIndex_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {

        }

        #region 实现节点拖拽功能
        private void tvIndex_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("System.Windows.Forms.TreeNode"))
            {
                e.Effect = DragDropEffects.Move;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void tvIndex_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }
        #endregion

        private void tvIndex_DragDrop(object sender, DragEventArgs e)
        {
            //判断数据是否是 TreeNode 的格式
            if (e.Data.GetDataPresent("System.Windows.Forms.TreeNode", false))
            {
                TreeNode dragedTreeNode = (TreeNode)e.Data.GetData("System.Windows.Forms.TreeNode");

                //获取鼠标落点处 TreeNode
                Point pt = ((TreeView)sender).PointToClient(new Point(e.X, e.Y));
                TreeNode targetTreeNode = ((TreeView)sender).GetNodeAt(pt);

                targetTreeNode.Nodes.Add(dragedTreeNode.Clone() as TreeNode);
                dragedTreeNode.Remove();

                (sender as TreeView).ExpandAll();
            }
            else
            {
                MessageBox.Show("不是有效的树节点！");
            }
        }

        private void tvIndex_ItemDrag(object sender, ItemDragEventArgs e)
        {
            TreeNode tn = e.Item as TreeNode;

            //根节点不允许拖动
            if (e.Button == MouseButtons.Left && tn != null && tn.Parent != null)
            {
                DoDragDrop(e.Item, DragDropEffects.Move);
            }
        }
        /*
        //开始拖动操作事件 
        private void TreeView_ItemDrag(object sender, ItemDragEventArgs e)
        {
            TreeNode tn = e.Item as TreeNode;
            if ((e.Button == MouseButtons.Left) && (tn != null) && (tn.Parent != null)) //根节点不允许拖放操作。 
            {
                this.treeView.DoDragDrop(tn, DragDropEffects.Copy | DragDropEffects.Move | DragDropEffects.Link);
            }

        }

        //是否允许拖放操作继续检查事件 
        private void TreeView_QueryContinueDrag(object sender, QueryContinueDragEventArgs e)
        {
            //例如，当光标悬停在 TreeView 控件上时，展开该控件中的 TreeNode 
            //this.textBox1.Text = p.ToString(); 
        }

        private void TreeView_DragEnter(object sender, DragEventArgs e)
        {
            //e.Effect = e.AllowedEffect; 

        }

        private void TreeView_DragOver(object sender, DragEventArgs e)
        {
            //当光标悬停在 TreeView 控件上时，展开该控件中的 TreeNode 
            Point p = this.treeView.PointToClient(Control.MousePosition);
            TreeNode tn = this.treeView.GetNodeAt(p);
            if (tn != null)
            {
                if (this.dragDropTreeNode != tn) //移动到新的节点 
                {
                    if (tn.Nodes.Count > 0 && tn.IsExpanded == false)
                    {
                        this.startTime = DateTime.Now;//设置新的起始时间 
                    }
                }
                else
                {
                    if (tn.Nodes.Count > 0 && tn.IsExpanded == false && this.startTime != DateTime.MinValue)
                    {
                        TimeSpan ts = DateTime.Now - this.startTime;
                        if (ts.TotalMilliseconds >= 1000) //一秒 
                        {
                            tn.Expand();
                            this.startTime = DateTime.MinValue;
                        }
                    }
                }

            }
            //设置拖放标签Effect状态 
            if (tn != null)//&& (tn != this.treeView.SelectedNode)) //当控件移动到空白处时，设置不可用。 
            {
                if ((e.AllowedEffect & DragDropEffects.Move) != 0)
                {
                    e.Effect = DragDropEffects.Move;
                }
                if (((e.AllowedEffect & DragDropEffects.Copy) != 0) && ((e.KeyState & 0x08) != 0))//Ctrl key 
                {
                    e.Effect = DragDropEffects.Copy;
                }
                if (((e.AllowedEffect & DragDropEffects.Link) != 0) && ((e.KeyState & 0x08) != 0) && ((e.KeyState & 0x04) != 0))//Ctrl key + Shift key 
                {
                    e.Effect = DragDropEffects.Link;
                }
                if (e.Data.GetDataPresent(typeof(TreeNode)))//拖动的是TreeNode 
                {

                    TreeNode parND = tn;//判断是否拖到了子项 
                    bool isChildNode = false;
                    while (parND.Parent != null)
                    {
                        parND = parND.Parent;
                        if (parND == this.treeView.SelectedNode)
                        {
                            isChildNode = true;
                            break;
                        }
                    }
                    if (isChildNode)
                    {
                        e.Effect = DragDropEffects.None;
                    }
                }
                else if (e.Data.GetDataPresent(typeof(ListViewItem)))//拖动的是ListViewItem 
                {
                    if (tn.Parent == null)
                    {
                        e.Effect = DragDropEffects.None;
                    }
                }
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }

            //设置拖放目标TreeNode的背景色 
            if (e.Effect == DragDropEffects.None)
            {
                if (this.dragDropTreeNode != null) //取消被放置的节点高亮显示 
                {
                    this.dragDropTreeNode.BackColor = SystemColors.Window;
                    this.dragDropTreeNode.ForeColor = SystemColors.WindowText;
                    this.dragDropTreeNode = null;
                }
            }
            else
            {
                if (tn != null)
                {
                    if (this.dragDropTreeNode != null)
                    {
                        if (this.dragDropTreeNode != tn)
                        {
                            this.dragDropTreeNode.BackColor = SystemColors.Window;//取消上一个被放置的节点高亮显示 
                            this.dragDropTreeNode.ForeColor = SystemColors.WindowText;
                            this.dragDropTreeNode = tn;//设置为新的节点 
                            this.dragDropTreeNode.BackColor = SystemColors.Highlight;
                            this.dragDropTreeNode.ForeColor = SystemColors.HighlightText;
                        }
                    }
                    else
                    {
                        this.dragDropTreeNode = tn;//设置为新的节点 
                        this.dragDropTreeNode.BackColor = SystemColors.Highlight;
                        this.dragDropTreeNode.ForeColor = SystemColors.HighlightText;
                    }
                }
            }
        }

        //随着鼠标的移动显示不同的光标效果 
        private void TreeView_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {
            //e.UseDefaultCursors = true; 

            // Use custom cursors if the check box is checked. 
            //if (UseCustomCursorsCheck.Checked) 
            //{ 
            //int i = 0; 
            // Sets the custom cursor based upon the effect. 
            //e.UseDefaultCursors = false; 
            if ((e.Effect & DragDropEffects.Move) == DragDropEffects.Move)
            {

                //Cursor d = new Cursor(""); 
                //Cursor.Current = MyNormalCursor; 
            }
            else
            {
                //Cursor.Current = MyNoDropCursor; 
            }
            //} 

        }

        private void TreeView_DragDrop(object sender, DragEventArgs e)
        {
            if (this.dragDropTreeNode != null)
            {
                if (e.Data.GetDataPresent(typeof(TreeNode)))
                {

                    TreeNode tn = (TreeNode)e.Data.GetData(typeof(TreeNode));
                    tn.Remove();//从原父节点移除被拖得节点 
                    this.dragDropTreeNode.Nodes.Add(tn);//添加被拖得节点到新节点下面 
                    Category category = (Category)tn.Tag;
                    if (this.dragDropTreeNode.Parent == null)
                    {
                        category.ParentID = 0;
                    }
                    else
                    {
                        category.ParentID = ((Category)this.dragDropTreeNode.Tag).CategoryID;
                    }
                    //更新节点移动到数据库 
                    DocumentController.GetInstance().UpdateCategoryParent(category);
                    if (this.dragDropTreeNode.IsExpanded == false)
                    {
                        this.dragDropTreeNode.Expand();//展开节点 
                    }

                }
                else if (e.Data.GetDataPresent(typeof(ListViewItem)))
                {
                    if (this.dragDropTreeNode.Parent != null)
                    {
                        int categoryID = ((Category)this.dragDropTreeNode.Tag).CategoryID;
                        ListViewItem listViewItem = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
                        Item item = (Item)listViewItem.Tag;
                        DocumentController.GetInstance().UpdateItemCategory(item.ItemID, categoryID);
                        listViewItem.Remove();
                    }
                }
                //取消被放置的节点高亮显示 
                this.dragDropTreeNode.BackColor = SystemColors.Window;
                this.dragDropTreeNode.ForeColor = SystemColors.WindowText;
                this.dragDropTreeNode = null;
            }
        }

        private void TreeView_DragLeave(object sender, EventArgs e)
        {
            if (this.dragDropTreeNode != null) //在按下{ESC}，取消被放置的节点高亮显示 
            {
                this.dragDropTreeNode.BackColor = SystemColors.Window;
                this.dragDropTreeNode.ForeColor = SystemColors.WindowText;
                this.dragDropTreeNode = null;
            }
        } 
*/
        
    }
}
