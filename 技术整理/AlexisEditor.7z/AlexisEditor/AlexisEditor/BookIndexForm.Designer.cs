﻿namespace AlexisEditor
{
    partial class BookIndexForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tvIndex = new System.Windows.Forms.TreeView();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddArticleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ImportHtmlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ReNameMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DeleteDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // tvIndex
            // 
            this.tvIndex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvIndex.LabelEdit = true;
            this.tvIndex.Location = new System.Drawing.Point(0, 0);
            this.tvIndex.Name = "tvIndex";
            this.tvIndex.Size = new System.Drawing.Size(187, 527);
            this.tvIndex.TabIndex = 0;
            this.tvIndex.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.tvIndex_AfterLabelEdit);
            this.tvIndex.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.tvIndex_ItemDrag);
            this.tvIndex.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvIndex_NodeMouseDoubleClick);
            this.tvIndex.DragDrop += new System.Windows.Forms.DragEventHandler(this.tvIndex_DragDrop);
            this.tvIndex.DragEnter += new System.Windows.Forms.DragEventHandler(this.tvIndex_DragEnter);
            this.tvIndex.DragOver += new System.Windows.Forms.DragEventHandler(this.tvIndex_DragOver);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddFolderToolStripMenuItem,
            this.AddArticleToolStripMenuItem,
            this.ImportHtmlToolStripMenuItem,
            this.ReNameMToolStripMenuItem,
            this.DeleteDToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(135, 114);
            // 
            // AddFolderToolStripMenuItem
            // 
            this.AddFolderToolStripMenuItem.Name = "AddFolderToolStripMenuItem";
            this.AddFolderToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.AddFolderToolStripMenuItem.Text = "新建文件夹";
            this.AddFolderToolStripMenuItem.Click += new System.EventHandler(this.AddFolderToolStripMenuItem_Click);
            // 
            // AddArticleToolStripMenuItem
            // 
            this.AddArticleToolStripMenuItem.Name = "AddArticleToolStripMenuItem";
            this.AddArticleToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.AddArticleToolStripMenuItem.Text = "新建文章";
            this.AddArticleToolStripMenuItem.Click += new System.EventHandler(this.AddArticleToolStripMenuItem_Click);
            // 
            // ImportHtmlToolStripMenuItem
            // 
            this.ImportHtmlToolStripMenuItem.Name = "ImportHtmlToolStripMenuItem";
            this.ImportHtmlToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ImportHtmlToolStripMenuItem.Text = "导入HTML";
            // 
            // ReNameMToolStripMenuItem
            // 
            this.ReNameMToolStripMenuItem.Name = "ReNameMToolStripMenuItem";
            this.ReNameMToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ReNameMToolStripMenuItem.Text = "重命名(&M)";
            this.ReNameMToolStripMenuItem.Click += new System.EventHandler(this.ReNameMToolStripMenuItem_Click);
            // 
            // DeleteDToolStripMenuItem
            // 
            this.DeleteDToolStripMenuItem.Name = "DeleteDToolStripMenuItem";
            this.DeleteDToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.DeleteDToolStripMenuItem.Text = "删除(&D)";
            this.DeleteDToolStripMenuItem.Click += new System.EventHandler(this.DeleteDToolStripMenuItem_Click);
            // 
            // BookIndexForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(187, 527);
            this.ContextMenuStrip = this.contextMenuStrip;
            this.Controls.Add(this.tvIndex);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HideOnClose = true;
            this.Name = "BookIndexForm";
            this.Text = "书籍文件夹";
            this.Load += new System.EventHandler(this.BookIndexForm_Load);
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView tvIndex;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem AddFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddArticleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ImportHtmlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ReNameMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DeleteDToolStripMenuItem;
    }
}