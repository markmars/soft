﻿namespace AlexisEditor
{
    partial class ConfigForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigForm));
            this.chkDeleteFiles = new System.Windows.Forms.CheckBox();
            this.txtHhcPath = new System.Windows.Forms.TextBox();
            this.btnHhcPath = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.rbCsdnEditor = new System.Windows.Forms.RadioButton();
            this.rbKindEditor = new System.Windows.Forms.RadioButton();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.rbHhc = new System.Windows.Forms.RadioButton();
            this.rbHha = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // chkDeleteFiles
            // 
            this.chkDeleteFiles.AutoSize = true;
            this.chkDeleteFiles.Location = new System.Drawing.Point(15, 84);
            this.chkDeleteFiles.Name = "chkDeleteFiles";
            this.chkDeleteFiles.Size = new System.Drawing.Size(98, 17);
            this.chkDeleteFiles.TabIndex = 0;
            this.chkDeleteFiles.Text = "删除临时文件";
            this.chkDeleteFiles.UseVisualStyleBackColor = true;
            // 
            // txtHhcPath
            // 
            this.txtHhcPath.Location = new System.Drawing.Point(88, 38);
            this.txtHhcPath.Name = "txtHhcPath";
            this.txtHhcPath.ReadOnly = true;
            this.txtHhcPath.Size = new System.Drawing.Size(273, 20);
            this.txtHhcPath.TabIndex = 1;
            // 
            // btnHhcPath
            // 
            this.btnHhcPath.Location = new System.Drawing.Point(367, 36);
            this.btnHhcPath.Name = "btnHhcPath";
            this.btnHhcPath.Size = new System.Drawing.Size(75, 23);
            this.btnHhcPath.TabIndex = 2;
            this.btnHhcPath.Text = "浏览";
            this.btnHhcPath.UseVisualStyleBackColor = true;
            this.btnHhcPath.Click += new System.EventHandler(this.btnHhcPath_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "hhc.exe路径";
            // 
            // rbCsdnEditor
            // 
            this.rbCsdnEditor.AutoSize = true;
            this.rbCsdnEditor.Location = new System.Drawing.Point(152, 84);
            this.rbCsdnEditor.Name = "rbCsdnEditor";
            this.rbCsdnEditor.Size = new System.Drawing.Size(76, 17);
            this.rbCsdnEditor.TabIndex = 4;
            this.rbCsdnEditor.TabStop = true;
            this.rbCsdnEditor.Text = "CsdnEditor";
            this.rbCsdnEditor.UseVisualStyleBackColor = true;
            // 
            // rbKindEditor
            // 
            this.rbKindEditor.AutoSize = true;
            this.rbKindEditor.Location = new System.Drawing.Point(277, 84);
            this.rbKindEditor.Name = "rbKindEditor";
            this.rbKindEditor.Size = new System.Drawing.Size(73, 17);
            this.rbKindEditor.TabIndex = 5;
            this.rbKindEditor.TabStop = true;
            this.rbKindEditor.Text = "KindEditor";
            this.rbKindEditor.UseVisualStyleBackColor = true;
            this.rbKindEditor.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(277, 111);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(367, 111);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // rbHhc
            // 
            this.rbHhc.AutoSize = true;
            this.rbHhc.Location = new System.Drawing.Point(18, 13);
            this.rbHhc.Name = "rbHhc";
            this.rbHhc.Size = new System.Drawing.Size(111, 17);
            this.rbHhc.TabIndex = 9;
            this.rbHhc.TabStop = true;
            this.rbHhc.Text = "使用hhc.exe编译";
            this.rbHhc.UseVisualStyleBackColor = true;
            // 
            // rbHha
            // 
            this.rbHha.AutoSize = true;
            this.rbHha.Location = new System.Drawing.Point(161, 13);
            this.rbHha.Name = "rbHha";
            this.rbHha.Size = new System.Drawing.Size(104, 17);
            this.rbHha.TabIndex = 10;
            this.rbHha.TabStop = true;
            this.rbHha.Text = "使用hha.dll编译";
            this.rbHha.UseVisualStyleBackColor = true;
            // 
            // ConfigForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 143);
            this.Controls.Add(this.rbHha);
            this.Controls.Add(this.rbHhc);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.rbKindEditor);
            this.Controls.Add(this.rbCsdnEditor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnHhcPath);
            this.Controls.Add(this.txtHhcPath);
            this.Controls.Add(this.chkDeleteFiles);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ConfigForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "选项";
            this.Load += new System.EventHandler(this.ConfigForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkDeleteFiles;
        private System.Windows.Forms.TextBox txtHhcPath;
        private System.Windows.Forms.Button btnHhcPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbCsdnEditor;
        private System.Windows.Forms.RadioButton rbKindEditor;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.RadioButton rbHhc;
        private System.Windows.Forms.RadioButton rbHha;
    }
}