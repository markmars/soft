﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ChmHelper;

namespace AlexisEditor
{
    public partial class ConfigForm : Form
    {
        private ChmHelper.XBookConfig config = XBookConfig.Instance;
        public ConfigForm()
        {
            InitializeComponent();
        }

        private void ConfigForm_Load(object sender, EventArgs e)
        {
            config.Load("config.xml");
            this.txtHhcPath.Text = config.HhcPath;
            if (config.IsDeleteTempFiles)
            {
                this.chkDeleteFiles.Checked=true;   
            }
            if (config.Editor=="CsdnEditor")
            {
                this.rbCsdnEditor.Checked = true;
            }
            else if (config.Editor=="KindEditor")
            {
                this.rbKindEditor.Checked = true;
            }

        }

        private void btnHhcPath_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog fbg = new OpenFileDialog())
            {
                fbg.ShowDialog();
                if (fbg.FileName!="")
                {
                    if (fbg.SafeFileName != "hhc.exe")
                    {
                        MessageBox.Show("请选择hhc.exe所在路径");
                        return;
                    }
                    this.txtHhcPath.Text = fbg.FileName;
                }
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if(this.txtHhcPath.Text!="")
            {
                config.HhcPath = this.txtHhcPath.Text;
            }
            if (this.rbCsdnEditor.Checked)
            {
                config.Editor = "CsdnEditor";
            }
            else if (this.rbKindEditor.Checked)
            {
                config.Editor = "KindEditor";
            }
            if (this.chkDeleteFiles.Checked)
            {
                config.IsDeleteTempFiles =true;
            }
            else
            {
                config.IsDeleteTempFiles = false;
            }
            config.Save("config.xml");
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
