﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CHM2Word;
using System.IO;
using System.Diagnostics;

namespace AlexisEditor
{
    /// <summary>
    /// 此处使用单例模式
    /// </summary>
    public partial class ToWordForm : Form
    {

        public ToWordForm()
        {
            InitializeComponent();
        }


        /// <summary>
        /// 选择chm文件按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd=new OpenFileDialog())
            {
                ofd.Filter = "CHM Files|*.chm";
                ofd.ShowDialog();
                if (ofd.FileName != "")
                {
                    this.textBox1.Text = ofd.FileName;
                }
            }
        }

        /// <summary>
        /// 开始转换按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConvert_Click(object sender, EventArgs e)
        {
            
            string startPath = Application.StartupPath;//起始路径
            if (textBox1.Text == "" || (textBox1.Text.Substring(textBox1.Text.LastIndexOf('.')) != ".chm" && textBox1.Text.Substring(textBox1.Text.LastIndexOf('.')) != ".CHM"))
            {
                MessageBox.Show("请选择CHM文件");
                return;
            }

            string _defaultTopic = textBox1.Text;
            try
            {
                string NameFile = _defaultTopic;

                bool blnFile = false;
                blnFile = true;
                if ((!File.Exists(NameFile)))
                {
                    blnFile = false;
                    if ((!Directory.Exists(NameFile)))
                    {
                        MessageBox.Show(this, "请选择文件", "找不到文件", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                }
                List<string> files = new List<string>();
                if (blnFile)
                {
                    files.Add(NameFile);
                }
                else
                {
                    //folder
                    foreach (string fileChm in Directory.GetFiles(NameFile, "*.chm"))
                    {
                        files.Add(fileChm);
                    }
                }
                string NameFileDoc = "";
                foreach (string fileChm in files)
                {
                    NameFileDoc = Path.Combine(Path.GetDirectoryName(fileChm), Path.GetFileNameWithoutExtension(fileChm) + ".doc");
                    d.DecompileAndExport(fileChm, NameFileDoc);
                }
                if (!File.Exists(NameFileDoc))
                {
                    //MessageBox.Show("出错，找不到" + NameFileDoc);
                }
                else
                {
                    if (MessageBox.Show("打开" + NameFileDoc, "ss", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        Process.Start(NameFileDoc);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

            }
        }


        private DecompileAndExportClass withEventsField_d = new DecompileAndExportClass();

        public DecompileAndExportClass d
        {
            get { return withEventsField_d; }
            set
            {
                if (withEventsField_d != null)
                {
                    withEventsField_d.ProcessFileIntoWord -= d_ProcessFileIntoWord;
                }
                withEventsField_d = value;
                if (withEventsField_d != null)
                {
                    withEventsField_d.ProcessFileIntoWord += d_ProcessFileIntoWord;
                }
            }
        }

        /// <summary>
        /// 在处理中的一些进程信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void d_ProcessFileIntoWord(object sender, CHM2Word.ProcessFileEventArgs e)
        {
            this.textBox2.Text = e.FileNameProcessed + ":" + e.FileNumberProcessed;
            this.textBox2.Refresh();
            //lblMessage.Text = e.FileNumberProcessed + " : " + e.FileNameProcessed;
            //lblMessage.Refresh();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
