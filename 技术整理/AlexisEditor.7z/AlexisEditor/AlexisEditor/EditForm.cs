﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using mshtml;
using ChmHelper;
using System.Xml;
using WeifenLuo.WinFormsUI.Docking;


using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.Search;
using Lucene.Net.QueryParsers;
using Lucene.Net.Analysis.Standard;

namespace AlexisEditor
{
    /// <summary>
    /// 文章编辑类
    /// </summary>
    public partial class EditForm : BaseDockForm
    {
        #region 成员
        /// <summary>
        /// 起始路径
        /// </summary>
        private string startPath;
        /// <summary>
        /// Edit窗体
        /// </summary>
        private static EditForm frmEdit;

        private string filePathEdit = "";//编辑时的文件名
        

        private CHMNode node;
        public CHMNode Node
        {
            get { return this.node; }
        }

        #endregion

        #region 构造器

        public EditForm()
        {
            InitializeComponent();
        }

        public static EditForm CreateEditForm()
        {
            if (frmEdit == null || frmEdit.IsDisposed)
            {
                frmEdit = new EditForm();
            }
            return frmEdit;
        }

        #endregion

        #region 事件
        /// <summary>
        /// 窗体加载事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EditForm_Load(object sender, EventArgs e)
        {
            startPath = Application.StartupPath;//起始路径
            Uri u = null;
            XBookConfig.Instance.Load("config.xml");
            //这边可以做成从配置文件中读取选择什么编辑器
            if (XBookConfig.Instance.Editor=="CsdnEditor")
            {
                u = new Uri(startPath + @"\CSDN_UBB\normal.htm");
            }
            else if (XBookConfig.Instance.Editor=="KindEditor")
            {
                u = new Uri(startPath + @"\ckeditor\index.html");
            }
            this.wbEditor.Navigating += new WebBrowserNavigatingEventHandler(wbEditor_Navigating);//为了获取前台的点击事件

            if (this.filePathEdit=="")
            {
                this.wbEditor.Url = u;    
            }
            else
            {
                this.wbEditor.Url = new Uri(startPath + @"\CSDN_UBB\normalTemp.htm");
            }
            
        }

        void wbEditor_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            
            string saveUrl = null;
            if (XBookConfig.Instance.Editor=="CsdnEditor")
            {
                saveUrl = startPath + @"\CSDN_UBB\loading.htm";
            }
            else if (XBookConfig.Instance.Editor=="KindEditor")
            {
                saveUrl = startPath + "";
            }

            if (e.Url.AbsolutePath.ToString().Replace('/', '\\') == saveUrl)
            {
                MessageBox.Show(this.wbEditor.Version.ToString());
                HtmlDocument hd = this.wbEditor.Document;//获取文档信息
                HtmlElement he = hd.GetElementById("content");
                IHTMLDocument2 doc = (IHTMLDocument2)this.wbEditor.Document.DomDocument;
                //要根据ie的版本去判断
                mshtml.HTMLInputElement text1=null;
                if (this.wbEditor.Version.ToString().Substring(0,1)=="6")
                {
                    text1 = (HTMLInputElement)doc.all.item("content",0);//获取隐藏域中的值
                }
                else
                {
                    text1 = (HTMLInputElement)doc.all.item("content");//获取隐藏域中的值
                }
                 
                string rr = text1.value;
                if (this.txtName.Text == "")
                {
                    MessageBox.Show("文章标题不能为空！");
                    return;
                }

                string filename = GetFileName();
                if (filePathEdit != "")
                {
                    filename = filePathEdit.Substring(filePathEdit.LastIndexOf('\\') + 1);
                    filename = filename.Substring(0, filename.LastIndexOf('.'));
                    File.Delete(filePathEdit);
                }
                //将内容存入到html模板中，并生产html文件
                if (rr != "")
                {
                    FileStream fs = new FileStream("html_files\\" + filename + ".htm", FileMode.Create);//文件名
                    StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.GetEncoding("UTF-8"));
                    sw.WriteLine("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">");
                    sw.WriteLine("<html xmlns=\"http://www.w3.org/1999/xhtml\">");
                    sw.WriteLine("<head>");
                    sw.WriteLine("<title>" + this.txtName.Text + "</title>");//文章名
                    sw.WriteLine("<meta content=\"text/html; charset=utf-8\" http-equiv=\"content-type\"/>");
                    sw.WriteLine("<link type=\"text/css\" rel=\"stylesheet\" href=\"Styles/SyntaxHighlighter.css\"></link>");
                    sw.WriteLine("<script type=\"text/javascript\" src=\"Scripts/shCore.js\"></script>");
                    sw.WriteLine("<script type=\"text/javascript\" src=\"Scripts/shBrushCSharp.js\"></script>");//C#
                    sw.WriteLine("<script type=\"text/javascript\" src=\"Scripts/shBrushJScript.js\"></script>");//Javascript
                    sw.WriteLine("<script type=\"text/javascript\" src=\"Scripts/shBrushJava.js\"></script>");//Java
                    sw.WriteLine("<script type=\"text/javascript\" src=\"Scripts/shBrushPhp.js\"></script>");//php
                    sw.WriteLine("<script type=\"text/javascript\" src=\"Scripts/shBrushPython.js\"></script>");//python
                    sw.WriteLine("<script type=\"text/javascript\" src=\"Scripts/shBrushSql.js\"></script>");//sql
                    sw.WriteLine("<script type=\"text/javascript\" src=\"Scripts/shBrushXml.js\"></script>");//xml
                    sw.WriteLine("<script type=\"text/javascript\"> window.onload = function () {");
                    sw.WriteLine("dp.SyntaxHighlighter.ClipboardSwf = 'Scripts/clipboard.swf';");
                    sw.WriteLine("dp.SyntaxHighlighter.HighlightAll('code');}");
                    sw.WriteLine("</script>");
                    sw.WriteLine("</head>");
                    sw.Write("<body>");
                    rr = ChangeString(rr);
                    sw.Write(rr);
                    sw.WriteLine("</body>");
                    sw.WriteLine("</html>");
                    sw.Close();
                }
                //将节点返回给目录，暂不做保存操作
                if (node == null)
                {
                    node = new CHMNode();
                }
                node.Local = startPath + "\\html_files\\" + filename + ".htm";
                node.Name = this.txtName.Text;
                node.KeyWords = this.txtKeyWords.Text;
                node.Nodes = null;//表示是文章节点
                node.ImageNo = "1";

                this.Close();
            }
        }
        #endregion

        #region 方法
        /// <summary>
        /// 编辑文章
        /// </summary>
        /// <param name="filePath"></param>
        public void Edit(CHMNode node)
        {
            startPath = Application.StartupPath;
            string filePath = node.Local;
            StreamReader sr = new StreamReader(filePath);
            string t = sr.ReadToEnd();
            sr.Close();
            int beginIndex = t.IndexOf("<body>");//找出body中的内容
            int endIndex = t.IndexOf("</body>");
            string htmContent = t.Substring(beginIndex + 6, endIndex - 6 - beginIndex);

            if (File.Exists(startPath + @"\CSDN_UBB\normalTemp.htm"))
            {
                File.Delete(startPath + @"\CSDN_UBB\normalTemp.htm");
            }
            //写文件

            FileStream fs = new FileStream(startPath + @"\CSDN_UBB\normalTemp.htm", FileMode.Create);//文件名
            StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.GetEncoding("UTF-8"));
            sw.WriteLine("<textarea name=\"tb_ReplyBody$_$Editor\" rows=\"2\" cols=\"20\" id=\"tb_ReplyBody___Editor\" style=\"height:290px;;width:100%;\">");
            sw.Write(ChangeStringToCode(htmContent));
            sw.WriteLine("</textarea>");
            sw.WriteLine("<script language=\"javascript\" type=\"text/javascript\" src=\"CsdnUbbEditor.js\"></script>");
            sw.WriteLine("<script type=\"text/javascript\">/*<![CDATA[*/");
            sw.WriteLine("var ubb = new CsdnUbbEditor(\"tb_ReplyBody___Editor\");");
            sw.WriteLine("ubb.contentLength = 8000;");
            sw.WriteLine("ubb.helpLink = \"help/ubb.html\";");
            sw.WriteLine("ubb.render(\"fontsize|space|bold|italic|underline|strikethrough|color|code|space|url|email|image|swf|movie|space|left|center|right|space|increase|decrease\");");
            sw.WriteLine("/*]]>*/</script>");
            sw.WriteLine("<input type=\"button\" value=\"保存\" onclick=\"getValue()\" />");
            sw.WriteLine("<input type=\"hidden\" id=\"content\" />");
            sw.WriteLine("<script type=\"text/javascript\">");
            sw.WriteLine("function getValue(){");
            sw.WriteLine("document.getElementById(\"content\").value=document.getElementById(\"tb_ReplyBody___Editor\").innerHTML;");
            sw.WriteLine("this.location.href=\"loading.htm\";");
            sw.WriteLine("}");
            sw.WriteLine("</script>");
            sw.Close();
            this.wbEditor.Url = new Uri(startPath + @"\CSDN_UBB\normalTemp.htm");
            this.txtName.Text = node.Name;
            this.txtKeyWords.Text = node.KeyWords;
            filePathEdit = filePath;
            this.node = node;
        }

        /// <summary>
        /// 字符串转换
        /// </summary>
        /// <param name="str"></param>
        /// <returns>返回转换后的字符串</returns>
        private string ChangeString(string str)
        {
            string changedStr = "";
            changedStr = str.Replace("[code=C#]", "<pre name=\"code\" class=\"CSharp\">");//C#
            changedStr = changedStr.Replace("[code=C/C++]", "<pre name=\"code\" class=\"cpp\">");//c++
            changedStr = changedStr.Replace("[code=JScript]", "<pre name=\"code\" class=\"javascript\">");//js
            changedStr = changedStr.Replace("[code=Java]", "<pre name=\"code\" class=\"java\">");//java
            changedStr = changedStr.Replace("[code=PHP]", "<pre name=\"code\" class=\"php\">");//php
            changedStr = changedStr.Replace("[code=Python]", "<pre name=\"code\" class=\"python\">");//python
            changedStr = changedStr.Replace("[code=SQL]", "<pre name=\"code\" class=\"sql\">");//sql
            changedStr = changedStr.Replace("[code=HTML]", "<pre name=\"code\" class=\"xml\">");//html
            changedStr = changedStr.Replace("[/code]", "</pre>");
            return changedStr;
        }

        private string ChangeStringToCode(string str)
        {
            string changedStr = "";
            changedStr = str.Replace("<pre name=\"code\" class=\"CSharp\">", "[code=C#]");//c#
            changedStr = changedStr.Replace("<pre name=\"code\" class=\"cpp\">", "[code=C/C++]");//c++
            changedStr = changedStr.Replace("<pre name=\"code\" class=\"javascript\">", "[code=JScript]");//javascript
            changedStr = changedStr.Replace("<pre name=\"code\" class=\"java\">", "[code=Java]");//java
            changedStr = changedStr.Replace("<pre name=\"code\" class=\"php\">", "[code=PHP]");//php
            changedStr = changedStr.Replace("<pre name=\"code\" class=\"python\">", "[code=Python]");//python
            changedStr = changedStr.Replace("<pre name=\"code\" class=\"sql\">", "[code=SQL]");//sql
            changedStr = changedStr.Replace("<pre name=\"code\" class=\"xml\">", "[code=HTML]");//html
            changedStr = changedStr.Replace("</pre>", "[/code]");
            return changedStr;
        }

        /// <summary>
        /// 根据时间获取保存的html的文件名
        /// </summary>
        /// <returns>返回以时间命名的文件名</returns>
        private string GetFileName()
        {
            return DateTime.Now.ToFileTime().ToString();
        }
        #endregion

       

    }
}
