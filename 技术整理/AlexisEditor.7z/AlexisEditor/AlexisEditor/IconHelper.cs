﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace AlexisEditor
{

    public static class IconHelper
    {
        private static ImageList imageList;
        private static List<Icon> iconList;
        static IconHelper()
        {
            System.Resources.ResourceManager resource = new System.Resources.ResourceManager("AlexisEditor.Properties.Resources", System.Reflection.Assembly.GetExecutingAssembly());
            Bitmap bitmap = (Bitmap)resource.GetObject("bookicons");

            //将加载的位图的图片提取出来，并放在list中
            imageList = new ImageList();
            iconList = new List<Icon>();
            for (int i = 0; i < bitmap.Width / 16; i++)
            {
                Bitmap img = bitmap.Clone(new Rectangle(16 * i, 0, 16, 16), bitmap.PixelFormat);//切割图标
                img.MakeTransparent(Color.Magenta);//设置过滤色
                imageList.Images.Add(img);
                System.IntPtr iconHandle = img.GetHicon();
                System.Drawing.Icon icon = Icon.FromHandle(iconHandle);
                iconList.Add(icon);
            }

        }

        public static Image GetBuildImage()
        {
            System.Resources.ResourceManager resource = new System.Resources.ResourceManager("AlexisEditor.Properties.Resources", System.Reflection.Assembly.GetExecutingAssembly());
            return (Image)resource.GetObject("Build");
        }

        /// <summary>
        /// 书籍ico图标
        /// </summary>
        public static Icon BookIcon
        {
            get { return iconList[0]; }
        }

        /// <summary>
        /// 文件夹ico图标
        /// </summary>
        public static Icon FolderIcon
        {
            get { return iconList[1]; }
        }

        /// <summary>
        /// 文章ico图标
        /// </summary>
        public static Icon ArticleIcon
        {
            get { return iconList[10]; }
        }

        /// <summary>
        /// 批量导入文件夹中的html文件
        /// </summary>
        public static Icon ImportFolderIcon
        {
            get { return iconList[24]; }
        }
    }
}
