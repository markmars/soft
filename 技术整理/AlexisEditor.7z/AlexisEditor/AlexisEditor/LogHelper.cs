﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace AlexisEditor
{
    public static class LogHelper
    {
        public static void WriteLog(string log)
        {
            string path = Application.StartupPath + "\\log.txt";
            FileStream filestream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None);
            StreamWriter sw = new StreamWriter(filestream, Encoding.Default);
            sw.BaseStream.Seek(0, SeekOrigin.End);
            sw.WriteLine("*********Exception*********");
            sw.WriteLine("Time:" + DateTime.Now);
            sw.WriteLine("Message:" + log);
            sw.WriteLine("*********Exception*********");
            sw.WriteLine();
            sw.WriteLine();
            sw.Close();
        }
        

    }
}
