﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using ChmHelper;

namespace AlexisEditor
{
    public partial class DirectoryForm : Form
    {
        public DirectoryForm()
        {
            InitializeComponent();
        }

        private void btnSelectPath_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd=new FolderBrowserDialog())
            {
                fbd.ShowDialog();
                if (fbd.SelectedPath!="")
                {
                    this.txtPath.Text = fbd.SelectedPath;
                }
            }
        }

        private void btnComplie_Click(object sender, EventArgs e)
        {
            if (this.txtPath.Text=="")
            {
                MessageBox.Show("请选择目录");
                return;
            }
            
            CHMDocument document = new CHMDocument();
            document.FileName = "Made by Alexis";
            document.Title = "Alexis";//设置根目录的名字
            //根节点
            CHMNode root = new CHMNode();
            root.Name = this.txtPath.Text.Substring(this.txtPath.Text.LastIndexOf('\\') + 1);
            document.Nodes.Add(root);
            GetFiles(this.txtPath.Text, root);
            //编译
            document.Compile("a");
        }

        private void GetFiles(string filePath, CHMNode node)
        {
            DirectoryInfo folder = new DirectoryInfo(filePath);
            node.Name = folder.Name;

            FileInfo[] chldFiles = folder.GetFiles("*.*");
            foreach (FileInfo chlFile in chldFiles)
            {
                if (chlFile.Extension == ".htm" || chlFile.Extension == ".html")
                {
                    CHMNode chldNode = new CHMNode();
                    chldNode.Name = chlFile.Name;
                    chldNode.Local = chlFile.FullName;
                    node.Nodes.Add(chldNode);
                }
            }

            DirectoryInfo[] chldFolders = folder.GetDirectories();
            foreach (DirectoryInfo chldFolder in chldFolders)
            {
                CHMNode chldNode = new CHMNode();
                chldNode.Name = folder.Name;
                node.Nodes.Add(chldNode);
                GetFiles(chldFolder.FullName, chldNode);
            }

        }

        private bool IsHasCompileFile(BackgroundWorker worker, string path)
        {
            return true;
        }
    }
}
