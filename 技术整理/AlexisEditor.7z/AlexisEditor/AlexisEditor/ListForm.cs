﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ChmHelper;

using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.Search;
using Lucene.Net.QueryParsers;
using Lucene.Net.Analysis.Standard;
using System.IO;

namespace AlexisEditor
{
    public partial class ListForm :BaseDockForm
    {
        public ListForm()
        {
            InitializeComponent();
        }
        //获取电子书
        private CHMNodeList nodes;
        public CHMNodeList Nodes
        {
            get { return this.nodes; }
            set { nodes = value; }
        }

        private CHMNode nodeOpen=null;

        private void ListForm_Load(object sender, EventArgs e)
        {
            System.Resources.ResourceManager rm = new System.Resources.ResourceManager("AlexisEditor.Properties.Resources", System.Reflection.Assembly.GetExecutingAssembly());
            Bitmap bitmap=(Bitmap)rm.GetObject("logo");
            bitmap.MakeTransparent(Color.White);
            this.pictureBox1.Image = bitmap;
            //隐藏TabContol的标签栏
            this.tcList.SizeMode = TabSizeMode.Fixed;
            this.tcList.ItemSize = new Size(0, 1);
            //设置默认页面
            this.tcList.SelectedIndex = 0;
            this.rbByAll.Checked = true;
        }

        /// <summary>
        /// 查询(修改为在点击查询的时候再去索引什么)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string KEYWORD = this.txtKeyWords.Text.ToString();//关键字
            if (KEYWORD=="")
            {
                MessageBox.Show("请输入查询条件");
                return;
            }
            //INDEX_STORE_PATH 为索引存储目录
            string INDEX_STORE_PATH = Application.StartupPath+@"\index";  

            //先存储索引
            IndexWriter writer = new IndexWriter(INDEX_STORE_PATH, new StandardAnalyzer(), true);
            SetIndex(writer,this.nodes);

            //在从索引中查询
            
            IndexSearcher searcher;

            try
            {
                searcher = new IndexSearcher(INDEX_STORE_PATH);
                QueryParser q = null;

                if (rbByTitle.Checked)
                {
                    q = new QueryParser("title", new StandardAnalyzer());
                }
                else if (rbByKeywords.Checked)
                {
                    q = new QueryParser("keywords", new StandardAnalyzer());
                }
                else if (rbByAll.Checked)
                {
                    q = new QueryParser("contents", new StandardAnalyzer());
                }
                
                Query query = q.Parse(KEYWORD);
                Hits hits = searcher.Search(query);

                //创建DataTable用于绑定
                DataTable dtResult = new DataTable();
                DataColumn dc1 = new DataColumn("Title", Type.GetType("System.String"));
                DataColumn dc2= new DataColumn("KeyWords", Type.GetType("System.String"));
                DataColumn dc3 = new DataColumn("Content", Type.GetType("System.String"));
                DataColumn dc4 = new DataColumn("FilePath", Type.GetType("System.String"));
                dtResult.Columns.Add(dc1);
                dtResult.Columns.Add(dc2);
                dtResult.Columns.Add(dc3);
                dtResult.Columns.Add(dc4);

                if (hits != null && hits.Length()>0)
                {
                    for (int i = 0; i < hits.Length(); i++)
                    {
                        Document doc = hits.Doc(i);
                        DataRow dr=dtResult.NewRow();
                        dr["Title"] = doc.Get("title");//文章标题
                        dr["KeyWords"] = doc.Get("keywords");//文章关键字
                        dr["Content"] = doc.Get("contents");//内容
                        dr["FilePath"] = doc.Get("filename");//文件路径
                        dtResult.Rows.Add(dr);
                    }
                    this.tcList.SelectedIndex = 1;
                    this.dgvResult.DataSource = dtResult;
                    this.dgvResult.Columns["FilePath"].Visible = false;
                }
                else
                {
                    MessageBox.Show("没有查到相关记录!");
                }
                searcher.Close();
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog(ex.Message);
            }
        }

        void linkTitle_Click(object sender, EventArgs e)
        {
            //点击链接事件
        }

        //找到当前的节点
        private void GetNode(string fileName,CHMNodeList nodes)
        {
            if (this.nodes==null || this.nodes.Count==0)
            {
                return ;
            }
            foreach (CHMNode n in nodes)
            {
                //if (node.Nodes==null)
                if (n.ImageNo=="1")//使用imageNo来判断
                {
                    if (n.Local==fileName)
                    {
                        this.nodeOpen = n;
                        return ;
                    }
                }
                else 
                {
                    GetNode(fileName,n.Nodes);   
                }
            }
            return ;
        }

        /// <summary>
        /// 遍历chmDocument，将节点存储为索引
        /// </summary>
        private void SetIndex(IndexWriter writer, CHMNodeList nodes)
        {
            if (this.nodes == null || this.nodes.Count == 0)
            {
                return;
            }
            foreach (CHMNode n in nodes)
            {
                //if (node.Nodes==null)
                if (n.ImageNo == "1")//使用imageNo来判断
                {
                    IndexFile(n, writer);
                }
                else
                {
                    SetIndex(writer,n.Nodes);
                }
            }
            writer.Close();// 关闭writer
        }

        private void IndexFile(CHMNode node, IndexWriter writer)
        {
            try
            {
                Document doc = new Document();
                doc.Add(new Field("filename", node.Local, Field.Store.YES, Field.Index.TOKENIZED));
                doc.Add(new Field("title", node.Name, Field.Store.YES, Field.Index.TOKENIZED));
                doc.Add(new Field("keywords", node.KeyWords, Field.Store.YES, Field.Index.TOKENIZED));
                doc.Add(new Field("contents", new StreamReader(node.Local, System.Text.Encoding.Default)));
                writer.AddDocument(doc);
            }
            catch (FileNotFoundException fnfe)
            {
                LogHelper.WriteLog(fnfe.Message);
            }
           
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.tcList.SelectedIndex = 0;
        }

        private void dgvResult_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //点击的是超链接
            if (e.ColumnIndex==0)
            {
                //获取当前行的文件名
                string path=this.dgvResult.CurrentRow.Cells[3].Value.ToString();

                //调用编辑窗口
                GetNode(path,this.nodes);
                CHMNode node = this.nodeOpen;
                EditForm form = new EditForm();
                form.Edit(node);
                form.ShowDialog();
            }
        }
    }
}
