﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Word;
using System.Diagnostics;



namespace CHM2Word
{
    /// <summary>
    /// 反编译并导出类
    /// </summary>
    public class DecompileAndExportClass
    {

        public event EventHandler<ProcessFileEventArgs> ProcessFileIntoWord;//定义一个事件属性
        private WordClass withEventsField_w = new WordClass();
        /// <summary>
        /// 通过这个类，我们可以转换为word，并且把事件传给调用者
        /// </summary>    
        public WordClass w
        {
            get { return withEventsField_w; }
            set
            {
                if (withEventsField_w != null)//如果不为null，撤销事件
                {
                    withEventsField_w.ProcessFile -= w_ProcessFile;
                }
                withEventsField_w = value;
                if (withEventsField_w != null)//如果不为null，注册
                {
                    withEventsField_w.ProcessFile += w_ProcessFile;
                }
            }
        }

        private string _outPutText;
        public string OutPutText
        {
            get { return this._outPutText; }
            set { _outPutText = value; }
        }


        /// <summary>
        /// 主要函数：反编译、导出
        /// </summary>
        /// <param name="ChmFile">待反编译的CHM文件</param>
        /// <param name="DocFile">word文件名</param>
        /// <remarks>word文件一定不存在</remarks>
        public void DecompileAndExport(string ChmFile, string DocFile)
        {
            try
            {
                Decompile d = new Decompile();//实例化一个反编译类
                string strHHC = d.DecompileChm(ChmFile);//获取hhc文件
                this._outPutText = d.outPut;
                w.AddToWord(strHHC, DocFile);//调用word类的添加到word中方法
            }
            catch (System.Runtime.InteropServices.COMException ex)
            {
                //throw new clsError("Com exception:" + ex.Message, ErrorsOcurred.ComError);
            }

        }
        /// <summary>
        /// 反编译并创建同CHM文件同名的word
        /// </summary>
        /// <param name="ChmFile">name of chm file</param>
        /// <remarks></remarks>
        public void DecompileAndExport(string ChmFile)
        {
            FileInfo f = new FileInfo(ChmFile);
            string DocFile = f.Directory.FullName;
            DocFile = Path.Combine(DocFile, Path.GetFileNameWithoutExtension(ChmFile));
            DocFile += ".doc";
            DecompileAndExport(ChmFile, DocFile);
        }
        /// <summary>
        /// raising the event to the caller
        /// </summary>
        /// <param name="sender">clsWord</param>
        /// <param name="e">the file name, the file number</param>
        private void w_ProcessFile(object sender, ProcessFileEventArgs e)
        {
            if (ProcessFileIntoWord != null)
            {
                ProcessFileIntoWord(this, new ProcessFileEventArgs(e.FileNameProcessed, e.FileNumberProcessed));
            }
        }


    }
}
