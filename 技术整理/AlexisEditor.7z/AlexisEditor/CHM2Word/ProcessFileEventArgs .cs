﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;



namespace CHM2Word
{
    public class ProcessFileEventArgs : EventArgs
    {
        /// <summary>
        /// name of the processed htm file
        /// </summary>
        public string FileNameProcessed;
        /// <summary>
        /// the number of the file processed
        /// </summary>

        public long FileNumberProcessed;

        internal ProcessFileEventArgs(string FileName, long FileNumber)
        {
            FileNameProcessed = FileName;
            FileNumberProcessed = FileNumber;


        }
    }
}
