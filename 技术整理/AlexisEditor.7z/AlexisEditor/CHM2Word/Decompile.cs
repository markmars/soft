﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace CHM2Word
{
    /// <summary>
    /// 反编译类
    /// </summary>
    public class Decompile
    {
        private string ghil = "" + (char)34;

        public string outPut = "";
        /// <summary>
        /// 反编译CHM文件
        /// </summary>
        /// <param name="CHMFile">CHM文件名</param>
        /// <returns>返回hhc文件名</returns>
        /// <remarks>uses the <see cref="DecompileChm"></see></remarks>
        public string DecompileChm(string CHMFile)
        {
            string pathDir = Path.GetDirectoryName(CHMFile);//得到chm文件的绝对路径
            pathDir = Path.Combine(pathDir, Path.GetFileNameWithoutExtension(CHMFile));
            return DecompileChm(CHMFile, ref pathDir);
        }
        /// <summary>
        /// 反编译CHM文件
        /// </summary>
        /// <param name="CHMFile">CHM文件名</param>
        /// <param name="FolderToPut">反编译后的文件存放路径</param>
        /// <returns>返回反编译后的hhc文件名</returns>
        /// <remarks>使用hh.exe反编译</remarks>
        public string DecompileChm(string CHMFile, ref string FolderToPut)
        {
            if ((!System.IO.File.Exists(CHMFile)))
            {
                throw new ArgumentException(CHMFile+"文件不存在");
            }
            if ((!Directory.Exists(FolderToPut)))
            {
                FolderToPut = FolderToPut.Replace(" ", "_");
                Directory.CreateDirectory(FolderToPut);
            }
            DirectoryInfo di = new DirectoryInfo(FolderToPut);
            if ((di.Name.Contains(" ")))
            {
                throw new ArgumentException("反编译的文件夹名不能包含空格");
            }
            string strD = null;
            strD = " -decompile " + di.FullName + " " + CHMFile;//反编译命令
            Console.WriteLine(strD);
            Process p = Process.Start("hh.exe", strD);//调用hh.exe进行反编译
            p.WaitForExit();
            //Process helpCompileProcess = new Process();
            //ProcessStartInfo processStartInfo = new ProcessStartInfo();
            //processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            //processStartInfo.FileName = "hh.exe";  //调入HHC.EXE文件 
            //processStartInfo.Arguments = strD;
            //processStartInfo.UseShellExecute = false;
            //processStartInfo.CreateNoWindow = true;
            //processStartInfo.RedirectStandardOutput = true;
            //helpCompileProcess.StartInfo = processStartInfo;
            //helpCompileProcess.Start();
            //helpCompileProcess.WaitForExit();
            //this.outPut = helpCompileProcess.StandardOutput.ReadToEnd();
            //helpCompileProcess.Close();
            return Directory.GetFiles(FolderToPut, "*.HHC")[0];
        }

    }
}
