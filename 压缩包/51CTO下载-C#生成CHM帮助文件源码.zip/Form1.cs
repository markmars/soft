﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        string startPath = "";

        string hhcFile = @"C:\Program Files\HTML Help Workshop\hhc.exe";//hhc.exe文件位置，windows自带的，一般是这个路径
        public string _defaultTopic = "";//默认的页面
        StreamWriter streamWriter;

        StreamWriter str1;
        StreamWriter str2;
        StreamWriter str3;
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnCreate.Click += new EventHandler(btnCreate_Click);
        }

        void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists("HTML"))  //判断名为HTML文件夹是否存在，不存在的话就创建一个
                {
                    Directory.CreateDirectory("HTML");
                }
                startPath = Application.StartupPath;//起始路径
                OpenHhp(_defaultTopic);//打开hhp文件
                OpenHhc(_defaultTopic);//打开hhc文件
                OpenHhk();//打开hhk文件
                Compile();
                MessageBox.Show("生成成功！");
            }
            catch (Exception ex)
            {
                MessageBox.Show("生成失败！");
                throw;
            }
        }

        #region 自定义方法

        /// <summary>
        /// 创建hhp文件
        /// </summary>
        /// <param name="htmFile">htm文件名</param>
        public void OpenHhp(string htmFile)
        {
            FileStream fs = new FileStream("test.hhp", FileMode.Create); //创建hhp文件
            streamWriter = new System.IO.StreamWriter(fs, System.Text.Encoding.GetEncoding("GB18030"));


            streamWriter.WriteLine("[OPTIONS]");
            streamWriter.WriteLine("Compatibility=1.1 or later");
            streamWriter.WriteLine("Compiled file=" + textBox1.Text.Trim() + ".chm");      //定义生成文件名称
            streamWriter.WriteLine("Contents file=test.hhc");
            streamWriter.WriteLine("Default topic=HTML\\全部对象.htm");
            streamWriter.WriteLine("Display compile progress=Yes");
            streamWriter.WriteLine("Index file=DBO_HELP.hhk");
            streamWriter.WriteLine("Language=0x804 中文(中国)");
            streamWriter.WriteLine("Title=数据库结构展示");
            streamWriter.WriteLine("      ");
            streamWriter.WriteLine("[FILES]");
            streamWriter.WriteLine("全部对象.htm");
            streamWriter.WriteLine("       ");
            streamWriter.WriteLine("[INFOTYPES]");
            streamWriter.WriteLine(htmFile);
            streamWriter.WriteLine();
            streamWriter.Close();
        }

        /// <summary>
        /// 创建hhc文件
        /// </summary>
        /// <param name="htmFile">htm文件名</param>
        private void OpenHhc(string htmFile)
        {
            string sSubDir = "", sDBOType = "", status = "";
            StringBuilder Modes = new StringBuilder();

            string sDir = "\\表";


            FileStream fs = new FileStream(GetContentsHtmlFilename(), FileMode.Create); //创建hhp文件
            streamWriter = new System.IO.StreamWriter(fs, System.Text.Encoding.GetEncoding("GB18030"));
            FileStream fs1 = new FileStream("HTML\\全部对象.htm", FileMode.Create); //
            str1 = new System.IO.StreamWriter(fs1, System.Text.Encoding.GetEncoding("GB18030"));

            streamWriter.WriteLine("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
            streamWriter.WriteLine("<HTML>");
            streamWriter.WriteLine("<HEAD>");
            streamWriter.WriteLine("<meta name=\"GENERATOR\" content=\"Microsoft&reg; HTML Help Workshop 4.1\">");
            streamWriter.WriteLine("<!-- Sitemap 1.0 -->");
            streamWriter.WriteLine("</HEAD>");
            streamWriter.WriteLine("<BODY>");
            streamWriter.WriteLine("<OBJECT type=\"text/site properties\">");
            streamWriter.WriteLine("<param name=\"Window Styles\" value=\"0x800025\">");
            streamWriter.WriteLine("</OBJECT>");


            var v = from m in cx.Models select m;
            DataTable dt = v.ToDataTable(cx);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                #region
                if (i == 0)
                {
                    streamWriter.WriteLine("	<UL>");
                    streamWriter.WriteLine("	    <LI> <OBJECT type=\"text/sitemap\">");
                    streamWriter.WriteLine("	        <param name=\"Name\" value=\"数据库服务器\">");
                    streamWriter.WriteLine("			<param name=\"Local\" value=\"HTML\\全部对象.htm\">");
                    streamWriter.WriteLine("	        <param name=\"ImageNumber\" value=\"13\">");
                    streamWriter.WriteLine("	        </OBJECT>");
                    streamWriter.WriteLine("	<UL>");


                    Modes.Append("<!doctype html public \"-//W3C//DTD HTML 4.0 Transitional//EN\"> \r");
                    Modes.Append("<html>  \r");
                    Modes.Append("      <head>  \r");
                    Modes.Append("       <title>所有模块</title>    \r");
                    Modes.Append("     <meta name=\"Generator\" content=\"EditPlus\">  \r");
                    Modes.Append("       <meta name=\"Author\" content=\"\"> \r");
                    Modes.Append("       <meta name=\"Keywords\" content=\"\">   \r");
                    Modes.Append("       <meta name=\"Description\" content=\"\">  \r");
                    Modes.Append("        </head> \r");
                    Modes.Append("       <body>  \r");
                    Modes.Append("       <div align=\"Center\" style=\"font-size:20px;font-width:bold;;color:green\">全部模块</div>\r");
                    Modes.Append(" <hr color = #FF0000>");
                    Modes.Append("       <div align=\"Center\"><A href=\"" + dt.Rows[i]["mName"].ToString() + ".htm\">" + dt.Rows[i]["mName"].ToString() + "</A></div>\r");


                }
                if (i > 0)
                {
                    Modes.Append("  <br/>");
                    Modes.Append("       <div align=\"Center\"><A href=\"" + dt.Rows[i]["mName"].ToString() + ".htm\">" + dt.Rows[i]["mName"].ToString() + "</A></div>\r");
                }

                streamWriter.WriteLine("		<LI> <OBJECT type=\"text/sitemap\">");
                streamWriter.WriteLine("			<param name=\"Name\" value=\"" + dt.Rows[i]["mName"].ToString() + "\">");
                streamWriter.WriteLine("			<param name=\"Local\" value=\"HTML\\" + dt.Rows[i]["mName"].ToString() + ".htm\">");
                streamWriter.WriteLine("	        <param name=\"ImageNumber\" value=\"21\">");
                //streamWriter.WriteLine("	        <param name=\"ImageNumber\" value=\"1\">");
                streamWriter.WriteLine("			</OBJECT>");
                streamWriter.WriteLine("	    <UL>");

                #endregion

                #region

                StringBuilder tables = new StringBuilder();

                for (int idboT = 1; idboT < 6; idboT++)
                {

                    FileStream fs2 = new FileStream("HTML\\" + dt.Rows[i]["mName"].ToString() + ".htm", FileMode.Create, FileAccess.Write); //
                    str2 = new StreamWriter(fs2, Encoding.Default);

                    switch (idboT)
                    {
                        case 1:
                            sSubDir = "表\\";
                            sDBOType = "表";
                            status = "1";
                            break;
                        case 2:
                            sSubDir = "视图\\";
                            sDBOType = "视图";
                            status = "2";
                            break;
                        case 3:
                            sSubDir = "存储过程\\";
                            sDBOType = "存储过程";
                            status = "3";
                            break;
                        case 4:
                            sSubDir = "函数\\";
                            sDBOType = "函数";
                            status = "5";
                            break;
                        case 5:
                            sSubDir = "触发器\\";
                            sDBOType = "触发器";
                            status = "4";
                            break;
                    }


                    streamWriter.WriteLine("		<LI> <OBJECT type=\"text/sitemap\">");
                    streamWriter.WriteLine("			<param name=\"Name\" value=\"" + sDBOType + "\">");
                    streamWriter.WriteLine("			<param name=\"Local\" value=\"HTML\\" + dt.Rows[i]["mName"].ToString() + sDBOType + ".htm\">");
                    streamWriter.WriteLine("	        <param name=\"ImageNumber\" value=\"1\">");
                    streamWriter.WriteLine("			</OBJECT>");
                    streamWriter.WriteLine("	    <UL>");

                    if (idboT == 1)
                    {
                        tables.Append("<!doctype html public \"-//W3C//DTD HTML 4.0 Transitional//EN\"> \r");
                        tables.Append("<html>  \r");
                        tables.Append("      <head>  \r");
                        tables.Append("       <title>" + dt.Rows[0]["mName"].ToString() + "</title>    \r");
                        tables.Append("     <meta name=\"Generator\" content=\"EditPlus\">  \r");
                        tables.Append("       <meta name=\"Author\" content=\"\"> \r");
                        tables.Append("       <meta name=\"Keywords\" content=\"\">   \r");
                        tables.Append("       <meta name=\"Description\" content=\"\">  \r");
                        tables.Append("        </head> \r");
                        tables.Append("       <body>  \r");
                        tables.Append("       <div align=\"Center\" style=\"font-size:20px;font-width:bold;;color:green\">" + dt.Rows[0]["mName"].ToString() + "</div>\r");
                        tables.Append("       <hr color = #FF0000>");
                        tables.Append("       <div align=\"Center\"><A href=\"" + dt.Rows[0]["mName"].ToString() + sDBOType + ".htm\">" + sDBOType + "</A></div>\r");
                    }
                    else
                    {
                        tables.Append("  <br/>");
                        tables.Append("       <div align=\"Center\"><A href=\"" + dt.Rows[i]["mName"].ToString() + sDBOType + ".htm\">" + sDBOType + "</A></div>\r");
                    }


                    var v1 = from d in cx.Documents join r in cx.Relations on d.dId equals r.rdId where r.rmId == Convert.ToInt32(dt.Rows[i]["mId"]) && d.status == Convert.ToInt32(status) select d;
                    DataTable dt1 = v1.ToDataTable(cx);
                    StreamWriter str;

                    #region
                    StringBuilder itme = new StringBuilder();
                    FileStream fs3 = new FileStream("HTML\\" + dt.Rows[i]["mName"].ToString() + sDBOType + ".htm", FileMode.Create, FileAccess.Write); //
                    str3 = new StreamWriter(fs3, Encoding.Default);
                    int a = 0;
                    foreach (DataRow dr1 in dt1.Rows)
                    {
                        a++;
                        if (a == 1)
                        {
                            itme.Append("<!doctype html public \"-//W3C//DTD HTML 4.0 Transitional//EN\"> \r");
                            itme.Append("<html>  \r");
                            itme.Append("      <head>  \r");
                            itme.Append("       <title>" + sDBOType + "</title>    \r");
                            itme.Append("     <meta name=\"Generator\" content=\"EditPlus\">  \r");
                            itme.Append("       <meta name=\"Author\" content=\"\"> \r");
                            itme.Append("       <meta name=\"Keywords\" content=\"\">   \r");
                            itme.Append("       <meta name=\"Description\" content=\"\">  \r");
                            itme.Append("        </head> \r");
                            itme.Append("       <body>  \r");
                            itme.Append("       <div align=\"Center\" style=\"font-size:20px;font-width:bold;;color:green\">" + sDBOType + "</div>\r");
                            itme.Append("       <hr color = #FF0000>");
                            itme.Append("       <div align=\"Center\"><table width=700 >");//style=\"border-collapse:collapse;\"
                            itme.Append("       <tr bgcolor=\"#97C853\">\r");
                            itme.Append("       <td>id</td>\r");
                            itme.Append("       <td>" + sDBOType + "名</td>\r");
                            itme.Append("       <td>别名</td>\r");
                            itme.Append("       </tr>\r");
                            itme.Append("       <tr >\r");
                            itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dId"].ToString() + "</a></td>\r");
                            itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dName"].ToString() + "</a></td>\r");
                            itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dChName"].ToString() + "</a></td>\r");
                            itme.Append("       </tr>\r");
                            //itme.Append("       <div align=\"Center\"><A href=\"" + dr1["dName"].ToString() + ".htm\">" + dr1["dName"].ToString() + "</A></div>\r");
                        }
                        else
                        {
                            if (a % 2 == 0)
                            {
                                itme.Append("       <tr bgcolor=\"#E3F7DB\">\r");
                                itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dId"].ToString() + "</a></td>\r");
                                itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dName"].ToString() + "</a></td>\r");
                                itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dChName"].ToString() + "</a></td>\r");
                                itme.Append("       </tr>\r");
                            }
                            else
                            {
                                itme.Append("       <tr >\r");
                                itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dId"].ToString() + "</a></td>\r");
                                itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dName"].ToString() + "</a></td>\r");
                                itme.Append("       <td><a href=\"" + dr1["dName"].ToString() + ".htm\" >" + dr1["dChName"].ToString() + "</a></td>\r");
                                itme.Append("       </tr>\r");
                            }
                            //itme.Append("  <br/>");
                            //itme.Append("       <div align=\"Center\"><A href=\"" + dr1["dName"].ToString() + ".htm\">" + dr1["dName"].ToString() + "</A></div>\r");
                        }

                        StringBuilder sHead = new StringBuilder();

                        FileStream f = new FileStream(@"HTML\" + dr1["dName"].ToString() + ".htm", FileMode.Create, FileAccess.Write); //创建hhp文件

                        str = new StreamWriter(f, Encoding.Default);

                        sHead.Append("<!doctype html public \"-//W3C//DTD HTML 4.0 Transitional//EN\"> \r");
                        sHead.Append("<html>  \r");
                        sHead.Append("      <head>  \r");
                        sHead.Append("       <title>" + dr1["dName"].ToString() + "</title>    \r");
                        sHead.Append("     <meta name=\"Generator\" content=\"EditPlus\">  \r");
                        sHead.Append("       <meta name=\"Author\" content=\"\"> \r");
                        sHead.Append("       <meta name=\"Keywords\" content=\"\">   \r");
                        sHead.Append("       <meta name=\"Description\" content=\"\">  \r");
                        sHead.Append("        </head> \r");
                        sHead.Append("       <body>  \r");
                        //sHead.Append("       " + IntToStr(iCount) + " ." + sTemp + "(" + sDBOType + +") \r");
                        sHead.Append("       <hr color = #FF0000> \r");
                        sHead.Append("       <table border=\"1\" cellspacing=0 cellpadding=0 style=\"border-collapse:collapse;");
                        sHead.Append("        border:none;mso-border-alt:solid windowtext .5pt;mso-padding-alt:0cm 5.4pt 0cm 5.4pt\" width =\"100%\"> \r");
                        sHead.Append("        <tr> \r");
                        sHead.Append("    <td width=\"17%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    bgcolor=#c0c0c0><B>对象名</B></td> \r");
                        sHead.Append("    <td width=\"12%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    colspan=\"3\"><b>" + dr1["dName"].ToString() + "</b></td> \r");
                        sHead.Append("    <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    bgcolor=#c0c0c0 ><B>模块名</B></td> \r");
                        sHead.Append("    <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    colspan=\"2\">" + dt.Rows[i]["mName"].ToString() + "</td> \r");
                        sHead.Append(" </tr> \r");
                        sHead.Append("        <tr> \r");
                        sHead.Append("   <td width=\"17%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("   bgcolor=#c0c0c0><B>创建时间</B></td> \r");
                        sHead.Append("   <td width=\"12%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    colspan=\"3\"><b>" + dr1["dCreTime"].ToString() + "</b></td> \r");
                        sHead.Append("    <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    bgcolor=#c0c0c0 ><B>" + DBNull.Value + "个数</B></td> \r");
                        sHead.Append("    <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    colspan=\"2\">" + dr1["dFieidNum"].ToString() + "</td> \r");
                        sHead.Append(" </tr> \r");
                        sHead.Append(" <tr>   \r");
                        sHead.Append(" <td width=\"17%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("  bgcolor=#c0c0c0><B>对象别名</B></td> \r");
                        sHead.Append("  <td width=\"12%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("  colspan=\"6\" >" + dr1["dChName"].ToString() + "</td> \r");
                        sHead.Append(" </tr> \r");
                        sHead.Append("  <tr>   \r");
                        sHead.Append("     <td width=\"17%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    height=\"39\" bgcolor=#c0c0c0><B>功能描述</B></td> \r");
                        sHead.Append("     <td width=\"12%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("     colspan=\"6\" >" + dr1["dFunctionDesc"].ToString() + "</td> \r");
                        sHead.Append("  </tr> \r");
                        sHead.Append(" <tr>   \r");
                        sHead.Append("   <td width=\"17%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("   height=\"39\" bgcolor=#c0c0c0><B>相关对象</B></td> \r");
                        sHead.Append("   <td width=\"12%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    colspan=\"6\" >" + DBNull.Value + "</td> \r");
                        sHead.Append(" </tr> \r");
                        sHead.Append(" <tr> \r");
                        sHead.Append("    <td width=\"17%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("   bgcolor=#c0c0c0><b>" + DBNull.Value + "名</b></td> \r");
                        sHead.Append("   <td width=\"12%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("   bgcolor=#c0c0c0><b>数据类型</b></td> \r");
                        sHead.Append("  <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    bgcolor=#c0c0c0><b>长度</b></td> \r");
                        sHead.Append("  <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    bgcolor=#c0c0c0><b>空值否</b></td> \r");
                        sHead.Append("    <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("     bgcolor=#c0c0c0><b>默认値</b></td> \r");
                        //sHead.Append("   <td width=\"30%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        //sHead.Append("    bgcolor=#c0c0c0><b>描述</b></td> \r");
                        sHead.Append("    <td width=\"48%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                        sHead.Append("    bgcolor=#c0c0c0><b>备注</b></td> \r");
                        sHead.Append(" </tr> \r");





                        //string sql2 = "SELECT dcId,dcName,dcType,dcLength,CASE WHEN dcDefault=0 THEN NULL ELSE dcDefault END AS dcDefault,dcRemark,ddcId,CASE WHEN dcIsNull=1 THEN '√' ELSE '×'END AS dcIsNull FROM DocumentChilds WHERE ddcId='" + dr1["dId"].ToString() + "'";
                        //DataTable dt2 = DBHelper.getDatatable(sql2);
                        var v2 = from dc in cx.DocumentChilds where dc.ddcId==Convert .ToInt32(dr1["dId"]) select dc;
                        DataTable dt2 = v2.ToDataTable(cx);

                        foreach (DataRow dr2 in dt2.Rows)
                        {
                            sHead.Append(" <tr> \r");
                            sHead.Append("	<td width=\"17%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                            sHead.Append(">" + dr2["dcName"].ToString() + "</td> \r");
                            sHead.Append("  <td width=\"12%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\"");
                            sHead.Append("  ><center>" + dr2["dcType"].ToString() + "</center></td> \r");
                            sHead.Append("  <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                            sHead.Append(" ><p align=\"right\">" + dr2["dcLength"].ToString() + "</td> \r");
                            sHead.Append("  <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                            sHead.Append("><center>" + dr2["dcIsNull"].ToString() + "</center></td> \r");
                            sHead.Append("  <td width=\"8%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                            sHead.Append(" >" + dr2["dcDefault"].ToString() + "</td> \r");
                            //sHead.Append(" <td width=\"30%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                            //sHead.Append(">" +dr2["length"].ToString()+"</td> \r");
                            sHead.Append(" <td width=\"48%\"  style=\"border:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt\" ");
                            sHead.Append("> " + dr2["dcRemark"].ToString() + "</td> \r");
                            sHead.Append("</tr> \r ");
                        }

                        //QAPub->Next();
                        //sTabName = QAPub->FieldByName("di.DBO_NAME")->AsString;
                        //if (sTemp != sTabName || QAPub->Eof)
                        //{
                        //iCount += 1;
                        sHead.Append(" </table><hr color = #FF0000></body>\r</html> ");
                        str.Write(sHead.ToString());

                        str.Close();



                        //strLst->Clear();
                        //strLst->Text = sBody;
                        //strLst->SaveToFile(sDir + "\\" + sSubDir + sTemp + ".htm");
                        //strLst_hhc->Add("		    <LI> <OBJECT type=\"text/sitemap\">");
                        //strLst_hhc->Add("			    <param name=\"Name\" value=\"" + IntToStr(iCount) + " ." + sTemp + "\">");
                        //strLst_hhc->Add("			    <param name=\"Local\" value=\"" + sSubDir + sTemp + ".htm\">");
                        //strLst_hhc->Add("			    </OBJECT>");
                        streamWriter.WriteLine(sDir + "\\" + dr1["dName"].ToString() + ".htm");
                        streamWriter.WriteLine("		    <LI> <OBJECT type=\"text/sitemap\">");
                        streamWriter.WriteLine("			    <param name=\"Name\" value=\"" + dr1["dName"].ToString() + "\">");
                        streamWriter.WriteLine("			    <param name=\"Local\" value=\"HTML\\" + dr1["dName"].ToString() + ".htm\">");
                        streamWriter.WriteLine("			    </OBJECT>");
                        //}
                    }
                    #endregion
                    itme.Append(" </table></div></BODY>\r</HTML>");
                    str3.Write(itme.ToString());
                    str3.Close();
                    tables.Append(" </BODY>\r</HTML>");
                    str2.Write(tables.ToString());
                    str2.Close();
                    streamWriter.WriteLine(" </UL>");
                }
                #endregion
                streamWriter.WriteLine("</UL>");
                Modes.Append(" </BODY>\r</HTML>");

            }
            streamWriter.WriteLine("</UL>\r</UL>\r</BODY>\r</HTML>");


            streamWriter.WriteLine();
            streamWriter.Close();
            str1.WriteLine(Modes);
            str1.Close();



        }

        private void OpenHhk()
        {
            FileStream fs = new FileStream(startPath + @"\test.hhk", FileMode.Create); //创建hhp文件
            //streamWriter = new System.IO.StreamWriter(fs, System.Text.Encoding.GetEncoding("GB18030"));
            streamWriter = new System.IO.StreamWriter(fs, System.Text.Encoding.GetEncoding("UTF-8"));
            streamWriter.WriteLine("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
            streamWriter.WriteLine("<HTML>");
            streamWriter.WriteLine("<HEAD>");
            streamWriter.WriteLine("<meta name=\"GENERATOR\" content=\"Microsoft&reg; HTML Help Workshop 4.1\">");
            streamWriter.WriteLine("<!-- Sitemap 1.0 -->");
            streamWriter.WriteLine("</HEAD>");
            streamWriter.WriteLine("<BODY>");
            streamWriter.WriteLine("<UL>");
            var v3 = from dc in cx.Documents orderby dc.dName select dc;
            DataTable dt1 = v3.ToDataTable(cx);
            foreach (DataRow dr in dt1.Rows)
            {
                streamWriter.WriteLine("	<LI> <OBJECT type=\"text/sitemap\">");
                streamWriter.WriteLine("		<param name=\"Name\" value=\"" + dr["dName"].ToString() + "\">");
                streamWriter.WriteLine("<param name=\"Local\" value=\"" + dr["dName"].ToString() + ".htm\">");
                streamWriter.WriteLine("</OBJECT>");
            }
            streamWriter.WriteLine("</UL>");
            streamWriter.WriteLine("</BODY>");
            streamWriter.WriteLine("</HTML>");
            streamWriter.WriteLine();
            streamWriter.Close();
        }

        /// <summary>
        /// 获取hhp文件路径
        /// </summary>
        /// <returns></returns>
        private string GetPathToProjectFile()
        {
            return startPath + @"\test.hhp";
        }

        /// <summary>
        /// 获取含有列表的hhc文件
        /// </summary>
        /// <returns></returns>
        private string GetContentsHtmlFilename()
        {
            return "test.hhc";
        }

        /// <summary>
        /// 设置编译后的文件名
        /// </summary>
        /// <returns></returns>
        private string GetCompiledHtmlFilename()
        {
            return "test.chm";
        }

        private bool Compile()
        {
            string _chmFile = startPath + @"\test.chm";//chm文件存储路径
            Process helpCompileProcess = new Process();  //创建新的进程，用Process启动HHC.EXE来Compile一个CHM文件
            try
            {
                //判断文件是否存在并不被占用
                try
                {
                    string path = _chmFile;  //chm生成路径
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("文件被打开！");
                }

                ProcessStartInfo processStartInfo = new ProcessStartInfo();
                processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                processStartInfo.FileName = hhcFile;  //调入HHC.EXE文件 
                processStartInfo.Arguments = "\"" + GetPathToProjectFile() + "\"";//获取空的HHP文件
                processStartInfo.UseShellExecute = false;
                helpCompileProcess.StartInfo = processStartInfo;
                helpCompileProcess.Start();
                helpCompileProcess.WaitForExit(); //组件无限期地等待关联进程退出

                if (helpCompileProcess.ExitCode == 0)
                {
                    MessageBox.Show(new Exception().Message);
                    return false;
                }
            }
            finally
            {
                helpCompileProcess.Close();
            }
            return true;
        }
        #endregion
    }
}
