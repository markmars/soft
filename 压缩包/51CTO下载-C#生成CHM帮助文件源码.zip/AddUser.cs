﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class AddUser : Form
    {
        string uId = "";
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public AddUser()
        {
            InitializeComponent();
        }
        public AddUser(string Id)
        {
            InitializeComponent();
            uId = Id;
        }

        private void AddUser_Load(object sender, EventArgs e)
        {
            show();

            btnExit.Click += new EventHandler(btnExit_Click);
            btnOk.Click += new EventHandler(btnOk_Click);
        }

        void btnOk_Click(object sender, EventArgs e)
        {
            if (tbUserName.Text == "")
            {
                MessageBox.Show("用户名不能为空！");
                return;
            }
            if (tbPwd.Text == "")
            {
                MessageBox.Show("密码不能为空！");
                return;
            }

            string sex = "";
            if (rdbSex.Checked && !rdbWoman.Checked)
            {

                sex = "男";
            }
            else if (!rdbSex.Checked && rdbWoman.Checked)
            {
                sex = "女";
            }

            int status = ckbIsAble.Checked == true ? 0 : 1;
            int role = 0;
            try
            {
                if (uId == "")
                {
                    User users = new User();
                    users.uName = tbUserName.Text.Trim();
                    users.uPwd = tbPwd.Text.Trim();
                    users.uSex = sex;
                    users.uRole = role;
                    users.status = status;
                    cx.Users.InsertOnSubmit(users);
                    cx.SubmitChanges();
                }
                else
                {
                    //sql = "UPDATE Users SET uName=@Name,uPwd=@Pwd,uSex=@Sex,uRole=@Role,status=@Status WHERE uId=" + uId + "";
                    User users = cx.Users.SingleOrDefault(User => User.uId == Convert.ToInt32(uId));
                    users.uName = tbUserName.Text.Trim();
                    users.uPwd = tbPwd.Text.Trim();
                    users.uSex = sex;
                    users.uRole = role;
                    users.status = status;
                    cx.SubmitChanges();
                }
                MessageBox.Show("保存成功！");
            }
            catch (Exception)
            {
                MessageBox.Show("保存失败！");
                throw;
            }
           
        }

        void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region 自定义

        private void show()
        {
            if (uId != "")
            {
                var v = from u in cx.Users where u.uId == Convert.ToInt32(uId) select u;
                User users = v.First();

                tbUserName.Text = users.uName.ToString();
                if (users.uSex.ToString() == "男")
                {
                    rdbSex.Checked = true;
                }
                else
                {
                    rdbWoman.Checked = true;
                }
                ckbIsAble.Checked = users.status.ToString() == "0" ? true : false;
                tbPwd.Text = users.uPwd.ToString();

            }
        }

        #endregion
    }
}
