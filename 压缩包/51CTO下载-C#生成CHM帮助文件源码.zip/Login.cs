﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Login : Form
    {
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public Login()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Login_Load(object sender, EventArgs e)
        {
            btnEixt.Click += new EventHandler(btnEixt_Click);
            btnLogin.Click += new EventHandler(btnLogin_Click);
        }
        /// <summary>
        /// 登陆
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnLogin_Click(object sender, EventArgs e)
        {
            if (Logins(tbUser.Text.Trim()))
            {
                Global.UserName = tbUser.Text.Trim();  //设置全局用户

                Main m = new Main();
                m.Show();
            }
            else
            {
                MessageBox.Show("你的用户名或密码有误！请重新输入");
            }
        }
        /// <summary>
        /// 关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnEixt_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        #region 自定义方法
        //登陆方法
        private bool Logins(string name)
        {
            var userMes = from users in cx.Users where users.uName == name select users;
            User u = userMes.First();
           
            string pwd = "";
          
            if (u!=null)
            {
                pwd = u.uPwd;
                Global.UserRole = u.uRole.ToString();
            }
            if (pwd.Equals(tbPwd.Text.Trim()))
                return true;
            else
                return false;
        }
        #endregion
     
    }
}
