﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Details : Form
    {
        DataTable dts = null;
        DataTable dt = null;
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public Details()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Detail_Load(object sender, EventArgs e)
        {
            ShowTree();
            id.Focus();
            tbChName.ReadOnly = true;
            tbFuncDesc.ReadOnly = true;

            //事件
            btnExit.Click += new EventHandler(btnExit_Click);
            btnOk.Click += new EventHandler(btnOk_Click);
            treeView1.NodeMouseDoubleClick += new TreeNodeMouseClickEventHandler(treeView1_NodeMouseDoubleClick);
              
        }
        /// <summary>
        /// 树鼠标双击事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void treeView1_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            //string sql = "SELECT * FROM Documents WHERE dId='" + e.Node.Tag + "'";
            //dt = DBHelper.getDatatable(sql);
            int ids=Convert.ToInt32(e.Node.Tag);
            var v3 = from d in cx.Documents where d.dId ==ids select d;
            dt = v3.ToDataTable(cx);


            tbChName.ReadOnly = true;
            tbFuncDesc.ReadOnly = true;
            tbChName.Text = "";
            tbFuncDesc.Text = "";

            dataGridView1.DataSource = null;

            if (dt.Rows.Count > 0)
            {
                tbChName.Focus();
                tbChName.ReadOnly = false;
                tbFuncDesc.ReadOnly = false;


                tbDocuName.Text = dt.Rows[0]["dName"].ToString();
                tbModelName.Text = e.Node.Parent.Parent.Text;
                tbCreTime.Text = dt.Rows[0]["dCreTime"].ToString();
                tbFieidNum.Text = dt.Rows[0]["dFieidNum"].ToString();
                id.Text = dt.Rows[0]["dId"].ToString();
                tbChName.Text = dt.Rows[0]["dChName"].ToString();
                tbFuncDesc.Text = dt.Rows[0]["dFunctionDesc"].ToString();


                //string sql1 = "SELECT dcId,dcName,dcType,dcLength,CASE WHEN dcIsNull=1 THEN '√' ELSE '×'END AS dcIsNull,CASE WHEN dcDefault=0 THEN NULL ELSE dcDefault END AS dcDefault,dcRemark,ddcId FROM DocumentChilds WHERE ddcId='" + e.Node.Tag + "' ORDER BY dcName";
                //dts = DBHelper.getDatatable(sql1);
             
                
                var v4 = from dc in cx.DocumentChilds where dc.ddcId == Convert.ToInt32(e.Node.Tag) select new 
                {   
                    dc.dcId,
                    dc.dcName,
                    dc.dcType,
                    dc.dcLength,
                    dc.dcIsNull,
                    dc.dcDefault,
                    dc.dcRemark,
                    dc.ddcId
                };
                dts = v4.ToDataTable(cx);
                if (dts.Rows.Count > 0)
                {
                    this.dataGridView1.AutoGenerateColumns = false;//规定不自动生成列
                    dataGridView1.DataSource = dts;
                }
            }
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnOk_Click(object sender, EventArgs e)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                string chName = tbChName.Text.Trim();
                string descript = tbFuncDesc.Text.Trim();

                //SqlConnection conn = DBHelper.Connection;
                //SqlTransaction transaction = conn.BeginTransaction();
                cx.Connection.Open();
                cx.Transaction = cx.Connection.BeginTransaction(System.Data.IsolationLevel.Serializable);  //此处用事务
                try
                {

                    //string sql = "UPDATE Documents SET dChName=@ChName,dFunctionDesc=@Desc WHERE dId=" + id.Text.ToString().Trim() + "";
                    //SqlParameter[] par = new SqlParameter[] { new SqlParameter("@ChName", tbChName.Text.ToString()), new SqlParameter("@Desc", tbFuncDesc.Text.ToString()) };
                    //SqlCommand cmd = new SqlCommand(sql, conn);
                    //cmd.Parameters.AddRange(par);
                    //cmd.Transaction = transaction;
                    //cmd.ExecuteNonQuery();
                    Document upDocument = cx.Documents.SingleOrDefault(Document => Document.dId == Convert.ToInt32(id.Text));
                    upDocument.dChName = tbChName.Text.ToString();
                    upDocument.dFunctionDesc = tbFuncDesc.Text.ToString();
                    cx.SubmitChanges();

                    foreach (DataRow dr in dts.Rows)
                    {
                        DocumentChild upDocumentChild = cx.DocumentChilds.SingleOrDefault(DocumentChild => DocumentChild.dcId == Convert.ToInt32(dr["dcId"]));
                        upDocumentChild.dcRemark = dr["dcRemark"].ToString();
                        cx.SubmitChanges();
                        //string sql1 = "UPDATE DocumentChilds SET dcRemark=@Remark WHERE dcId=" + dr["dcId"].ToString() + "";
                        //SqlParameter[] par1 = new SqlParameter[] { new SqlParameter("@Remark", dr["dcRemark"].ToString()), new SqlParameter("@Desc", tbFuncDesc.Text.ToString()) };
                        //SqlCommand cmd1 = new SqlCommand(sql1, conn);
                        //cmd1.Parameters.AddRange(par1);
                        //cmd1.Transaction = transaction;
                        //cmd1.ExecuteNonQuery();
                    }
                    cx.Transaction.Commit();
                    MessageBox.Show("保存成功！");
                }
                catch (Exception)
                {
                    cx.Transaction.Rollback();
                    MessageBox.Show("保存失败！");
                    throw;
                }
                finally
                {
                    cx.Transaction = null;
                    cx.Connection.Close();
                }
            }
            else
            {
                MessageBox.Show("当前没有可保存的内容，请输入内容！");
            }
        }
        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// 窗体按下事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Details_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                e.Handled = true;
                SendKeys.Send("{TAB}");
            }

            if (tbFuncDesc.Focused)
            {
                dataGridView1.Focus();
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[5];
            }
        }

        #region 自定义方法

        private void ShowTree()
        {
            treeView1.TopNode.Nodes.Clear();

            var v = from m in cx.Models select m;
            DataTable dt = v.ToDataTable(cx);
            foreach (DataRow dr in dt.Rows)
            {
                TreeNode dn = new TreeNode();
                dn.Text = dr["mName"].ToString();
                dn.Name = dr["mId"].ToString();
                treeView1.TopNode.Nodes.Add(dn);
                dn.Nodes.Clear();
               

                TreeNode tn1 = new TreeNode();
                tn1.Text = "表";
                tn1.Name = "table";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes.Add(tn1);
                TreeNode tn2 = new TreeNode();
                tn2.Text = "视图";
                tn2.Name = "view";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes.Add(tn2);
                TreeNode tn3 = new TreeNode();
                tn3.Text = "存储过程";
                tn3.Name = "proceduer";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes.Add(tn3);
                TreeNode tn4 = new TreeNode();
                tn4.Text = "触发器";
                tn4.Name = "trigger";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes.Add(tn4);
                TreeNode tn5 = new TreeNode();
                tn5.Text = "函数";
                tn5.Name = "function";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes.Add(tn5);

                //string sql2 = "SELECT dId,dName,status FROM Relations r Right JOIN Documents d ON r.rdId=d.dId WHERE rmId=" + dr["mId"].ToString() + " ORDER BY dName";
                //DataTable dt1 = DBHelper.getDatatable(sql2);
                var v1 = from d in cx.Documents join r in cx.Relations on d.dId equals r.rdId where r.rmId == Convert.ToInt32(dr["mId"]) orderby d.dName select d;
                DataTable dt1 = v1.ToDataTable(cx);
                foreach (DataRow dr1 in dt1.Rows)
                {
                    TreeNode tns = new TreeNode();
                    string node = "";
                    switch (dr1["status"].ToString())
                    {
                        case "1":
                            node = "table";
                            break;
                        case "2":
                            node = "view";
                            break;
                        case "3":
                            node = "proceduer";
                            break;
                        case "4":
                            node = "trigger";
                            break;
                        case "5":
                            node = "function";
                            break;
                        default:
                            break;
                    }

                    tns.Text = dr1["dName"].ToString();
                    tns.Name = dr1["dName"].ToString();
                    tns.Tag = dr1["dId"].ToString();
                    treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes[node].Nodes.Add(tns);
                }
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["table"].Text += "(" + treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["table"].Nodes.Count + ")";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["view"].Text += "(" + treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["view"].Nodes.Count + ")";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["proceduer"].Text += "(" + treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["proceduer"].Nodes.Count + ")";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["trigger"].Text += "(" + treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["trigger"].Nodes.Count + ")";
                treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["function"].Text += "(" + treeView1.TopNode.Nodes[dr["mId"].ToString()].Nodes["function"].Nodes.Count + ")";
            }

            TreeNode dns = new TreeNode();
            dns.Text = "未定义模块";
            dns.Name = "NotDefine";
            treeView1.TopNode.Nodes.Add(dns);
            dns.Nodes.Clear();

            TreeNode tns1 = new TreeNode();
            tns1.Text = "表";
            tns1.Name = "table";
            treeView1.TopNode.Nodes["NotDefine"].Nodes.Add(tns1);
            TreeNode tns2 = new TreeNode();
            tns2.Text = "视图";
            tns2.Name = "view";
            treeView1.TopNode.Nodes["NotDefine"].Nodes.Add(tns2);
            TreeNode tns3 = new TreeNode();
            tns3.Text = "存储过程";
            tns3.Name = "proceduer";
            treeView1.TopNode.Nodes["NotDefine"].Nodes.Add(tns3);
            TreeNode tns4 = new TreeNode();
            tns4.Text = "触发器";
            tns4.Name = "trigger";
            treeView1.TopNode.Nodes["NotDefine"].Nodes.Add(tns4);
            TreeNode tns5 = new TreeNode();
            tns5.Text = "函数";
            tns5.Name = "function";
            treeView1.TopNode.Nodes["NotDefine"].Nodes.Add(tns5);

            //string sql3 = "SELECT dId,dName,status FROM Relations r RIGHT JOIN Documents d ON r.rdId=d.dId WHERE NOT EXISTS(SELECT 1 FROM Documents a WHERE r.rdId=a.dId) ORDER BY dName";
            //DataTable dt2 = DBHelper.getDatatable(sql3);
            var v2 = from d in cx.Documents join r in cx.Relations on d.dId equals r.rdId into Document orderby d.dName select d;
            DataTable dt2 = v2.ToDataTable(cx);
            foreach (DataRow dr1 in dt2.Rows)
            {
                TreeNode tns = new TreeNode();
                string node = "";
                switch (dr1["status"].ToString())
                {
                    case "1":
                        node = "table";
                        break;
                    case "2":
                        node = "view";
                        break;
                    case "3":
                        node = "proceduer";
                        break;
                    case "4":
                        node = "trigger";
                        break;
                    case "5":
                        node = "function";
                        break;
                    default:
                        break;
                }

                tns.Text = dr1["dName"].ToString();
                tns.Name = dr1["dName"].ToString();
                tns.Tag = dr1["dId"].ToString();
                treeView1.TopNode.Nodes["NotDefine"].Nodes[node].Nodes.Add(tns);
            }
            treeView1.TopNode.Nodes["NotDefine"].Nodes["table"].Text += "(" + treeView1.TopNode.Nodes["NotDefine"].Nodes["table"].Nodes.Count + ")";
            treeView1.TopNode.Nodes["NotDefine"].Nodes["view"].Text += "(" + treeView1.TopNode.Nodes["NotDefine"].Nodes["view"].Nodes.Count + ")";
            treeView1.TopNode.Nodes["NotDefine"].Nodes["proceduer"].Text += "(" + treeView1.TopNode.Nodes["NotDefine"].Nodes["proceduer"].Nodes.Count + ")";
            treeView1.TopNode.Nodes["NotDefine"].Nodes["trigger"].Text += "(" + treeView1.TopNode.Nodes["NotDefine"].Nodes["trigger"].Nodes.Count + ")";
            treeView1.TopNode.Nodes["NotDefine"].Nodes["function"].Text += "(" + treeView1.TopNode.Nodes["NotDefine"].Nodes["function"].Nodes.Count + ")";


        }
        #endregion

        
    }
}
