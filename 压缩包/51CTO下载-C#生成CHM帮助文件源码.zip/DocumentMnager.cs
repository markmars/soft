﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class DocumentMnager : Form
    {
        int Id = 0;
        string Name = "";
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public DocumentMnager()
        {
            InitializeComponent();
        }

        public DocumentMnager(int id,string name)
        {
            InitializeComponent();
            Id = id;
            Name = name;
        }
        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DocumentMnager_Load(object sender, EventArgs e)
        {

            lblModelName.Text = Name;

            DataGridViewButtonColumn dbc = dataGridView1.Columns["Delete"] as DataGridViewButtonColumn;
            dbc.UseColumnTextForButtonValue = true;
            dbc.Text = "删除";

            saveDocument();
            datatable();

            //事件
            btnExit.Click += new EventHandler(btnExit_Click);
            btnOK.Click += new EventHandler(btnOK_Click);
            treeView1.NodeMouseDoubleClick += new TreeNodeMouseClickEventHandler(treeView1_NodeMouseDoubleClick);
            dataGridView1.CellContentClick += new DataGridViewCellEventHandler(dataGridView1_CellContentClick);
        }
        /// <summary>
        /// 狗日的view单元格
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int k = e.ColumnIndex;
            if (k == 4)
            {
                string a = "";
                switch (dataGridView1.CurrentRow.Cells["docuType"].Value.ToString())
                {
                    case "表":
                        a = "table";
                        break;
                    case "视图":
                        a = "view";
                        break;
                    case "存储过程":
                        a = "proceduer";
                        break;
                    case "触发器":
                        a = "trigger";
                        break;
                    case "函数":
                        a = "function";
                        break;
                    default:
                        break;
                }
                treeView1.Nodes["data"].Nodes[a].Nodes[dataGridView1.CurrentRow.Cells["dName"].Value.ToString()].ForeColor = Color.Black;

                dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);


            }
        }
        /// <summary>
        /// 树节点鼠标双击
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void treeView1_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.ForeColor != Color.Gray)
            {


                string name = e.Node.Name;
                string id = e.Node.Tag.ToString();
                string a = "";
                switch (e.Node.Parent.Name)
                {
                    case "table":
                        a = "表";
                        break;
                    case "view":
                        a = "视图";
                        break;
                    case "proceduer":
                        a = "存储过程";
                        break;
                    case "trigger":
                        a = "触发器";
                        break;
                    case "function":
                        a = "函数";
                        break;
                    default:
                        break;
                }

                e.Node.ForeColor = Color.Gray;


                dataGridView1.Rows.Add(1);
                dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells["dId"].Value = id;
                dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells["dName"].Value = name;
                dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells["No"].Value = dataGridView1.Rows.Count - 1;
                dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells["docuType"].Value = a;


            }
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnOK_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                cx.Connection.Open();
                cx.Transaction = cx.Connection.BeginTransaction(System.Data.IsolationLevel.Serializable);  //此处用事务
                try
                {
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        int dId = Convert.ToInt32(dataGridView1.Rows[i].Cells["dId"].Value);
                        int mId = Id;

                        Relation relations = new Relation();
                        relations.rmId = mId;
                        relations.rdId = dId;
                        cx.Relations.InsertOnSubmit(relations);
                        cx.SubmitChanges();
                    }
                    cx.Transaction.Commit();
                    MessageBox.Show("保存成功！");
                }
                catch (Exception)
                {

                    cx.Transaction.Rollback();
                    throw;
                }
                finally
                {
                    cx.Transaction = null;
                    cx.Connection.Close();
                }
            }
            else
            {
                MessageBox.Show("当前没有要保存的内容，请输入内容！");
            }
        }
        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        #region 自定义方法
        /// <summary>
        /// 显示对象
        /// </summary>
        private void datatable()
        {
            List<string> list = new List<string>();

            treeView1.TopNode.Nodes["table"].Nodes.Clear();
            treeView1.TopNode.Nodes["view"].Nodes.Clear();
            treeView1.TopNode.Nodes["proceduer"].Nodes.Clear();
            treeView1.TopNode.Nodes["trigger"].Nodes.Clear();
            treeView1.TopNode.Nodes["function"].Nodes.Clear();



            var v = from r in cx.Relations select r.rdId;
            foreach (var item in v)
            {
                list.Add(item.ToString());
            }

            var v1 = from d in cx.Documents orderby d.dName select d;
            DataTable dt = v1.ToDataTable(cx);
            foreach (DataRow dr in dt.Rows)
            {
                TreeNode tn = new TreeNode();
                string node = "";
                switch (dr["status"].ToString())
                {
                    case "1":
                        node = "table";
                        break;
                    case "2":
                        node = "view";
                        break;
                    case "3":
                        node = "proceduer";
                        break;
                    case "4":
                        node = "trigger";
                        break;
                    case "5":
                        node = "function";
                        break;
                    default:
                        break;
                }

                tn.Text = dr["dName"].ToString();
                tn.Name = dr["dName"].ToString();
                tn.Tag = dr["dId"].ToString();
                treeView1.TopNode.Nodes[node].Nodes.Add(tn);
                if (list != null)
                {

                    if (list.Contains(dr["dId"].ToString()))
                    {
                        treeView1.TopNode.Nodes[node].Nodes[dr["dName"].ToString()].ForeColor = Color.Gray;
                    }
                }

            }

        }

        /// <summary>
        /// 获取sql表信息
        /// </summary>
        /// <returns></returns>
        private DataTable getTable()
        {
            string sql = "select name from ht0518.dbo.sysobjects where type='U' and status>=0 order by name ";
            return DBHelper1.getDatatable(sql);
        }
        /// <summary>
        /// 获取sql试图信息
        /// </summary>
        /// <returns></returns>
        private DataTable getView()
        {
            string sql = "select name from ht0518.dbo.sysobjects where type='V' and status>=0 order by name ";
            return DBHelper1.getDatatable(sql);
        }
        /// <summary>
        /// 获取sql存储过程信息
        /// </summary>
        /// <returns></returns>
        private DataTable getProceduer()
        {
            string sql = "select name from ht0518.dbo.sysobjects where type='P' and status>=0 order by name ";
            return DBHelper1.getDatatable(sql);
        }
        /// <summary>
        /// 获取sql触发器信息
        /// </summary>
        /// <returns></returns>
        private DataTable getTrigger()
        {
            string sql = "select name from ht0518.dbo.sysobjects where type='TR' and status>=0 order by name ";
            return DBHelper1.getDatatable(sql);
        }
        /// <summary>
        /// 获取sql函数信息
        /// </summary>
        /// <returns></returns>
        private DataTable getFunction()
        {
            string sql = "select name from ht0518.dbo.sysobjects where type='FN' and status>=0 order by name ";
            return DBHelper1.getDatatable(sql);
        }
        /// <summary>
        /// 加载对象
        /// </summary>
        private void saveDocument()
        {
            DataTable dt = new DataTable();


            var v2 = from d in cx.Documents select d.dName;
            DataTable dts=v2.ToDataTable(cx);

            if (dts.Rows.Count == 0)
            {
                MessageBox.Show("第一次使用需要加载数据，请耐心等待！");

                StringBuilder sqls = new StringBuilder();

                sqls.Append("select name as dname,crdate,info,1 as status from " + DBHelper1.FromDataBase + ".dbo.sysobjects where type='U' and status>=0  union all ");
                sqls.Append("select name as dname,crdate,info,2 as status from " + DBHelper1.FromDataBase + ".dbo.sysobjects where type='V' and status>=0  union all ");
                sqls.Append("select name as dname,crdate,info,3 as status from " + DBHelper1.FromDataBase + ".dbo.sysobjects where type='P' and status>=0  union all ");
                sqls.Append("select name as dname,crdate,info,4 as status from " + DBHelper1.FromDataBase + ".dbo.sysobjects where type='TR' and status>=0 union all ");
                sqls.Append("select name as dname,crdate,info,5 as status from " + DBHelper1.FromDataBase + ".dbo.sysobjects where type='FN' and status>=0   ");
                DataTable dt1 = DBHelper1.getDatatable(sqls.ToString());


                SqlConnection conn1 = DBHelper1.Connection;
                cx.Connection.Open();
                cx.Transaction = cx.Connection.BeginTransaction(System.Data.IsolationLevel.Serializable);  //此处用事务
                try
                {
                   

                    foreach (DataRow dr in dt1.Rows)
                    {

                        Document documents = new Document();
                        documents.dName = dr["dname"].ToString();
                        documents.dCreTime = Convert.ToDateTime(dr["crdate"]);
                        documents.dFieidNum = Convert.ToInt32(dr["info"]);
                        documents.status = Convert.ToInt32(dr["status"]);
                        cx.Documents.InsertOnSubmit(documents);
                        cx.SubmitChanges();
                       
                        var v1 = from d in cx.Documents where d.dName == dr["dname"].ToString() select d.dId;
                        int result = v1.First();

                        DataTable dt2 = new DataTable();
                        string sql2 = "SELECT syscolumns.name, systypes.name AS type, syscolumns.isnullable, syscolumns.length,syscolumns.cdefault FROM syscolumns INNER JOIN systypes ON syscolumns.xusertype = systypes.xusertype WHERE (syscolumns.id = OBJECT_ID('" + dr["dname"].ToString() + "'))";
                        SqlCommand cmd3 = new SqlCommand(sql2, conn1);
                        SqlDataAdapter da = new SqlDataAdapter(cmd3);
                        SqlCommandBuilder cb = new SqlCommandBuilder(da);
                        da.Fill(dt2);

                        foreach (DataRow dr2 in dt2.Rows)
                        {
                            DocumentChild doucmentchilds = new DocumentChild();
                            doucmentchilds.dcName = dr2["name"].ToString();
                            doucmentchilds.dcType = dr2["type"].ToString();
                            doucmentchilds.dcLength = Convert.ToInt32(dr2["length"]);
                            doucmentchilds.dcIsNull = dr2["isnullable"].ToString();
                            doucmentchilds.dcDefault = dr2["cdefault"].ToString();
                            doucmentchilds.ddcId = result;
                            cx.DocumentChilds.InsertOnSubmit(doucmentchilds);
                            cx.SubmitChanges();
                          
                        }


                    }
                    cx.Transaction.Commit();
                }
                catch (Exception)
                {
                    cx.Transaction.Rollback();
                    throw;
                }
                finally
                {
                    cx.Transaction = null;
                    cx.Connection.Close();
                }


            }
        }
        #endregion
    }
}
