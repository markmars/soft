﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;

namespace WindowsFormsApplication2
{
   public static class Global
    {
        public static string UserName = "";
        public static string UserRole = "";

        /// <summary>
        /// 对 System.Data.Linq 的扩展
        /// 从给定的Linq To SQL 查询获取 DataTable 对象 
        /// </summary>
        /// <param name="source"></param>
        /// <param name="db"></param>
        /// <returns></returns>
        public static DataTable ToDataTable(this IQueryable source, DataClasses1DataContext db)
        {
            //将 LinqToSQL查询传递给 GetCommand（）以获取DbCommand对象
            DbCommand cmd = db.GetCommand(source);
            //打开数据库链接，这里可以进一步扩展，比如传递进来自己定义的继承自 DbConnection 的对象
            if (db.Connection.State == ConnectionState.Closed)
                db.Connection.Open();
            //声明 DataTable 对象
            DataTable dt = new DataTable();
            //调用DataTable 对象的 Load方法 ，从 DbDataReader 对象加载数据。
            dt.Load(cmd.ExecuteReader());
            //关闭DbConnection 链接 
            db.Connection.Close();

            return dt;
        }
    }
}
