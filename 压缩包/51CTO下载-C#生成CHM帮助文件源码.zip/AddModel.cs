﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Common;

namespace WindowsFormsApplication2
{
    public partial class AddModel : Form
    {
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public AddModel()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddModel_Load(object sender, EventArgs e)
        {
            this.dataGridView1.AutoGenerateColumns = false;//规定不自动生成列
            dataGridView1.DataSource = getModes();

            DataGridViewButtonColumn dbc = dataGridView1.Columns["Setdocu"] as DataGridViewButtonColumn;
            dbc.UseColumnTextForButtonValue = true;
            dbc.Text = "设置";
            DataGridViewButtonColumn dbc1 = dataGridView1.Columns["Delete"] as DataGridViewButtonColumn;
            dbc1.UseColumnTextForButtonValue = true;
            dbc1.Text = "删除";

            //事件
            btnExit.Click += new EventHandler(btnExit_Click);
            btnModel.Click += new EventHandler(btnModel_Click);
            dataGridView1.CellContentClick += new DataGridViewCellEventHandler(dataGridView1_CellContentClick);
        }
        /// <summary>
        /// gridview单元格内容事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //判断下单元格内容是不是第一列，也就是说单击的单元格内容是不是button列
            int k = e.ColumnIndex;
            if (k == 3)
            {
                int id = (int)dataGridView1.CurrentRow.Cells["mId"].Value;
                string name = dataGridView1.CurrentRow.Cells["mName"].Value.ToString();
                DocumentMnager f = new DocumentMnager(id, name);
                f.ShowDialog();

                this.dataGridView1.AutoGenerateColumns = false;//规定不自动生成列
                dataGridView1.DataSource = getModes();
            }
            if (k == 4)
            {
                DialogResult resutl = MessageBox.Show("你确认要删除该条数据？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (resutl == DialogResult.OK)
                {
                    cx.Transaction =cx.Connection.BeginTransaction(System.Data.IsolationLevel.Serializable);  //此处用事务


                    try
                    {
                        //删除模块信息
                        int mid=(int)dataGridView1.CurrentRow.Cells["mId"].Value;
                        var v = from m in cx.Models where m.mId == mid select m;
                        Model models = v.First();
                        if (models!=null)
                        {
                            cx.Models.DeleteOnSubmit(models);
                            cx.SubmitChanges();
                        }

                        //删除对应关系
                        int rid=(int)dataGridView1.CurrentRow.Cells["mId"].Value;
                        var vs = from r in cx.Relations where r.rmId == rid select r;
                        Relation relations = vs.First();
                        if (relations!=null)
                        {
                            cx.Relations.DeleteOnSubmit(relations);
                            cx.SubmitChanges();
                        }
                        cx.Transaction.Commit();
                        MessageBox.Show("删除成功！");
                        this.dataGridView1.AutoGenerateColumns = false;//规定不自动生成列
                        dataGridView1.DataSource = getModes();
                    }
                    catch (Exception)
                    {
                        cx.Transaction.Rollback();
                        MessageBox.Show("删除失败！");
                        throw;
                    }
                }

            }
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnModel_Click(object sender, EventArgs e)
        {
            AddModels f = new AddModels();
            f.ShowDialog();

            this.dataGridView1.AutoGenerateColumns = false;//规定不自动生成列
            dataGridView1.DataSource = getModes();
        }
        /// <summary>
        /// 关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region 自定义方法

        private DataTable getModes()
        {
            var models = from m in cx.Models select m;
            DataTable dt = new DataTable();
            dt = models.ToDataTable(cx);
            return dt;
           
        }

        #endregion
    }
}
