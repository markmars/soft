﻿namespace WindowsFormsApplication2
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.用户设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.模块设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.对象设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生成chmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.用户设置ToolStripMenuItem,
            this.模块设置ToolStripMenuItem,
            this.对象设置ToolStripMenuItem,
            this.生成chmToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(990, 25);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 用户设置ToolStripMenuItem
            // 
            this.用户设置ToolStripMenuItem.Name = "用户设置ToolStripMenuItem";
            this.用户设置ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.用户设置ToolStripMenuItem.Text = "用户设置";
            // 
            // 模块设置ToolStripMenuItem
            // 
            this.模块设置ToolStripMenuItem.Name = "模块设置ToolStripMenuItem";
            this.模块设置ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.模块设置ToolStripMenuItem.Text = "模块设置";
            // 
            // 对象设置ToolStripMenuItem
            // 
            this.对象设置ToolStripMenuItem.Name = "对象设置ToolStripMenuItem";
            this.对象设置ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.对象设置ToolStripMenuItem.Text = "对象设置";
            // 
            // 生成chmToolStripMenuItem
            // 
            this.生成chmToolStripMenuItem.Name = "生成chmToolStripMenuItem";
            this.生成chmToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.生成chmToolStripMenuItem.Text = "生成chm";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 494);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "主窗体";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 用户设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 模块设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 对象设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 生成chmToolStripMenuItem;
    }
}