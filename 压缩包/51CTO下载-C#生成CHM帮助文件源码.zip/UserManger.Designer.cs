﻿namespace WindowsFormsApplication2
{
    partial class UserManger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.IsAble = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.UpdUser = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.uId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uSex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UpdRole = new System.Windows.Forms.DataGridViewButtonColumn();
            this.lblUsername = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "当前用户：";
            // 
            // IsAble
            // 
            this.IsAble.DataPropertyName = "IsAble";
            this.IsAble.FalseValue = "1";
            this.IsAble.HeaderText = "可用";
            this.IsAble.Name = "IsAble";
            this.IsAble.ReadOnly = true;
            this.IsAble.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.IsAble.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.IsAble.TrueValue = "0";
            this.IsAble.Width = 55;
            // 
            // btnAddUser
            // 
            this.btnAddUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddUser.Location = new System.Drawing.Point(409, 293);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(75, 23);
            this.btnAddUser.TabIndex = 8;
            this.btnAddUser.Text = "添加用户";
            this.btnAddUser.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Location = new System.Drawing.Point(504, 293);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "取消";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // UpdUser
            // 
            this.UpdUser.HeaderText = "修改用户";
            this.UpdUser.Name = "UpdUser";
            this.UpdUser.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.UpdUser.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.UpdUser.Width = 80;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.uId,
            this.uName,
            this.uSex,
            this.uRole,
            this.UpdRole,
            this.UpdUser,
            this.IsAble});
            this.dataGridView1.Location = new System.Drawing.Point(3, 33);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 16;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(577, 252);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.Tag = "";
            // 
            // uId
            // 
            this.uId.DataPropertyName = "uId";
            this.uId.HeaderText = "uId";
            this.uId.Name = "uId";
            this.uId.ReadOnly = true;
            this.uId.Visible = false;
            // 
            // uName
            // 
            this.uName.DataPropertyName = "uName";
            this.uName.HeaderText = "用户名";
            this.uName.Name = "uName";
            this.uName.ReadOnly = true;
            // 
            // uSex
            // 
            this.uSex.DataPropertyName = "uSex";
            this.uSex.HeaderText = "性别";
            this.uSex.Name = "uSex";
            this.uSex.ReadOnly = true;
            this.uSex.ToolTipText = "sss";
            this.uSex.Width = 55;
            // 
            // uRole
            // 
            this.uRole.DataPropertyName = "uRole";
            this.uRole.HeaderText = "用户类别";
            this.uRole.Name = "uRole";
            this.uRole.ReadOnly = true;
            this.uRole.Width = 80;
            // 
            // UpdRole
            // 
            this.UpdRole.HeaderText = "修改权限";
            this.UpdRole.Name = "UpdRole";
            this.UpdRole.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.UpdRole.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.UpdRole.Width = 80;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblUsername.ForeColor = System.Drawing.Color.Red;
            this.lblUsername.Location = new System.Drawing.Point(74, 4);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(59, 16);
            this.lblUsername.TabIndex = 10;
            this.lblUsername.Text = "管理员";
            // 
            // UserManger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 320);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAddUser);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblUsername);
            this.Name = "UserManger";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "用户管理";
            this.Load += new System.EventHandler(this.UserManger_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn IsAble;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridViewButtonColumn UpdUser;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn uId;
        private System.Windows.Forms.DataGridViewTextBoxColumn uName;
        private System.Windows.Forms.DataGridViewTextBoxColumn uSex;
        private System.Windows.Forms.DataGridViewTextBoxColumn uRole;
        private System.Windows.Forms.DataGridViewButtonColumn UpdRole;
        private System.Windows.Forms.Label lblUsername;
    }
}