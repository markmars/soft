﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class UserManger : Form
    {
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public UserManger()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserManger_Load(object sender, EventArgs e)
        {
            lblUsername.Text = Global.UserName;

            Show();   //填充datagridview

            #region 静态数据

            DataGridViewButtonColumn dbc = dataGridView1.Columns["UpdRole"] as DataGridViewButtonColumn;
            dbc.UseColumnTextForButtonValue = true;
            dbc.Text = "修改";

            DataGridViewButtonColumn dbc1 = dataGridView1.Columns["UpdUser"] as DataGridViewButtonColumn;
            dbc1.UseColumnTextForButtonValue = true;
            dbc1.Text = "修改";
            dbc1.ReadOnly = true;
            #endregion


            btnAddUser.Click += new EventHandler(btnAddUser_Click);
            btnExit.Click += new EventHandler(btnExit_Click);
            dataGridView1.CellContentClick += new DataGridViewCellEventHandler(dataGridView1_CellContentClick);
        }
        /// <summary>
        /// gridview单元格
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //判断下单元格内容是不是第一列，也就是说单击的单元格内容是不是button列
            int k = e.ColumnIndex;
            if (k == 4)
            {
                MessageBox.Show("暂时不做！");
            }
            if (k == 5)
            {
                AddUser f = new AddUser(dataGridView1.CurrentRow.Cells["uId"].Value.ToString());
                f.ShowDialog();
            }
        }
        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnAddUser_Click(object sender, EventArgs e)
        {
            AddUser f = new AddUser();
            f.ShowDialog();
        }


        #region 自定义方法

        /// <summary>
        /// 显示用户信息
        /// </summary>
        private void Show()
        {
            string gs = "管理员";
            string ps = "普通用户";
            var v = from u in cx.Users select new { 
            u.uId,
            u.uName,
            u.uSex,
            u.uRole,
            u.status};
            DataTable dt = v.ToDataTable(cx);
            this.dataGridView1.AutoGenerateColumns = false;//规定不自动生成列
            dataGridView1.DataSource = dt;
        }
        #endregion
    }
}
