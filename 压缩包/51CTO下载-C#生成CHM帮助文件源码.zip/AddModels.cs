﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class AddModels : Form
    {
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public AddModels()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddModels_Load(object sender, EventArgs e)
        {
            //事件
            btnExit.Click += new EventHandler(btnExit_Click);
            btnSave.Click += new EventHandler(btnSave_Click);
            tbName.Validating += new CancelEventHandler(tbName_Validating);
        }
        /// <summary>
        /// 模块名称验证
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void tbName_Validating(object sender, CancelEventArgs e)
        {
            string name = tbName.Text.Trim();
            var v = from m in cx.Models where m.mName == name select m;
            Model models = v.First();
            if (models != null)
            {
                MessageBox.Show("模块名称已存在，请重新输入");
                tbName.Focus();
                tbName.Text = "";
            }
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnSave_Click(object sender, EventArgs e)
        {
            if (tbName.Text.Trim() == "")
            {
                MessageBox.Show("模块名称不能为空！");
                tbName.Focus();
                return;
            }
            try
            {
                Model models = new Model();
                models.mName = tbName.Text.Trim();
                models.mRemark = tbRemark.Text.Trim();
                cx.Models.InsertOnSubmit(models);
                cx.SubmitChanges();
                MessageBox.Show("保存成功！");
                tbName.Focus();
                tbName.Text = "";
                tbRemark.Text = "";
            }
            catch (Exception)
            {
                MessageBox.Show("保存失败！");
                throw;
            }
        }
        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        #region 自定义方法

       

        #endregion
    }
}
