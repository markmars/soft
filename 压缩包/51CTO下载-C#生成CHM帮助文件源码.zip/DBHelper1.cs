﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace WindowsFormsApplication2
{
    class DBHelper1
    {
        private static SqlConnection connection;
        public static string UserName = "";
        public static string FromDataBase = "Tables";

        public static SqlConnection Connection
        {
            get
            {
                string connectionString = "Data Source=THINK-THINK\\SQLEXPRESS;Initial Catalog=Tables;Integrated Security=True";
               
                if (connection == null)
                {
                    connection = new SqlConnection(connectionString);
                    connection.Open();
                }
                else if (connection.State == System.Data.ConnectionState.Closed)
                {
                    connection.Open();
                }
                else if (connection.State == System.Data.ConnectionState.Broken)
                {
                    connection.Close();
                    connection.Open();
                }
                return connection;
            }
        }

        public static DataTable getDatatable(string safeSql)
        {
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand(safeSql, Connection);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds.Tables[0];
        }

        public static Object getExecuteScalar(string str, SqlParameter[] pr)
        {
            SqlCommand cmd = new SqlCommand(str, Connection);
            cmd.Parameters.AddRange(pr);
            return cmd.ExecuteScalar();
        }

        public static int getExecuteNonQuery(string str, SqlParameter[] pr)
        {
            SqlCommand cmd = new SqlCommand(str, Connection);
            cmd.Parameters.AddRange(pr);
            return cmd.ExecuteNonQuery();
        }
    }
}
