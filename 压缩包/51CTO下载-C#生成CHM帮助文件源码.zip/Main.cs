﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Main : Form
    {
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            
            用户设置ToolStripMenuItem.Click += new EventHandler(用户设置ToolStripMenuItem_Click);
            模块设置ToolStripMenuItem.Click += new EventHandler(模块设置ToolStripMenuItem_Click);
            对象设置ToolStripMenuItem.Click += new EventHandler(对象设置ToolStripMenuItem_Click);
            生成chmToolStripMenuItem.Click += new EventHandler(生成chmToolStripMenuItem_Click);
        }

        void 生成chmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 detail = new Form1();
            detail.MdiParent = this;
            detail.Show();
        }

        void 对象设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //string sql = "SELECT  dname FROM DOCUMENTS ";
            ////SqlParameter[] par = new SqlParameter[] { };
            //DataTable dts = DBHelper.getDatatable(sql);
            var v = from d in cx.Documents select d;
            if (v==null)
            {
                MessageBox.Show("不好意思，没有数据！请先到模块设置中加载数据");
                return;
            }

            Details detail = new Details();
            detail.MdiParent = this;
            detail.Show();
        }

        void 模块设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Global.UserRole == "0")
            {
                AddModel model = new AddModel();
                model.MdiParent = this;
                model.Show();
            }
            else
            {
                MessageBox.Show("你没有权限访问！");
            }
        }

        void 用户设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Global.UserRole == "0")
            {
                UserManger user = new UserManger();
                user.MdiParent = this;
                user.Show();
            }
            else
            {
                MessageBox.Show("你没有权限访问！");
            }
        }
    }
}
