namespace Zivsoft.Log
{
    /// <summary>
    /// This structure shall be used to keep the size of the screen.
    /// </summary>
    struct Size
    {
        /// <summary>
        /// Test Comment
        /// </summary>
        public int CX;
        /// <summary>
        /// Test comment
        /// </summary>
        public int CY;
    }
}