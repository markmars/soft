﻿namespace Zivsoft.Log
{
    /// <summary>
    /// Error>Warning>Info>Debug
    /// When in debug status, you can see detail error message
    /// </summary>
    enum LogLevel
    {
        Debug = 0,
        Info = 1,
        Warning = 2,
        Error = 3,
    };
}