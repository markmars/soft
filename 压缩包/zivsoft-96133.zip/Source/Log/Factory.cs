﻿
namespace Zivsoft.Log
{
    /// <summary>
    /// software factory
    /// </summary>
    static class Factory
    {
        private static ILog _log;
        public static ILog FileLog
        {
            get
            {
                if (_log == null)
                {
                    _log = new FileLogger();
                }
                return _log;
            }
        }

        
        private static ILog _xmlLogger;
        /// <summary>
        /// 
        /// </summary>
        public static ILog XmlLog
        {
            get
            {
                if (_xmlLogger == null)
                {
                    _xmlLogger = new XmlLogger();
                }
                return _xmlLogger;
            }
        }

        private static ILog _colorLogger;
        /// <summary>
        /// color Console log
        /// </summary>
        public static ILog ColorLog
        {
            get
            {
                if (_colorLogger == null)
                {
                    _colorLogger = new ColorLogger(LogConfig.Single().ColorConsoleLogMaxLength);
                }
                return _colorLogger;
            }
        }

    }
}