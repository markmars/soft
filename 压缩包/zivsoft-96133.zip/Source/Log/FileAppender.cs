﻿using System.IO;

namespace Zivsoft.Log
{
    class FileAppender
    {

        private StreamWriter _sw;

        public FileAppender(ref StreamWriter streamWriter)
        {
            _sw = streamWriter;
        }

        /// <summary>
        /// back write</Test>
        /// </summary>
        public void BackPosition()
        {
            long totLength = _sw.BaseStream.Length;
            long tagLength = 8L;//back write</Test>
            long position = totLength - tagLength;
            if (position > 0)//if flag back
            {
                _sw.BaseStream.Position = position;
            }
        }
    }
}