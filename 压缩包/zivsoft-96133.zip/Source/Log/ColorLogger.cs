﻿using System;

namespace Zivsoft.Log
{
    /// <summary>
    /// 
    /// </summary>
    class ColorLogger:ILog
    {

        private int _maxLong;

        public ColorLogger()
        {
            _maxLong = int.MaxValue;
        }

        public ColorLogger(int maxLength)
        {
            _maxLong = maxLength;
        }


        private string Get<T>(T t, int min, int max)
        {
            if (max < 0)
            {
                max = Int32.MaxValue;
            }

            if (t.ToString().Length < min)
            {
                string v = t.ToString();
                for (int i = 0, k = min - v.Length; i < k; i++)
                {
                    v = "0" + v;
                }
                return v;
            }
            else if (t.ToString().Length > max)
            {
                return t.ToString().Remove(max) + "...";
            }
            return t.ToString();
        }

        private void WriteLine(string msg, params object[] args)
        {
            string message = string.Empty;
            try
            {
                message = string.Format(msg, args);
            }
            catch
            {
                message = msg;
            }
            Console.WriteLine(DateFormat.LogDate.GetLogDateFormat(DateTime.Now) + " " +Get<string>(message, 0, _maxLong));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="args"></param>
        public void LogDebug(string msg, params object[] args)
        {
            if (LogConfig.Single().LogLevel == LogLevel.Debug)
            {
                Console.ForegroundColor = ConsoleColor.White;
                WriteLine(msg, args);
                Console.ResetColor();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="args"></param>
        public void LogInfo(string msg, params object[] args)
        {
            if (LogConfig.Single().LogLevel == LogLevel.Info || LogConfig.Single().LogLevel == LogLevel.Debug)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                WriteLine(msg, args);
                Console.ResetColor();
            }
        }

        public void LogError(string msg, params object[] args)
        {
            
            Console.ForegroundColor = ConsoleColor.Red;
            WriteLine(msg, args);
            Console.ResetColor();
        }

        public void LogWarning(string msg, params object[] args)
        {
            if (LogConfig.Single().LogLevel < LogLevel.Warning || LogConfig.Single().LogLevel == LogLevel.Warning)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                WriteLine(msg, args);
                Console.ResetColor();
            }
        }


    }
}