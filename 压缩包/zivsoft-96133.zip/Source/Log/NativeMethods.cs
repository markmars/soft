﻿using System;
using System.Runtime.InteropServices;

namespace Zivsoft.Log
{
    /// <summary>
    /// Provides access to Win32 methods needed for logging.
    /// </summary>
    class NativeMethods : MarshalByRefObject
    {
        private NativeMethods() { }

        /// <summary>
        /// Test Comment
        /// </summary>
        public const int SM_CXSCREEN = 0;
        /// <summary>
        /// Test Comment
        /// </summary>
        public const int SM_CYSCREEN = 1;

        /// <summary>
        /// Test Comment
        /// </summary>
        public const int SRCCopy = 13369376;

        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("user32.dll", EntryPoint = "GetDesktopWindow")]
        internal static extern IntPtr GetDesktopWindow();
        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("user32.dll", EntryPoint = "GetDC")]
        internal static extern IntPtr getDC(IntPtr ptr);

        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("user32.dll", EntryPoint = "GetSystemMetrics")]
        internal static extern int GetSystemMetrics(int abc);

        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("user32.dll", EntryPoint = "ReleaseDC")]
        internal static extern Int32 ReleaseDC(IntPtr hWnd, IntPtr hDc);

        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("gdi32.dll", EntryPoint = "DeleteDC")]
        internal static extern Int32 DeleteDC(IntPtr hDc);

        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("gdi32.dll", EntryPoint = "BitBlt")]
        internal static extern bool BitBlt(IntPtr hdcDestination, int xDestination, int yDestination, int wDestination,
                                           int hDestination, IntPtr hdcSource, int xSource, int ySource, int rasterOperation);
        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("gdi32.dll", EntryPoint = "CreateCompatibleBitmap")]
        internal static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);
        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("gdi32.dll", EntryPoint = "CreateCompatibleDC")]
        internal static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        /// <summary>
        /// Test Comment
        /// </summary>
        [DllImport("gdi32.dll", EntryPoint = "SelectObject")]
        internal static extern IntPtr SelectObject(IntPtr hdc, IntPtr bmp);
    }
}