﻿using System.Configuration;
using System.Xml;
using System.Diagnostics;

namespace Zivsoft.Log
{
    class Handler:IConfigurationSectionHandler
    {
        public object Create(object parent, object configContext, XmlNode section)
        {
            if (section == null)
            {
                Debug.WriteLine("<section name='Test' type='Test.ConfigHandler,Test'/>");
            }
            return section;
        }
    }
}
