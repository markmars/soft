﻿using System;
using System.Security.Permissions;

/**************************************
 * 
 * Created by Lihua Zhou at 2008-08-15
 * 
 * Entry for Logger.dll
 * 
 * 
 **************************************/
namespace Zivsoft.Log
{
    /// <summary>
    /// All logger will be implemented from this class
    /// Entry for <c>Logger</c>
    /// <author>Lihua</author>
    /// </summary>
    public static class Logger
    {
        /// <summary>
        /// Test Debug Message
        /// </summary>
        public static void LogDebug(string message, params object[] args)
        {
            //1
            if (LogConfig.Single().IsFileLogEnabled)
            {
                Factory.FileLog.LogDebug(message, args);
            }

            //2
            if (LogConfig.Single().IsColorConsoleLogEnabled)
            {
                Factory.ColorLog.LogDebug(message, args);
            }

            //4
            if (LogConfig.Single().IsXmlLogEnabled)
            {
                Factory.XmlLog.LogDebug(message, args);
            }

        }

        public static void LogError(Exception exception)
        {
#if DEBUG
            LogError("{0}", exception);
#else
            LogError(exception.Message);
#endif
        }


        /// <summary>
        /// Test Error Message
        /// </summary>
        public static void LogError(string message, params object[] args)
        {
            if (LogConfig.Single().IsFileLogEnabled)
            {
                Factory.FileLog.LogError(message, args);
            }

            if (LogConfig.Single().IsColorConsoleLogEnabled)
            {
                Factory.ColorLog.LogError(message, args);
            }

            if (LogConfig.Single().IsXmlLogEnabled)
            {
                Factory.XmlLog.LogError(message, args);
            }
        }
        /// <summary>
        /// Test Warning Message
        /// </summary>
        public static void LogWarning(string message, params object[] args)
        {
            //1
            if (LogConfig.Single().IsFileLogEnabled)
            {
                Factory.FileLog.LogWarning(message, args);
            }

            //2
            if (LogConfig.Single().IsColorConsoleLogEnabled)
            {
                Factory.ColorLog.LogWarning(message, args);
            }


            //4
            if (LogConfig.Single().IsXmlLogEnabled)
            {
                Factory.XmlLog.LogWarning(message, args);
            }
        }
        /// <summary>
        /// Test Information Message
        /// </summary>
        public static void LogInfo(string message, params object[] args)
        {
            if (LogConfig.Single().IsFileLogEnabled)
            {
                Factory.FileLog.LogInfo(message, args);
            }

            if (LogConfig.Single().IsColorConsoleLogEnabled)
            {
                Factory.ColorLog.LogInfo(message, args);
            }

            if (LogConfig.Single().IsXmlLogEnabled)
            {
                Factory.XmlLog.LogInfo(message, args);
            }
        }
    }
}