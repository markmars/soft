﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Globalization;

namespace Zivsoft.Log
{
    class DataXmlNotFound:FileNotFoundException
    {
        public DataXmlNotFound():base(){
            
        }
    }
}
