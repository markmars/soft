﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Zivsoft.Log
{
    class LevelParser
    {
        const string cError = "[Error] ";
        const string cInfo = "[Info] ";
        const string cWarning = "[Warning] ";
        const string cDebug = "[Debug] ";

        public static string GetName(LogLevel level)
        {
            switch (level)
            {
                case LogLevel.Error:
                    return cError;
                case LogLevel.Info:
                    return cInfo;
                case LogLevel.Warning:
                    return cWarning;
                case LogLevel.Debug:
                    return cDebug;
                default:
                    return "*********inner error***********";
            }
        }
    }
}