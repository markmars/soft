﻿using System;
using System.IO;
using System.Diagnostics;


namespace Zivsoft.Log
{
    class LogFileMover
    {
        private readonly FileInfo _fileInfo;
        public LogFileMover(FileInfo file)
        {
            _fileInfo = file;
        }

        /// <summary>
        /// 
        /// </summary>
        public void Move()
        {
            string standardName = CheckLogBackupFolder() + DateFormat.LogDate.GetDateName(DateTime.Now);
            int i = 0;
            string newFileName = standardName + ".0";
            while (File.Exists(newFileName))
            {
                newFileName = standardName + "." + (++i);
            }
            try
            {
                _fileInfo.MoveTo(newFileName);
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }
        }
        
        private static string CheckLogBackupFolder()
        {
            //this is a folder, so should like c:\abc\
            string path = Path.GetFullPath(LogConfig.Single().FileLogFullName).Replace(Path.GetFileName(LogConfig.Single().FileLogFullName), "");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            return path;
        }
    }
}