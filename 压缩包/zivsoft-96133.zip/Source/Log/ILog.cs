﻿using System.Runtime.InteropServices;
using System;
/*******************************
 * Created By Lihua Zhou
 * Description: Test interface
 *******************************/

namespace Zivsoft.Log
{
    /// <summary>
    /// INNER LOG INTERFACE
    /// </summary>
    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("96BC3CB8-1523-4d63-A174-BF655B1911AA")]
    interface ILog
    {
        /// <summary>
        /// Write log for Dev, Test and User
        /// </summary>
        [PreserveSig]
        void LogError([In, Out, MarshalAs(UnmanagedType.BStr)]string message, params object[] args);

        /// <summary>
        /// Write log for User, Dev and Test
        /// </summary>
        /// <param name="message"></param>
        void LogWarning([In, Out]string message, params object[] args);
     
        /// <summary>
        /// Write log for User
        /// </summary>
        /// <param name="message">User message</param>
        void LogInfo(string message, params object[] args);
        /// <summary>
        /// Write log for Dev
        /// </summary>
        /// <param name="message">Debug message</param>
        void LogDebug(string message, params object[] args);
    }

    interface ILogDate
    {
        /// <summary>
        /// 08/28/2008 13:24:03.0046
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        string GetLogDateFormat(DateTime dt);
        /// <summary>
        /// 2008-08-28
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        string GetDateName(DateTime dt);
    }

    [Guid("96BC3CB8-1523-4d63-A174-BF655B1911AA")]
    interface ILogConfig
    {
        /// <summary>
        /// all log
        /// </summary>
        LogLevel LogLevel { get; }

        /// <summary>
        /// file log name
        /// </summary>
        string FileLogFullName { get; }
        /// <summary>
        /// Xml name
        /// </summary>
        string XmlLogName { get; }

        /// <summary>
        /// ColorConsole
        /// </summary>
        bool IsColorConsoleLogEnabled { get; }

        /// <summary>
        /// XML
        /// </summary>
        bool IsXmlLogEnabled { get; }

        /// <summary>
        /// 
        /// </summary>
        bool IsFileLogEnabled { get; }

        /// <summary>
        /// ColorConsole
        /// </summary>
        int ColorConsoleLogMaxLength { get; }

        /// <summary>
        /// FileLog
        /// </summary>
        bool IsShowHeader { get; }

    }

}