using System.IO;

namespace Zivsoft.Log
{

    /// <summary>
    /// Change the new file
    /// </summary>
    class LogSizeChecker
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly FileStream _fileStream;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileStream"></param>
        public LogSizeChecker(FileStream fileStream)
        {
            this._fileStream = fileStream;
        }
        /// <summary>
        /// If size > 512K, then backup.
        /// </summary>
        /// <returns>true or false</returns>
        public bool IsOver512KBytes()
        {
            long length = this._fileStream.Length / 1024;
            if (length > 512)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
