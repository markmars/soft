﻿using System;
using System.Drawing;
using Size = Zivsoft.Log.Size;
using System.Diagnostics;

namespace Zivsoft.Log
{
    /// <summary>
    /// This class shall keep all the functionality for capturing 
    /// the desktop.
    /// </summary>
    class CaptureScreen : MarshalByRefObject
    {
        /// <summary>
        /// Test Comment
        /// </summary>
        static IntPtr HBitmap;

        private CaptureScreen() { }

        /// <summary>
        /// Test Comment
        /// </summary>
        public static Bitmap DesktopImage()
        {
            try
            {
                //In size variable we shall keep the size of the screen.
                Size size;

                //Here we get the handle to the desktop device context.
                IntPtr hDC = NativeMethods.getDC(NativeMethods.GetDesktopWindow());

                //Here we make a compatible device context in memory for screen device context.
                IntPtr hMemDC = NativeMethods.CreateCompatibleDC(hDC);

                //We pass SM_CXSCREEN constant to GetSystemMetrics to get the X coordinates of screen.
                size.CX = NativeMethods.GetSystemMetrics(NativeMethods.SM_CXSCREEN);

                //We pass SM_CYSCREEN constant to GetSystemMetrics to get the Y coordinates of screen.
                size.CY = NativeMethods.GetSystemMetrics(NativeMethods.SM_CYSCREEN);

                //We create a compatible bitmap of screen size and using screen device context.
                HBitmap = NativeMethods.CreateCompatibleBitmap(hDC, size.CX, size.CY);

                //As m_HBitmap is IntPtr we can not check it against null. For this purspose IntPtr.Zero is used.
                if (HBitmap != IntPtr.Zero)
                {
                    //Here we select the compatible bitmap in memeory device context and keeps the refrence to Old bitmap.
                    IntPtr hOld = (IntPtr)NativeMethods.SelectObject(hMemDC, HBitmap);
                    //We copy the Bitmap to the memory device context.
                    NativeMethods.BitBlt(hMemDC, 0, 0, size.CX, size.CY, hDC, 0, 0, NativeMethods.SRCCopy);
                    //We select the old bitmap back to the memory device context.
                    NativeMethods.SelectObject(hMemDC, hOld);
                    //We delete the memory device context.
                    NativeMethods.DeleteDC(hMemDC);

                    //We release the screen device context.
                    NativeMethods.ReleaseDC(NativeMethods.GetDesktopWindow(), hDC);
                    //Image is created by Image bitmap handle and returned.
                    return System.Drawing.Image.FromHbitmap(HBitmap);
                }

                //If m_HBitmap is null return null.
                return null;
            }
            catch(Exception e)
            {
                Debug.WriteLine(e);
                return null;
            }
        }
    }
}