﻿using System;
using System.IO;
using System.Diagnostics;

/**********************************
 * Created by Lihua at 10/09/2007
 **********************************/

namespace Zivsoft.Log
{
    /// <summary>
    /// Logger
    /// </summary>
    class FileLogger :ILog,IDisposable
    {
        private readonly LogLevel _logLevel;
        private readonly string _logFile;
        private readonly bool _isShowHeader;

        /// <summary>
        /// init config
        /// </summary>
        internal FileLogger()
        {
            _logLevel = LogConfig.Single().LogLevel;
            _logFile = LogConfig.Single().FileLogFullName;
            _isShowHeader = LogConfig.Single().IsShowHeader;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logLevel"></param>
        /// <param name="logFile"></param>
        /// <param name="isShowHeader"></param>
        public FileLogger(LogLevel logLevel,string logFile,bool isShowHeader)
        {
            _logLevel = logLevel;
            _logFile = logFile;
            _isShowHeader = isShowHeader;
        }

        /// <summary>
        /// All write action here
        /// </summary>
        /// <param name="level">Test Level</param>
        /// <param name="message">Message</param>
        private void WriteLog(LogLevel level, object message)
        {
            bool isAddHead = _isShowHeader;
            if (isAddHead)
            {
                isAddHead=!File.Exists(_logFile);
            }
            string head1 = "=============================================================";
            string head2 = "    Date       Time     MsgType            Message           ";
            string head3 = "=============================================================";
            lock (this)
            {
                FileStream fs = null;
                try
                {
                    fs = File.Open(_logFile, FileMode.Append);
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                    return;
                }
                LogSizeChecker logChecker = new LogSizeChecker(fs);
                if (logChecker.IsOver512KBytes())
                {
                    fs.Close();
                    FileInfo file = new FileInfo(_logFile);
                    LogFileMover fileMover = new LogFileMover(file);
                    fileMover.Move();
                    fs = File.Open(_logFile, FileMode.Append);
                    isAddHead = true;
                }
                StreamWriter sw = new StreamWriter(fs);
                if (isAddHead)
                {
                    sw.WriteLine(head1);
                    sw.WriteLine(head2);
                    sw.WriteLine(head3);
                }
                string preText = DateFormat.LogDate.GetLogDateFormat(DateTime.Now) + " " + LevelParser.GetName(level);
                if(!_isShowHeader)
                {
                    preText = string.Empty;
                }
                //begin to write log
                if (message is Exception)
                {
                    Exception e = message as Exception;
                    if (LogConfig.Single().LogLevel == LogLevel.Debug)
                    {
                        sw.WriteLine(preText + e);
                    }
                    else
                    {
                        sw.WriteLine(preText + e.Message);
                    }
                }
                else
                {
                    sw.WriteLine(preText + message);
                }
                sw.Close();
                fs.Close();
            }

        }

        public void LogError(string message, params object[] args)
        {
            string msg = string.Empty;
            try
            {
                msg= string.Format(message, args);
            }
            catch(Exception e)
            {
                WriteLog(LogLevel.Error,e.Message);
            }
            WriteLog(LogLevel.Error,msg);
        }

        public void LogWarning(string message, params object[] args)
        {
            if (_logLevel> LogLevel.Warning)
            {
                return;//do not write log
            }
            WriteLog(LogLevel.Warning, string.Format(message,args));
        }

        public void LogInfo(string message, params object[] args)
        {
            if (_logLevel > LogLevel.Info)
            {
                return;
            }
            WriteLog(LogLevel.Info, string.Format(message,args));
        }

        public void LogDebug(string message, params object[] args)
        {
            if (_logLevel > LogLevel.Debug)
            {
                return;//won't write log, if the level is higher than Debug
            }
            WriteLog(LogLevel.Debug, string.Format(message,args));
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

    }
}