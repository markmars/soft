﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Zivsoft.Services;
namespace Zivsoft.IO.Register
{
    public class RegisterRequest:Request
    {
        public RegisterRequest(string dealMethod) : base("RegisterBH", dealMethod) { }
    }
}
