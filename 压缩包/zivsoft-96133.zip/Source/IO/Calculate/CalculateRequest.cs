﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;

namespace Zivsoft.IO.Calculate
{
    public class CalculateRequest:BusinessRequest
    {
        public CalculateRequest() : base("Calculate") { }
        public string Expression
        {
            get
            {
                return this["Expression"] as string;
            }
            set
            {
                this["Expression"] = value;
            }
        }
    }

    public class CalculateResponse : Response
    {
        public string Result
        {
            get
            {
                return this["Result"] as string;

            }
            set
            {
                this["Result"] = value;
            }
        }
    }
}
