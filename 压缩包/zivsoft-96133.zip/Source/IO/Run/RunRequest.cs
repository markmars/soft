﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;

namespace Zivsoft.IO.Run
{
    public class RunRequest:BusinessRequest
    {
        public RunRequest() : base("run") { }


    }
    public class RunResponse:Response
    {

    }
}
