﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;

namespace Zivsoft.IO.Security
{
    public class SecurityResponse : Response
    {
        public bool Cert
        {
            get;
            set;
        }

    }
}
