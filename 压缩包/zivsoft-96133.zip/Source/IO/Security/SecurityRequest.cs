﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;

namespace Zivsoft.IO.Security
{

    public class SecurityRequest : RequestBase
    {
        public static SecurityRequest CheckCert()
        {
            return new CheckCert();
        }

        public SecurityRequest(string dealMethod) : base("SecurityBH", dealMethod) { }

        new public SecurityResponse GetResponse()
        {
            return base.GetResponse<SecurityResponse>(new SecurityResponse());
        }
    }


}
