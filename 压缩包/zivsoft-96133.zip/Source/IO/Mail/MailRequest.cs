﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;

namespace Zivsoft.IO.Mail
{
    public class MailRequest:RequestBase
    {
        public MailRequest() : base("Mail","SendMail") { }

        public string Message
        {
            get
            {
                return this["Message"] as string;
            }
            set
            {
                this["Message"] = value;
            }
        }

    }
}
