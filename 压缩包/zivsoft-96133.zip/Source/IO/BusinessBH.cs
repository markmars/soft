﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

using Zivsoft.Services;
namespace Zivsoft.IO
{

    /// <summary>
    /// Zivsoft.Business.dll业务请求类
    /// </summary>
    public class BusinessRequest : RequestBase
    {
        public BusinessRequest(string dealMethod) : base("BusinessBH", dealMethod) { }
    }

}
