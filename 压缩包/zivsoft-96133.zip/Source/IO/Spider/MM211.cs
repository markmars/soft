﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.IO.Spider
{
    public class MM211 : SpiderRequest
    {
        /// <summary>
        /// 注意DealMethod出分大小写
        /// </summary>
        public MM211(): base("MM211"){}
    }
}
