﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Zivsoft.Services;
namespace Zivsoft.IO.Spider
{

    public class SpiderResponse : Response
    {

    }
}
