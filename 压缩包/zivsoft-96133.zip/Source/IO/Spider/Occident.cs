﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.IO.Spider
{
    public class Occident:SpiderRequest
    {
        public Occident() : base("Occident") { }
    }
}
