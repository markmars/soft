﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;

namespace Zivsoft.IO.Spider
{



    public class SpiderRequest:RequestBase
    {
        public static MM211 CreateMM211()
        {
            return new MM211();
        }

        public SpiderRequest(string dealMethod)
            : base("SpiderBH", dealMethod)
        {
        }

        new public SpiderResponse GetResponse()
        {
            return base.GetResponse<SpiderResponse>(new SpiderResponse());
        }

    }

}
