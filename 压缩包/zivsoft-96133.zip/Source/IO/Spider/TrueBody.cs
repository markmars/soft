﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.IO.Spider
{
    public class TrueBody:SpiderRequest
    {
        public TrueBody() : base("人体写真") { }

    }
}
