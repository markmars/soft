﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.IO.Spider
{
    public class BodyModel:SpiderRequest
    {
        public BodyModel() : base("人体模特") { }
    }
}
