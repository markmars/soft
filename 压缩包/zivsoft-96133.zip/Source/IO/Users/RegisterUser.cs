﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;

namespace Zivsoft.IO.Users
{
    public class RegisterUser:LoginRequest
    {
        public RegisterUser() : base("RegisterUser") { }

        public string UserName
        {
            get
            {
                return this["UserName"] as string;

            }
            set
            {
                this["UserName"] = value;
            }
        }
    }

    public class RegisterUserResponse : Response
    {
        public bool IsSuccess
        {
            get
            {
                return Convert.ToBoolean(this["IsSuccess"]);
            }
            set
            {
                this["IsSuccess"] = value;
            }
        }
    }
}
