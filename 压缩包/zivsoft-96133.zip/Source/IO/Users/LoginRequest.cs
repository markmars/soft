﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.IO.Users
{
    public class LoginRequest : BusinessRequest
    {
        /// <summary>
        /// 供子类使用
        /// </summary>
        /// <param name="dealMethod"></param>
        protected LoginRequest(string dealMethod) : base(dealMethod) { }

        public LoginRequest() : base("LoginByGlobal") { }

        public string UserId
        {
            get
            {
                return this["UserId"] + "";
            }
            set
            {
                this["UserId"] = value;
            }
        }
        public string Password
        {
            get
            {
                return this["UserPwd"] + "";
            }
            set
            {
                this["UserPwd"] = value;
            }
        }
        public string IP
        {
            get
            {
                return this["IP"] + "";
            }
            set
            {
                this["IP"] = value;
            }
        }

        new public LoginResponse GetResponse()
        {
            return base.GetResponse<LoginResponse>(new LoginResponse());
        }

    }
}
