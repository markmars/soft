﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace Zivsoft.IO.Core
{
    public class MenuTreeRequest : BusinessRequest
    {
        public MenuTreeRequest() : base("LoadMenuTree") { }

        public string UserId { get { return this["UserId"] + ""; } set { this["UserId"] = value; } }
        public Menu Menu { get { return this["Menu"] as Menu; } set { this["Menu"] = value; } }
        public TreeView Tree { get { return this["Tree"] as TreeView; } set { this["Tree"] = value; } }
        public string ExitText { get { return this["Exit"] + ""; } set { this["Exit"] = value; } }
    }
}
