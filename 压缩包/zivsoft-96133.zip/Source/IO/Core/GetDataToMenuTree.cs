﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.IO.Core
{
    public class GetDataToMenuTree:BusinessRequest
    {
        public GetDataToMenuTree() : base("GetDataViewByRole") { }

    }
}
