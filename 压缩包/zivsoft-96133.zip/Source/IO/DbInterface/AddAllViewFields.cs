﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;

namespace Zivsoft.IO.DbInterface
{
    public class AddAllViewFields:BusinessRequest
    {
        public AddAllViewFields() : base("AddAllViewFields") { }
    }
    public class AddAllViewFieldsResponse : Response
    {
        public int Item
        {
            get
            {
                return Convert.ToInt32(this["Item"]);
            }
            set
            {
                this["Item"] = value;
            }

        }
    }
}
