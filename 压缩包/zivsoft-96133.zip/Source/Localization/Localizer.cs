using System;
using System.IO;
using System.Xml;

namespace Zivsoft.Localization
{
    /// <summary>
    /// Summary description for Localizer.
    /// </summary>
    public class Localizer
    {
        private XmlDocument _doc = null;
        private XmlNode _pagePointer = null;
        private string _fileName = "";
        private string _currentPage = "";
        private string _code = "";

        /// <summary>
        /// </summary>
        public Localizer()
        {
        }

        /// <summary>
        /// </summary>
        /// <param name="fileName"></param>
        public Localizer(string fileName)
        {
            this._fileName = fileName;
            this.loadFile();
        }

        /// <summary>
        /// </summary>
        private void loadFile()
        {
            if (this._fileName == "" || !File.Exists(this._fileName))
                throw(new ApplicationException("Invalid language file " + this._fileName));

            if (this._doc == null)
                this._doc = new XmlDocument();

            this._doc.Load(this._fileName);
            try
            {
                this._doc.Load(this._fileName);
                if (this._doc.DocumentElement.Attributes["code"] != null)
                    this._code = this._doc.DocumentElement.Attributes["code"].Value;
                else
                    this._code = "en";
            }
            catch
            {
                this._doc = null;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="fileName"></param>
        public void loadFile(string fileName)
        {
            this._fileName = fileName;
            this.loadFile();
        }

        /// <summary>
        /// </summary>
        /// <param name="Page"></param>
        public void setPage(string Page)
        {
            if (this._currentPage == Page)
                return;

            this._pagePointer = null;
            this._currentPage = "";

            if (this._doc != null)
            {
                this._pagePointer = this._doc.SelectSingleNode(string.Format("//page[@name='{0}']", Page.ToUpper()));
                this._currentPage = Page;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public string getText(string text)
        {
            if (this._doc == null)
                return "";

            XmlNode el = null;

#if DEBUG
            if (this._pagePointer == null)
                throw new Exception("Missing page pointer: " + text);
#endif

            if (this._pagePointer != null)
            {
                el = this._pagePointer.SelectSingleNode(string.Format("Resource[@tag='{0}']", text));
                if (el == null)
                    el = this._doc.SelectSingleNode(string.Format("//Resource[@tag='{0}']", text));
            }
            else
            {
                el = this._doc.SelectSingleNode(string.Format("//Resource[@tag='{0}']", text));
            }

            if (el != null)
                return el.InnerText;
            else
                return null;
        }

        /// <summary>
        /// </summary>
        /// <param name="page"></param>
        /// <param name="text"></param>
        /// <returns></returns>
        public string getText(string page, string text)
        {
            this.setPage(page);
            return this.getText(text);
        }

        /// <summary>
        /// </summary>
        public string LanguageCode
        {
            get { return this._code; }
        }
    }
}