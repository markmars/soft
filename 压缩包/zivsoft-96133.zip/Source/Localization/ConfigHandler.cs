﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Xml;
using System.Diagnostics;

namespace Zivsoft.Localization
{
    class ConfigHandler : IConfigurationSectionHandler
    {
        public object Create(object parent, object configContext, XmlNode section)
        {
            if (section == null)
            {
                Debug.WriteLine(@"<section name='Localization' type='Zivsoft.Localization.ConfigHandler,Zivsoft.Localization'/>");
            }
            return section;
        }
    }

}
