﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace Zivsoft.Localization
{
    interface IConfig
    {
        LocType LocalizationType { get; }
    }
    interface IXmlConfig
    {
        string LoadFilePathByCulture(string cultureId);
    }

    class Factory
    {
        public static XmlNode GetConfig()
        {
            XmlNode node = null;
            XmlDocument xml = new XmlDocument();
            try
            {
                xml.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Data\\Data.xml");
            }
            catch (DirectoryNotFoundException)
            {
                xml.Load(AppDomain.CurrentDomain.BaseDirectory + "Data.xml");
            }
            var nodes = xml.SelectNodes("/Config/Localization");//xpath
            foreach (XmlNode n in nodes)
            {
                if (n.Name == "Localization")
                {
                    node = n;
                    break;
                }
            }
            return node;
        }
    }
}
