﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Localization
{
    /// <summary>
    /// 
    /// </summary>
    class LocalizationException : Exception
    {
        public LocalizationException()
            : base()
        {

        }

        public LocalizationException(string message)
            : base(message)
        {

        }

        public LocalizationException(string message, params object[] args)
            : base(string.Format(message, args))
        {
        }

    }
}
