
namespace Zivsoft.Localization
{
    /// <summary>
    /// <example>
    /// <add key="ResourceFile" value="Resource.xml"/>
    /// </example>
    /// </summary>
    public interface IResource
    {
        /// <summary>
        /// </summary>
        string this[string key]{get;}
    }
}