using System;
using System.Collections;
using System.Xml;
using System.IO;


namespace Zivsoft.Localization
{
    /// <summary>
    /// </summary>
    public class SqlResource:IResource
    {
        public static SqlResource Empty;
        private static Hashtable _htSqlRes;
        static SqlResource()
        {
            SqlResource._htSqlRes = new Hashtable();
            SqlResource.Empty = new SqlResource(String.Empty);
        }
        /// <summary>
        /// </summary>
        public static SqlResource Instance(string mod)
        {
            if(String.IsNullOrEmpty(mod))
            {
                return SqlResource.Empty;
            }
            if(SqlResource._htSqlRes.ContainsKey(mod))
            {
                return SqlResource._htSqlRes[mod] as SqlResource;
            }
            else
            {
                SqlResource sqlRes = new SqlResource(mod);
                sqlRes.loadData();
                SqlResource._htSqlRes.Add(mod,sqlRes);
                return sqlRes;
            }
        }
        /// <summary>
        /// </summary>
        private void loadData()
        {
            this._htData.Clear();
            string fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Sql.xml");
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                xmlDoc.Load(fileName);
                XmlNode root = xmlDoc.DocumentElement;
                foreach(XmlNode xNode in root.ChildNodes)
                {
                    if(xNode.Name != "config")
                    {
                        continue;
                    }

                    XmlAttribute attr = xNode.Attributes["module"];
                    if(null == attr)
                    {
                        continue;
                    }

                    if(this._module == xNode.Attributes["module"].Value)
                    {
                        foreach(XmlNode sql in xNode.ChildNodes)
                        {
                            attr = sql.Attributes["key"];
                            if(null == attr || this._htData.ContainsKey(attr.Value))
                            {
                                continue;
                            }
                            string strSql = sql.InnerText.Replace("\r\n"," ").Replace("\t\t\t"," ").Replace("\t\t"," ");
                            strSql = strSql.Replace('\r',' ').Replace('\n',' ').Replace('\t',' ');
                            this._htData.Add(attr.Value,strSql);
                        }
                        break;
                    }
                }
            }
            catch (Exception e)
            {
                this._htData.Clear();
                throw new Exception(""+fileName+"", e);
            }
        }

        private Hashtable _htData;
        private string _module;
        /// <summary>
        /// </summary>
        private SqlResource(string module)
        {
            this._module = module;
            this._htData = new Hashtable();
        }
        /// <summary>
        /// 
        /// </summary>
        public string this[string key]
        {
            get
            {
                return this._htData[key] as string;
            }
        }
        /// <summary>
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetResource(string key)
        {
            return this[key];
        }
    }
}