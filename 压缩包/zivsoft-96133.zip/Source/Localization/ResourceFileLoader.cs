﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Collections;
using System.Globalization;
using System.Diagnostics;

namespace Zivsoft.Localization
{
    /// <summary>
    /// 
    /// </summary>
    class ResourceFileLoader:IXmlConfig
    {
        private Hashtable _has;

        public ResourceFileLoader()
        {
            if (_has == null)
            {
                _has = new Hashtable();
            }
        }

        private XmlNode GetSectionRoot()
        {
            XmlNode node = null;
            try
            {
                node = ConfigurationManager.GetSection("Localization") as XmlNode; //root
            }
            catch (ConfigurationErrorsException e)
            {
                Debug.WriteLine(e);
            }
            finally
            {
                if (null == node)
                {
                    node = Factory.GetConfig();
                }
            }
            return node;
        }

        /// <summary>
        /// The default is CurrentCulture.Name
        /// </summary>
        /// <returns></returns>
        internal string GetCurrentLanguage()
        {
            XmlNode root = GetSectionRoot();
            if (root == null || root.Attributes.Count == 0)
            {
                return CultureInfo.CurrentCulture.Name;
            }
            for (int i = 0, t = root.ChildNodes.Count; i < t; i++)
            {
                var name = root.ChildNodes[i].Name;
                var value = root.ChildNodes[i].InnerText.Trim();
                if (!_has.Contains(name))
                {
                    _has.Add(name, value);
                }
            }
            return root.Attributes[0].Value;
        }

        public string GetFullFilePath()
        {
            var lan = GetCurrentLanguage();
            if (_has.Contains(lan))
            {
                string currentLab = _has[lan] as string;
                if (string.IsNullOrEmpty(currentLab))
                {
                    throw new LocalizationException("Get current language [{0}] failed.",lan);
                }
                return GetFullFilePath(currentLab);
            }
            else
            {
                throw new LocalizationException("Did not config the node [{0}]", lan);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private string GetFullFilePath(string fileName)
        {
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("File can't be found", filePath);
            }
            return filePath;
        }

        #region IXmlConfig Members

        public string LoadFilePathByCulture(string cultureId)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
