﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Permissions;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Zivsoft.Utils")]
[assembly: AssemblyDescription("All frameworks designed by Lihua")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Zivsoft")]
[assembly: AssemblyProduct("Zivsoft \u00AE Solutions Framework")]
[assembly: AssemblyCopyright("Copyright © Zivsoft 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("ce6d08dd-394b-45c5-956e-d33f52a18549")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("0.5.1.2")]
[assembly: AssemblyFileVersionAttribute("2.0.0.9")]
