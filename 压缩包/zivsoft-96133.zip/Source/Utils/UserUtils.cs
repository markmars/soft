using System;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;

namespace Zivsoft.Utils
{
    /// <summary>
    /// </summary>
    public static class UserUtils
    {
        private const string UserId = "user_id";

        public static string GetCurrentUserId()
        {
            return GetCurrentUserId(HttpContext.Current.Session);
        }

        public static string GetCurrentUserId(this HttpSessionState ss)
        {
            return (ss[UserId] as string);
        }

        public static void SetCurrentUserId(this HttpSessionState ss,string userId)
        {
            ss[UserId]=userId;
        }

        public static string GetCurrentUserId(this Page page)
        {
            if(null == page)
            {
                return String.Empty;
            }
            return page.Session[UserId]+"";
        }

        public static void RemoveUserId(this Page page)
        {
            page.Session.Remove(UserId);
        }

        public static void RemoveUserId(this HttpSessionState page)
        {
            page.Remove(UserId);
        }

    }
}