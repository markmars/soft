﻿using System.Collections;

namespace Zivsoft.Utils
{
    /// <summary>
    /// </summary>
    public class ComparerUtils
    {
        public static bool CompareByHashtableKeys(Hashtable ht1, Hashtable ht2)
        {
            if (ht1.Count != ht2.Count)
            {
                return false;
            }
            ICollection key1=ht1.Keys;
            ArrayList al1 = new ArrayList();
            foreach (string key in key1)
            {
                al1.Add(key.Trim());
            }
            al1.Sort();

            ICollection key2 = ht2.Keys;
            ArrayList al2 = new ArrayList();
            foreach (string key in key2)
            {
                al2.Add(key.Trim());
            }
            al2.Sort();

            for (int i = 0, t = al1.Count; i < t; i++)
            {
                string s1 = al1[i].ToString();
                string s2 = al2[i].ToString();
                if (s1!=s2)
                {
                    return false;
                }
            }
            return true;
        }
    }
}