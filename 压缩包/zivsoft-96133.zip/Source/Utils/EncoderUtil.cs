using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Zivsoft.Utils
{
    public static class EncoderUtil
    {

        private static string[] hex = {
                                          "00","01","02","03","04","05","06","07","08","09","0A","0B","0C","0D","0E","0F",
                                          "10","11","12","13","14","15","16","17","18","19","1A","1B","1C","1D","1E","1F",
                                          "20","21","22","23","24","25","26","27","28","29","2A","2B","2C","2D","2E","2F",
                                          "30","31","32","33","34","35","36","37","38","39","3A","3B","3C","3D","3E","3F",
                                          "40","41","42","43","44","45","46","47","48","49","4A","4B","4C","4D","4E","4F",
                                          "50","51","52","53","54","55","56","57","58","59","5A","5B","5C","5D","5E","5F",
                                          "60","61","62","63","64","65","66","67","68","69","6A","6B","6C","6D","6E","6F",
                                          "70","71","72","73","74","75","76","77","78","79","7A","7B","7C","7D","7E","7F",
                                          "80","81","82","83","84","85","86","87","88","89","8A","8B","8C","8D","8E","8F",
                                          "90","91","92","93","94","95","96","97","98","99","9A","9B","9C","9D","9E","9F",
                                          "A0","A1","A2","A3","A4","A5","A6","A7","A8","A9","AA","AB","AC","AD","AE","AF",
                                          "B0","B1","B2","B3","B4","B5","B6","B7","B8","B9","BA","BB","BC","BD","BE","BF",
                                          "C0","C1","C2","C3","C4","C5","C6","C7","C8","C9","CA","CB","CC","CD","CE","CF",
                                          "D0","D1","D2","D3","D4","D5","D6","D7","D8","D9","DA","DB","DC","DD","DE","DF",
                                          "E0","E1","E2","E3","E4","E5","E6","E7","E8","E9","EA","EB","EC","ED","EE","EF",
                                          "F0","F1","F2","F3","F4","F5","F6","F7","F8","F9","FA","FB","FC","FD","FE","FF"
                                      };
        private static byte[] val = {
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,
                                        0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F
                                    };

        public static string DecodeContentAsFile(string encoding, string content, string path)
        {
            if (File.Exists(path)) File.Delete(path);
            FileStream fs = File.Create(path);
            byte[] bs = EncoderUtil.DecodeContent(encoding, content);
            fs.Write(bs, 0, bs.Length);
            fs.Flush();
            fs.Close();
            return path;
        }

        public static string DecodeContent(string charset, string encoding, string content)
        {
            if (encoding == "8bit" || encoding == "7bit") return content;
            Encoding encode = EncoderUtil.GetEncodingByCharset(charset);
            return encode.GetString(EncoderUtil.DecodeContent(encoding, content)).Replace("\0", "");
        }
        /// <summary>
        /// ͨ���ַ�������һ�������Encoding����
        /// �ַ�������Сд��
        /// </summary>
        /// <param name="charset"></param>
        /// <returns></returns>
        private static Encoding GetEncodingByCharset(string charset)
        {
            Encoding encode = Encoding.Default;
            if (charset == "gbk") charset = "gb18030";
            if (charset != null && charset != String.Empty) encode = Encoding.GetEncoding(charset);
            return encode;
        }
        /// <summary>
        /// ���������ı�,������BASE64,QP����
        ///		���ݽ���
        /// </summary>
        public const string STR_REGEX_TEXT = @"\=\?(?<Charset>\S+)\?(?<Encoding>\w)\?(?<Content>\S+)\?\=";
        public const string STR_MUTI = @"\=\?[\S]+\?\=";
        public static string DecodeText(string line)
        {
            int start = line.IndexOf("=?");
            int flag = start;
            while (start >= 0)
            {
                int end = line.IndexOf("?=", flag);
                string raw = String.Empty;
                if (end > start) raw = line.Substring(start, end - start + 2);
                else break;
                Match match = Regex.Match(raw, EncoderUtil.STR_REGEX_TEXT);
                if (match.Success)
                {
                    string temp = String.Empty;
                    string encoding = match.Groups["Encoding"].Value.ToUpper();
                    string charset = match.Groups["Charset"].Value.ToLower();
                    string content = match.Groups["Content"].Value;
                    switch (encoding)
                    {
                        case "B": temp = EncoderUtil.DecodeContent(charset, "base64", content); break;
                        case "Q": temp = EncoderUtil.DecodeContent(charset, "quoted-printable", content); break;
                        default: break;
                    }
                    line = line.Replace(raw, temp);
                }
                else
                {
                    flag = end + 2;
                    continue;
                }
                start = line.IndexOf("=?");
                flag = start;
            }
            return line.Replace("\0", "");
        }

        public static byte[] DecodeContent(string encoding, string content)
        {
            switch (encoding)
            {
                case "7bit": return EncoderUtil.Decode7BitContent(content);
                case "8bit": return EncoderUtil.Decode8BitContent(content);
                case "binary": return EncoderUtil.DecodeBinaryContent(content);
                case "quoted-printable": return EncoderUtil.DecodeQPContent(content);
                case "base64": return EncoderUtil.DecodeBase64Content(content);
                default: return Encoding.Default.GetBytes(content);
            }
        }

        /// <summary>
        /// 7bit����
        /// </summary>
        private static byte[] Decode7BitContent(string content)
        {
            return Encoding.ASCII.GetBytes(content);
        }
        /// <summary>
        /// 8bit����
        /// </summary>
        private static byte[] Decode8BitContent(string content)
        {
            return Encoding.Default.GetBytes(content);
        }
        /// <summary>
        /// Binary����
        /// </summary>
        private static byte[] DecodeBinaryContent(string content)
        {
            return Encoding.Default.GetBytes(content);
        }
        /// <summary>
        /// qp����
        /// </summary>
        private static byte[] DecodeQPContent(string content)
        {
            byte[] bs = new byte[content.Length];
            int index = 0;
            bool todo = false;
            for (int i = 0, size = content.Length; i < size; i++)
            {
                char chF = content[i];
                switch (todo)
                {
                    case false:
                        if (chF == '=') todo = true;
                        else bs[index++] = (byte)chF;
                        break;
                    case true:
                        //�����ǰ����=������ַ���16���ƣ���ѽ���ȡ����������һ���ո���
                        char chS = '\0';
                        if (i < size - 1) chS = content[i + 1];
                        if (EncoderUtil.MayBeQP(chF, chS))
                        {
                            bs[index++] = EncoderUtil.GetQPByte((byte)chF, (byte)chS);
                            i++;
                            todo = false;
                        }
                        else
                        {
                            if (chF != '=')
                            {
                                bs[index++] = (byte)chF;
                                todo = false;
                            }
                        }
                        break;
                }
            }

            //����
            byte[] ret = new byte[index];
            Array.Copy(bs, 0, ret, 0, index);
            bs = null;
            return ret;
        }
        /// <summary>
        /// �Ƿ���16�����ַ�
        /// </summary>
        private static bool MayBeQP(char chF, char chS)
        {
            bool flagF = (chF >= '0' && chF <= '9') || (chF >= 'A' && chF <= 'F');
            bool flagS = (chS >= '0' && chS <= '9') || (chS >= 'A' && chS <= 'F');
            return flagF && flagS;
        }
        /// <summary>
        /// ��QP����Ĺ����������ַ������һ���ֽ�
        /// </summary>
        private static byte GetQPByte(byte bf, byte bs)
        {
            if (bf >= 65) bf -= 55;
            else bf -= 48;
            if (bs >= 65) bs -= 55;
            else bs -= 48;
            return (byte)((bf << 4) | bs);
        }
        /// <summary>
        /// base64����
        /// </summary>
        private static byte[] DecodeBase64Content(string content)
        {
            return System.Convert.FromBase64String(EncoderUtil.TideupB64(content));
            //			byte[] parm = new byte[4];
            //			byte index = 0;
            //			content = ContentDecoder.TideupB64(content);
            //			int size = content.Length;
            //			byte[] ret = new byte[size*3/4];
            //			for(int i=0;i<size;i++)
            //			{
            //
            //				byte temp = (byte)content[i];
            //				if(temp>=65 && temp<=90) temp -= 65;
            //				else if(temp>=97 && temp<=122) temp -= 71;
            //				else if(temp>=48 && temp<=57) temp+=4;
            //				else if(temp==43) temp=62;
            //				else if(temp==47) temp=63;
            //				else if(temp==61) temp=0;
            //				parm[index++] = temp;
            //				if(index%4 == 0)
            //				{
            //					index = 0;
            //					Array.Copy(ContentDecoder.GetB64Byte(parm),0,ret,i/4*3,3);
            //				}
            //			}
            //			return ret;
        }
        /// <summary>
        /// ����Ĳ���Ϊ4���ֽڱ���
        /// </summary>
        //		private static byte[] GetB64Byte(byte[] group)
        //		{
        //			byte[] ret = new byte[3];
        //			byte step = 2;
        //			for(int i=0;i<3;i++)
        //			{
        //				ret[i]=(byte)(group[i]<<step);
        //				step+=2;
        //				ret[i] |= (byte)(group[i+1]>>(8-step));
        //			}
        //			return ret;
        //		}
        /// <summary>
        /// �����Ǳ�׼��BASE64�����ı�
        /// </summary>
        /// <param name="text">Source text</param>
        /// <returns>standard base 64 text</returns>
        private static string TideupB64(string text)
        {
            if (null == text)
            {
                return "";
            }
            //ȥ������Ҫ�Ŀ��ַ�
            text = text.Replace("\0", "");
            //�ж��ַ����ĳ����ܷ�4����.�������,��˵��BASE64������ַ���������.
            //�ȰѲ����λ�ò���'=' ,���ж����4λ�Ƿ��� '=' ,����� ,��ȥ��
            int residual = text.Length % 4;

            //����ܱ�4����,���߲�����=��β,ֱ�ӷ����ַ���
            if (residual == 0)
            {
                return text;
            }

            //�����λ���ϲ��� '='
            for (int i = 4 - residual; i > 0; i--)
            {
                text += "=";
            }

            //�ж����4λ�Ƿ��� '=' ����ȥ��
            if (text.EndsWith("===="))
            {
                text = text.Substring(0, text.Length - 4);
            }

            return text;
        }
    }
}