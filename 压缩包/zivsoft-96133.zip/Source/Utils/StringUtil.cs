using System;
using System.Collections;
/*
 * Created by ziv at 2007-1-12
 */

namespace Zivsoft.Utils
{
    /// <summary>
    /// </summary>
    public static class StringUtil
    {

		public static bool IsNullOrEmpty(this string str)
		{
			return str==null||str.Trim()==String.Empty;
		}

        public static bool IsNullOrEmpty(this string[] array)
        {
            if(array==null||array.Length==0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// </summary>
        public static  Object[] ArrayListToObjectArray(this ArrayList al)
        {
            var obj=new object[al.Count];
            for(var i=0;i<al.Count;i++)
            {
                obj[i] = al[i];
            }
            return obj;
        }
	    
        /// <summary>
        /// </summary>
        public static string[] ArrayListToStringArray(this ArrayList al)
        {
            var obj = new string[al.Count];
            for (int i = 0; i < al.Count; i++)
            {
                obj[i] = al[i]+"";
            }
            return obj;
        }

        /// <summary>
        /// </summary>
        public static string ToSepString(this ICollection collect, object sep)
        {
            if (null == collect)
            {
                return String.Empty;
            }
            if(null == sep)
            {
                sep = ' ';
            }
            string strRet = null;
            foreach (object obj in collect)
            {
                if (null != obj)
                {
                    if (strRet == null)
                    {
                        strRet = obj.ToString();
                    }
                    else
                    {
                        strRet += sep.ToString() + obj.ToString();
                    }
                }
            }
            return strRet;
        }
        /// <summary>
        /// </summary>
        public static string ToSepString(this ICollection collect,object sep,char quote)
        {
            if (null == collect)
            {
                return String.Empty;
            }
            if(null == sep)
            {
                sep = ' ';
            }
            string strRet = String.Empty;
            foreach (object obj in collect)
            {
                if (null != obj)
                {
                    string unit = String.Format("{0}{1}{0}",quote,obj.ToString());
                    if (strRet == String.Empty)
                    {
                        strRet = unit;
                    }
                    else
                    {
                        strRet += sep.ToString() + unit;
                    }
                }
            }
            return strRet;
        }

        /// <summary>
        /// </summary>
        public static ICollection FromSepString(this string str, char sep)
        {
            if(String.IsNullOrEmpty(str))
            {
                return new string[0];
            }
            return str.Split(sep);
        }
        /// <summary>
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string GetFileNameFromPath(this string path)
        {
            if(String.IsNullOrEmpty(path))
            {
                return path;
            }

            int pos = path.LastIndexOfAny(new char[]{'/','\\'});
            if(pos > -1)
            {
                return path.Substring(pos+1);
            }else
            {
                return path;
            }
        }
        /// <summary>
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string GetFilePathFromPath(this string path) {
            if(String.IsNullOrEmpty(path)) {
                return path;
            }

            int pos = path.LastIndexOfAny(new char[]{'/','\\'});
            if(pos > -1) {
                return path.Substring(0,pos);
            }else {
                return String.Empty;
            }
        }
        /// <summary>
        /// </summary>
        public static string GetNameWithoutExt(this string fileName)
        {
            if(String.IsNullOrEmpty(fileName))
            {
                return String.Empty;
            }

            string tmp = StringUtil.GetFileNameFromPath(fileName);
            int pos = tmp.LastIndexOf(".");
            if(pos>-1)
            {
                return tmp.Substring(0,pos);
            }else
            {
                return tmp;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string FilterQuotationAndSlashForHtml(this string text)
        {
            if(String.IsNullOrEmpty(text))
            {
                return text;
            }
            return text.Replace("\"","&#34;").Replace("/","&#47;");
        }
        /// <summary>
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string DecodeToGb2312(this string str)
        {
            if(String.IsNullOrEmpty(str))
            {
                return String.Empty;
            }

            string encoding = "";
            string att = str;
            int begin = att.IndexOf("?=");
            if(begin == -1)
            {
                return str;
            }
            else
            {
                att = att.Replace("?=","");
                int end = att.IndexOf("=?");
                if(end == -1) 
                {
                    return str;
                }
                else
                {
                    att = att.Replace("=?","");	
					
                    begin = att.IndexOf("?",0);
                    if(begin == -1)
                    {
                        return str;
                    }
                    else
                    {
                        encoding = att.Substring(0,begin);
                    }
                    att = att.Replace(encoding+"?","");
                    string flag = att.Substring(0,1);
                    att = att.Replace(flag+"?","");
                    flag = flag.ToLower();
                    if(flag == "b")
                    {
                        byte[] bytes = Convert.FromBase64String(att);
                        att = System.Text.Encoding.GetEncoding(encoding).GetString(bytes);
                    }
                }
            }
            return att;
        }
    }
}