using System;
using System.Collections;
using System.Data;
using System.Globalization;
using System.Text;

/*
 * Created by ziv at 2007-1-8
 */

namespace Zivsoft.Utils
{
    /// <summary>
    /// </summary>
    public partial class SqlUtility
    {
        /// <summary>
        /// <returns></returns>
        public static string CleanSql(string strSql)
        {
            return strSql.Replace("'", "''");
        }
        /// <summary>
        /// </summary>
        /// <param name="strField"></param>
        /// <returns></returns>
        public static string FilterField(string strField)
        {
            if (null == strField)
            {
                return "null";
            }
            return strField.Replace("'", "''");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="fields"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        public static string MakeUpdateSqlByHashtable(string tableName, Hashtable fields, Hashtable where)
        {
            string sqlFormat = "update {0} set {1} where {2}";
            string param0 = tableName;

            IDictionaryEnumerator dict = fields.GetEnumerator();
            ArrayList list = new ArrayList();
            while (dict.MoveNext())
            {
                list.Add(String.Format("{0}='{1}'", dict.Key, dict.Value));
            }
            if (list.Count == 0)
            {
                return String.Empty;
            }
            string param1 = StringUtil.ToSepString(list, ',');

            list.Clear();
            dict = where.GetEnumerator();
            while (dict.MoveNext())
            {
                list.Add(String.Format("{0}='{1}'", dict.Key, dict.Value));
            }
            string param2 = StringUtil.ToSepString(list, " and ");

            if (String.IsNullOrEmpty(param2))
            {
                param2 = "1=1";
            }

            return String.Format(sqlFormat, param0, param1, param2);
        }
        public static string FilterAlias(string alias)
        {
            if (null == alias)
            {
                return String.Empty;
            }
            return alias.Replace('.', '_');
        }

        public string GetTableName(string sql)
        {
            sql = sql.ToLower();
            int i = sql.IndexOf("where");
            if (i != -1)
            {
                sql = sql.Remove(i, sql.Length - i);
            }
            i = sql.IndexOf("from");
            if (i != -1)
            {
                sql = sql.Remove(0, i);
            }
            sql = sql.Replace("from", "").Trim();
            return sql;
        }

        public string GetInsertSql(DataTable dt)
        {
            string strSql = "insert " + dt.TableName + " (";
            string strSqlResult = null;
            DataView dv = dt.DefaultView;
            if (dv != null)
            {
                dt = dv.Table;
                for (int col = 0, t = dt.Columns.Count; col < t; col++)
                {
                    strSql += dt.Columns[col].Caption;
                    if (col < t - 1)
                    {
                        strSql += ",";
                    }
                    if (col == t - 1)
                    {
                        strSql += ")";
                    }
                }
                strSql += " values('";
                strSqlResult = strSql;
                for (int row = 0, t = dt.Rows.Count; row < t; row++)
                {
                    for (int col = 0, k = dt.Columns.Count; col < k; col++)
                    {
                        object objValue = dt.Rows[row][col];
                        if (objValue == DBNull.Value)
                        {
                            strSqlResult = strSqlResult.Remove(strSqlResult.Length - 1, 1);
                            strSqlResult += "null";
                            if (col < k - 1)
                            {
                                strSqlResult += ",'";
                            }
                            if (col == k - 1)
                            {
                                strSqlResult += ");\r\n";
                            }
                        }
                        else
                        {
                            strSqlResult += objValue;
                            if (col < k - 1)
                            {
                                strSqlResult += "','";
                            }
                            if (col == k - 1)
                            {
                                strSqlResult += "');\r\n";
                            }
                        }
                    }
                    if (row < t - 1)
                    {
                        strSqlResult += strSql;
                    }
                }
            }
            return strSqlResult;
        }

        public static string filterField(string strField)
        {
            if (null == strField)
            {
                return "null";
            }
            return strField.Replace("'", "''");
        }
        public string filterSql(string sql)
        {
            return SqlUtility.cleanSql(sql);
        }
        public static string cleanSql(string sql)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="fields"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        public static string makeUpdateSqlByHashtable(string tableName, Hashtable fields, Hashtable where)
        {
            string sqlFormat = "update {0} set {1} where {2}";
            string param0 = tableName;
            IDictionaryEnumerator dict = fields.GetEnumerator();
            ArrayList list = new ArrayList();
            while (dict.MoveNext())
            {
                list.Add(String.Format("{0}='{1}'", dict.Key, dict.Value));
            }
            if (list.Count == 0)
            {
                return String.Empty;
            }
            string param1 = StringUtil.ToSepString(list, ',');
            list.Clear();
            dict = where.GetEnumerator();
            while (dict.MoveNext())
            {
                list.Add(String.Format("{0}='{1}'", dict.Key, dict.Value));
            }
            string param2 = StringUtil.ToSepString(list, " and ");

            if (StringUtil.IsNullOrEmpty(param2))
            {
                param2 = "1=1";
            }

            return String.Format(sqlFormat, param0, param1, param2);
        }
        public static string WrapSql(string rawSql, ArrayList alParams)
        {
            if (StringUtil.IsNullOrEmpty(rawSql))
            {
                return string.Empty;
            }
            int num1 = 0;
            int num2 = rawSql.IndexOf('?');
            int num3 = 0;
            StringBuilder builder1 = new StringBuilder();
            while (num2 >= 0)
            {
                builder1.Append(rawSql.Substring(num1, num2 - num1));
                builder1.Append(SqlUtility.MakeParam(num3, alParams));
                num1 = num2 + 1;
                num2 = rawSql.IndexOf('?', num1);
                num3++;
            }
            builder1.Append(rawSql.Substring(num1));
            return builder1.ToString();
        }
        protected static string MakeParam(int paramIndex, ArrayList alParams)
        {
            if (paramIndex < alParams.Count)
            {
                object obj1 = alParams[paramIndex];
                if (obj1 == null)
                {
                    return "null";
                }
                if (obj1 is ArrayList)
                {
                    StringBuilder builder1 = new StringBuilder();
                    ArrayList list1 = obj1 as ArrayList;
                    int num1 = 0;
                    int num2 = list1.Count;
                    while (num1 < num2)
                    {
                        builder1.Append(SqlUtility.MakeParam(num1, list1));
                        builder1.Append(",");
                        num1++;
                    }
                    if (builder1.Length > 0)
                    {
                        builder1.Remove(builder1.Length - 1, 1);
                        return builder1.ToString();
                    }
                    return "''";
                }
                if (obj1 is DateTime)
                {
                    DateTime time1 = (DateTime)obj1;
                    return string.Format("'{0}'", time1.ToString("s", DateTimeFormatInfo.CurrentInfo));
                }
                if (obj1 is bool)
                {
                    if ((bool)obj1)
                    {
                        return "'1'";
                    }
                    return "'0'";
                }
                if ((obj1 is string) || (obj1 is char))
                {
                    return string.Format("'{0}'", obj1);
                }
                if (((obj1 is int) || (obj1 is double)) || ((obj1 is byte) || (obj1 is decimal)))
                {
                    return obj1.ToString();
                }
            }
            return "null";
        }
    }
}