﻿using System;
using Microsoft.Win32;

/***************************
 * 
 * 
 * 
 ***************************/

namespace Zivsoft.Utils
{
    /// <summary>
    /// 
    /// </summary>
    public static class GACUtil
    {

        public static void RegisterSDK()
        {
            var sdkName = "Zivsoft SDK";
            var regkeyname = @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\.NETFramework\AssemblyFolders\{0}";
            var keyuser = @"HKEY_CURRENT_USER\SOFTWARE\Microsoft\.NETFramework\AssemblyFolders\{0}";
            AddRegister(string.Format(regkeyname,sdkName));
            AddRegister(string.Format(keyuser, sdkName));
        }

        /// <summary>
        /// Add reference of Zivsoft
        /// </summary>
        private static void AddRegister(string regkeyname)
        {
            try
            {
                var path = AppDomain.CurrentDomain.BaseDirectory;
                if (!string.IsNullOrEmpty(path))
                {
                    Registry.SetValue(regkeyname, null, path);
                }
                else
                {
                    
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}