﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Utils
{
    public static class MathUtil
    {
        /// <summary>
        /// Convert decimal number to y=2^n1+2^n2+……
        /// </summary>
        /// <param name="number">type:long</param>
        /// <returns>note: return the string not the number</returns>
        public static string ConvertToBinaryPower(this long number)
        {
            //convert number to binary string
            var strBinary = Convert.ToString(number, 2);
            //define the result
            var strResult = number + "=";
            for (int i = strBinary.Length - 1, j = 0; i >= 0; i--, j++)
            {
                if (strBinary[i] == 49)//49 here is '1'
                {
                    strResult += "2^" + j;
                    if (i > 0)//if is the last one, need not add '+'
                    {
                        strResult += "+";
                    }
                }
            }
            return strResult;
        }

        /// <summary>
        /// Convert decimal number to binary number
        /// </summary>
        /// <param name="number">decimal number</param>
        /// <returns>return the binary number (type:string)</returns>
        public static string ConvertDecimalToBinary(this long number)
        {
            long[] temp = new long[100];//as the type is long, the length 100 is enough
            //if 0, will not be converted
            if (number == 0) return (number.ToString());
            var i = 0;
            while (number != 0)
            {
                temp[i++] = number % 2;
                number /= 2;
            }
            var strBinary = "";
            for (var j = 0; j <= i - 1; j++)
                strBinary += (char)(temp[i - j - 1] + 48);//48 here means the char '0'
            return (strBinary);
        }

    }
}
