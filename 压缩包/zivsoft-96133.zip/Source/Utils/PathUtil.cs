﻿using System;
using System.Diagnostics;
using System.Web;
using System.Web.UI.WebControls;
/*
 * 
 */

namespace Zivsoft.Utils
{
    public class PathUtil
    {

        private string _path;
        /// <summary>
        /// </summary>
        /// <param name="path"></param>
        public PathUtil(string path)
        {
            this._path = path;
        }
        /// <summary>
        /// </summary>
        /// <returns></returns>
        public string[] GetFolders()
        {
            string[] dirs = { };
            try
            {
                dirs = System.IO.Directory.GetDirectories(this._path);
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }
            return dirs;
        }
        /// <summary>
        /// </summary>
        /// <returns></returns>
        public string[] GetFiles()
        {
            string[] files = { };
            try
            {
                files = System.IO.Directory.GetFiles(this._path);
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }
            return files;
        }

        private HttpRequest _request;
        private PlaceHolder _placeHolder;
        public PathUtil(HttpRequest request, PlaceHolder placeHolder)
        {
            this._request = request;
            this._placeHolder = placeHolder;
        }

        public void Load()
        {
            string virtualPath = _request.PhysicalApplicationPath;
            this.ShowDirs(virtualPath);

        }

        private void ShowDirs(string path)
        {
            HyperLink hl = new HyperLink();
            hl.ID = "hLink_" + Guid.NewGuid().ToString();
            hl.NavigateUrl = _request.Url.Host + ":" + _request.Url.Port;
            hl.Text = path + "<br/>";
            PathUtil p = new PathUtil(path);
            string[] dirs = p.GetFolders();
            for (int i = 0, t = dirs.Length; i < t; i++)
            {
                if (System.IO.Directory.Exists(dirs[i]))
                {
                    ShowDirs(dirs[i]);
                    this.ShowFiles(dirs[i]);
                }
            }
        }
        private void ShowFiles(string path)
        {
            PathUtil p = new PathUtil(path);
            string[] files = p.GetFiles();
            for (int i = 0, t = files.Length; i < t; i++)
            {
                HyperLink hl = new HyperLink();
                hl.ID = "hLink_" + Guid.NewGuid().ToString();
                hl.NavigateUrl = "http://" + this._request.Url.Host + ":" + this._request.Url.Port + "/" + files[i].Replace(this._request.PhysicalApplicationPath, "");
                hl.Text = files[i].Replace(this._request.PhysicalApplicationPath, "") + "<br/>";
                this._placeHolder.Controls.Add(hl);
            }
        }
    }
}