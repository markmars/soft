﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace Zivsoft.Utils
{
    ///   <summary>   
    ///   
    ///   </summary>   
    public static class CaptureFormUtil 
    {
        [DllImportAttribute("gdi32.dll")]
        private static extern bool BitBlt(
            IntPtr hdcDest,
            int nXDest,
            int nYDest,
            int nWidth,
            int nHeight,
            IntPtr hdcSrc,
            int nXSrc,
            int nYSrc,
            Int32 dwRop
            );

        [DllImportAttribute("gdi32.dll")]
        private static extern IntPtr CreateDC(
            string lpszDriver,
            string lpszDevice,
            string lpszOutput,
            IntPtr lpInitData
            );

        public static void Capture(string file)
        {
            var dc1 = CreateDC("DISPLAY", null, null, (IntPtr)null);
            var g1 = Graphics.FromHdc(dc1);
            var MyImage = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, g1);
            var g2 = Graphics.FromImage(MyImage);
            var dc3 = g1.GetHdc();
            var dc2 = g2.GetHdc();
            BitBlt(dc2, 0, 0, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, dc3, 0, 0, 13369376);
            g1.ReleaseHdc(dc3);
            g2.ReleaseHdc(dc2);
            MyImage.Save(file, ImageFormat.Jpeg);
        }
    }
}