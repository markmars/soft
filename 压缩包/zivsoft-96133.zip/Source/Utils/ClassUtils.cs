using System;
using System.Reflection;
using System.Runtime.Remoting;

/**
 * 
 * Created By Lihua At 2006-05-08
 * 
 */

namespace Zivsoft.Utils
{
    /// <summary>
    /// </summary>
    public class ClassUtils
    {
        /// <summary>
        /// </summary>
        /// <param name="assembly"></param>
        /// <param name="className"></param>
        /// <returns></returns>
        public static object GenInstance(string assembly, string className)
        {
            try
            {
                string dllPath = FileUtils.CombinePath(AppDomain.CurrentDomain.BaseDirectory, @"bin/" + assembly);
                ObjectHandle objHandle = Activator.CreateInstanceFrom(dllPath, className);
                return objHandle.Unwrap();
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="assembly"></param>
        /// <param name="className"></param>
        /// <param name="methodName"></param>
        /// <returns></returns>
        public static MethodInfo GetMethod(string assembly, string className, string methodName)
        {
            try
            {
                string dllPath = FileUtils.CombinePath(AppDomain.CurrentDomain.BaseDirectory, @"bin/" + assembly);
                return Assembly.LoadFrom(dllPath).GetType(className).GetMethod(methodName);
            }
            catch
            {
                return null;
            }

        }
    }
}