﻿using System;
using System.Collections.Generic;
using System.Text;
/*
 * 
 * Created by ziv at 2008-8-28
 */
namespace Zivsoft.Data
{
    /// <summary>
    /// 数据库类型
    /// </summary>
    public enum EDatabaseType
    {
        Access,
        MySQL,
        Oracle,
        SQLServer,
        Unknown
    }
}
