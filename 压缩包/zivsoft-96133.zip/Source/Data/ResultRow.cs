using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Zivsoft.Data
{
    /// <summary>
    /// </summary>
    public class ResultRow
    {
        protected Hashtable _htRow;
        /// <summary>
        /// </summary>
        public ResultRow()
        {
            this._htRow = new Hashtable();
        }
        /// <summary>
        /// </summary>
        public object this[string colName]
        {
            get
            {
                if (null == colName)
                {
                    return null;
                }
                return this._htRow[colName];
            }
            set
            {
                if (this._htRow.ContainsKey(colName))
                {
                    this._htRow[colName] = value;
                }
                else
                {
                    this._htRow.Add(colName, value);
                }
            }
        }
        /// <summary>
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static implicit operator Hashtable(ResultRow row)
        {
            return row._htRow;
        }
        /// <summary>
        /// return by hashtable
        /// </summary>
        /// <returns></returns>
        public Hashtable AsHashtable()
        {
            return this._htRow;
        }
    }
}
