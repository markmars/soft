using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Zivsoft.Data;

namespace Zivsoft.Data
{
    /// <summary>
    /// Generic column
    /// </summary>
    public class ColumnAttribute:BaseField
    {
        public ColumnAttribute(string columnName,DbType dbType)
        {
            this.FieldName = columnName;
            this.DbType = dbType;
        }
    }
}
