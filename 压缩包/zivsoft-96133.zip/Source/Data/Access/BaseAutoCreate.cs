﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
/*
 * Created by ziv at 2007-2-3
 * ORM SqlServer SQL
 */
namespace Zivsoft.Data.Access
{
    /// <summary>
    /// Auto create table
    /// </summary>
    abstract class  BaseAutoCreate
    {
        /// <summary>
        /// conn
        /// </summary>
        /// <returns></returns>
        public abstract string GetShortConnectionString();
    }
}
