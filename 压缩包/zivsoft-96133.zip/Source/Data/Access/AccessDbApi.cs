﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using Zivsoft.Log;
/*
 * Author:Lihua Zhou 
 * Date:2007-12-7
 * Function:Entry for Access, this is the core db operator
 */
namespace Zivsoft.Data.Access
{
    /// <summary>
    /// db access class, it is a big class can do all operations
    /// </summary>
    class AccessDbApi
    {
        /// <summary>
        /// Sqlconnection
        /// Note that static is not permitted here, because multi users will use this
        /// </summary>
        private OleDbConnection _connection;
        /// <summary>
        /// 
        /// </summary>
        private string _connectionString=DbFactory.GetDefaultConnectionString();
        /// <summary>
        /// 
        /// </summary>
        private static int _transNum;
        private OleDbDataAdapter _sqlAda;
        private DataSet _ds;
        private DataRow _datarow;
        private OleDbCommand _command;

        private static OleDbTransaction[] _transaction = new OleDbTransaction[8];
        /// <summary>
        /// 
        /// </summary>
        public IDbCommand Command
        {
            set
            {
                this._command = value as OleDbCommand;
            }
            get
            {
                return this._command;
            }
        }
        /// <summary>
        /// Core db access: Auto create db/table is here
        /// </summary>
        public AccessDbApi()
        {
            if (_connection == null)
            {
                _connection = new OleDbConnection(this._connectionString);
                _connection.Open();
            }
            else
            {
                if (_connection.State == ConnectionState.Closed)
                {
                    try
                    {
                        _connection.Open();
                    }
                    catch
                    {
                        throw new Exception(string.Format("Open database failed: {0}",_connectionString));
                    }
                }
                else
                {
                    _connection.Close();
                    _connection.Open();
                }
            }
        }


        /// <summary>
        /// Close database
        /// </summary>
        private void Close()
        {
            if (_connection.State != ConnectionState.Closed)
            {
                _connection.Close();
            }
        }
        /// <summary>
        /// start transaction
        /// </summary>
        public void BeginTransaction()
        {
            _transaction[++_transNum] = _connection.BeginTransaction();
        }
        /// <summary>
        /// do
        /// </summary>
        public void Commit()
        {
            _transaction[_transNum--].Commit();
        }
        /// <summary>
        /// rollback the last step do
        /// </summary>
        public void Rollback()
        {
            _transaction[_transNum--].Rollback();
        }
        /// <summary>
        /// </summary>
        /// <param name="sql">select-sql</param>
        /// <returns>ResultSet</returns>
        public IResultSet Query4ResultSet(string sql)
        {
            //if connect
            if (null == _connection)
            {
                return ResultSet.Empty;
            }
            IDbCommand cmd = _connection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sql;
            IDataReader reader = cmd.ExecuteReader();
            return this.GetResultSetFromReader(reader);
        }
        /// <summary>
        /// 
        /// </summary>
        private IResultSet GetResultSetFromReader(IDataReader reader)
        {
            ResultSet resSet = new ResultSet(reader);
            return resSet;
        }
        /// <summary>
        /// a item data, and put into a hashtable
        /// </summary>
        /// <param name="sql">select-sql</param>
        /// <returns>return hashtable</returns>
        public Hashtable Query4Hashtable(string sql)
        {
            IResultSet rs = this.Query4ResultSet(sql);
            Hashtable ht = new Hashtable();
            if (rs.Next())
            {
                for (int i = 0; i < rs.GetCols(); i++)
                {
                    ht.Add(rs.GetColName(i), rs.GetValue(i));
                }
            }
            return ht;
        }
        /// <summary>
        /// Insert by hashtable
        /// </summary>
        /// <param name="tableName">tablename</param>
        /// <param name="values">(field-value) format</param>
        /// <returns></returns>
        public int Insert(string tableName, Hashtable values)
        {
            //param check
            if (null == tableName || null == values || values.Count == 0)
            {
                return 0;
            }
            string sqlPattern = "insert into {0}({1}) values({2})";
            string fields = null;
            string vs = null;
            IDictionaryEnumerator dicEnum = values.GetEnumerator();
            while (dicEnum.MoveNext())
            {
                fields += dicEnum.Key + ",";
                if (dicEnum.Value + "" == "")
                {
                    vs += "null,";
                }
                else
                {
                    vs += "'" + dicEnum.Value + "',";
                }
            }
            //erase the last ','
            fields = fields.Remove(fields.Length - 1, 1);
            vs = vs.Remove(vs.Length - 1, 1);
            return this.ExcuteSql(String.Format(sqlPattern, tableName, fields, vs));
        }
        /// <summary>
        /// rollback all operations
        /// </summary>
        private static void RollbackAll()
        {
            while (_transNum > 0) _transaction[_transNum--].Rollback();
        }
        /// <summary>
        /// Create command
        /// </summary>
        /// <param name="cmdstr"></param>
        public void CreateCommand(string cmdstr)
        {
            Command = new OleDbCommand(cmdstr, _connection, _transaction[_transNum]);
        }
        public void Prepare()
        {
            Command.Prepare();
        }

        public int ExecuteNonQuery(string cmdstr)
        {
            OleDbCommand cmd = this._command;
            if (cmdstr != null) cmd = new OleDbCommand(cmdstr, _connection, _transaction[_transNum]);
            return cmd.ExecuteNonQuery();
        }

        public object ExecuteScalar(string cmdstr)
        {
            OleDbCommand cmd = _command;
            if (cmdstr != null) cmd = new OleDbCommand(cmdstr, _connection, _transaction[_transNum]);
            return cmd.ExecuteScalar();
        }
        /// <summary>
        /// GetData
        /// </summary>
        /// <param name="dataReader">DataReader</param>
        /// <param name="objItemBase">ORMObject</param>
        public void GetData(IDataReader dataReader, IItemBase objItemBase)
        {
            int columnCount = dataReader.FieldCount;
            //objItemBase.InterId = dataReader.GetValue(0);
            for (int i = 1; i < columnCount; i++)
            {
                object v = dataReader.GetValue(i);
                if (v == DBNull.Value) v = null;
                //objItemBase[dataReader.GetName(i)] = v;
                objItemBase.SetValue(dataReader.GetName(i), v);
            }
        }

        /// <summary>
        /// select
        /// </summary>
        /// <typeparam name="DataItem"></typeparam>
        /// <param name="cmdstr"></param>
        /// <returns></returns>
        public List<DataItem> Select<DataItem>(string cmdstr) where DataItem : IItemBase, new()
        {
            OleDbCommand cmd = _command;
            if (cmdstr != null) cmd = new OleDbCommand(cmdstr, _connection, _transaction[_transNum]);
            using (OleDbDataReader res = cmd.ExecuteReader())
            {
                List<DataItem> a = new List<DataItem>();
                while (res.Read())
                {
                    DataItem di = new DataItem();
                    GetData(res, di);
                    a.Add(di);
                }
                return a;
            }
        }
        public List<ValueText> Select(string cmdstr)
        {
            OleDbCommand cmd = _command;
            if (cmdstr != null) cmd = new OleDbCommand(cmdstr, _connection, _transaction[_transNum]);
            using (OleDbDataReader res = cmd.ExecuteReader())
            {
                List<ValueText> a = new List<ValueText>();
                if (res.FieldCount > 1)
                {
                    while (res.Read())
                    {
                        object v = res.GetValue(1);
                        a.Add(new ValueText(res.GetValue(0), v == DBNull.Value ? null : v.ToString()));
                    }
                }
                else
                {
                    while (res.Read())
                    {
                        a.Add(new ValueText(res.GetValue(0), null));
                    }
                }
                return a;
            }
        }
        public DataSet Query4DataSet(string strSql)
        {
            OleDbDataAdapter dp = new OleDbDataAdapter();
            CreateCommand(strSql);
            dp.SelectCommand = _command;
            DataSet ds = new DataSet();
            try
            {
                dp.Fill(ds);
            }
            catch (Exception err)
            {
                Logger.LogError(err);
            }
            return ds;
        }

        public SqlParam AddParam(string name, object value)
        {
            OleDbParameter p = new OleDbParameter(name, value != null ? value : DBNull.Value);
            Command.Parameters.Add(p);
            SqlParam stuSql = new SqlParam(p);
            return stuSql;
        }

        /// <summary>
        /// Insert SQL by ORM Object
        /// </summary>
        /// <param name="tbl_name">table name</param>
        /// <param name="di">orm table object</param>
        /// <param name="tbl_key">primary key name</param>
        /// <returns>if return -1, then it gets exception.</returns>
        public int Insert(string tbl_name, IOrmTable di, string tbl_key)
        {
            object innerId = di.Fields[tbl_key];
            if (innerId == null)
            {
                //return exception
                return -1;
            }

            StringBuilder sb0 = new StringBuilder();
            StringBuilder sb1 = new StringBuilder();

            sb0.Append("insert into " + tbl_name + " (" + tbl_key);
            sb1.Append(") values('" + innerId + "'");
            foreach (KeyValuePair<string, object> f in di.Fields)
            {
                if (f.Key != tbl_key)
                {
                    sb0.Append("," + f.Key);
                    sb1.Append(",'" + f.Value + "'");
                }
            }
            sb0.Append(sb1.ToString() + ");");
            sb0.Append("select " + tbl_key + " from " + tbl_name + " where " + tbl_key + "='" + innerId + "'");
            OleDbCommand cmd = new OleDbCommand(sb0.ToString(), _connection);
            foreach (KeyValuePair<string, object> f in di.Fields)
            {
                cmd.Parameters.AddWithValue("@" + f.Key, f.Value);
            }
            int i = 0;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw new Exception(string.Format("[SQL]:{0},[Error]:{1}", cmd.CommandText, e));
            }
            return i;
        }
        /// <summary>
        /// 
        /// </summary>
        public int Insert(IOrmTable objTable)
        {
            string keyName = objTable.GetPKName()[0] + "";
            //objTable.InterId = objTable.Fields[keyName];
            if (keyName == null || keyName.Trim() == "")
            {
                
            }
            return this.Insert(objTable.GetName(), objTable, keyName);
        }

        /// <summary>
        /// 关于ACCESS数据库的更新操作
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="di"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public int Update(string tableName, IItemBase di, string key)
        {
            StringBuilder sb0 = new StringBuilder();
            sb0.Append("UPDATE ");
            sb0.Append(tableName);
            sb0.Append(" SET ");
            foreach (KeyValuePair<string, object> f in di.Fields)
            {
                sb0.Append(f.Key);
                sb0.Append('=');
                sb0.Append('@');
                sb0.Append(f.Key);
                sb0.Append(',');
            }
            sb0.Length--;
            sb0.Append(" WHERE " + key + "=@"+key);
            OleDbCommand cmd = new OleDbCommand(sb0.ToString(), _connection, _transaction[_transNum]);
            foreach (KeyValuePair<string, object> f in di.Fields)
            {
                cmd.Parameters.Add(new OleDbParameter('@' + f.Key, f.Value != null ? f.Value : DBNull.Value));
            }
            cmd.Parameters.Add(new OleDbParameter("@"+key, di.Fields[key]));
            return cmd.ExecuteNonQuery();
        }
        /// <summary>
        /// 
        /// </summary>
        public int Update(IOrmTable objTable)
        {
            string keyName = objTable.GetPKName()[0] + "";
            if (keyName == null || keyName.Trim() == "")
            {
                throw new Exception("DbApi-Update: Primary key is unknown.");
            }
            return this.Update(objTable, keyName);
        }
        public int Update(IItemBase di, string key)
        {
            return Update(di.GetName(), di, key);
        }
        private int Delete(string tbl, object key)
        {
            OleDbCommand cmd = new OleDbCommand("DELETE FROM " + tbl + " WHERE " + key + "=@"+key, _connection, _transaction[_transNum]);
            cmd.Parameters.Add(new OleDbParameter("@"+key, key));
            return cmd.ExecuteNonQuery();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objTable"></param>
        /// <returns>If returns -1, it means here gets a sql exception.</returns>
        public int DeleteAItemBase(IItemBase objTable)
        {
            string pk = objTable.GetPKName()[0] + "";
            object interId = objTable.Fields[pk];
            OleDbCommand cmd = new OleDbCommand("delete from " + objTable.GetName() + " where " + pk + "=@" + pk, _connection, _transaction[_transNum]);
            cmd.Parameters.Add(new OleDbParameter("@" + pk, interId));

            int i = 0;
            try
            {
                i = cmd.ExecuteNonQuery();
            }
            catch (OleDbException e)
            {
                i = -1;
                Logger.LogError(e);
            }
            return i;
        }
        /// <summary>
        /// 
        /// </summary>
        public int DeleteBaseTable(IOrmTable objTable)
        {
            string pkName = objTable.GetPKName()[0] + "";
            object pkValue = objTable.Fields[pkName];
            string tableName = objTable.GetName();
            string sql = "delete {0} where {1}='{2}'";
            sql = string.Format(sql, tableName, pkName, pkValue);
            return this.ExcuteSql(sql);
        }

        /// <summary>
        /// This is the common method for all db operations
        /// </summary>
        /// <returns>if return -1, here means exception was thrown</returns>
        public int ExcuteSql(string sql)
        {
            int iFlag = 0;
            OleDbCommand cmd = new OleDbCommand(sql, _connection);
            try
            {
                iFlag = cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                Debug.WriteLine(err);
                iFlag = -1;
                throw err;
            }
            return iFlag;
        }
        
        /// <summary>
        /// 
        /// </summary>
        public DataTable Query4DataTable(string strSql)
        {
            OleDbDataAdapter ada = new OleDbDataAdapter(strSql, _connection);
            DataSet ds = new DataSet();
            try
            {
                ada.Fill(ds);
            }
            catch (Exception err)
            {
                Close();
                throw err;
            }
            DataTable dt = ds.Tables[0];
            return dt;
        }
        #region Query4Value
        /// <summary>
        /// Get a value for a field
        /// </summary>
        public string Query4Value(string strSql)
        {
            return Query4Value(strSql, 0, 0);
        }

        public string Query4Value(string strSql, int columnIndex)
        {
            return Query4Value(strSql, 0, columnIndex);
        }

        private string Query4Value(string strSql,int rowIndex, int columnIndex)
        {
            DataTable dt = this.Query4DataTable(strSql);
            if (dt.Rows.Count >rowIndex)
            {
                object o = dt.Rows[rowIndex][columnIndex];
                if (o == null)
                {
                    return null;
                }
                else
                {
                    return dt.Rows[rowIndex][columnIndex] + "";
                }
            }
            else {
                return null;
            }
        }
        #endregion
        /// <summary>
        /// return DataSet
        /// </summary>
        public DataSet Query4DataSet(IItemBase objItemBase)
        {
            string tableName = objItemBase.GetName();
            DataTable dt = this.Query4DataTable("select * from " + tableName);
            return dt.DataSet;
        }
        /// <summary>
        /// Get all item count in database
        /// </summary>
        public int GetAllCount(string tableName)
        {
            string sql = "select count(*) from {0} where 1=1";
            sql = string.Format(sql, tableName);
            return Convert.ToInt32(this.Query4Value(sql));
        }

        /// <summary>
        /// return item count by sql
        /// </summary>
        public int GetCount(string strSql)
        {
            DataTable dt = this.Query4DataTable(strSql);
            if (dt == null)
            {
                return 0;
            }
            return dt.Rows.Count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns>return IDataReader</returns>
        public IDataReader Query4DataReader(string strSql)
        {
            OleDbCommand cmd = new OleDbCommand(strSql, _connection, _transaction[_transNum]);
            OleDbDataReader dataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            return dataReader;
        }
        /// <summary>
        /// update DataRow
        /// </summary>
        public void UpdateDataRow()
        {
            this._ds.Tables[0].Rows.Add(this._datarow);
            this._sqlAda.Update(this._ds);
            this._ds.Clear();
        }
        /// <summary>
        /// return DataRow
        /// </summary>
        /// <param name="strSql">select-sql</param>
        /// <returns>return DataRow</returns>
        public DataRow Query4DataRow(string strSql)
        {
            this._sqlAda = new OleDbDataAdapter(strSql, _connection);
            OleDbCommandBuilder myCommandBuilder = new OleDbCommandBuilder(this._sqlAda);
            this._ds = new DataSet();
            this._sqlAda.Fill(this._ds);
            this._datarow = this._ds.Tables[0].NewRow();
            return this._datarow;
        }
        /// <summary>
        /// Create table for new database
        /// </summary>
        /// <param name="baseItem">orm object</param>
        /// <returns>result</returns>
        internal int CreateDbTable(IItemBase baseItem)
        {
            //sql
            string tableName = baseItem.GetName();
            StringBuilder sb = new StringBuilder("CREATE TABLE [" + tableName + "]\r\n");
            sb.Append("(\r\n");
            Hashtable htCols = baseItem.GetAllColumn();
            ICollection keys = htCols.Keys;
            foreach (string key in keys)
            {
                BaseField colProperty = (BaseField)htCols[key];
                sb.Append(key + " " + DbTypeConvert.GetDbType(colProperty.DbType, colProperty.Length) + ",\r\n");
            }
            sb.Append("PRIMARY KEY(");
            //Get primary key
            Hashtable htPk = baseItem.GetPKColumn();
            ICollection pKeys = htPk.Keys;
            foreach (string key in pKeys)
            {
                DbType dbType = (DbType)htPk[key];
                sb.Append(key + ",");
            }
            sb.Length--;
            sb.Append(")\r\n");
            sb.Append(") ");

            //do
            return this.ExcuteSql(sb.ToString());
        }
        /// <summary>
        /// Create table
        /// </summary>
        /// <param name="ormTable"></param>
        /// <returns></returns>
        internal int CreateDbTable(IOrmTable ormTable)
        {
            return 0;
        }


      
    }
}
