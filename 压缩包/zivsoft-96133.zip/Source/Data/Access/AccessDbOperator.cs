﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;



namespace Zivsoft.Data.Access
{
    /// <summary>
    /// ACCESS Db Operation
    /// </summary>
    class AccessDbOperator:IDbOperator
    {
        private AccessDbApi dbi=null;
        /// <summary>
        /// Core
        /// </summary>
        protected AccessDbApi operate
        {
            get
            {
                if (this.dbi == null)
                {
                    try
                    {
                        this.dbi = new AccessDbApi();
                    }
                    catch (Exception err)
                    {
                        throw err;
                    }
                }
                return this.dbi;
            }
            set
            {
                this.dbi = value;
            }
        }

        #region IDbOperator members

        public void BeginTransaction()
        {
            operate.BeginTransaction();
        }

        public void Commit()
        {
            operate.Commit();
        }

        public bool Delete(string tableName)
        {
            string sql = "drop table " + tableName;
            int i = this.operate.ExcuteSql(sql);
            if (i == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public int Delete(object obj)
        {
            if (obj is IItemBase)
            {
                return operate.DeleteAItemBase(obj as IItemBase);
            }
            else if (obj is IOrmTable)
            {
                return operate.DeleteBaseTable(obj as IOrmTable);
            }
            else
            {
                throw new Exception("Do not suport " + obj.GetType());
            }
        }

        public int ExecuteSql(string sql)
        {
            return operate.ExcuteSql(sql);
        }

        public int GetCount(string sql)
        {
            return operate.GetCount(sql);
        }

        public int Insert(object ormTable)
        {
            if (ormTable is IOrmTable)
            {
                return operate.Insert(ormTable as IOrmTable);
            }
            else
            {
                throw new Exception("Do not support type " + ormTable.GetType());
            }
        }

        public int Insert(string tableName, Hashtable values)
        {
            //check
            if (null == tableName || null == values || values.Count == 0)
            {
                return 0;
            }
            string sqlPattern = "insert into {0}({1}) values({2})";
            string fields = null;
            string vs = null;
            IDictionaryEnumerator dicEnum = values.GetEnumerator();
            while (dicEnum.MoveNext())
            {
                fields += dicEnum.Key + ",";
                if (dicEnum.Value + "" == "")
                {
                    vs += "null,";
                }
                else
                {
                    vs += "'" + dicEnum.Value + "',";
                }
            }
            //erase the ','
            fields = fields.Remove(fields.Length - 1, 1);
            vs = vs.Remove(vs.Length - 1, 1);
            return this.ExecuteSql(String.Format(sqlPattern, tableName, fields, vs));
        }

        public IDataReader Query4DataReader(string strSql)
        {
            return this.operate.Query4DataReader(strSql);
        }

        public DataRow Query4DataRow(string strSql)
        {
            return operate.Query4DataRow(strSql);
        }

        public DataSet Query4DataSet(object obj)
        {
            if (obj is string)
            {
                return operate.Query4DataSet(obj.ToString());
            }
            else if (obj is IItemBase)
            {
                return operate.Query4DataSet(obj as IItemBase);
            }
            else
            {
                throw new Exception("SqlServerDbOperator-Query4DataSet: not found " + obj.GetType());
            }
        }

        public DataTable Query4DataTable(object obj)
        {
            if (obj is string)
            {
                return this.operate.Query4DataTable(obj.ToString());
            }
            else
            {
                throw new Exception("AccessDbOperator-Query4DataTable: No support for "+obj.GetType());
            }
        }

        public Hashtable Query4Hashtable(string sql)
        {
            return operate.Query4Hashtable(sql);
        }

        public IResultSet Query4ResultSet(string strSql)
        {
            return operate.Query4ResultSet(strSql);
        }

        #region Query4Value
        public string Query4Value(string sql)
        {
            return operate.Query4Value(sql);
        }

        public string Query4Value(string sql, int columnIndex)
        {
            return operate.Query4Value(sql, columnIndex);
        }
        #endregion

        public List<ValueText> Query4VtObject(string sql)
        {
            return operate.Select(sql);
        }

        public void Rollback()
        {
            operate.Rollback();
        }

        public int Update(object objTable)
        {
            if (objTable is IOrmTable)
            {
                return operate.Update(objTable as IOrmTable);
            }
            else
            {
                throw new Exception("SqlServerDbOperator-Update: no support " + objTable.GetType());
            }
        }

        public int Update(string tableName, System.Collections.Hashtable values, string sqlWhere)
        {
            //check
            if (null == tableName || null == values || values.Count == 0)
            {
                return 0;
            }
            StringBuilder sqlBuilder = new StringBuilder("update ");
            sqlBuilder.Append(tableName);
            sqlBuilder.Append(" set ");

            IDictionaryEnumerator dicEnum = values.GetEnumerator();
            while (dicEnum.MoveNext())
            {
                if (dicEnum.Value + "" == "")
                {
                    sqlBuilder.Append(dicEnum.Key + "=null,");
                }
                else
                {
                    sqlBuilder.Append(dicEnum.Key + "='" + dicEnum.Value + "',");
                }
            }

            //erase ","
            sqlBuilder.Remove(sqlBuilder.Length - 1, 1);

            //add SQL-Where
            if (sqlWhere != null && sqlWhere.Trim() != "")
            {
                sqlBuilder.Append(" where ");
                sqlBuilder.Append(sqlWhere);
            }

            return this.ExecuteSql(sqlBuilder.ToString());
        }
        public int CreateDbTable(object objTable)
        {
            if (objTable is IItemBase)
            {
                return operate.CreateDbTable(objTable as IItemBase);
            }
            else if (objTable is IOrmTable)
            {
                return operate.CreateDbTable(objTable as IOrmTable);
            }
            else
            {
                throw new Exception("SqlServerDbOperator-CreateDbTable： no support for param " + objTable.GetType());
            }

        }
        public bool IsExistTable(string tableName)
        {

            return false;
        }

        #endregion
    }
}
