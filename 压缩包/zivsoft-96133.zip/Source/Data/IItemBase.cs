using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Zivsoft.Data
{
   
    public interface IItemBase
    {
        ArrayList GetPKName();
        Hashtable GetPKColumn();
        Hashtable GetAllColumn();
        //object InterId { get; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldname"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        void SetValue(string fieldname,object value);
        Dictionary<string, object> Fields { get; set; }
        string GetName();
    }
    public interface IOrmTable:IItemBase
    {
       
    }
}
