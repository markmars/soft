using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class RoleAccess:OrmTable
    {
        #region RoleId
        [Column("RoleId",DbType.String)]
        public ColumnValue<string> RoleId{
            get{
				return new ColumnValue<string> {Name = "RoleId", Value = GetString("RoleId")};
            }
            set{
                Fields["RoleId"]=value.Value;
            }
        }
        #endregion
        #region ModId
        [PrimaryKey("ModId",DbType.String)]
        public ColumnValue<string> ModId{
            get{
				return new ColumnValue<string> {Name = "ModId", Value = GetString("ModId")};
            }
            set{
                Fields["ModId"]=value.Value;
            }
        }
        #endregion
        
    }
}