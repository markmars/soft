using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class All:OrmTable
    {
        #region TradeDate
        [Column("TradeDate",DbType.String)]
        public ColumnValue<string> TradeDate{
            get{
				return new ColumnValue<string> {Name = "TradeDate", Value = GetString("TradeDate")};
            }
            set{
                Fields["TradeDate"]=value.Value;
            }
        }
        #endregion
        #region BusinessSummary
        [Column("BusinessSummary",DbType.String)]
        public ColumnValue<string> BusinessSummary{
            get{
				return new ColumnValue<string> {Name = "BusinessSummary", Value = GetString("BusinessSummary")};
            }
            set{
                Fields["BusinessSummary"]=value.Value;
            }
        }
        #endregion
        #region Kind
        [Column("Kind",DbType.String)]
        public ColumnValue<string> Kind{
            get{
				return new ColumnValue<string> {Name = "Kind", Value = GetString("Kind")};
            }
            set{
                Fields["Kind"]=value.Value;
            }
        }
        #endregion
        #region Type
        [Column("Type",DbType.String)]
        public ColumnValue<string> Type{
            get{
				return new ColumnValue<string> {Name = "Type", Value = GetString("Type")};
            }
            set{
                Fields["Type"]=value.Value;
            }
        }
        #endregion
        #region Incoming
        [Column("Incoming",DbType.String)]
        public ColumnValue<string> Incoming{
            get{
				return new ColumnValue<string> {Name = "Incoming", Value = GetString("Incoming")};
            }
            set{
                Fields["Incoming"]=value.Value;
            }
        }
        #endregion
        #region Cost
        [Column("Cost",DbType.String)]
        public ColumnValue<string> Cost{
            get{
				return new ColumnValue<string> {Name = "Cost", Value = GetString("Cost")};
            }
            set{
                Fields["Cost"]=value.Value;
            }
        }
        #endregion
        #region Rest
        [Column("Rest",DbType.String)]
        public ColumnValue<string> Rest{
            get{
				return new ColumnValue<string> {Name = "Rest", Value = GetString("Rest")};
            }
            set{
                Fields["Rest"]=value.Value;
            }
        }
        #endregion
        
    }
}