using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class HomeOperator:OrmTable
    {
        #region Date
        [PrimaryKey("Date",DbType.String)]
        public ColumnValue<string> Date{
            get{
				return new ColumnValue<string> {Name = "Date", Value = GetString("Date")};
            }
            set{
                Fields["Date"]=value.Value;
            }
        }
        #endregion
        #region Cost
        [Column("Cost",DbType.String)]
        public ColumnValue<string> Cost{
            get{
				return new ColumnValue<string> {Name = "Cost", Value = GetString("Cost")};
            }
            set{
                Fields["Cost"]=value.Value;
            }
        }
        #endregion
        
    }
}