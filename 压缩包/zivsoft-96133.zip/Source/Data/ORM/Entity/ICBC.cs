using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class ICBC:OrmTable
    {
        #region Incoming
        [Column("Incoming",DbType.String)]
        public ColumnValue<string> Incoming{
            get{
				return new ColumnValue<string> {Name = "Incoming", Value = GetString("Incoming")};
            }
            set{
                Fields["Incoming"]=value.Value;
            }
        }
        #endregion
        #region Outcoming
        [Column("Outcoming",DbType.String)]
        public ColumnValue<string> Outcoming{
            get{
				return new ColumnValue<string> {Name = "Outcoming", Value = GetString("Outcoming")};
            }
            set{
                Fields["Outcoming"]=value.Value;
            }
        }
        #endregion
        #region Rest
        [Column("Rest",DbType.String)]
        public ColumnValue<string> Rest{
            get{
				return new ColumnValue<string> {Name = "Rest", Value = GetString("Rest")};
            }
            set{
                Fields["Rest"]=value.Value;
            }
        }
        #endregion
        #region Id
        [Column("Id",DbType.String)]
        public ColumnValue<string> Id{
            get{
				return new ColumnValue<string> {Name = "Id", Value = GetString("Id")};
            }
            set{
                Fields["Id"]=value.Value;
            }
        }
        #endregion
        
    }
}