﻿using System.Data;
using Zivsoft.Data;


namespace Zivsoft.Data.Entity
{
    public class Sequence:OrmTable
    {
        [PrimaryKey("seqName",DbType.String)]
        public string SeqName
        {
            get
            {
                return GetString("seqName");
            }
            set
            {
                Fields["seqName"] = value;
            }
        }
        [Column("SeqNumber",DbType.Int64)]
        public long SeqNumber
        {
            get
            {
                return GetLong("SeqNumber");
            }
            set
            {
                Fields["seqNumber"] = value;
            }
        }
    }
}
