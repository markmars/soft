using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class RoleInfo:OrmTable
    {
        #region RoleId
        [PrimaryKey("RoleId",DbType.String)]
        public ColumnValue<string> RoleId{
            get{
				return new ColumnValue<string> {Name = "RoleId", Value = GetString("RoleId")};
            }
            set{
                Fields["RoleId"]=value.Value;
            }
        }
        #endregion
        #region RoleName
        [Column("RoleName",DbType.String)]
        public ColumnValue<string> RoleName{
            get{
				return new ColumnValue<string> {Name = "RoleName", Value = GetString("RoleName")};
            }
            set{
                Fields["RoleName"]=value.Value;
            }
        }
        #endregion
        
    }
}