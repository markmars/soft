using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class ViewFields:OrmTable
    {
        #region ViewId
        [Column("ViewId",DbType.String)]
        public ColumnValue<string> ViewId{
            get{
				return new ColumnValue<string> {Name = "ViewId", Value = GetString("ViewId")};
            }
            set{
                Fields["ViewId"]=value.Value;
            }
        }
        #endregion
        #region ColumnNo
        [PrimaryKey("ColumnNo",DbType.String)]
        public ColumnValue<string> ColumnNo{
            get{
				return new ColumnValue<string> {Name = "ColumnNo", Value = GetString("ColumnNo")};
            }
            set{
                Fields["ColumnNo"]=value.Value;
            }
        }
        #endregion
        #region FieldName
        [Column("FieldName",DbType.String)]
        public ColumnValue<string> FieldName{
            get{
				return new ColumnValue<string> {Name = "FieldName", Value = GetString("FieldName")};
            }
            set{
                Fields["FieldName"]=value.Value;
            }
        }
        #endregion
        #region FieldId
        [Column("FieldId",DbType.String)]
        public ColumnValue<string> FieldId{
            get{
				return new ColumnValue<string> {Name = "FieldId", Value = GetString("FieldId")};
            }
            set{
                Fields["FieldId"]=value.Value;
            }
        }
        #endregion
        #region IsQuery
        [Column("IsQuery",DbType.String)]
        public ColumnValue<bool> IsQuery{
            get{
                return new ColumnValue<bool> { Name = "IsQuery", Value = GetBool("IsQuery") };
            }
            set{
                Fields["IsQuery"]=value.Value;
            }
        }
        #endregion
        #region MultiLine
        [Column("MultiLine",DbType.String)]
        public ColumnValue<string> MultiLine{
            get{
				return new ColumnValue<string> {Name = "MultiLine", Value = GetString("MultiLine")};
            }
            set{
                Fields["MultiLine"]=value.Value;
            }
        }
        #endregion
        #region DictId
        [Column("DictId",DbType.String)]
        public ColumnValue<string> DictId{
            get{
				return new ColumnValue<string> {Name = "DictId", Value = GetString("DictId")};
            }
            set{
                Fields["DictId"]=value.Value;
            }
        }
        #endregion
        #region IsVisible
        [Column("IsVisible",DbType.String)]
        public ColumnValue<string> IsVisible{
            get{
				return new ColumnValue<string> {Name = "IsVisible", Value = GetString("IsVisible")};
            }
            set{
                Fields["IsVisible"]=value.Value;
            }
        }
        #endregion
        #region Regex
        [Column("Regex",DbType.String)]
        public ColumnValue<string> Regex{
            get{
				return new ColumnValue<string> {Name = "Regex", Value = GetString("Regex")};
            }
            set{
                Fields["Regex"]=value.Value;
            }
        }
        #endregion
        #region IsNull
        [Column("IsNull",DbType.String)]
        public ColumnValue<string> IsNull{
            get{
				return new ColumnValue<string> {Name = "IsNull", Value = GetString("IsNull")};
            }
            set{
                Fields["IsNull"]=value.Value;
            }
        }
        #endregion
        #region ControlLen
        [Column("ControlLen",DbType.String)]
        public ColumnValue<string> ControlLen{
            get{
				return new ColumnValue<string> {Name = "ControlLen", Value = GetString("ControlLen")};
            }
            set{
                Fields["ControlLen"]=value.Value;
            }
        }
        #endregion
        #region GroupName
        [Column("GroupName",DbType.String)]
        public ColumnValue<string> GroupName{
            get{
				return new ColumnValue<string> {Name = "GroupName", Value = GetString("GroupName")};
            }
            set{
                Fields["GroupName"]=value.Value;
            }
        }
        #endregion
        #region FieldLen
        [Column("FieldLen",DbType.String)]
        public ColumnValue<string> FieldLen{
            get{
				return new ColumnValue<string> {Name = "FieldLen", Value = GetString("FieldLen")};
            }
            set{
                Fields["FieldLen"]=value.Value;
            }
        }
        #endregion
        #region IsWrite
        [Column("IsWrite",DbType.String)]
        public ColumnValue<string> IsWrite{
            get{
				return new ColumnValue<string> {Name = "IsWrite", Value = GetString("IsWrite")};
            }
            set{
                Fields["IsWrite"]=value.Value;
            }
        }
        #endregion
        #region IsGridVisible
        [Column("IsGridVisible",DbType.String)]
        public ColumnValue<bool> IsGridVisible{
            get{
				return new ColumnValue<bool> {Name = "IsGridVisible", Value = GetBool("IsGridVisible")};
            }
            set{
                Fields["IsGridVisible"]=value.Value;
            }
        }
        #endregion
        #region FieldType
        [Column("FieldType",DbType.String)]
        public ColumnValue<int?> FieldType{
            get{
				return new ColumnValue<int?> {Name = "FieldType", Value = GetInt("FieldType")};
            }
            set{
                Fields["FieldType"]=value.Value;
            }
        }
        #endregion
        #region DefaultValue
        [Column("DefaultValue",DbType.String)]
        public ColumnValue<string> DefaultValue{
            get{
				return new ColumnValue<string> {Name = "DefaultValue", Value = GetString("DefaultValue")};
            }
            set{
                Fields["DefaultValue"]=value.Value;
            }
        }
        #endregion
        #region DecimalLen
        [Column("DecimalLen",DbType.String)]
        public ColumnValue<int?> DecimalLen{
            get{
				return new ColumnValue<int?> {Name = "DecimalLen", Value = GetInt("DecimalLen")};
            }
            set{
                Fields["DecimalLen"]=value.Value;
            }
        }
        #endregion
        #region IsPK
        [Column("IsPK",DbType.String)]
        public ColumnValue<string> IsPK{
            get{
				return new ColumnValue<string> {Name = "IsPK", Value = GetString("IsPK")};
            }
            set{
                Fields["IsPK"]=value.Value;
            }
        }
        #endregion
        
    }
}