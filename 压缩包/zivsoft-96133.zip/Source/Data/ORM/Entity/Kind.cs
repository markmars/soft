using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Kind:OrmTable
    {
        #region Id
        [Column("Id",DbType.String)]
        public ColumnValue<string> Id{
            get{
				return new ColumnValue<string> {Name = "Id", Value = GetString("Id")};
            }
            set{
                Fields["Id"]=value.Value;
            }
        }
        #endregion
        #region DealMethod
        [Column("DealMethod",DbType.String)]
        public ColumnValue<string> DealMethod{
            get{
				return new ColumnValue<string> {Name = "DealMethod", Value = GetString("DealMethod")};
            }
            set{
                Fields["DealMethod"]=value.Value;
            }
        }
        #endregion

        [Column("Name", DbType.String)]
        public ColumnValue<string> Name
        {
            get
            {
                return new ColumnValue<string> { Name = "Name", Value = GetString("Name") };
            }
            set
            {
                Fields["Name"] = value.Value;
            }
        }
        
    }
}