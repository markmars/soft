using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Counter:OrmTable
    {
        #region Value
        [Column("Value",DbType.String)]
        public ColumnValue<long> Value{
            get{
				return new ColumnValue<long> {Name = "Value", Value = GetLong("Value")};
            }
            set{
                Fields["Value"]=value.Value;
            }
        }
        #endregion
        #region UpdateDate
        [Column("UpdateDate",DbType.String)]
        public ColumnValue<string> UpdateDate{
            get{
				return new ColumnValue<string> {Name = "UpdateDate", Value = GetString("UpdateDate")};
            }
            set{
                Fields["UpdateDate"]=value.Value;
            }
        }
        #endregion
        
    }
}