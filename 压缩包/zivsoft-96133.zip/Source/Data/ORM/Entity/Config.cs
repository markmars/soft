using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Config:OrmTable
    {
        #region ConfigId
        [PrimaryKey("ConfigId",DbType.String)]
        public ColumnValue<string> ConfigId{
            get{
				return new ColumnValue<string> {Name = "ConfigId", Value = GetString("ConfigId")};
            }
            set{
                Fields["ConfigId"]=value.Value;
            }
        }
        #endregion
        #region ConfigValue
        [Column("ConfigValue",DbType.String)]
        public ColumnValue<string> ConfigValue{
            get{
				return new ColumnValue<string> {Name = "ConfigValue", Value = GetString("ConfigValue")};
            }
            set{
                Fields["ConfigValue"]=value.Value;
            }
        }
        #endregion
        
    }
}