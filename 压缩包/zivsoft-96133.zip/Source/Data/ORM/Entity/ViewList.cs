using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class ViewList:OrmTable
    {
        #region ViewId
        [PrimaryKey("ViewId",DbType.String)]
        public ColumnValue<string> ViewId{
            get{
				return new ColumnValue<string> {Name = "ViewId", Value = GetString("ViewId")};
            }
            set{
                Fields["ViewId"]=value.Value;
            }
        }
        #endregion
        #region TableName
        [Column("TableName",DbType.String)]
        new public ColumnValue<string> TableName{
            get{
				return new ColumnValue<string> {Name = "TableName", Value = GetString("TableName")};
            }
            set{
                Fields["TableName"]=value.Value;
            }
        }
        #endregion
        #region ViewName
        [Column("ViewName",DbType.String)]
        public ColumnValue<string> ViewName{
            get{
				return new ColumnValue<string> {Name = "ViewName", Value = GetString("ViewName")};
            }
            set{
                Fields["ViewName"]=value.Value;
            }
        }
        #endregion

        [Column("GridWidth",DbType.Int32)]
        public ColumnValue<int?> GridWidth
        {
            get
            {
                return new ColumnValue<int?> { Name = "GridWidth", Value = GetInt("GridWidth") };
            }
            set
            {
                Fields["GridWidth"] = value.Value;   
            }
        }
        
    }
}