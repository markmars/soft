using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Info:OrmTable
    {
        #region ID
        [Column("ID",DbType.String)]
        public ColumnValue<string> Id{
            get{
				return new ColumnValue<string> {Name = "ID", Value = GetString("ID")};
            }
            set{
                Fields["ID"]=value.Value;
            }
        }
        #endregion
        #region Title
        [Column("Title",DbType.String)]
        public ColumnValue<string> Title{
            get{
				return new ColumnValue<string> {Name = "Title", Value = GetString("Title")};
            }
            set{
                Fields["Title"]=value.Value;
            }
        }
        #endregion
        #region Content
        [Column("Content",DbType.String)]
        public ColumnValue<string> Content{
            get{
				return new ColumnValue<string> {Name = "Content", Value = GetString("Content")};
            }
            set{
                Fields["Content"]=value.Value;
            }
        }
        #endregion
        #region CreateDate
        [Column("CreateDate",DbType.String)]
        public ColumnValue<string> CreateDate{
            get{
				return new ColumnValue<string> {Name = "CreateDate", Value = GetString("CreateDate")};
            }
            set{
                Fields["CreateDate"]=value.Value;
            }
        }
        #endregion
        #region IP
        [Column("IP",DbType.String)]
        public ColumnValue<string> IP{
            get{
				return new ColumnValue<string> {Name = "IP", Value = GetString("IP")};
            }
            set{
                Fields["IP"]=value.Value;
            }
        }
        #endregion
        #region Author
        [Column("Author",DbType.String)]
        public ColumnValue<string> Author{
            get{
				return new ColumnValue<string> {Name = "Author", Value = GetString("Author")};
            }
            set{
                Fields["Author"]=value.Value;
            }
        }
        #endregion
        #region Kind
        [Column("Kind",DbType.String)]
        public ColumnValue<string> Kind{
            get{
				return new ColumnValue<string> {Name = "Kind", Value = GetString("Kind")};
            }
            set{
                Fields["Kind"]=value.Value;
            }
        }
        #endregion
        
    }
}