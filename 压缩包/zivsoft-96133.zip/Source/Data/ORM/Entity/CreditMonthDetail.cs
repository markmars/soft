using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class CreditMonthDetail:OrmTable
    {
        #region MonthId
        [Column("MonthId",DbType.String)]
        public ColumnValue<string> MonthId{
            get{
				return new ColumnValue<string> {Name = "MonthId", Value = GetString("MonthId")};
            }
            set{
                Fields["MonthId"]=value.Value;
            }
        }
        #endregion
        #region DetailId
        [PrimaryKey("DetailId",DbType.String)]
        public ColumnValue<string> DetailId{
            get{
				return new ColumnValue<string> {Name = "DetailId", Value = GetString("DetailId")};
            }
            set{
                Fields["DetailId"]=value.Value;
            }
        }
        #endregion
        #region TradeSummary
        [Column("TradeSummary",DbType.String)]
        public ColumnValue<string> TradeSummary{
            get{
				return new ColumnValue<string> {Name = "TradeSummary", Value = GetString("TradeSummary")};
            }
            set{
                Fields["TradeSummary"]=value.Value;
            }
        }
        #endregion
        #region Cost
        [Column("Cost",DbType.String)]
        public ColumnValue<string> Cost{
            get{
				return new ColumnValue<string> {Name = "Cost", Value = GetString("Cost")};
            }
            set{
                Fields["Cost"]=value.Value;
            }
        }
        #endregion
        
    }
}