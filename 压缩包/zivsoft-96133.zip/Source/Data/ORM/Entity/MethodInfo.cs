using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class MethodInfo:OrmTable
    {
        #region MethodId
        [PrimaryKey("MethodId",DbType.String)]
        public ColumnValue<string> MethodId{
            get{
				return new ColumnValue<string> {Name = "MethodId", Value = GetString("MethodId")};
            }
            set{
                Fields["MethodId"]=value.Value;
            }
        }
        #endregion
        #region Desc
        [Column("Desc",DbType.String)]
        public ColumnValue<string> Desc{
            get{
				return new ColumnValue<string> {Name = "Desc", Value = GetString("Desc")};
            }
            set{
                Fields["Desc"]=value.Value;
            }
        }
        #endregion
        
    }
}