﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Zivsoft.Data;

namespace Zivsoft.Data.Entity
{
    public class SysColumns:OrmTable
    {
        [Column("xtype",DbType.Int32)]
        public int? XType
        {
            get
            {
                return GetInt("xtype");
            }
            set
            {
                Fields["xtype"] = value;
            }
        }
    }
}
