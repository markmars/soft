using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class DailyFinance:OrmTable
    {
        #region Date
        [Column("Date",DbType.String)]
        public ColumnValue<string> Date{
            get{
				return new ColumnValue<string> {Name = "Date", Value = GetString("Date")};
            }
            set{
                Fields["Date"]=value.Value;
            }
        }
        #endregion
        #region Cost
        [Column("Cost",DbType.String)]
        public ColumnValue<string> Cost{
            get{
				return new ColumnValue<string> {Name = "Cost", Value = GetString("Cost")};
            }
            set{
                Fields["Cost"]=value.Value;
            }
        }
        #endregion
        #region Incoming
        [Column("Incoming",DbType.String)]
        public ColumnValue<string> Incoming{
            get{
				return new ColumnValue<string> {Name = "Incoming", Value = GetString("Incoming")};
            }
            set{
                Fields["Incoming"]=value.Value;
            }
        }
        #endregion
        #region Desc
        [Column("Desc",DbType.String)]
        public ColumnValue<string> Desc{
            get{
				return new ColumnValue<string> {Name = "Desc", Value = GetString("Desc")};
            }
            set{
                Fields["Desc"]=value.Value;
            }
        }
        #endregion
        
    }
}