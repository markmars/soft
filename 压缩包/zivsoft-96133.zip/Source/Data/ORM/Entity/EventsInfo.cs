using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class EventsInfo:OrmTable
    {
        #region ID
        [PrimaryKey("ID",DbType.String)]
        public ColumnValue<string> ID{
            get{
				return new ColumnValue<string> {Name = "ID", Value = GetString("ID")};
            }
            set{
                Fields["ID"]=value.Value;
            }
        }
        #endregion
        #region Date
        [Column("Date",DbType.String)]
        public ColumnValue<string> Date{
            get{
				return new ColumnValue<string> {Name = "Date", Value = GetString("Date")};
            }
            set{
                Fields["Date"]=value.Value;
            }
        }
        #endregion
        #region Events
        [Column("Events",DbType.String)]
        public ColumnValue<string> Events{
            get{
				return new ColumnValue<string> {Name = "Events", Value = GetString("Events")};
            }
            set{
                Fields["Events"]=value.Value;
            }
        }
        #endregion
        
    }
}