using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Products:OrmTable
    {
        #region ID
        [PrimaryKey("ID",DbType.String)]
        public ColumnValue<string> ID{
            get{
				return new ColumnValue<string> {Name = "ID", Value = GetString("ID")};
            }
            set{
                Fields["ID"]=value.Value;
            }
        }
        #endregion
        #region ProdutcName
        [Column("ProdutcName",DbType.String)]
        public ColumnValue<string> ProdutcName{
            get{
				return new ColumnValue<string> {Name = "ProdutcName", Value = GetString("ProdutcName")};
            }
            set{
                Fields["ProdutcName"]=value.Value;
            }
        }
        #endregion
        #region Cost
        [Column("Cost",DbType.String)]
        public ColumnValue<string> Cost{
            get{
				return new ColumnValue<string> {Name = "Cost", Value = GetString("Cost")};
            }
            set{
                Fields["Cost"]=value.Value;
            }
        }
        #endregion
        
    }
}