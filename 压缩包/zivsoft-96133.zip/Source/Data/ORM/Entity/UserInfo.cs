using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class UserInfo:OrmTable
    {
        #region UserId
        [PrimaryKey("UserId",DbType.String)]
        public ColumnValue<string> UserId{
            get{
				return new ColumnValue<string> {Name = "UserId", Value = GetString("UserId")};
            }
            set{
                Fields["UserId"]=value.Value;
            }
        }
        #endregion
        #region Password
        [Column("Password",DbType.String)]
        public ColumnValue<string> Password{
            get{
				return new ColumnValue<string> {Name = "Password", Value = GetString("Password")};
            }
            set{
                Fields["Password"]=value.Value;
            }
        }
        #endregion
        #region IP
        [Column("IP",DbType.String)]
        public ColumnValue<string> IP{
            get{
				return new ColumnValue<string> {Name = "IP", Value = GetString("IP")};
            }
            set{
                Fields["IP"]=value.Value;
            }
        }
        #endregion
        #region RoleId
        [Column("RoleId",DbType.String)]
        public ColumnValue<string> RoleId{
            get{
				return new ColumnValue<string> {Name = "RoleId", Value = GetString("RoleId")};
            }
            set{
                Fields["RoleId"]=value.Value;
            }
        }
        #endregion
        #region VerLanguage
        [Column("VerLanguage",DbType.String)]
        public ColumnValue<string> VerLanguage{
            get{
				return new ColumnValue<string> {Name = "VerLanguage", Value = GetString("VerLanguage")};
            }
            set{
                Fields["VerLanguage"]=value.Value;
            }
        }
        #endregion
        #region UserName
        [Column("UserName",DbType.String)]
        public ColumnValue<string> UserName{
            get{
				return new ColumnValue<string> {Name = "UserName", Value = GetString("UserName")};
            }
            set{
                Fields["UserName"]=value.Value;
            }
        }
        #endregion
        #region LoginTime
        [Column("LoginTime",DbType.String)]
        public ColumnValue<DateTime?> LoginTime{
            get{
                return new ColumnValue<DateTime?> { Name = "LoginTime", Value = GetDateTime("LoginTime") };
            }
            set{
                Fields["LoginTime"]=value.Value;
            }
        }
        #endregion
        #region Theme
        [Column("Theme",DbType.String)]
        public ColumnValue<string> Theme{
            get{
				return new ColumnValue<string> {Name = "Theme", Value = GetString("Theme")};
            }
            set{
                Fields["Theme"]=value.Value;
            }
        }
        #endregion
        
    }
}