using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Message:OrmTable
    {
        #region UserName
        [Column("UserName",DbType.String)]
        public ColumnValue<string> UserName{
            get{
				return new ColumnValue<string> {Name = "UserName", Value = GetString("UserName")};
            }
            set{
                Fields["UserName"]=value.Value;
            }
        }
        #endregion
        #region CreateDate
        [Column("CreateDate",DbType.String)]
        public ColumnValue<string> CreateDate{
            get{
				return new ColumnValue<string> {Name = "CreateDate", Value = GetString("CreateDate")};
            }
            set{
                Fields["CreateDate"]=value.Value;
            }
        }
        #endregion
        #region Content
        [Column("Content",DbType.String)]
        public ColumnValue<string> Content{
            get{
				return new ColumnValue<string> {Name = "Content", Value = GetString("Content")};
            }
            set{
                Fields["Content"]=value.Value;
            }
        }
        #endregion
        #region IP
        [Column("IP",DbType.String)]
        public ColumnValue<string> IP{
            get{
				return new ColumnValue<string> {Name = "IP", Value = GetString("IP")};
            }
            set{
                Fields["IP"]=value.Value;
            }
        }
        #endregion
        #region SSMA_TimeStamp
        [Column("SSMA_TimeStamp",DbType.String)]
        public ColumnValue<string> SSMA_TimeStamp{
            get{
				return new ColumnValue<string> {Name = "SSMA_TimeStamp", Value = GetString("SSMA_TimeStamp")};
            }
            set{
                Fields["SSMA_TimeStamp"]=value.Value;
            }
        }
        #endregion
        
    }
}