using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Dtproperties:OrmTable
    {
        #region id
        [PrimaryKey("id",DbType.String)]
        public ColumnValue<string> id{
            get{
				return new ColumnValue<string> {Name = "id", Value = GetString("id")};
            }
            set{
                Fields["id"]=value.Value;
            }
        }
        #endregion
        #region objectid
        [Column("objectid",DbType.String)]
        public ColumnValue<string> objectid{
            get{
				return new ColumnValue<string> {Name = "objectid", Value = GetString("objectid")};
            }
            set{
                Fields["objectid"]=value.Value;
            }
        }
        #endregion
        #region property
        [Column("property",DbType.String)]
        public ColumnValue<string> property{
            get{
				return new ColumnValue<string> {Name = "property", Value = GetString("property")};
            }
            set{
                Fields["property"]=value.Value;
            }
        }
        #endregion
        #region value
        [Column("value",DbType.String)]
        public ColumnValue<string> value{
            get{
				return new ColumnValue<string> {Name = "value", Value = GetString("value")};
            }
            set{
                Fields["value"]=value.Value;
            }
        }
        #endregion
        #region uvalue
        [Column("uvalue",DbType.String)]
        public ColumnValue<string> uvalue{
            get{
				return new ColumnValue<string> {Name = "uvalue", Value = GetString("uvalue")};
            }
            set{
                Fields["uvalue"]=value.Value;
            }
        }
        #endregion
        #region lvalue
        [Column("lvalue",DbType.String)]
        public ColumnValue<string> lvalue{
            get{
				return new ColumnValue<string> {Name = "lvalue", Value = GetString("lvalue")};
            }
            set{
                Fields["lvalue"]=value.Value;
            }
        }
        #endregion
        #region version
        [Column("version",DbType.String)]
        public ColumnValue<string> version{
            get{
				return new ColumnValue<string> {Name = "version", Value = GetString("version")};
            }
            set{
                Fields["version"]=value.Value;
            }
        }
        #endregion
        
    }
}