using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Address:OrmTable
    {
        #region Name
        [PrimaryKey("Name",DbType.String)]
        public ColumnValue<string> Name{
            get{
				return new ColumnValue<string> {Name = "Name", Value = GetString("Name")};
            }
            set{
                Fields["Name"]=value.Value;
            }
        }
        #endregion
        #region Birthday
        [Column("Birthday",DbType.String)]
        public ColumnValue<string> Birthday{
            get{
				return new ColumnValue<string> {Name = "Birthday", Value = GetString("Birthday")};
            }
            set{
                Fields["Birthday"]=value.Value;
            }
        }
        #endregion
        #region Email
        [Column("Email",DbType.String)]
        public ColumnValue<string> Email{
            get{
				return new ColumnValue<string> {Name = "Email", Value = GetString("Email")};
            }
            set{
                Fields["Email"]=value.Value;
            }
        }
        #endregion
        #region Relationship
        [Column("Relationship",DbType.String)]
        public ColumnValue<string> Relationship{
            get{
				return new ColumnValue<string> {Name = "Relationship", Value = GetString("Relationship")};
            }
            set{
                Fields["Relationship"]=value.Value;
            }
        }
        #endregion
        #region QQ
        [Column("QQ",DbType.String)]
        public ColumnValue<string> QQ{
            get{
				return new ColumnValue<string> {Name = "QQ", Value = GetString("QQ")};
            }
            set{
                Fields["QQ"]=value.Value;
            }
        }
        #endregion
        #region Phone
        [Column("Phone",DbType.String)]
        public ColumnValue<string> Phone{
            get{
				return new ColumnValue<string> {Name = "Phone", Value = GetString("Phone")};
            }
            set{
                Fields["Phone"]=value.Value;
            }
        }
        #endregion
        #region HomePhone
        [Column("HomePhone",DbType.String)]
        public ColumnValue<string> HomePhone{
            get{
				return new ColumnValue<string> {Name = "HomePhone", Value = GetString("HomePhone")};
            }
            set{
                Fields["HomePhone"]=value.Value;
            }
        }
        #endregion
        #region UserId
        [Column("UserId",DbType.String)]
        public ColumnValue<string> UserId{
            get{
				return new ColumnValue<string> {Name = "UserId", Value = GetString("UserId")};
            }
            set{
                Fields["UserId"]=value.Value;
            }
        }
        #endregion
        
    }
}