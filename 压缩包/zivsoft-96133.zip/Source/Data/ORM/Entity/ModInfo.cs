using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class ModInfo:OrmTable
    {
        #region ModId
        [PrimaryKey("ModId",DbType.String)]
        public ColumnValue<string> ModId{
            get{
				return new ColumnValue<string> {Name = "ModId", Value = GetString("ModId")};
            }
            set{
                Fields["ModId"]=value.Value;
            }
        }
        #endregion
        #region ModName
        [Column("ModName",DbType.String)]
        public ColumnValue<string> ModName{
            get{
				return new ColumnValue<string> {Name = "ModName", Value = GetString("ModName")};
            }
            set{
                Fields["ModName"]=value.Value;
            }
        }
        #endregion
        #region NavigateUrl
        [Column("NavigateUrl",DbType.String)]
        public ColumnValue<string> NavigateUrl{
            get{
				return new ColumnValue<string> {Name = "NavigateUrl", Value = GetString("NavigateUrl")};
            }
            set{
                Fields["NavigateUrl"]=value.Value;
            }
        }
        #endregion
        #region IsValid
        [Column("IsValid",DbType.String)]
        public ColumnValue<string> IsValid{
            get{
				return new ColumnValue<string> {Name = "IsValid", Value = GetString("IsValid")};
            }
            set{
                Fields["IsValid"]=value.Value;
            }
        }
        #endregion
        #region ImageUrl
        [Column("ImageUrl",DbType.String)]
        public ColumnValue<string> ImageUrl{
            get{
				return new ColumnValue<string> {Name = "ImageUrl", Value = GetString("ImageUrl")};
            }
            set{
                Fields["ImageUrl"]=value.Value;
            }
        }
        #endregion
        #region ModType
        [Column("ModType",DbType.String)]
        public ColumnValue<string> ModType{
            get{
				return new ColumnValue<string> {Name = "ModType", Value = GetString("ModType")};
            }
            set{
                Fields["ModType"]=value.Value;
            }
        }
        #endregion
        
    }
}