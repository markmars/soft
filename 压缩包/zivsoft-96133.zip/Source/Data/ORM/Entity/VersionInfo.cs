using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class VersionInfo:OrmTable
    {
        #region Version
        [PrimaryKey("Version",DbType.String)]
        public ColumnValue<string> Version{
            get{
				return new ColumnValue<string> {Name = "Version", Value = GetString("Version")};
            }
            set{
                Fields["Version"]=value.Value;
            }
        }
        #endregion
        
    }
}