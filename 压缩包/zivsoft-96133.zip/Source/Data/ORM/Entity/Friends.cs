using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Friends:OrmTable
    {
        #region UserId
        [PrimaryKey("UserId",DbType.String)]
        public ColumnValue<string> UserId{
            get{
				return new ColumnValue<string> {Name = "UserId", Value = GetString("UserId")};
            }
            set{
                Fields["UserId"]=value.Value;
            }
        }
        #endregion
        #region FamilyName
        [Column("FamilyName",DbType.String)]
        public ColumnValue<string> FamilyName{
            get{
				return new ColumnValue<string> {Name = "FamilyName", Value = GetString("FamilyName")};
            }
            set{
                Fields["FamilyName"]=value.Value;
            }
        }
        #endregion
        #region FirstName
        [Column("FirstName",DbType.String)]
        public ColumnValue<string> FirstName{
            get{
				return new ColumnValue<string> {Name = "FirstName", Value = GetString("FirstName")};
            }
            set{
                Fields["FirstName"]=value.Value;
            }
        }
        #endregion
        #region City
        [Column("City",DbType.String)]
        public ColumnValue<string> City{
            get{
				return new ColumnValue<string> {Name = "City", Value = GetString("City")};
            }
            set{
                Fields["City"]=value.Value;
            }
        }
        #endregion
        #region Sex
        [Column("Sex",DbType.String)]
        public ColumnValue<string> Sex{
            get{
				return new ColumnValue<string> {Name = "Sex", Value = GetString("Sex")};
            }
            set{
                Fields["Sex"]=value.Value;
            }
        }
        #endregion
        #region BirthYear
        [Column("BirthYear",DbType.String)]
        public ColumnValue<string> BirthYear{
            get{
				return new ColumnValue<string> {Name = "BirthYear", Value = GetString("BirthYear")};
            }
            set{
                Fields["BirthYear"]=value.Value;
            }
        }
        #endregion
        #region BirthMonth
        [Column("BirthMonth",DbType.String)]
        public ColumnValue<string> BirthMonth{
            get{
				return new ColumnValue<string> {Name = "BirthMonth", Value = GetString("BirthMonth")};
            }
            set{
                Fields["BirthMonth"]=value.Value;
            }
        }
        #endregion
        #region BirthDay
        [Column("BirthDay",DbType.String)]
        public ColumnValue<string> BirthDay{
            get{
				return new ColumnValue<string> {Name = "BirthDay", Value = GetString("BirthDay")};
            }
            set{
                Fields["BirthDay"]=value.Value;
            }
        }
        #endregion
        #region Identify
        [Column("Identify",DbType.String)]
        public ColumnValue<string> Identify{
            get{
				return new ColumnValue<string> {Name = "Identify", Value = GetString("Identify")};
            }
            set{
                Fields["Identify"]=value.Value;
            }
        }
        #endregion
        #region Call
        [Column("Call",DbType.String)]
        public ColumnValue<string> Call{
            get{
				return new ColumnValue<string> {Name = "Call", Value = GetString("Call")};
            }
            set{
                Fields["Call"]=value.Value;
            }
        }
        #endregion
        #region QQ
        [Column("QQ",DbType.String)]
        public ColumnValue<string> QQ{
            get{
				return new ColumnValue<string> {Name = "QQ", Value = GetString("QQ")};
            }
            set{
                Fields["QQ"]=value.Value;
            }
        }
        #endregion
        #region MSN
        [Column("MSN",DbType.String)]
        public ColumnValue<string> MSN{
            get{
				return new ColumnValue<string> {Name = "MSN", Value = GetString("MSN")};
            }
            set{
                Fields["MSN"]=value.Value;
            }
        }
        #endregion
        
    }
}