using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class SalarySummary:OrmTable
    {
        #region Id
        [PrimaryKey("Id",DbType.String)]
        public ColumnValue<string> Id{
            get{
				return new ColumnValue<string> {Name = "Id", Value = GetString("Id")};
            }
            set{
                Fields["Id"]=value.Value;
            }
        }
        #endregion
        #region In
        [Column("In",DbType.String)]
        public ColumnValue<string> In{
            get{
				return new ColumnValue<string> {Name = "In", Value = GetString("In")};
            }
            set{
                Fields["In"]=value.Value;
            }
        }
        #endregion
        #region Out
        [Column("Out",DbType.String)]
        public ColumnValue<string> Out{
            get{
				return new ColumnValue<string> {Name = "Out", Value = GetString("Out")};
            }
            set{
                Fields["Out"]=value.Value;
            }
        }
        #endregion
        
    }
}