using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class Sysdiagrams:OrmTable
    {
        #region name
        [Column("name",DbType.String)]
        public ColumnValue<string> name{
            get{
				return new ColumnValue<string> {Name = "name", Value = GetString("name")};
            }
            set{
                Fields["name"]=value.Value;
            }
        }
        #endregion
        #region principal_id
        [Column("principal_id",DbType.String)]
        public ColumnValue<string> principal_id{
            get{
				return new ColumnValue<string> {Name = "principal_id", Value = GetString("principal_id")};
            }
            set{
                Fields["principal_id"]=value.Value;
            }
        }
        #endregion
        #region diagram_id
        [PrimaryKey("diagram_id",DbType.String)]
        public ColumnValue<string> diagram_id{
            get{
				return new ColumnValue<string> {Name = "diagram_id", Value = GetString("diagram_id")};
            }
            set{
                Fields["diagram_id"]=value.Value;
            }
        }
        #endregion
        #region version
        [Column("version",DbType.String)]
        public ColumnValue<string> version{
            get{
				return new ColumnValue<string> {Name = "version", Value = GetString("version")};
            }
            set{
                Fields["version"]=value.Value;
            }
        }
        #endregion
        #region definition
        [Column("definition",DbType.String)]
        public ColumnValue<string> definition{
            get{
				return new ColumnValue<string> {Name = "definition", Value = GetString("definition")};
            }
            set{
                Fields["definition"]=value.Value;
            }
        }
        #endregion
        
    }
}