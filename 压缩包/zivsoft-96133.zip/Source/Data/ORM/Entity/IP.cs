using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class IP:OrmTable
    {
        #region IPValue
        [Column("IPValue",DbType.String)]
        public ColumnValue<string> IPValue{
            get{
				return new ColumnValue<string> {Name = "IPValue", Value = GetString("IPValue")};
            }
            set{
                Fields["IPValue"]=value.Value;
            }
        }
        #endregion
        #region LastAccessDate
        [Column("LastAccessDate",DbType.String)]
        public ColumnValue<DateTime?> LastAccessDate{
            get{
                return new ColumnValue<DateTime?> { Name = "LastAccessDate", Value = GetDateTime("LastAccessDate") };
            }
            set{
                Fields["LastAccessDate"]=value.Value;
            }
        }
        #endregion
        
    }
}