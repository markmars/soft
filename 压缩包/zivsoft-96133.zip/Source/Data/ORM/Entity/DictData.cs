using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
/*************************************
 * 
 * Created by Zivsoft.Data.ORM.Setup
 *
 *************************************/
namespace Zivsoft.Data.ORM.Entity
{
    public class DictData:OrmTable
    {
        #region FieldId
        [PrimaryKey("FieldId",DbType.String)]
        public ColumnValue<string> FieldId{
            get{
				return new ColumnValue<string> {Name = "FieldId", Value = GetString("FieldId")};
            }
            set{
                Fields["FieldId"]=value.Value;
            }
        }
        #endregion
        #region FieldValue
        [Column("FieldValue",DbType.String)]
        public ColumnValue<string> FieldValue{
            get{
				return new ColumnValue<string> {Name = "FieldValue", Value = GetString("FieldValue")};
            }
            set{
                Fields["FieldValue"]=value.Value;
            }
        }
        #endregion
        
    }
}