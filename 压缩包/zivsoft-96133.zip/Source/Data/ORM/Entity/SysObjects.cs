﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Zivsoft.Data;

namespace Zivsoft.Data.Entity
{
    public class SysObjects:OrmTable
    {
        [Column("name",DbType.String)]
        public string Name
        {
            get
            {
                return GetString("name");
            }
            set
            {
                base.Fields["name"] = value;
            }
        }

        [Column("xtype", DbType.String)]
        public string XType
        {
            get
            {
                return GetString("xtype");
            }
            set
            {
                base.Fields["xtype"] = value;
            }
        }
    }
}
