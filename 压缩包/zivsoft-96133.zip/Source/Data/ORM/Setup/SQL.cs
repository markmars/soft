using System;
using System.Collections.Generic;
using System.Text;
/*
 * Created By Lihua Zhou At 12/07/2007
 */
namespace Zivsoft.Data.ORM.Setup
{
    class SQL
    {
        public const string GetPrimaryKeySQL = "	declare	@TableName varchar(128) "
            + "	select @TableName = '{0}' "
            + "	select 	c.COLUMN_NAME "
            + "	from 	INFORMATION_SCHEMA.TABLE_CONSTRAINTS pk ,"
            + "		INFORMATION_SCHEMA.KEY_COLUMN_USAGE c"
            + "	where 	pk.TABLE_NAME = @TableName"
            + "	and	CONSTRAINT_TYPE = 'PRIMARY KEY'"
            + "	and	c.TABLE_NAME = pk.TABLE_NAME"
            + "	and	c.CONSTRAINT_NAME = pk.CONSTRAINT_NAME";
    }
}
