﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.Data.ORM.Setup
{
    class Program
    {
        static void Main()
        {
            try
            {
                Template temp = new Template();
                bool bResult = temp.Excute();
                if (bResult)
                {
                    Console.WriteLine("Done successfully.");
                }
                else
                {
                    Console.WriteLine("Done but failed.");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.Write("\nPress any key to exit.");
            Console.Read();
        }
    }
}
