using System;
using System.Reflection;
using System.IO;

namespace Zivsoft.Data.ORM.Setup
{
    class TemplateReader
    {
        private string _templateName;
        private string _prjtemp;

        public TemplateReader()
        {
            this._templateName = "Template.ini";
            this._prjtemp = "PrjTemp.xml";
        }

        public String ReadToEnd()
        {
            var install = Assembly.GetExecutingAssembly();
            var name = GetType().FullName.Replace(GetType().Name,string.Empty)+_templateName;
            Stream s = null;
            try
            {
                s = install.GetManifestResourceStream(name);
            }
            catch
            {
                return String.Empty;
            }
            if (s == null)
            {
                return String.Empty;
            }
            var sr = new StreamReader(s);
            string result = null;
            try
            {
                result = sr.ReadToEnd();
            }
            catch (OutOfMemoryException)
            {
                return string.Empty;
            }
            catch (IOException)
            {
                return string.Empty;
            }
            return result;
        }
        public String ReadProjectTemplate()
        {
            var install = Assembly.GetExecutingAssembly();
            string name = install.GetName().Name + ".Setup." + this._prjtemp;
            var s = install.GetManifestResourceStream(name);
            var sr = new StreamReader(s);
            string result = null;
            try
            {
                result = sr.ReadToEnd();
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("When read the " + name + " it was out of memroy.");
                return string.Empty;
            }
            catch (IOException)
            {
                Console.WriteLine("IO Exception was thrown when read the file " + name + ".");
                return string.Empty;
            }
            return result;
        }
    }
}
