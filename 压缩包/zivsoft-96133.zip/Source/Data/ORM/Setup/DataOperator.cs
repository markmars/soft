using System.Collections;
using System.Diagnostics;

namespace Zivsoft.Data.ORM.Setup
{
    class DataOperator
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ArrayList GetTableList() {
            var sql = "SELECT [name] FROM [sysobjects] WHERE (xtype = 'U')";
            Debug.WriteLine(sql);
            var dr = DbFactory.DefaultDbOperator().Query4DataReader(sql);
            var al = new ArrayList();
            while (dr.Read())
            {
                al.Add(dr.GetValue(0));
            }
            return al;
        }

        public ArrayList GetColumnList(string tableName)
        {
            string sql = "SELECT syscolumns.name  FROM syscolumns INNER JOIN  sysobjects ON syscolumns.id = sysobjects.id WHERE (sysobjects.name = '{0}')";
            sql = string.Format(sql, tableName);
            var dr = DbFactory.DefaultDbOperator().Query4DataReader(sql);
            var al = new ArrayList();
            while (dr.Read())
            {
                al.Add(dr.GetValue(0));
            }
            return al;
        }

        public string GetPrimaryKeyByTableName(string tableName)
        {
            var sql=string.Format(SQL.GetPrimaryKeySQL, tableName);
            var key = DbFactory.DefaultDbOperator().Query4Value(sql);
            if (string.IsNullOrEmpty(key))
            {
                Debug.WriteLine("primary key is null in table " + tableName);
            }
            return key;
        }
    }
}
