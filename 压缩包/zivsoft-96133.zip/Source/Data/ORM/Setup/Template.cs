using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;
using System.Configuration;

namespace Zivsoft.Data.ORM.Setup
{
    public class Template
    {

        static string GetOutPath()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory+"Table\\";
            
            if(!Directory.Exists(path)){
                Directory.CreateDirectory(path);
            }
            return path;
        }
        /// <summary>
        /// To export entity table cs files to Current domain table folder.
        /// Exception:
        ///           ExportException
        /// </summary>
        public bool Excute()
        {
            bool isSuccess;
            string prj = null;//for the PrjTemp.xml file
            var tpt=new TemplateReader();
            var outPath = GetOutPath();
            try
            {
                //====================Create Entity==========================
                var strEntity = tpt.ReadToEnd();
                var dbOper = new DataOperator();
                var al = dbOper.GetTableList();
                for (int i = 0, t = al.Count; i < t; i++)
                {
                    string tableName = al[i].ToString();
                    //set entity class name
                    string className =al[i].ToString();
                    className = className[0].ToString().ToUpper() + className.Remove(0, 1);
                    string strClassContent = strEntity.Replace("${ClassName}", className);
                    string fileName = outPath + className + ".cs";

                    strClassContent = this.AddPropert(dbOper, tableName, strClassContent);
                    prj +=string.Format("<Compile Include=\"{0}.cs\"/>\n",className);

                    //do the primary key
                    string primaryKey=dbOper.GetPrimaryKeyByTableName(tableName);
                    strClassContent = strClassContent.Replace(string.Format("[Column(\"{0}\",DbType.String)]", primaryKey), string.Format("[PrimaryKey(\"{0}\",DbType.String)]", primaryKey));

                    File.WriteAllText(fileName, strClassContent);
                    //write message to user
                }
                //================Create Project========================
                string strProject = tpt.ReadProjectTemplate();
                string strPrjContent=strProject.Replace("<!--[Compile Include=\"%Table%.cs\"]-->", prj);

                File.WriteAllText(outPath + "Table.csproj", strPrjContent);
                
                //End
                isSuccess = true;
            }
            catch(Exception e)
            {
                throw e;
            }
            return isSuccess;
        }
        private string AddPropert(DataOperator dbOper, string tableName,string entity)
        {
            string strEntity = entity;
            int indexStart=strEntity.IndexOf("#region");
            int indexEnd = strEntity.IndexOf("#endregion");
            string strPropertyTemp = strEntity.Substring(indexStart, indexEnd - indexStart+10);//10 here means include #end
            string ok = strEntity.Replace(strPropertyTemp, "");
            string strResult = null;
            ArrayList al = dbOper.GetColumnList(tableName);
            for (int i = 0, t = al.Count; i < t; i++)
            {

                string strPropertyName = al[i].ToString();
                string strColumn = al[i].ToString();
                string strProperty = strPropertyTemp.Replace("${PropertyName}", strPropertyName);
                strProperty = strProperty.Replace("${columnName}", strColumn);
                strResult += strProperty + "\r\n        ";
            }
            string s=ok.Insert(indexStart, strResult);
            return s;
        }
    }
}
