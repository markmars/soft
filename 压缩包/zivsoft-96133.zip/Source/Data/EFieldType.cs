using System;

namespace Zivsoft.Data
{
	public enum EFieldType
	{
		FT_BOOL,
		FT_NUMBER,
		FT_CHAR,
		FT_DATE,
		EMPTY
	}
}
