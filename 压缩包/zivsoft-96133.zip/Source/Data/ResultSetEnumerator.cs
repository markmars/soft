using System;
using System.Collections;
using System.Text;

namespace Zivsoft.Data
{
    /// <summary>
    /// ReslutSet
    /// </summary>
    internal class ResultSetEnumerator : IEnumerator
    {
        private ResultSet _rs;
        public ResultSetEnumerator(ResultSet rs)
        {
            this._rs = rs;
        }

        /// <summary>
        /// 
        /// </summary>
        public void Reset()
        {
            this._rs.Reset();
        }
        /// <summary>
        /// 
        /// </summary>
        public object Current
        {
            get
            {
                ResultRow rRow = new ResultRow();
                for (int i = 0, size = this._rs.GetCols(); i < size; i++)
                {
                    string name=this._rs.GetColName(i);
                    object value=this._rs.GetValue(i);
                    rRow[name] = value;
                }
                return rRow;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool MoveNext()
        {
            return this._rs.Next();
        }
    }
}
