﻿using System.Configuration;
using System.Xml;
using Zivsoft.Log;

namespace Zivsoft.Data
{
    internal class ConfigHandler:IConfigurationSectionHandler
    {
        public object Create(object parent, object content, XmlNode section)
        {
            if (section == null)
            {
                Logger.LogWarning("Please configurate the <section name=\"Data\" type=\"Data.ConfigHandler,Data\"/>.");
            }
            return section;
        }
    }


}
