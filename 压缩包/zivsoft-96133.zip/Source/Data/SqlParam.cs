﻿using System;
using System.Data;

namespace Zivsoft.Data
{
    /// <summary>
    /// Sql param
    /// </summary>
    public  struct SqlParam
    {
        IDataParameter  param;
        public object Value
        {
            set
            {
                param.Value = value == null ? DBNull.Value : value;
            }
        }
        /// <summary>
        /// The param is interface
        /// </summary>
        public SqlParam(IDataParameter param)
        {
            this.param = param;
        }
    }
}
