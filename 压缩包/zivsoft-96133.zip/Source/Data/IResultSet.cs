﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Zivsoft.Data
{
    public interface IResultSet
    {
        bool Next();
        int GetCols();
        int GetRows();
        string GetColName(int col);
        object GetValue(int col);
        object GetValue(string colName);
        EFieldType GetColType(int col);
        ResultSet SubSet(int start, int length);
        void InsertEmptyRow(int pos);
        IEnumerator GetEnumerator();
        void Reset();
    }
}
