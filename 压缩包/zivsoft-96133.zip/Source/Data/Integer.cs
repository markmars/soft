﻿using System;
/*
 * Function:integer
 */
namespace Zivsoft.Data
{
    /// <summary>
    /// this type can be set to null value
    /// </summary>
    public class Integer
    {
        private int? _number;
        public Integer(int? number)
        {
            _number = number;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static implicit operator Integer (int? number)
        {
            return new Integer(number);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static explicit operator int?(Integer number)
        {
            return number._number;
        }

        public override string ToString()
        {
            if(this._number==null)
            {
                return null;
            }
            else
            {
                return this._number.Value.ToString();
            }
        }
    }
}
