﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

[assembly: AssemblyTitle("Zivsoft.Data")]

[assembly: InternalsVisibleTo("Zivsoft.Data.SqlServer,PublicKey=0024000004800000940000000602000000240000525341310004000001000100293c5392d25d02110c01e275b81f77422d98ea269425b11a0ab6fbe241eb4b838412d7d17a5172e1a3ec8155d3eedfc984cb3b4648afc9518175b01054f711604efaff4cbe563ea6434a64e601fb80690743ddc5b3c06839be29619a1ed4ba3d0702d8905b4784f7db2374d3e7b23636d4cd7d61cd4cfc2d3e578460066484bb")]
[assembly: InternalsVisibleTo("Zivsoft.Data.Access,PublicKey=0024000004800000940000000602000000240000525341310004000001000100293c5392d25d02110c01e275b81f77422d98ea269425b11a0ab6fbe241eb4b838412d7d17a5172e1a3ec8155d3eedfc984cb3b4648afc9518175b01054f711604efaff4cbe563ea6434a64e601fb80690743ddc5b3c06839be29619a1ed4ba3d0702d8905b4784f7db2374d3e7b23636d4cd7d61cd4cfc2d3e578460066484bb")]
[assembly: AssemblyVersionAttribute("0.5.1.4")]
[assembly: AssemblyFileVersionAttribute("2.0.0.9")]
[assembly: AssemblyDescriptionAttribute("数据层基本库")]
[assembly: AssemblyCompanyAttribute("Zivsoft")]
[assembly: AssemblyProductAttribute("Zivsoft.Data")]
