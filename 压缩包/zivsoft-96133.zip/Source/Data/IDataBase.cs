using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Data
{
    public interface IDataBase
    {
        string TableName { get;set;}
    }
}
