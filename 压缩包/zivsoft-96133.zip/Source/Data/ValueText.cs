﻿
namespace Zivsoft.Data
{
    /// <summary>
    /// 
    /// </summary>
    public class ValueText
    {
        object _value;
        string _text;
        public ValueText(object value, string text)
        {
            _value = value;
            _text = text;
        }
        /// <summary>
        /// This is the value you want
        /// </summary>
        public object Value
        {
            get
            {
                return _value;
            }
            set
            {
                _value = value;
            }
        }
        /// <summary>
        /// This is the string value you want
        /// </summary>
        public string Text
        {
            get
            {
                return _text;
            }
            set
            {
                _text = value;
            }
        }
        public static string Find(ValueText[] a, object value)
        {
            foreach (ValueText vt in a)
            {
                if (vt._value.Equals(value)) return vt._text;
            }
            return string.Empty;
        }
    }
}
