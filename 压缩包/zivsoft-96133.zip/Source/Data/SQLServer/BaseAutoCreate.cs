﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

/*
 * Created by ziv at 2007-2-3
 */
namespace Zivsoft.Data.SQLServer
{
    /// <summary>
    /// </summary>
    abstract class  BaseAutoCreate
    {
        /// <summary>
        /// </summary>
        public abstract string GetShortConnectionString();
    }
}
