﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Text;




/*
 * Created by ziv at 2007-1-28
 */
namespace Zivsoft.Data.SQLServer
{
    internal class SqlServerDbOperator:IDbOperator
    {
        /// <summary>
        /// SqlServer core
        /// </summary>
        private SqlServerDbApi dbi = null;

        /// <summary>
        /// Delete table
        /// </summary>
        /// <param name="tableName">table name</param>
        /// <returns>results</returns>
        public bool Delete(string sql)
        {
            int i=this.operate.ExcuteSql(sql);
            if (i == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        public bool IsExistTable(string tableName)
        {
            int i=operate.GetCount("SELECT * FROM [sysobjects] WHERE [name]='" + tableName + "'");
            if (i == 0)
            {
                return false;
            }
            else
            {
                return true;

            }
        }

        /// <summary>
        /// </summary>
        public int CreateDbTable(object objTable)
        {
            if (objTable is IItemBase)
            {
                return operate.CreateDbTable(objTable as IItemBase);
            }
            else if (objTable is IOrmTable)
            {
                return operate.CreateDbTable(objTable as IOrmTable);
            }
            else
            {
                throw new Exception("SqlServerDbOperator-CreateDbTabl" + objTable.GetType());
            }

        }
        
        /// <summary>
        /// operate hander
        /// </summary>
        protected SqlServerDbApi operate
        {
            get
            {
                if (dbi == null)
                {
                    try
                    {
                        operate = new SqlServerDbApi();
                    }
                    catch (Exception err)
                    {
                        throw err;
                    }
                }
                return dbi;
            }
            set
            {
                dbi = value;
            }
        }
        protected string CheckRights()
        {
            string result = null;
            return result;
        }

        protected void BeginTrans()
        {
            operate.BeginTransaction();
        }

        protected void CommitTrans()
        {
            operate.Commit();
        }

        protected void RollTrans()
        {
            operate.Rollback();
        }

        
        private void CaptureError(Exception ex, string errMsg)
        {
            if (errMsg != null)
            {
                System.Diagnostics.Debug.WriteLine(errMsg);
            }
            else if (ex != null)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }
        public int SelectCount(string tableName, string condition)
        {
            if (tableName == null || tableName == "")
            {
                return -1;
            }
            if (condition == null || condition == "")
            {
                condition = " 1=1";
            }

            List<ValueText> vos = null;

            try
            {
                BeginTrans();
                vos = operate.Select("SELECT COUNT(*), STR(COUNT(*)) FROM " + tableName + " WHERE 1=1 " + condition);
            }
            catch (Exception ex)
            {
                CaptureError(ex, "");
            }
            finally
            {
                RollTrans();
            }

            if (vos == null || vos.Count == 0)
            {
                return -1;
            }
            return Int32.Parse(vos[0].Text);
        }
            
        public int ExecuteNonQuery(string cmdstr)
        {
            return operate.ExecuteNonQuery(cmdstr);
        }
        public object ExecuteScalar(string cmdstr)
        {
            return operate.ExecuteScalar(cmdstr);
        }
        
        internal void GetData(SqlDataReader res, IItemBase di)
        {
            operate.GetData(res,di);
        }
        public List<DataItem> Select<DataItem>(string cmdstr) where DataItem : IItemBase, new()
        {
            return operate.Select<DataItem>(cmdstr);
        }


        public SqlParam AddParam(string name, object value)
        {
            return operate.AddParam(name, value);
        }
        public void Insert(string tbl_name, IOrmTable di, string tbl_key)
        {
          operate.Insert(tbl_name,di,tbl_key);
        }
  
        /// <summary>
		/// 执行一个数据库的SQL查询,并返回数据集结果
		/// 不会返回null,如果结果为空,返回ResultSet.Empty,next()返回false
		/// </summary>
		/// <param name="sql"></param>
		/// <returns></returns>
        public IResultSet QueryResulSet(string sql)
		{
            return operate.Query4ResultSet(sql);
        }

        
        public DataRow Query4DataRow(string strSql)
        {
            return operate.Query4DataRow(strSql);
        }
        public void BeginTransaction()
        {
            operate.BeginTransaction();
        }
        public void Commit()
        {
            operate.Commit();
        }
        public void Rollback()
        {
            operate.Rollback();
        }
        public List<ValueText> Query4VtObject(string cmdstr)
        {
            return operate.Select(cmdstr);
        }


        public DataSet Query4DataSet(object obj)
        {
            if (obj is string)
            {
                return operate.Query4DataSet(obj.ToString());
            }
            else if (obj is IItemBase)
            {
                return operate.Query4DataSet(obj as IItemBase);
            }
            else
            {
                throw new Exception("SqlServerDbOperator-Query4DataSet: not found" + obj.GetType());
            }
        }
        public int Update(string tbl, IItemBase di, string key)
        {
            return operate.Update(tbl, di, key);
        }


        public int Update(object objTable)
        {
            if (objTable is IOrmTable)
            {
                return operate.Update(objTable as IOrmTable);
            }
            else
            {
                throw new Exception("SqlServerDbOperator-Update: no support " + objTable.GetType());
            }
        }
        #region Query4Value
        /// <summary>
        /// select-sql
        /// </summary>
        public string Query4Value(string sql)
        {
            return operate.Query4Value(sql);
        }

        public string Query4Value(string sql, int columnIndex)
        {
            return operate.Query4Value(sql,columnIndex);
        }
        #endregion

        public int Delete(object obj)
        {
            if (obj is IItemBase)
            {
                return operate.DeleteAItemBase(obj as IItemBase);
            }
            else if (obj is IOrmTable)
            {
                return operate.DeleteBaseTable(obj as IOrmTable);
            }
            else
            {
                throw new Exception("Do not suport " + obj.GetType());
            }
        }

        /// <summary>
        /// 根据条件删除一个对象
        /// </summary>
        public int Remove(IOrmTable objTable)
        {
            return 0;
        }

        /// <summary>
        /// 执行Sql语句
        /// </summary>
        public int ExecuteSql(string sql)
        {
            return operate.ExcuteSql(sql);
        }

        /// <summary>
        /// 新增一个对象
        /// </summary>
        public int Insert(object objTable)
        {
            if (objTable is IOrmTable)
            {
                return operate.Insert(objTable as IOrmTable);
            }
            else
            {
                throw new Exception("SqlServerDbOperator-Insert: do not support type "+objTable.GetType());
            }
        }
        /// <summary>
        /// 取得数据库中某一条纪录返回哈希表
        /// </summary>
        /// <param name="sql">查询语句</param>
        /// <returns>返回哈希表</returns>
        public Hashtable Query4Hashtable(string sql)
        {
            return operate.Query4Hashtable(sql);
        }


        /// <summary>
		/// key为sql.xml的SQL的键值
		/// ps任意个参数各个类型
		/// 其中SQL中的参数用?表示..
		/// </summary>
		/// <returns></returns>
        public IResultSet Query4ResultSet(string strSql)
		{
            return operate.Query4ResultSet(strSql);
            
		}

		/// <summary>
		/// 插入数据库新记录
		/// </summary>
		/// <param name="tableName">数据库表名</param>
		/// <param name="values">(字段-值)的形式</param>
		/// <returns>成功返回1,失败返回0</returns>
		public  int Insert(string tableName, Hashtable values)
		{
			//check
			if(null == tableName || null == values || values.Count == 0)
			{
				return 0;
			}
			string sqlPattern = "insert into {0}({1}) values({2})";
			string fields = null;
			string vs = null;
			IDictionaryEnumerator dicEnum = values.GetEnumerator();
			while(dicEnum.MoveNext())
			{
				fields += dicEnum.Key+",";
				if(dicEnum.Value+"" == "")
				{
					vs += "null,";
				}
				else
				{
					vs += "'"+dicEnum.Value+"',";
				} 
			}
			//erase the ','
			fields = fields.Remove(fields.Length-1,1);
			vs = vs.Remove(vs.Length-1,1);
			return this.ExecuteSql(String.Format(sqlPattern,tableName,fields,vs));
		}

		/// <summary>
		/// 更新数据库记录
		/// Sql的where语句,不带where的条件
		/// </summary>
		/// <param name="tableName">数据库表名</param>
		/// <param name="values">(字段-值)的形式</param>
		/// <returns></returns>
		public   int Update(string tableName, Hashtable values,string sqlWhere)
		{
			//check
			if(null == tableName || null == values || values.Count == 0)
			{
				return 0;
			}
			StringBuilder sqlBuilder = new StringBuilder("update ");
			sqlBuilder.Append(tableName);
			sqlBuilder.Append(" set ");

			IDictionaryEnumerator dicEnum = values.GetEnumerator();
			while(dicEnum.MoveNext())
			{
				if(dicEnum.Value+"" == "")
				{
					sqlBuilder.Append(dicEnum.Key+"=null,");
				}
				else
				{
					sqlBuilder.Append(dicEnum.Key+"='"+dicEnum.Value+"',");
				}
			}

			//移除最后的逗号
			sqlBuilder.Remove(sqlBuilder.Length-1,1);

			//添加SQL的Where语句
			if(sqlWhere!=null&&sqlWhere.Trim()!="")
			{
				sqlBuilder.Append(" where ");
				sqlBuilder.Append(sqlWhere);
			}

			return this.ExecuteSql(sqlBuilder.ToString());
		}
	
		/// <summary>
		///	按照参数判断
		/// </summary>
		public  DataTable Query4DataTable(object obj)
		{
            if (obj is string)
            {
                string sql = obj + "";
                return operate.Query4DataTable(sql);
            }
            else
            {
                throw new Exception();
            }
		}

		/// <summary>
		/// 查询出来的数据作为Reader的对象返回
		/// </summary>
		public  IDataReader Query4DataReader(string sql)
		{
            return this.operate.QueryDataReader(sql);
		}


        public  void GetData(IDataReader res, IItemBase di)
        {
            operate.GetData(res, di);
        }


        public  int Update(IItemBase di, string key)
        {
            return operate.Update(di, key);
        }

        /// <summary>
        /// 
        /// </summary>
        public int GetCount(string sql)
        {
            return operate.GetCount(sql);
        }
    }
}
