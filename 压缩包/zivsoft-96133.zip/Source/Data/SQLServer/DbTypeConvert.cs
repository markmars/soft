﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace Zivsoft.Data.SQLServer
{
    class DbTypeConvert
    {
        private DbTypeConvert()
        {

        }


        public static string GetDbType(DbType dbType,int length)
        {
            switch (dbType)
            {
                case DbType.String:
                case DbType.AnsiString:
                    return VarChar(length);
                case DbType.Date:
                    return "smalldatetime";
                case DbType.DateTime:
                    return "datetime";
                case DbType.Decimal:
                    return "Numeric(9)";
                case DbType.Boolean:
                    return "[bit]";
                case DbType.Int32:
                    return "[int]";
                default:
                    throw new Exception("DbTypeConvert-GetDbType: Can't get the db type " + dbType.ToString());
            }
        }

        private static string VarChar(int length)
        {
            if (length > 0 && length < 8000)
            {
                return "[varchar](" + length + ")";
            }
            else
            {
                return "[varchar](50)";
            }
        }
    }
}
