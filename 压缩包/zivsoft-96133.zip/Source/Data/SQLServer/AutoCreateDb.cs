﻿namespace Zivsoft.Data.SQLServer
{
    /// <summary>
    /// to create db for sqlserver
    /// </summary>
    class AutoCreateDb:BaseAutoCreate
    {
        public override string GetShortConnectionString()
        {
            var sSplit = DbFactory.GetDefaultConnectionString().Split(';');
            string sOk = null;
            for (var i = 0; i < sSplit.Length; i++)
            {
                var sTemp = sSplit[i];
                //if not atabase 
                var index = sTemp.IndexOf("database");
                if (index == -1)
                {
                    sOk += sTemp + ";";
                }
            }
            return sOk;
        }
    }
}
