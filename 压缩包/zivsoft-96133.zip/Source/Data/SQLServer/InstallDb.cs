﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Zivsoft.Data.SQLServer
{
    /// <summary>
    /// Setup database
    /// </summary>
    class InstallDb
    {
        private string _strConn;

        public InstallDb(string strConn)
        {
            this._strConn = strConn;
        }
        /// <summary>
        /// Create db, and return item count
        /// </summary>
        /// <param name="dbName">db name</param>
        /// <returns>return count</returns>
        public  SqlConnection CreateDb(string dbName){
            SqlConnection sqlConn = new SqlConnection(this._strConn);
            sqlConn.Open();
            string sql = "create database " + dbName;
            SqlCommand cmd = new SqlCommand(sql, sqlConn);
            cmd.ExecuteNonQuery();
            sqlConn.ChangeDatabase(dbName);
            return sqlConn;
        }
    }
}
