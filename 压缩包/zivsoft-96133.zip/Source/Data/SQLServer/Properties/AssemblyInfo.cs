﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Permissions;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Zivsoft.Data.SQLServer")]
[assembly: AssemblyVersionAttribute("0.5.1.2")]
[assembly: AssemblyFileVersionAttribute("2.0.0.9")]
[assembly: AssemblyDescriptionAttribute("SQLServer数据库")]
[assembly: AssemblyCompanyAttribute("Zivsoft")]
[assembly: AssemblyProductAttribute("Zivsoft.Data.SQLServer")]
[assembly: AssemblyCopyrightAttribute("Zivsoft")]
