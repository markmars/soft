using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace Zivsoft.Data
{
	/// <summary>
	/// RsSqlServer
    /// Used for DataUI control
	/// </summary>
    public class ResultSet : IEnumerable,IResultSet
	{
		public static readonly ResultSet Empty = null;
		static ResultSet()
		{
			ResultSet.Empty = new ResultSet();
			ResultSet.Empty._alValues = new ArrayList(0);
			ResultSet.Empty._curRow = -1;
			ResultSet.Empty._ftColTypes = new EFieldType[0];
			ResultSet.Empty._strColNames = new string[0];
		}
		
		protected int _curRow;
		
		protected string[] _strColNames;
		
		protected EFieldType[] _ftColTypes;
		
		protected ArrayList _alValues;

		/// <summary>
		
		/// </summary>
		/// <param name="reader"></param>
		public ResultSet(IDataReader reader)
		{
			this._curRow = -1;
			this._strColNames = null;
			this._alValues = null;
			this.Parse(reader);
		}

		/// <summary>
		/// </summary>
		private ResultSet()
		{
		}

		/// <summary>
		/// </summary>
		/// <returns></returns>
		public int GetRows()
		{
			if (null == this._alValues)
			{
				return 0;
			}
			return this._alValues.Count;
		}

		/// <summary>
		/// </summary>
		/// <returns></returns>
		public int GetCols()
		{
			if (null == this._strColNames)
			{
				return 0;
			}
			return this._strColNames.Length;
		}

		/// <summary>
		/// </summary>
		/// <returns></returns>
		public bool Next()
		{
			if (this._curRow == this.GetRows() - 1)
			{
				return false;
			}
			this._curRow ++;
			return true;
		}

		/// <summary>
		/// </summary>
		/// <param name="col"></param>
		/// <returns></returns>
		public object GetValue(int col)
		{
			if (col < 0 || col >= this.GetCols())
			{
				return null;
			}
			if (this._curRow != -1)
			{
				object[] vals = this._alValues[this._curRow] as object[];
				if (null == vals)
				{
					return null;
				}
				return vals[col];
			}
			return null;
		}

		/// <summary>
		/// </summary>
		/// <param name="colName"></param>
		/// <returns></returns>
		public object GetValue(string colName)
		{
			int col = -1;
			if (null == this._strColNames)
			{
				return null;
			}

			for (int i = 0, size = this.GetCols(); i < size; i++)
			{
				if (this._strColNames[i] == colName)
				{
					col = i;
					break;
				}
			}
			return this.GetValue(col);
		}

		/// <summary>
		/// </summary>
		/// <param name="row"></param>
		public void GotoRow(int row)
		{
			if (row <= -1)
			{
				this._curRow = -1;
			}
			else if (row >= this.GetRows())
			{
				this._curRow = this.GetRows() - 1;
			}
			else
			{
				this._curRow = row;
			}

		}

		/// <summary>
		/// </summary>
		public void Reset()
		{
			this.GotoRow(-1);
		}

		/// <summary>
		/// </summary>
		/// <param name="col"></param>
		/// <returns></returns>
		public string GetColName(int col)
		{
			if (col < 0 || col >= this.GetCols())
			{
				return null;
			}
			return this._strColNames[col];
		}

		/// <summary>
		/// </summary>
		/// <param name="col"></param>
		/// <returns></returns>
		public EFieldType GetColType(int col)
		{
			if (col < 0 || col >= this.GetCols())
			{
				return EFieldType.EMPTY;
			}
			return this._ftColTypes[col];
		}

		/// <summary>
		/// </summary>
		/// <param name="start"></param>
		/// <param name="length"></param>
		/// <returns></returns>
		public ResultSet SubSet(int start, int length)
		{
			ResultSet rs = new ResultSet();

			int rows = this._alValues.Count;
			int begin = start;
			int size = length;
			if (start >= rows)
			{
				begin = 0;
			}
			if (rows < length || rows < length + start)
			{
				size = rows - start;
			}

			rs._curRow = 0;
			rs._ftColTypes = this._ftColTypes;
			rs._strColNames = this._strColNames;
			rs._alValues = new ArrayList(size);
			for (int i = 0; i < size; i++)
			{
				rs._alValues.Add(this._alValues[i + begin]);
			}
			return rs;
		}

		/// <summary>
		/// </summary>
		/// <param name="pos"></param>
		public void InsertEmptyRow(int pos)
		{
			object[] objs = new object[this._strColNames.Length];
			for(int i=0,size=objs.Length;i<size;i++)
			{
				objs[i] = String.Empty;
			}
			this._alValues.Insert(pos,objs);
		}

		/// <summary>
		/// </summary>
		/// <param name="obj"></param>
		protected virtual void Parse(object obj)
		{
			if (null == obj)
			{
				return;
			}
			if (obj is OleDbDataReader) //
			{
				OleDbDataReader reader = obj as OleDbDataReader;
				if (null == reader)
				{
					return;
				}
				int fieldCount = reader.FieldCount;
				this._strColNames = new string[fieldCount];
				this._ftColTypes = new EFieldType[fieldCount];
				for (int i = 0; i < fieldCount; i++)
				{
					this._strColNames[i] = reader.GetName(i);

					string ftName = reader.GetDataTypeName(i);
					if (ftName == "DBTYPE_VARCHAR" || ftName == "DBTYPE_CHAR")
					{
						this._ftColTypes[i] = EFieldType.FT_CHAR;
					}
					else if (ftName == "DBTYPE_BOOL")
					{
						this._ftColTypes[i] = EFieldType.FT_BOOL;
					}
					else if (ftName == "DBTYPE_DBTIMESTAMP")
					{
						this._ftColTypes[i] = EFieldType.FT_DATE;
					}
					else
					{
						this._ftColTypes[i] = EFieldType.FT_NUMBER;
					}
				}
				this._alValues = new ArrayList();
				while (reader.Read())
				{
					object[] vals = new object[fieldCount];
					for (int i = 0; i < fieldCount; i++)
					{
						vals[i] = reader.GetValue(i);
					}
					this._alValues.Add(vals);
				}

				if(!reader.IsClosed)
				{
					reader.Close();
				}
			}
		    else if(obj is SqlDataReader)
		    {
                SqlDataReader reader = obj as SqlDataReader;
                if (null == reader)
                {
                    return;
                }
                int fieldCount = reader.FieldCount;
                this._strColNames = new string[fieldCount];
                this._ftColTypes = new EFieldType[fieldCount];
                for (int i = 0; i < fieldCount; i++)
                {
                    this._strColNames[i] = reader.GetName(i);

                    string ftName = reader.GetDataTypeName(i);
                    if (ftName == "DBTYPE_VARCHAR" || ftName == "DBTYPE_CHAR")
                    {
                        this._ftColTypes[i] = EFieldType.FT_CHAR;
                    }
                    else if (ftName == "DBTYPE_BOOL")
                    {
                        this._ftColTypes[i] = EFieldType.FT_BOOL;
                    }
                    else if (ftName == "DBTYPE_DBTIMESTAMP")
                    {
                        this._ftColTypes[i] = EFieldType.FT_DATE;
                    }
                    else
                    {
                        this._ftColTypes[i] = EFieldType.FT_NUMBER;
                    }
                }
                this._alValues = new ArrayList();
                while (reader.Read())
                {
                    object[] vals = new object[fieldCount];
                    for (int i = 0; i < fieldCount; i++)
                    {
                        vals[i] = reader.GetValue(i);
                    }
                    this._alValues.Add(vals);
                }

                if (!reader.IsClosed)
                {
                    reader.Close();
                }
		    }
		    else
		    {
                throw new Exception("ResultSet-parse: δ֪����" + obj.GetType());
		    }
		}

		/// <summary>
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator()
		{
			return new ResultSetEnumerator(this);
		}
	}


}