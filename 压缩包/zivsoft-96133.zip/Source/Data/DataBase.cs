﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
/*
 * Created by ziv at 2007-2-2
 * 基类，同时又是ORM调用数据库的入口，所有ORM的数据操作将从这里开始
 * Date:2006-12-4
 */
namespace Zivsoft.Data
{
    /// <summary>
    /// ORM表对象的基类，这是最基本的类
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class DataBase:Attribute,IDataBase
    {
        protected string _tableName;
        internal DataBase()
        {
        }
        /// <summary>
        /// 表的名称
        /// </summary>
        public string TableName
        {
            get
            {
                return this._tableName;
            }
            set
            {
                this._tableName = value;
            }
        }

        private IDbOperator _dbi = null;
        
        /// <summary>
        /// 
        /// </summary>
        internal IDbOperator Operate
        {
            get
            {
                if (_dbi == null)
                {
                    _dbi = DbFactory.DefaultDbOperator();
                }
                return _dbi;
            }
        }
        /// <summary>
        /// 权限控制
        /// </summary>
        protected virtual string CheckRights()
        {
            string result = null;
            return result;
        }

        /// <summary>
        /// 开始事务
        /// </summary>
        protected void BeginTrans()
        {
            Operate.BeginTransaction();
        }

        /// <summary>
        /// 执行事务
        /// </summary>
        protected void CommitTrans()
        {
            Operate.Commit();
        }

        /// <summary>
        /// roll back
        /// </summary>
        protected void RollTrans()
        {
            
            Operate.Rollback();
        }


        /// <summary>
        /// 查询
        /// </summary>
        internal DataSet Query4DataSet(string cmdText)
        {
            return Operate.Query4DataSet(cmdText);
        }
        /// <summary>
        /// 查询数据库
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public DataTable Query4DataTable(string strSql)
        {
            return Operate.Query4DataTable(strSql);
        }

        /// <summary>
        /// 查询记录数
        /// </summary>
        /// <param name="condition">不包含where的条件</param>
        /// <returns></returns>
        protected int SelectCount(string tableName, string condition)
        {
            if (tableName == null || tableName == "")
            {
                return -1;
            }
            if (condition == null || condition == "")
            {
                condition = " 1=1";
            }

            List<ValueText> vos = null;

            try
            {
                BeginTrans();
                vos = Operate.Query4VtObject("SELECT COUNT(*), STR(COUNT(*)) FROM " + tableName + " WHERE 1=1 and " + condition);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                RollTrans();
            }

            if (vos == null || vos.Count == 0)
            {
                return -1;
            }
            return Int32.Parse(vos[0].Text);
        }
    }
}
