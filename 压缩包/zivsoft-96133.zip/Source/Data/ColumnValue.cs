﻿/**************************
 * 
 * 
 * 
 **************************/
namespace Zivsoft.Data
{
    /// <summary>
    /// Be used as SQL wrapper
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ColumnValue<T>
    {
        public string Name
        {
            get; set;
        }
        public T Value
        {
            get;set;
        }

        public static implicit operator ColumnValue<T>(T t)
        {
            return new ColumnValue<T> {Value = t};
        }
    }
}
