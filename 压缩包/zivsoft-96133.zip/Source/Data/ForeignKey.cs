﻿using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System;
using Zivsoft.Data;

/*
 * Date:2006-12-4
 */
namespace Zivsoft.Data
{
    /// <summary>
    /// ForeignKey
    /// </summary>
    public class ForeignKey:BaseField
    {
        private ArrayList _fkMaps = new ArrayList();

        private ArrayList _ds = new ArrayList();
        /// <summary>
        /// 
        /// </summary>
        private Type _type;
        private string _foreignKey;

        /// <summary>
        /// 
        /// </summary>
        public Type Type
        {
            get
            {
                return this._type;
            }
            set
            {
                this._type = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ForeignKeyName
        {
            get
            {
                return this._foreignKey;
            }
            set
            {
                this._foreignKey = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        internal ForeignKey()
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="type">entity table</param>
        /// <param name="keyName">foreign key</param>
        public ForeignKey(string keyName, Type type,string foreignKey)
        {

            base.FieldName = keyName;
            this.Type = type;
            this.ForeignKeyName = foreignKey;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="keyPair">RoleId:RoleId</param>
        public void AddMapKey(string keyPair, AItemBase baseTable, AItemBase mapTable)
        {
            int i = 0;
            for (i = 0; i < this._fkMaps.Count; i++)
            {
                if (((string)this._fkMaps[i]).IndexOf(keyPair) >= 0)
                {
                    break;
                }
            }
            if (i < this._fkMaps.Count)
            {
                this._fkMaps.RemoveAt(i);
                System.Data.DataTable dt = (System.Data.DataTable)this._ds[i];
                dt.Clear();
                this._ds.RemoveAt(i);
                dt = null;
            }
            this._fkMaps.Add(keyPair);
            string[] keys = keyPair.Split(':');
            //
            string baseField = keys[0];
            //
            string mapField = keys[1];

            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT DISTINCT * FROM ");
            sb.Append(mapTable.GetName());//
            sb.Append(" INNER JOIN ");
            sb.Append(baseTable.GetName());//


            sb.Append(" ON " + baseTable.GetName() + "." + baseField + "=");//
            sb.Append(mapTable.GetName());//
            sb.Append("."+mapField);

            IDataReader dr=DbFactory.DefaultDbOperator().Query4DataReader(sb.ToString());
            baseTable.Load(dr);
            mapTable.Load(dr);
        }

        public void AddMapKeyWithConditions(string keyPair, AItemBase BaseTable, AItemBase mapTable, string condition)
        {
            int i = 0;
            for (i = 0; i < this._fkMaps.Count; i++)
            {
                if (((string)this._fkMaps[i]).IndexOf(keyPair + "=") >= 0)
                {
                    break;
                }
            }
            if (i < this._fkMaps.Count)
            {
                this._fkMaps.RemoveAt(i);
                DataTable dt = (DataTable)this._ds[i];
                dt.Clear();
                this._ds.RemoveAt(i);
                dt = null;
            }
            this._fkMaps.Add(keyPair);
            string[] keys = keyPair.Split(':');
            string baseField = keys[0];
            string mapField = keys[1];
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT DISTINCT " + mapTable.GetName() + "."+mapTable.GetPKName()+", " + mapTable.GetName() + ".");
            sb.Append(mapField);
            sb.Append(" FROM ");
            sb.Append(mapTable.GetName());
            sb.Append(" INNER JOIN ");
            sb.Append(BaseTable.GetName());
            sb.Append(" ON " + BaseTable.GetName() + "." + baseField + "=");
            sb.Append(mapTable.GetName());
            sb.Append("."+mapField);
            sb.Append(" WHERE 1=1 ");
            if (condition != null && condition != "")
            {
                sb.Append(" AND ");
                sb.Append(condition);
            }
            sb.Append(" ORDER BY " + mapTable.GetName() + "."+mapTable.GetPKName());
            IDbOperator db = DbFactory.DefaultDbOperator();
            DataSet tmp = db.Query4DataSet(sb.ToString());
            this._ds.Add(tmp.Tables[0]);
            tmp.Tables.Clear();
            tmp = null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="di"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public object FindValueByFK(AItemBase di, string field)
        {
            object result = "";
            int i = 0;
            string strMap = "";
            if (0 < this._fkMaps.Count) 
            {
                strMap = (string)this._fkMaps[0];
            }

            if (i == this._fkMaps.Count)
            {
                return null;
            }

            DataTable dt = (DataTable)this._ds[i];

            string[] keys=strMap.Split(':');
            string localField = keys[0];
            string mapField = keys[1];

            if (di[localField] != null)
            {
                DataRow[] drs = dt.Select(localField+"='" + di[localField] + "'");

                if (drs.Length != 1)
                {
                    return null;
                }

                string fieldName = mapField;

                return drs[0][fieldName];
            }
            return "";
        }
    }
}
