﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Reflection;
using System.Collections;
using Zivsoft.Data;


namespace Zivsoft.Data
{
    /// <summary>
    /// entity for a table
    /// </summary>
    public abstract class AItemBase : DataBase, IItemBase
    {
        /// <summary>
        /// 取得当前表对象：所有表对象的父类都是<see cref="BaseTable"/>作为基类继承。
        /// </summary>
        protected abstract OrmTable GetTableObject();

        public void SetValue(string name,object value)
        {
            if (value is bool)
            {
                if (value.Equals(true))
                {
                    this[name] = 1;
                }
                else
                {
                    this[name] = 0;
                }
            }
        }

        /// <summary>
        /// field for db field
        /// </summary>
        private Dictionary<string, object> fields = new Dictionary<string, object>();

        public Dictionary<string, object> Fields
        {
            get
            {
                return this.fields;
            }
            set
            {
                this.fields = value;
            }
        }

        internal protected static ForeignKey foreignKey = new ForeignKey();

        /// <summary>
        /// 构造函数
        /// </summary>
        internal AItemBase()
        {
            if (foreignKey == null)
            {
                foreignKey = new ForeignKey();
            }
        }

        /// <summary>
        /// 索引器
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        /// <returns>返回值</returns>
        public object this[string fieldName]
        {
            get
            {
                object v;
                fields.TryGetValue(fieldName, out v);
                return v;
            }
            set
            {
                fields[fieldName] = value;
            }
        }
        /// <summary>
        /// 判断是否包含字段
        /// </summary>
        /// <param name="field"></param>
        /// <returns></returns>
        internal bool Contains(string field)
        {
            return fields.ContainsKey(field);
        }


        /// <summary>
        /// Int?
        /// </summary>
        /// <param name="field"></param>
        /// <returns></returns>
        protected int? GetInt(string field)
        {
            object v;
            fields.TryGetValue(field, out v);
            return (int?)v;
        }
        protected bool GetBool(string field)
        {
            object v;
            fields.TryGetValue(field, out v);
            return v == null ? false : (bool)v;
        }
        /// <summary>
        /// GUID
        /// </summary>
        protected Guid GetGuid(string field)
        {
            object v;
            fields.TryGetValue(field, out v);
            return v == null ? Guid.Empty : (Guid)v;
        }
        protected double GetFloat(string field)
        {
            object v;
            fields.TryGetValue(field, out v);
            return v == null ? 0.0 : (double)v;
        }
        /// <summary>
        /// 转化成时间格式
        /// </summary>
        /// <param name="field"></param>
        /// <returns>DateTime?</returns>
        protected DateTime? GetDateTime(string field)
        {
            object v;
            fields.TryGetValue(field, out v);
            if (v == null || v == DBNull.Value)
            {
                return null;
            }
            else
            {
                try
                {
                    DateTime? dt = (DateTime?)v;
                    return dt;
                }
                catch
                {
                    return null;
                }
            }
        }

        protected long GetLong(string field)
        {
            object v;
            fields.TryGetValue(field, out v);
            return v == null ? 0 : Convert.ToInt64(v);
        }
        /// <summary>
        /// 字符串转换
        /// </summary>
        protected String GetString(string field)
        {
            object v;
            fields.TryGetValue(field, out v);
            return v == null ? null : v.ToString();
        }

        /// <summary>
        /// 获取表对象名称
        /// </summary>
        /// <returns>返回表对象的名称</returns>
        public virtual string GetName()
        {
            return this.GetType().Name;
        }
        
        /// <summary>
        /// 外键关联
        /// </summary>
        /// <param name="ormTable"></param>
        /// <returns></returns>
        internal AItemBase JoinOn(AItemBase ormTable)
        {
            ForeignKey fk = new ForeignKey();

            //获取实体属性
            IDictionary<string, Hashtable> al = this.GetFKObject();
            ICollection<string> keys=al.Keys;
            foreach (string key in keys)
            {
                //获取外键对象
                Hashtable foreignObject = al[key];

                //遍历
                ICollection fKeys = foreignObject.Keys;
                foreach (Type obj in fKeys)
                {
                    if (obj==ormTable.GetType())
                    {
                        string fkName = foreignObject[obj] + "";
                        //外键操作
                        fk.AddMapKey(key + ":" + fkName, ormTable, this);
                    }
                }

            }
            return null;
        }

        /// <summary>
        /// Get data as datatable
        /// </summary>
        public DataTable LoadDataTable()
        {
            string cmdText = "";
            string condition = "";
            string pk = this.GetPKName()[0] as string;
            object pv = this.Fields[pk];

            if (fields.Count == 0)
            {

                if (pv != null)
                {
                    condition = pk+ "='" + pv + "'";
                    return base.Query4DataTable("select * from " + this.GetName() + " where " + condition);
                }
                else
                {
                    return base.Query4DataTable("select * from " + this.GetName());
                }
            }
            StringBuilder sb0 = new StringBuilder();

            foreach (KeyValuePair<string, object> f in fields)
            {
                sb0.Append(f.Key);

                if (f.Value is bool)
                {
                    bool? b = (bool?)f.Value;
                    if (b == null)
                    {
                        sb0.Append(" is null ");
                    }
                    else if (b == true)
                    {
                        sb0.Append("=1");
                    }
                    else
                    {
                        sb0.Append("=0");
                    }
                    sb0.Append(" and ");
                }
                else
                {
                    sb0.Append('=');
                    sb0.Append('\'');
                    sb0.Append(f.Value);
                    sb0.Append("' and ");
                }

            }
            if (pv != null)
            {
                sb0.Append(this.GetPKName() + "='" + pv + "'");
            }
            else
            {
                sb0.Length = sb0.Length - 5;
            }
            condition = sb0.ToString();
            cmdText = "select * from " + this.GetName() + " where " + condition;
            return base.Query4DataTable(cmdText);
        }

        /// <summary>
        /// 获取数据集
        /// </summary>
        public DataSet Query4DataSet()
        {
            string cmdText="";
            string condition = "";
            string pk = null;
            object pv = null;
            if (fields.Count == 0)
            {
                if (this.GetPKName().Count != 0)
                {
                    pk = this.GetPKName()[0] as string;
                }
                if (Fields.ContainsKey(pk))
                {
                    pv = this.Fields[pk];
                }
                if (pv != null)
                {
                    condition=pk+"='" +pv + "'";
                    return base.Query4DataSet("select * from " + this.GetName() + " where " + condition);
                }
                else
                {
                    return base.Query4DataSet("select * from " + this.GetName());
                }
            }
            StringBuilder sb0 = new StringBuilder();

            foreach (KeyValuePair<string, object> f in fields)
            {
                sb0.Append(f.Key);
                                
                if (f.Value is bool)
                {
                    bool? b = (bool?)f.Value;
                    if (b == null)
                    {
                        sb0.Append(" is null ");
                    }
                    else if (b==true)
                    {
                        sb0.Append("=1");
                    }
                    else
                    {
                        sb0.Append("=0");
                    }
                    sb0.Append(" and ");
                }
                else
                {
                    sb0.Append('=');
                    sb0.Append('\'');
                    sb0.Append(f.Value);
                    sb0.Append("' and ");
                }
                
            }
            if (pv != null)
            {
                sb0.Append(this.GetPKName()+"='" + pv + "'");
            }
            else
            {
                sb0.Length = sb0.Length - 5;
            }
            condition = sb0.ToString();
            cmdText = "select * from " + this.GetName()[0] + " where " + condition;
            return base.Query4DataSet(cmdText);
        }


        protected void Load(Hashtable primaryKey)
        {
            string sql = "SELECT * FROM " + this.GetName()+ " WHERE ";
            
            ICollection keys=primaryKey.Keys;
            foreach(string key in keys)
            {
                sql += key + "='" + primaryKey[key] + "' and ";
            }
            sql = sql.Remove(sql.Length - 5);
            using (IDataReader res = Operate.Query4DataReader(sql))
            {
                if (res.Read())
                {
                    this.GetData(res, this);
                }
            }
        }

        /// <summary>
        /// Get data from database
        /// </summary>
        internal void GetData(IDataReader dataReader, AItemBase objItemBase)
        {
            int columnCount = dataReader.FieldCount;
            string pk = null;
            if (objItemBase.GetPKName().Count != 0)
            {
                pk = objItemBase.GetPKName()[0].ToString();
                objItemBase.Fields[pk] = dataReader[pk];
            }
            for (int i = 0; i < columnCount; i++)
            {
                object v = dataReader.GetValue(i);
                if (v == DBNull.Value) v = null;
                string name = dataReader.GetName(i);
                objItemBase[name] = v;
            }
        }

        internal void Load(IDataReader dataReader)
        {
            if (dataReader.Read())
            {
                this.GetData(dataReader, this);
            }
        }

        /// <summary>
        /// Insert one item to database on this table
        /// </summary>
        public int Insert()
        {
            return Operate.Insert(this.GetTableObject());
        }
        
        public int Update()
        {
            return Operate.Update(this.GetTableObject());
        }
        
        /// <summary>
        /// delete data
        /// not drop table
        /// </summary>
        public int Delete()
        {
            return Operate.Delete(this);
        }
        
        /// <summary>
        /// 通过字段查找这个字段的值
        /// </summary>
        /// <param name="fieldName">字段名成</param>
        /// <returns>返回字段的值</returns>
        internal object FindValueByName(string fieldName)
        {
            object value = foreignKey.FindValueByFK(this, fieldName);
            return value;
        }

        /// <summary>
        /// 查询对象数量
        /// </summary>
        /// <returns></returns>
        public int SelectCount()
        {
            string condition =this.ConstrucSqlCondition();
            return SelectCount(this.GetName(), condition);
        }

        private DbType FindTypeByName(string fieldName)
        {
            PropertyInfo[] pInfos = this.GetType().GetProperties();
            foreach (PropertyInfo pInfo in pInfos)
            {
                foreach (Attribute attr in GetCustomAttributes(pInfo))
                {
                    BaseField field = (BaseField)attr;
                    if (field.FieldName == fieldName)
                    {
                        return field.DbType;
                    }
                }
            }
            return DbType.String;
        }

        /// <summary>
        /// create sql sentence
        /// </summary>
        /// <returns>return sql-where content (not include where)</returns>
        protected string ConstrucSqlCondition()
        {
            StringBuilder sb = new StringBuilder();
            foreach(KeyValuePair<string,object> f in fields){
                DbType t = this.FindTypeByName(f.Key);
                if (t == DbType.Boolean)
                {
                    sb.Append(f.Key);
                    sb.Append('=');
                    sb.Append('\'');
                    
                    if (f.Value.ToString().ToLower()=="true"||f.Value.ToString().ToLower()=="1")
                    {
                        sb.Append(1);
                    }
                    else
                    {
                        sb.Append(0);
                    }
                    sb.Append("' and ");
                }
                else
                {
                    sb.Append(f.Key);
                    sb.Append('=');
                    sb.Append('\'');
                    sb.Append(f.Value);
                    sb.Append("' and ");
                }
            }
            

            if (sb.Length > 5)
            {
                sb.Length = sb.Length - 5;
            }
            else
            {
                sb.Length = 0;
            }
            return sb.ToString();
        }

        internal int SelectCount(string condition)
        {
            return SelectCount(this.GetName(), condition);
        }

        /// <summary>
        /// 获取外键对象
        /// </summary>
        internal IDictionary<string,Hashtable> GetFKObject()
        {
            IDictionary<string, Hashtable> fk = new Dictionary<string, Hashtable>();
            PropertyInfo[] pInfos = this.GetType().GetProperties();
            foreach (PropertyInfo pInfo in pInfos)
            {
                foreach (Attribute attr in GetCustomAttributes(pInfo))
                {
                    if (attr.GetType() == typeof(ForeignKey))
                    {
                        //外键信息
                        ForeignKey foreignKey=(ForeignKey)attr;
                        Type fkObject=foreignKey.Type;
                        string fkName = foreignKey.ForeignKeyName;
                        Hashtable ht=new Hashtable();
                        ht.Add(fkObject,fkName);
                        //本字段名称
                        fk.Add(foreignKey.FieldName, ht);
                    }
                }
            }
            return fk;
        }

        /// <summary>
        /// 返回所有列
        /// </summary>
        /// <returns>返回哈西表，key为列名，value属性</returns>
        public Hashtable GetAllColumn()
        {
            Hashtable htCol = new Hashtable();
            PropertyInfo[] pInfos = this.GetType().GetProperties();
            foreach (PropertyInfo pInfo in pInfos)
            {
                foreach (Attribute attr in GetCustomAttributes(pInfo))
                {
                    BaseField baseField=(BaseField)attr;
                    string key = baseField.FieldName;//自段名称
                    //DbType type=baseField.DbType;//数据库类型
                    htCol.Add(key, baseField);
                }
            }
            return htCol;
        }

        /// <summary>
        /// Return the all keys
        /// </summary>
        public Hashtable GetPKColumn()
        {
            Hashtable htPk = new Hashtable();
            PropertyInfo[] pInfos = this.GetType().GetProperties();
            foreach (PropertyInfo pInfo in pInfos)
            {
                foreach (Attribute attr in GetCustomAttributes(pInfo))
                {
                    if (attr is PrimaryKey)//primary key
                    {
                        PrimaryKey keyField = (PrimaryKey)attr;
                        string key = keyField.FieldName;//field name
                        DbType type = keyField.DbType;//db type
                        htPk.Add(key, type);
                    }
                }
            }
            return htPk;
        }
        
        /// <summary>
        /// Get primary keys collection
        /// </summary>
        /// <returns>return ArrayList</returns>
        public ArrayList GetPKName()
        {
            ArrayList al = new ArrayList(0);
            string pk = null;
            PropertyInfo[] pInfos = this.GetType().GetProperties();
            foreach (PropertyInfo pInfo in pInfos)
            {
                foreach (Attribute attr in GetCustomAttributes(pInfo))
                {
                    if (attr.GetType() == typeof(PrimaryKey))
                    {
                        pk = ((PrimaryKey)attr).FieldName;
                        //如果主建被赋值
                        if (fields.ContainsKey(pk))
                        {
                            al.Add(pk);
                            //将主建赋给内部关键字
                            //this._interId = fields[pk];
                            //移处主建
                            //fields.Remove(pk);
                        }
                        break;
                    }
                }
            }
            return al;
        }
    }
}
