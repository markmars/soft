﻿using System.Data;
using System.Collections;

/*
 * date：2006-12-4
 * Created by ziv at 2007-3-27
 */
namespace Zivsoft.Data
{
    /// <summary>
    /// ORM
    /// </summary>
    public abstract class OrmTable : AItemBase, IOrmTable
    {
        /// <summary>
        /// 
        /// </summary>
        public OrmTable()
        {

        }
        /// <summary>
        /// drop table
        /// not delete data from table
        /// </summary>
        public bool Drop()
        {
            return Operate.Delete(this.GetName());
        }
        protected override OrmTable GetTableObject()
        {
            return this;
        }

        /// <summary>
        /// Load an object by a primary key
        /// Primary key should be only one (not zero and not more than one)
        /// </summary>
        public void Load()
        {
            this.Load(this.GetHashtable());
        }

        private Hashtable GetHashtable()
        {
            Hashtable ht = new Hashtable();
            ICollection keys = Fields.Keys;
            foreach (string key in keys)
            {
                ht.Add(key, Fields[key]);
            }
            return ht;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>ResultSet</returns>
        public IResultSet LoadResultSet()
        {
            string condition = this.ConstrucSqlCondition();
            if (condition != "")
            {
                string sql="select * from " + this.GetName() + " where " + condition;
                return Operate.Query4ResultSet(sql);
            }
            else
            {
                return Operate.Query4ResultSet("select * from " + this.GetName());
            }
        }

        public DataView LoadDataView()
        {
            return this.LoadDataTable().DefaultView;
        }
    }
}
