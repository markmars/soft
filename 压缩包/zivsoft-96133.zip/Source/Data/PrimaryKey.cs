using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Data;
using Zivsoft.Data;

/*
 * key
 */
namespace Zivsoft.Data
{
    /// <summary>
    /// key
    /// </summary>
    public class PrimaryKey : BaseField
    {
        public PrimaryKey(string keyName,DbType dbType)
        {
            base.FieldName = keyName;
            base.DbType = dbType;
        }

        public PrimaryKey(string keyName, DbType dbType, int length)
        {
            base.FieldName = keyName;
            base.DbType = dbType;
            base.Length = length;
        }
    }
}
