using System;
using System.Collections.Generic;
using System.Text;
using Zivsoft.Data;

namespace Zivsoft.Data
{
    public class ColumnField:BaseField
    {
        public ColumnField(string columnName)
        {
            this.FieldName = columnName;
        }
    }
}
