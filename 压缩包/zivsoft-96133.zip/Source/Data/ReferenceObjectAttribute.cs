﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Data
{
    [AttributeUsage(AttributeTargets.Property)]
    public class ReferenceObjectAttribute : Attribute
    {
        private Type referenceType;
        private string primaryKey;
        private string foreignKey;
        public ReferenceObjectAttribute(Type referenceType, string primaryKey, string foreignKey)
        {
            this.referenceType = referenceType;
            this.primaryKey = primaryKey;
            this.foreignKey = foreignKey;
        }

        public ReferenceObjectAttribute() { }

        public Type ReferenceType
        {
            get { return referenceType; }
            set { referenceType = value; }
        }

        public string PrimaryKey
        {
            get { return primaryKey; }
            set { primaryKey = value; }
        }

        public string ForeignKey
        {
            get { return foreignKey; }
            set { foreignKey = value; }
        }
    }
    [AttributeUsage(AttributeTargets.Property)]
    public class SubObjectAttribute : Attribute
    {
        private Type subObjectType;
        private string primaryKey;
        private string foreignKey;
        public SubObjectAttribute(Type subObjectType, string primaryKey, string foreignKey)
        {
            this.subObjectType = subObjectType;
            this.primaryKey = primaryKey;
            this.foreignKey = foreignKey;
        }

        public SubObjectAttribute() { }

        public Type SubObjectType
        {
            get { return subObjectType; }
            set { subObjectType = value; }
        }

        public string PrimaryKey
        {
            get { return primaryKey; }
            set { primaryKey = value; }
        }

        public string ForeignKey
        {
            get { return foreignKey; }
            set { foreignKey = value; }
        }
    }
    [AttributeUsage(AttributeTargets.Property)]
    public class AutoIncreaseAttribute : Attribute
    {
        private int step = 1;

        public AutoIncreaseAttribute() { }

        public AutoIncreaseAttribute(int step)
        {
            this.step = step;
        }

        public int Step
        {
            get { return step; }
            set { step = value; }
        }
    }
}
