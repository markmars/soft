﻿using System;
using System.IO;
using Zivsoft.Log;


/*
 * Created by ziv at 2007-2-8
 */
namespace Zivsoft.Data
{
    interface IDataConfig
    {
        string ConnectionString { get; }
        string DbType { get; }
        bool AutoCreateDb { get; }
        bool AutoCreateTable { get; }
    }

    interface IDataInstance {
        string GetDbEntityClassName();
        string GetDataProccessAssembly();

    }

    /// <summary>
    /// 
    /// </summary>
    internal partial class DataSection:IDataConfig,IDataInstance
    {
        
        #region Single1
        private static IDataConfig _single = null;
        public static IDataConfig Current
        {
            get 
            {
                if (null == _single)
                {
                    _single = new DataSection();
                }
                return _single;
            }
        }
        #endregion

        #region Single2
        private static IDataInstance _single2 = null;
        public static IDataInstance Assembly
        {
            get
            {
                if (null == _single2)
                {
                    _single2 = new DataSection();
                }
                return _single2;
            }
        }
        #endregion

        #region IDataInstance Interface members
        /// <summary>
        /// 
        /// </summary>
        public string GetDataProccessAssembly()
        {

            ReadXml();

            //0: if it is in GAC
            if (_assembly.IndexOf(',') != -1)
            {
                Logger.LogDebug("Detected that the data assembly is in GAC");
                return _assembly;
            }

            //1: all
            if (File.Exists(_assembly))
            {
                return _assembly;
            }

            //2: app
            if (string.IsNullOrEmpty(_assembly)) {
                Logger.LogError("_assembly is null or empty");
                throw new Exception("_assembly is null or empty"); 
            }
            string assemblyFile = AppDomain.CurrentDomain.BaseDirectory + @"\" + _assembly + ".dll";
            if (Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\bin\"))
            {
                //3: web
                assemblyFile = AppDomain.CurrentDomain.BaseDirectory + @"\bin\" + _assembly + ".dll";
            }
            
            //5: error
            if (!File.Exists(assemblyFile))
            {
                throw new FileNotFoundException(string.Format("File {0} not found!",assemblyFile));
            }
            return assemblyFile;
        }
        public string GetDbEntityClassName()
        {
            ReadXml();
            if (string.IsNullOrEmpty(_className))
            {
                throw new NullReferenceException("class name is null or empty in db config, \nplease check you have configured the db node in your config file.");
            }
            return _className;
        }
        #endregion

        #region IDataConfig Interface members
        public string ConnectionString
        {
            get
            {
                if (_appSettings == null)
                {
                    ReadXml();
                }
                if (!_appSettings.Contains(KEY_CONNECTIONSTRING))
                {
                    throw new Exception("ConnetionString [" + KEY_CONNECTIONSTRING + "] can't be found.");
                }
                return _appSettings[KEY_CONNECTIONSTRING].ToString();
            }
        }

        /// <summary>
        /// You should the node's name is DbType.
        /// </summary>
        public string DbType
        {
            get
            {
                return _section.Attributes[KEY_DBTYPE].Value;
            }
        }

        

        /// <summary>
        /// AutoCreateDb=True|true
        /// </summary>
        /// <returns></returns>
        public bool AutoCreateDb
        {
            get
            {
                if (_appSettings == null)
                {
                    ReadXml();
                }
                string s = _appSettings[KEY_AUTOCREATEDB] + "";
                if (s == null || s.Trim() == "")
                {
                    return false;
                }
                else if (s.Trim().ToLower() == "true")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool AutoCreateTable
        {
            get
            {
                if (_appSettings == null)
                {
                    ReadXml();
                }
                if (_appSettings == null)
                {
                    throw new Exception("_appSettings == null");
                }
                string s = _appSettings[KEY_AUTOCREATETABLE] + "";
                if (s == null || s.Trim() == "")
                {
                    return false;
                }
                else if (s.Trim().ToLower() == "true")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        #endregion
    }
}
