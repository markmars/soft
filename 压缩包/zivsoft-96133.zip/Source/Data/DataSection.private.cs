﻿using System;
using System.Xml;
using System.Collections;
using System.Configuration;
using System.IO;
using Zivsoft.Log;


namespace Zivsoft.Data
{
    partial class DataSection
    {
        private XmlNode _section;
        private static string _assembly;
        private static string _className;
        private static Hashtable _appSettings;
        private const string KEY_CONNECTIONSTRING = "ConnectionString";
        private const string KEY_AUTOCREATETABLE = "AutoCreateTable";
        private const string KEY_AUTOCREATEDB = "AutoCreateDb";
        private const string KEY_DBTYPE = "DbType";
        private const string KEY_ASSEMBLY = "assembly";

        /// <summary>
        /// 
        /// </summary>
        private DataSection()
        {
            if (_section == null)
            {
                Logger.LogDebug("Getting config file for [Zivsoft.Data]");
                _section = GetSectionRoot();
            }
        }

        private XmlNode GetSectionRoot()
        {
            XmlNode node = null;
            try
            {
                node = ConfigurationManager.GetSection("Data") as XmlNode; //root
                Logger.LogDebug("Getting [Data] section successfully.");
            }
            catch (ConfigurationErrorsException e)
            {
                Logger.LogWarning(e.Message);
                
            }
            if (null == node)
            {
                node = Factory.GetConfig();
            }
            return node;
        }

        private class Factory
        {
            public static XmlNode GetConfig()
            {
                XmlNode node = null;
                XmlDocument xml = new XmlDocument();
                try
                {
                    var file=AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Data\\Data.xml";
                    Logger.LogDebug("Loading {0}", file);
                    xml.Load(file);
                }
                catch (DirectoryNotFoundException)
                {

                    var file = AppDomain.CurrentDomain.BaseDirectory + "Data.xml";
                    Logger.LogDebug("Loading {0}", file);
                    xml.Load(file);
                }
                var nodes = xml.SelectNodes("/Config/Data");//xpath
                foreach (XmlNode n in nodes)
                {
                    if (n.Name == "Data")
                    {
                        node = n;
                        break;
                    }
                }
                return node;
            }
        }

        /// <summary>
        /// Read Data Node
        /// <SQLServer type="Zivsoft.Data.SQLServer.SqlServerDbOperator;SQLServer, Version=1.0.3.9, Culture=neutral, PublicKeyToken=BA9122935F80DBE7">
        /// </summary>
        private void ReadXml()
        {
            Logger.LogDebug("Begin to read xml for Zivsoft.Data");
            var flag = ';';
            bool bFindDbNode = false;
            if (_section == null)
            {
                var error = "Read Data.xml or Web.config or App.config failed.";
                Logger.LogError(error);
                throw new Exception(error);
            }
            for (int i = 0, t = _section.ChildNodes.Count; i < t; i++)
            {
                var item = _section.ChildNodes[i];
                if (item.Name == DbType && item.Attributes.Count != 0)
                {
                    string type = item.Attributes["type"].Value;
                    if (type.IndexOf(flag) != -1)
                    {
                        _className = type.Split(flag)[0];
                        _assembly = type.Split(flag)[1];
                    }
                    else
                    {
                        Logger.LogError("<... type=\"ClassName;AssemblyName\"></...> got an error.");
                        throw new Exception("<... type=\"ClassName;AssemblyName\"></...> got an error.");
                    }

                    //add into _appSettings
                    _appSettings = new Hashtable(0);
                    for (int j = 0, k = item.ChildNodes.Count; j < k; j++)
                    {
                        XmlNode appSettingsNode = item.ChildNodes[j];
                        if (appSettingsNode != null && appSettingsNode.Name == "add")
                        {
                            _appSettings.Add(appSettingsNode.Attributes["key"].Value, appSettingsNode.Attributes["value"].Value);
                        }
                    }
                    bFindDbNode = true;
                }
            }
            if (!bFindDbNode)
            {
                Logger.LogError("Can't find the node [" + DbType + "]");
                throw new Exception("Can't find the node [" + DbType + "]");
            }
        }


    }
}
