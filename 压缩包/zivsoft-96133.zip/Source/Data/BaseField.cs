﻿using System;
using System.Data;
/*
 * Created by ziv at 2006-11-25
 *
 */
namespace Zivsoft.Data
{
    /// <summary>
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class BaseField : Attribute
    {
        /// <summary>
        /// </summary>
        public string FieldName
        {
            get;
            set;
        }

        /// <summary>
        /// </summary>
        public DbType DbType
        {
            get;
            set;
        }

        /// <summary>
        /// </summary>
        public int Length
        {
            get;
            set;
        }
    }
}
