﻿using System.Collections;
using System.Collections.Generic;
using System.Data;

/*
 * ORM
 * Insert,Update,Delete,Query
 */
namespace Zivsoft.Data
{
    /// <summary>
    /// All db operatpor
    /// </summary>
    public interface IDbOperator
    {

        /// <summary>
        /// Create table
        /// </summary>
        /// <param name="objTable"></param>
        /// <returns></returns>
        int CreateDbTable(object objTable);
        /// <summary>
        /// Maybe in Access db, you can't do this, but in SQL server you can implement this interface
        /// </summary>
        /// <param name="tableName">table</param>
        /// <returns>return true or false</returns>
        bool IsExistTable(string tableName);
        /// <summary>
        /// Excute Sql
        /// </summary>
        int ExecuteSql(string sql);
        /// <summary>
        /// insert one new record
        /// </summary>
        /// <param name="tableName">tablename in db</param>
        /// <param name="values">(field-value)</param>
        int Insert(string tableName, Hashtable values);
        /// <summary>
        /// update
        /// </summary>
        /// <param name="tableName">tablename in db</param>
        /// <param name="values">(field-value)</param>
        /// <param name="sqlWhere"></param>
        /// <returns></returns>
        int Update(string tableName, Hashtable values, string sqlWhere);
        /// <summary>
        /// Return datatable
        /// </summary>
        DataTable Query4DataTable(object obj);
        /// <summary>
        /// select-sql
        /// return the first field value
        /// </summary>
        string Query4Value(string sql);
        /// <summary>
        /// select-sql
        /// </summary>
        /// <param name="sql">select-sql</param>
        /// <param name="columnIndex">from 0,1,2,...</param>
        /// <returns>the specified string value</returns>
        string Query4Value(string sql, int columnIndex);
        /// <summary>
        /// select-sql
        /// </summary>
        int GetCount(string sql);
        /// <summary>
        /// Begin Transaction
        /// </summary>
        void BeginTransaction();
        /// <summary>
        /// finish the transaction
        /// </summary>
        void Commit();
        /// <summary>
        /// rollback current transaction
        /// </summary>
        void Rollback();
        /// <summary>
        /// select field1, field2 from tablename
        /// </summary>
        List<ValueText> Query4VtObject(string sql);
        /// <summary>
        /// DataSet
        /// </summary>
        DataSet Query4DataSet(object obj);
        /// <summary>
        /// if error, then ResultSet returns Empty
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        IResultSet Query4ResultSet(string sql);
        /// <summary>
        /// get one record and return into a hashtable
        /// </summary>
        /// <param name="sql">sql-select</param>
        /// <returns></returns>
        Hashtable Query4Hashtable(string sql);
        /// <summary>
        /// select-sql
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        DataRow Query4DataRow(string strSql);
        /// <summary>
        /// as IDataREader
        /// </summary>
        /// <returns></returns>
        IDataReader Query4DataReader(string strSql);      
        /// <summary>
        /// add a new object(ORM)
        /// </summary>
        int Insert(object ormTable);
        /// <summary>
        /// update a existed object
        /// </summary>
        int Update(object ormTable);
        /// <summary>
        /// you must specify the primary key's value
        /// </summary>
        int Delete(object ormTable);
        /// <summary>
        /// delete all data, not drop table
        /// </summary>
        /// <param name="tableName">table</param>
        /// <returns></returns>
        bool Delete(string tableName);
    }
}
