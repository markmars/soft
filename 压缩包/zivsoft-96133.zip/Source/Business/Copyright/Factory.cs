﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

using Zivsoft.Business.Security;
using Zivsoft.Business.Register;

namespace Zivsoft.Business.Copyright
{
    static class Factory
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main()
        {
            try
            {
                ISecurity sec = new SecurityHelper();
                if (sec.CheckCert())
                {
                    StartApp();
                }
                else
                {
                    try
                    {
                        Application.Run(new RegUI());
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void StartApp()
        {
            try
            {
                Application.Run(new FMain());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}