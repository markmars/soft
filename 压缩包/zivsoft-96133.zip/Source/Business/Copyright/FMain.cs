﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO;
using System.Diagnostics;
using Zivsoft.Log;


namespace Zivsoft.Business.Copyright
{
    partial class FMain : Form
    {
        public FMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.lblColor.BackColor = Color.Red;
            this.lblColor.Text = Color.Red.Name;
        }
        public void AddTexttoImage(string[] picPath)
        {
            var i = 0;
            var t = picPath.Length;
            foreach (var s in picPath)
            {
                i++;
                lblInfo.Text = string.Format("{0} photos have been added photos successfully!", i);
                progressBar1.Value = i * 90 / t;
                AddTexttoImage(s);
            }
        }
        private void AddTexttoImage(string picPath)
        {
            // Define the Bitmap, Graphics, Font, and Brush for copyright logo
            Bitmap bm = new Bitmap(picPath);

            Graphics g = Graphics.FromImage(bm);
            
            //font
            string fontName = "Arial";
            if (!string.IsNullOrEmpty(this.comboFont.Text)) { fontName = this.comboFont.Text; }

            //font size
            int fontSize = 10;
            if (!string.IsNullOrEmpty(this.domainUpDown1.Text))
            {
                try
                {
                    fontSize = Convert.ToInt32(this.domainUpDown1.Text);
                }
                catch (Exception e)
                {
                    Logger.LogError(e);
                    fontSize = 10; 
                }
            }
            Font f = new Font(fontName, fontSize);

            //color
            Brush b = new SolidBrush(this.lblColor.BackColor);

            // Add the copyright text
            g.DrawString(this.tbContent.Text, f, b, 5, 5);

            // Save the image to the specified file in JPEG format
            bm.Save(Path.Combine(this.txtOutput.Text.Trim(),Path.GetFileName(picPath)), ImageFormat.Jpeg);

        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.Filter = "*.jpg|*.jpg|*.gif|*.gif";
            this.openFileDialog1.Multiselect = true;
            DialogResult dr = this.openFileDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                Logger.LogInfo("You are dealing with the photo: {0}",this.openFileDialog1.FileName);
                this.textBox1.Lines = this.openFileDialog1.FileNames;
            }
        }

        private void AddCopyrightText()
        {
            AddTexttoImage(this.textBox1.Lines);
            this.progressBar1.Value = 100;
            this.lblInfo.Text = string.Format("All ({0} items) photos have been added the copyright successfully! ", textBox1.Lines.Length);
            MessageBox.Show(string.Format("All ({0} items) photos have been added the copyright successfully! ", textBox1.Lines.Length), "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://www.zivsoft.com");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("mailto:v-lihuaz@microsoft.com");
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {

            this.lblInfo.Text = "Verifying your settings ...";
            if (this.textBox1.Lines.Length == 0)
            {
                MessageBox.Show("You did not select any photos!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.button1.Focus();
                return;
            }
            if (string.IsNullOrEmpty(tbContent.Text.Trim()))
            {
                MessageBox.Show("Copyright text can not be empty.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tbContent.Focus();
                return;
            }
            if (string.IsNullOrEmpty(this.txtOutput.Text.Trim()))
            {
                MessageBox.Show("Output folder can not be empty!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.txtOutput.Focus();
                return;
            }
            if (!Directory.Exists(this.txtOutput.Text.Trim()))
            {
                MessageBox.Show("Output folder does not exist!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.txtOutput.Focus();
                this.txtOutput.SelectAll();
                return;
            }
            this.progressBar1.Value = 10;
            AddCopyrightText();
        }

        private void btnOutput_Click(object sender, EventArgs e)
        {
            var r=this.folderBrowserDialog1.ShowDialog(this);
            if (r == DialogResult.OK)
            {
                this.txtOutput.Text = this.folderBrowserDialog1.SelectedPath;
            }
        }

        private void lblColor_Click(object sender, EventArgs e)
        {
            var result=this.colorDialog1.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.lblColor.BackColor = this.colorDialog1.Color;
                this.lblColor.Text = this.colorDialog1.Color.Name;
            }
        }

   
    }
}