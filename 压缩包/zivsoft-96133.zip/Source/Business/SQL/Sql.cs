using System;
using System.Data;

namespace Zivsoft.Business.SQL
{
	class Sql
	{
		public string GetTableName(string sql)
		{
			sql=sql.ToLower();
			int i=sql.IndexOf("where");
			if(i!=-1)
			{
				sql=sql.Remove(i,sql.Length-i);
			}
			i=sql.IndexOf("from");
			if(i!=-1)
			{
				sql=sql.Remove(0,i);
			}
			sql=sql.Replace("from","").Trim();
			return sql;
		}

		public string GetInsertSql(DataTable dt)
		{
			string strSql="insert "+dt.TableName+" (";
			string strSqlResult=null;
			DataView dv=dt.DefaultView;
			if(dv!=null)
			{
				dt=dv.Table;
				for(int col=0,t=dt.Columns.Count;col<t;col++)
				{
					strSql+=dt.Columns[col].Caption;
					if(col<t-1)
					{
						strSql+=",";
					}
					if(col==t-1)
					{
						strSql+=")";
					}
				}
				strSql+=" values('";
				strSqlResult=strSql;
				for(int row=0,t=dt.Rows.Count;row<t;row++)
				{
					for(int col=0,k=dt.Columns.Count;col<k;col++)
					{
						object objValue=dt.Rows[row][col];
						if(objValue==DBNull.Value)
						{
							strSqlResult=strSqlResult.Remove(strSqlResult.Length-1,1);
							strSqlResult+="null";
							if(col<k-1)
							{
								strSqlResult+=",'";
							}
							if(col==k-1)
							{
								strSqlResult+=");\r\n";
							}
						}
						else
						{
							strSqlResult+=objValue;
							if(col<k-1)
							{
								strSqlResult+="','";
							}
							if(col==k-1)
							{
								strSqlResult+="');\r\n";
							}
						}
					}
					if(row<t-1)
					{
						strSqlResult+=strSql;
					}
				}
			}
			return strSqlResult;
		}
	}
}
