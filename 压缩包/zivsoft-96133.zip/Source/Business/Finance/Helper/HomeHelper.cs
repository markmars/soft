﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Business.Finance.DbOperator;

namespace Zivsoft.Business.Finance.Helper
{
    class HomeHelper
    {
        public int GetCount()
        {
            int firstMonths = 9;//from the Apri
            int theYear = DateTime.Now.Year;
            int theOldYear = 2008;
            int k = theYear - theOldYear;
            int theMonthe = k * 12 + DateTime.Now.Month+firstMonths-1;
            return theMonthe;
        }

        public int GetAllMoney()
        {
            HomeOperatorDb home = new HomeOperatorDb();
            return home.GetMoney();
        }
    }
}