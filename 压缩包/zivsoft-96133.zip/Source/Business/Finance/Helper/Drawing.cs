﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Drawing;
using System.Text;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

namespace Zivsoft.Business.Finance.Helper
{
    /// <summary>
    /// Lihua Zhou
    /// </summary>
    class Drawing:IFinance
    {
        public  Drawing(int width, int height,float k,int iMonth,int iData)
        {
            iCanvasHeight = height;
            iCanvasWidth = width;
            x0 = width*1/15;
            y0 = height*7/8;


            var xLength = x0 * 13;
            var yLength = height * 6 / 8;
            x1 = x0 + xLength;
            y1 = y0 - yLength;
            iX = xLength / iMonth - 1;
            iY = yLength / iData - 1;
            this.k = k;
            this._x = iMonth;
            this.iData = iData;
        }

        int iData;
        private ArrayList arrMonth = new ArrayList();
        //
        private int iCanvasWidth;
        private int iCanvasHeight;


        //x
        private int _x;
        private int X
        {
            set
            {
                this._x = value;
            }
        }


        int x0, y0;
        int x1, y1;

        /// <summary>
        /// x
        /// </summary>
        private int iX;
        /// <summary>
        /// y
        /// </summary>
        private int iY;
        private float k=1f;

        private void InitArray(ArrayList arrData)
        {
            for (int i = 0; i < this._x; i++)
            {
                arrMonth.Add(i + 1);
            }
            for (int i = 0; i < arrData.Count; i++)
            {
                arrData[i] = Convert.ToInt32(arrData[i]) * k;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="backgroud"></param>
        /// <param name="lineColor"></param>
        /// <param name="dotColor"></param>
        /// <param name="arrData"></param>
        /// <returns></returns>
        public Bitmap Paint(Color backgroud,Color lineColor,Color dotColor,ArrayList arrData)
        {
            this.InitArray(arrData);

            Bitmap bitmap = new Bitmap(iCanvasWidth, iCanvasHeight, PixelFormat.Format24bppRgb);
            Graphics g=Graphics.FromImage(bitmap);
            g.Clear(backgroud);

            Font font = new Font("Arial", 8);
            SolidBrush brush = new SolidBrush(Color.Black);
            Pen pen = new Pen(lineColor);
            pen.EndCap = LineCap.ArrowAnchor;
            pen.DashStyle = DashStyle.Solid;
            
            //

            Point oPoint = new Point(x0, y0);
            Point xPoint = new Point(x0, y1);
            Point yPoint = new Point(x1, y0);

            g.DrawLine(pen, oPoint,xPoint);//X-Line
            g.DrawLine(pen, oPoint,yPoint);//Y-Line

            Pen dotPen=new Pen(dotColor);
            //x
            for (int i = 0; i < _x; i++)
            {
                g.DrawLine(dotPen, x0 + iX * (i+1), y0, x0 + iX * (i+1), y0 - 2);
                //g.DrawString((i+1).ToString(), font, brush, iX * (i + 2), y0 + 2);
            }

            //y
            for (int j = 0; j < iData; j++)
            {
                g.DrawLine(dotPen, x0, y0 - iY * (j+1), x0 + 2, y0 - iY * (j+1));
//                g.DrawString(((this.iCanvasHeight-iY*j)/k).ToString(), font, brush, x0 - 20, iY * (j + 1)+iY);
                //g.DrawString(((this.iCanvasHeight - iY * j) / k).ToString(), font, brush, x0 - 20, iY * (j + 1) + iY);
            }

            //Drawing the line
            double dblX1 = 20;
            double dblY1 = y0;
            for (int i = 0; i < arrData.Count; i++)
            {
                double dblData = Convert.ToDouble(arrData[i]);
                double dblY2 = y0 - dblData*k;

                double dblX2 = x0 + iX * Convert.ToInt32(arrMonth[i]);
                Pen linePen = new Pen(Color.Black, 2);
                if (i != 0)
                {
                    if (i < arrData.Count - 1)
                    {
                        g.DrawLine(linePen, float.Parse(dblX1.ToString()), float.Parse(dblY1.ToString()), float.Parse(dblX2.ToString()), float.Parse(dblY2.ToString()));
                    }
                    else
                    {
                        g.DrawLine(linePen, float.Parse(dblX1.ToString()), float.Parse(dblY1.ToString()), float.Parse(dblX2.ToString()), float.Parse(dblY2.ToString()));
                    }
                }

                dblX1 = dblX2;
                dblY1 = dblY2;
            }
            return bitmap;
        }
    }
}