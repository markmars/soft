﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Localization;

namespace Zivsoft.Business.Finance.Helper
{
    class ErrorDialogs
    {
        public static System.Windows.Forms.DialogResult Show(string text,string title)
        {
            return System.Windows.Forms.MessageBox.Show(
                text, title, System.Windows.Forms.MessageBoxButtons.OK,
                System.Windows.Forms.MessageBoxIcon.Warning
                );
        }
        public static System.Windows.Forms.DialogResult Show(string text)
        {
            return Show(text, "Warning");
        }
    }
}