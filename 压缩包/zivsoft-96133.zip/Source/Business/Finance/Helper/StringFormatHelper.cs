﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Windows.Forms;

namespace Zivsoft.Business.Finance.Helper
{
    class StringFormatHelper
    {
        /// <summary>
        /// YYYYMM
        /// </summary>
        public ArrayList GetDateIdFormat()
        {
            ArrayList al = new ArrayList();
            al.Add("200503");
            al.Add("200504");
            al.Add("200504");
            al.Add("200505");
            al.Add("200506");
            al.Add("200507");
            al.Add("200508");
            al.Add("200509");
            al.Add("200510");
            al.Add("200511");
            al.Add("200512");
            for (int year = 2006; year < DateTime.Now.Year; year++)
            {
                for (int month = 1; month < 13; month++)
                {
                    if (month < 10)
                    {
                        al.Add(year+ "0" + month);
                    }
                    else
                    {
                        al.Add(year+ ""+month);
                    }
                }
            }
            var yearInt = DateTime.Now.Year;
            var monthInt = DateTime.Now.Month;

            for (int m = 1; m < monthInt + 1; m++)
            {
                if (m < 10)
                {
                    al.Add(yearInt + "0" + m);
                }
                else
                {
                    al.Add(yearInt +""+ m);
                }
            }

            return al;
        }

        public string Next(string text)
        {

            if (text != "")
            {
                string year = "" + text[0] + text[1] + text[2] + text[3];
                string month = "" + text[4] + text[5];
                int monthPlus = Convert.ToInt32(month);
                int yearPlus = Convert.ToInt32(year);
                monthPlus++;
                if (monthPlus < 13)
                {
                    if (monthPlus < 10)
                    {
                        return year + "0" + monthPlus;
                    }
                    else
                    {
                        return year + "" + monthPlus;
                    }
                }
                else
                {
                    yearPlus++;
                    return yearPlus + "01";
                }
            }
            else
            {
                return string.Empty;
            }
        }
        public string Previous(string text)
        {

            if (text != "")
            {
                string year = "" + text[0] + text[1] + text[2] + text[3];
                string month = "" + text[4] + text[5];
                int monthPlus = Convert.ToInt32(month);
                int yearPlus = Convert.ToInt32(year);
                monthPlus--;
                if (monthPlus > 0)
                {
                    if (monthPlus < 10)
                    {
                        return year + "0" + monthPlus;
                    }
                    else
                    {
                        return year + "" + monthPlus;
                    }
                }
                else
                {
                    yearPlus--;
                    return yearPlus + "12";
                }
            }
            else
            {
                return string.Empty;
            }
        }

        public string GetCurrent()
        {
            var yearInt = DateTime.Now.Year;
            var monthInt = DateTime.Now.Month;


            if (monthInt < 10)
            {
                return yearInt + "0" + monthInt;
            }
            else
            {
                return yearInt + "" + monthInt;
            }
        }

        /// <summary>
        /// 验证正确的YYYYMM格式的字符串
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public bool CheckFormat(string text)
        {
            bool b = true;
            int number=0;
            if (text.Length != 6)
            {
                b = false;
            }

            try
            {
                number = Convert.ToInt32(text);
            }
            catch
            {
                return false;
            }
            if ( number< 200503)
            {
                b = false;
            }
            int month = Convert.ToInt32("" + text[4] + text[5]);
            if (month > 12||month<1) {
                return false;
            }
            return b;
        }
    }
}