﻿using System;
using System.Collections;
using System.Data;
using Zivsoft.Business.Finance.DbOperator.Base;
using System.ComponentModel;
using Zivsoft.Data.ORM.Entity;

namespace Zivsoft.Business.Finance.DbOperator
{
    
    class FianceBase : AccessDb, IMetaData, IORMDbOperator
    {
        public static DaysOperator T
        {
            get
            {
                return new DaysOperator();
            }
        }


        public FianceBase()
            : base(T.GetName())
        {
            Init();
        }


        public void Init()
        {
            K = 0.3f;
            DataSet ds = base.GetDataSet("Select * from " + T.GetName() + " order by " + T.DaysId.Name);
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                object cost = ds.Tables[0].Rows[i][T.Cost.Name];
                if (cost != DBNull.Value)
                {
                    this.Data.Add(cost);
                }
            }
        }


        #region IORMDbOperator Members

        public DataView GetDataView(string sql)
        {
            return base.GetDataSet(sql).Tables[0].DefaultView;
        }

        new public int GetCount(string sql)
        {
            return base.GetCount(sql);
        }


        new public int ExecuteSQL(string sql)
        {
            return base.ExecuteSQL(sql);
        }

        #endregion
    }
}