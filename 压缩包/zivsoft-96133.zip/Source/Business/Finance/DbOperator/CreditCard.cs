﻿using System;
using System.Data;
using Zivsoft.Business.Finance.DbOperator.Base;
using Zivsoft.Data.ORM.Entity;

namespace Zivsoft.Business.Finance.DbOperator
{
    class CreditCard:AccessDb
    {

        private static CreditMonth T
        { 
            get
            {
                return new CreditMonth();
            }
        }
        public CreditCard():base(T.GetName())
        {
            Init(T.Cost.Name);
        }

        public DataView GetDataView()
        {
            var dv = GetDataSet().Tables[0].DefaultView;
            dv.Sort = T.Month.Name+ " desc";
            return dv;
        }
        
        private void Init(string columnName)
        {
            K = 0.2f;
            DataSet ds = GetDataSet("select * from "+ T.GetName() +" order by "+ T.Month.Name +" asc");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                object cost = ds.Tables[0].Rows[i][columnName];
                if (cost != DBNull.Value)
                {
                    Data.Add(cost);
                }
            }
        }
    }
}