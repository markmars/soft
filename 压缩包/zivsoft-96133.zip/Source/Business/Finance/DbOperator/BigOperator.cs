﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Data;
using Zivsoft.Business.Finance;
using Zivsoft.Business.Finance.DbOperator.Base;

namespace Zivsoft.Business.Finance.DbOperator
{
    class BigOperator : AccessDb, IMetaData,IORMDbOperator
    {
        public BigOperator():base("BigOperator")
        {
            this.Init();

        }

        private void Init()
        {
            this.K
                = 0.5f;
            DataSet ds=base.GetDataSet("Select * from "+this.GetName()+" order by [Id]");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                object cost = ds.Tables[0].Rows[i]["Cost"];
                if (cost != DBNull.Value)
                {
                    this.Data.Add(cost);
                }
            }
        }

        #region IORMDbOperator Members

        public DataView GetDataView(string sql)
        {
            return base.GetDataSet(sql).Tables[0].DefaultView;
        }

        new public int GetCount(string sql)
        {
            return base.GetCount(sql);
        }


        new public int ExecuteSQL(string sql)
        {
            return base.ExecuteSQL(sql);
        }

        public int GetAllMoney()
        {
            return Convert.ToInt32(base.GetValue("select sum(cost) from " + this.GetName()));
        }

        #endregion
    }
}