﻿using System;
using System.Collections;
using System.Data;

using Zivsoft.Business.Finance.DbOperator.Base;
using Zivsoft.Data.ORM.Entity;
using System.ComponentModel;

namespace Zivsoft.Business.Finance.DbOperator
{
    class Salary2007:AccessDb,IMetaData
    {
        public static SalarySummary T
        {
            get
            {
                return new SalarySummary();
            }
        }

        public Salary2007()
            : base(T.GetName())
        {
            this.Init(T.In.Name);
        }

        private void Init(string columnName)
        {
            this.K = 0.1f;
            DataSet ds = base.GetDataSet("select * from "+GetName()+" order by "+T.Id.Name);
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                object cost = ds.Tables[0].Rows[i][columnName];
                if (cost != DBNull.Value)
                {
                    this.Data.Add(cost);
                }
            }
        }

               
        public int GetAllMoney()
        {
            return Convert.ToInt32(base.GetValue("select sum("+T.In.Name+") from " + this.GetName()))-1500;
        }
    }
}