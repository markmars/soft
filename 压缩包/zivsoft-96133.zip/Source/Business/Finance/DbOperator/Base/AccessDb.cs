﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using Zivsoft.Data;

namespace Zivsoft.Business.Finance.DbOperator.Base
{
    class AccessDb:MetaData
    {
        private string _tableName;

        public AccessDb(string tableName)
        {
            this._tableName = tableName;
        }
        public DataSet GetDataSet()
        {
            return DbFactory.DefaultDbOperator().Query4DataSet(string.Format("select * from [{0}]", this._tableName));
        }

        protected string GetName()
        {
            return this._tableName;
        }

        public DataSet GetDataSet(string sql)
        {
            return DbFactory.DefaultDbOperator().Query4DataSet(sql);
        }

        protected int ExecuteSQL(string sql)
        {
            return DbFactory.DefaultDbOperator().ExecuteSql(sql);
        }
        
        public int GetCount(string sql)
        {
            return DbFactory.DefaultDbOperator().GetCount(sql);
        }

        protected object GetValue(string sql)
        {
            return DbFactory.DefaultDbOperator().Query4Value(sql);
        }
    }
}