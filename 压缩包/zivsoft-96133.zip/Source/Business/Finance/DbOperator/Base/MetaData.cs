﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Zivsoft.Business.Finance.DbOperator.Base
{
    abstract class MetaData: IMetaData
    {
        private ArrayList _data = new ArrayList();
        public ArrayList Data
        {
            get
            {
                return this._data;

            }
            set
            {
                this._data = value;
            }
        }

        private float _k = 1;
        public float K
        {
            get
            {
                return this._k;
            }
            set
            {
                this._k = value;
            }
        }
    }
}