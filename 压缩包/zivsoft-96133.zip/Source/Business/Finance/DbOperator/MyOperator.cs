﻿using System;
using System.Collections;
using System.Data;
using Zivsoft.Business.Finance.DbOperator.Base;

namespace Zivsoft.Business.Finance.DbOperator
{
    class MyOperator:AccessDb,IMetaData
    {
        public MyOperator()
            : base("MyOperator")
        {
            this.Init("cost");
        }

        private void Init(string columnName)
        {
            this.K = 0.2f;
            DataSet ds = base.GetDataSet("select * from "+this.GetName()+"");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                object cost = ds.Tables[0].Rows[i][columnName];
                if (cost != DBNull.Value)
                {
                    this.Data.Add(cost);
                }
            }
        }

        
        public int GetAllMoney()
        {
            return Convert.ToInt32(base.GetValue("select cost from " + this.GetName()));
        }
        public int ShouldMoney()
        {
            int m = DateTime.Now.Month;
            int yNumber = DateTime.Now.Year - 2008;
            return (m + yNumber * 12) * 2000;
        }
    }
}