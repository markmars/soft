﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Zivsoft.Business.Finance.DbOperator
{
    interface IORMDbOperator
    {
        DataView GetDataView(string sql);
        int ExecuteSQL(string sql);
        int GetCount(string sql);
    }
}