﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Data;
using Zivsoft.Business.Finance.DbOperator.Base;

namespace Zivsoft.Business.Finance.DbOperator
{
    class All:AccessDb,IMetaData
    {
        public All()
            : base("All")
        {
            this.Init("Cost");
        }

        private void Init(string columnName)
        {
            this.K = 0.2f;
            DataSet ds = base.GetDataSet();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                object cost = ds.Tables[0].Rows[i][columnName];
                if (cost != DBNull.Value)
                {
                    this.Data.Add(cost);
                }
            }
        }
    }
}