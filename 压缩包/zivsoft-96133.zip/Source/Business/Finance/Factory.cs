﻿using Zivsoft.Business.Finance.DbOperator;
using All=Zivsoft.Business.Finance.DbOperator.All;

namespace Zivsoft.Business.Finance
{
    class Factory
    {
        public IMetaData DaysOperator()
        {
            return new FianceBase();
        }

        public IMetaData CreateAll()
        {
            return new All();
        }
        public IMetaData CreateSalary2007()
        {
            return new Salary2007();
        }
        public IMetaData CreateHomeOperator()
        {
            return new HomeOperatorDb();
        }
        public IMetaData CreateCreditCard()
        {
            return new CreditCard();
        }
        public IMetaData CreateSummary()
        {
            return new MonthCredit();
        }
    }
}