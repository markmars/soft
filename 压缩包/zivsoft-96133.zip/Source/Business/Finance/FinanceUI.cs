﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Zivsoft.Business.Finance.Helper;

namespace Zivsoft.Business.Finance
{
    partial class FinanceUI : Form
    {
        Factory f = new Factory();
        public FinanceUI()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void FinanceUI_Load(object sender, EventArgs e)
        {

            comboBox1.Items.Add("All");
            comboBox1.Items.Add("Credit");
            comboBox1.Items.Add("Salary");
            comboBox1.Items.Add("DaysOperator");
            comboBox1.Items.Add("Home");
            comboBox1.Items.Add("Big");
        }

        private void Display()
        {
            IMetaData me = null;
            switch (this.comboBox1.Text)
            {
                case "All":
                    me = f.CreateAll();
                    break;
                case "Credit":
                    me = f.CreateCreditCard();
                    break;
                case "Salary":
                    me = f.CreateSalary2007();
                    break;
                case "DaysOperator":
                    me = f.DaysOperator();//xing zhou li cai 2009                    
                    break;
                case "Home":
                    me = f.CreateHomeOperator();
                    break;
                case "Big":
                    me = f.CreateSummary();
                    break;
            }
            if (me == null)
            {
                return;
            }
            me.K = this.trackBar1.Value / 100f;
            IFinance drawing = new Drawing(this.pictureBox1.Width, this.pictureBox1.Height, me.K, me.Data.Count, 10);
            this.trackBar1.Value = (int)Math.Round(me.K * 100,0);
            pictureBox1.Image = drawing.Paint(Color.White, Color.Red, Color.Red, me.Data);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            this.label1.Text = this.trackBar1.Value + "%";
            Display();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Display();
        }
    }
}
