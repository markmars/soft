﻿using System;
using System.Data;
using Zivsoft.Business.Finance.DbOperator.Base;
using Zivsoft.Data.ORM.Entity;

namespace Zivsoft.Business.Finance
{
    class MonthCredit:AccessDb
    {
        public static BigOperator Big
        {
            get
            {
                return new BigOperator();
            }
        }
        public MonthCredit()
            : base(Big.GetName())
        {
            Init(Big.Cost.Name);
        }
        private void Init(string columnName)
        {
            base.K = 0.1f;
            DataSet ds = base.GetDataSet("select * from "+Big.GetName()+" order by "+Big.OperatID.Name+" asc");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                object cost = ds.Tables[0].Rows[i][columnName];
                if (cost != DBNull.Value)
                {
                    base.Data.Add(cost);
                }
            }
        }
    }
}