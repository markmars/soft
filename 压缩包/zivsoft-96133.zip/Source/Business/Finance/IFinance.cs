﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Drawing;

namespace Zivsoft.Business.Finance
{
    interface IFinance
    {
        /// <summary>
        /// Paint for the finance
        /// </summary>
        Bitmap Paint(Color backgroud, Color lineColor, Color dotColor, ArrayList data);
    }
}