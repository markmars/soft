﻿using System;
using System.Windows.Forms;
using Zivsoft.Log;


namespace Zivsoft.Business.Finance
{
    static class WindowsApplication
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new FinanceUI());
            }
            catch (Exception e)
            {
                Logger.LogError(e);
                Helper.ErrorDialogs.Show(e.Message);
            }
        }
    }
}