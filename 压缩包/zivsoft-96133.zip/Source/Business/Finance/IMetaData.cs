﻿using System.Collections;

namespace Zivsoft.Business.Finance
{
    interface IMetaData
    {
        ArrayList Data { get; }
        float K { get; set; } 
    }
}