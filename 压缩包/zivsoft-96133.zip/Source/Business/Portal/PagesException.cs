using System;

namespace Zivsoft.Business.Portal
{
    class PagesException : ApplicationException
    {
        /// <summary>
        /// </summary>
        private string _errorCode = String.Empty;
        public string ErrorCode
        {
            get
            {
                return this._errorCode;
            }
            set
            {
                this._errorCode = value;
            }
        }
        /// <summary>
        /// </summary>
        private string _errorParam = String.Empty;
        public string ErrorParam
        {
            get
            {
                return this._errorParam;
            }
            set
            {
                this._errorParam = value;
            }
        }
        public PagesException setErrorCode(string errorCode)
        {
            this.ErrorCode = errorCode;
            return this;
        }
        /// <summary>
        /// </summary>
        public PagesException(string errCode,string errParam)
        {
            this._errorCode = errCode;
            this._errorParam = errParam;
        }
        /// <summary>
        /// </summary>
        public PagesException() : base()
        {
        }

        /// <summary>
        /// </summary>
        /// <param name="strEx"></param>
        public PagesException(string strEx) : base(strEx)
        {
        }

        public PagesException(string str, ApplicationException ex) : base(str, ex)
        {
        }

        /// <summary>
        /// </summary>
        public PagesException(ApplicationException ex)
            : base("OBE", ex)
        {
        }
        /// <summary>
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return "PagesException:" + this.Source + this.Message + this.StackTrace;
        }
    }
}