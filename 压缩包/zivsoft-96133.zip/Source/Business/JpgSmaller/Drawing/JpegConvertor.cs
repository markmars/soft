﻿using System.Drawing;
using System.IO;

namespace Zivsoft.Business.JpgSmaller.Drawing
{
    class JpegConvertor
    {
        private string[] _picPaths;
        public JpegConvertor(string[] picPaths)
        {
            if (picPaths != null && picPaths.Length != 0)
            {
                _picPaths = picPaths;
            }
            else
            {
                _picPaths = new string[] { };
            }
        }

        public void Convert(string outFolder)
        {
            Bitmap bm = null;
            for (int i = 0, t = this._picPaths.Length; i < t; i++)
            {
                string picPath = this._picPaths[i];
                bm = new Bitmap(picPath);
                bm.SetPixel(bm.Width / 2, bm.Height / 2, Color.White);
                string fileName = Path.GetFileName(this._picPaths[i]);
                bm.Save(Path.Combine(outFolder, fileName));
            }
        }
    }
}