﻿using System;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using Zivsoft.Business.JpgSmaller.Business;

/******************************************
 * 
 * Lihua Zhou
 * 
 *******************************************/

namespace Zivsoft.Business.JpgSmaller.UI
{
    partial class JpgForm : Form
    {
        private delegate void InitializeViewsDelegate();

        /// <summary>
        /// 构造函数
        /// </summary>
        public JpgForm()
        {
            InitializeComponent();

        }

        /// <summary>
        /// 已开始被调用
        /// </summary>
        public void Run()
        {
            Thread uiThread = new Thread(new ThreadStart(ThreadMain));
            uiThread.SetApartmentState(ApartmentState.STA);
            uiThread.Priority = ThreadPriority.Normal;
            uiThread.Start();
        }


        /// <summary>
        /// 进程被调用
        /// </summary>
        public void ThreadMain()
        {
            Application.Run(this);
        }

        /// <summary>
        /// 异常捕捉
        /// </summary>
        /// <param name="runMessageLoopDelegate"></param>
        public static void HandleScopeChangedExceptions(MethodInvoker runMessageLoopDelegate)
        {
            try
            {
                runMessageLoopDelegate();
            }
            catch (Exception e)
            {
                Show(e.Message);
            }
        }


        private static void Show(string message)
        {
            MessageBox.Show(message, "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        /// <summary>
        /// 
        /// </summary>
        public void InitializeViews()
        {
            this.Cursor = Cursors.WaitCursor;
            this.Cursor = Cursors.Default;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="state"></param>
        public void ThreadJob(object state)
        {
            //initialize the search folder list box
            try
            {
                Invoke(new InitializeViewsDelegate(InitializeViews));
            }
            catch (Exception e)
            {
                Show(e.Message);
                ((AutoResetEvent)state).Set();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnImport_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.Multiselect = true;
            this.openFileDialog1.Filter = "*.jpg|*.jpg";
            DialogResult result = this.openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                string[] paths = this.txtShowPath.Lines = this.openFileDialog1.FileNames;
            }
        }

        /// <summary>
        /// Folder Browser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnFolderBrowser_Click(object sender, EventArgs e)
        {
            this.folderBrowserDialog1.ShowNewFolderButton = true;
            DialogResult result = this.folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.txtOutPath.Text = this.folderBrowserDialog1.SelectedPath;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExport_Click(object sender, EventArgs e)
        {
            if (this.txtShowPath.Text == string.Empty)
            {
                MessageBox.Show("You did not select any pictures.", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.btnImport.Focus();

            }
            else if (this.txtOutPath.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Output path could not be empty.", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.txtOutPath.Focus();
            }
            else if (!Directory.Exists(this.txtOutPath.Text.Trim()))
            {
                MessageBox.Show("Directory does not exist.","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                this.txtOutPath.Focus();
                this.txtOutPath.SelectAll();
            }
            else
            {
                var jpegConvertor = new JpegConvertor(this.txtShowPath.Lines);
                var r=jpegConvertor.Convert(this.txtOutPath.Text);
                if (!r)
                {
                    MessageBox.Show(jpegConvertor.Error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void JpgForm_Load(object sender, EventArgs e)
        {
            TimerCallback initializeDataDelegate;
            System.Threading.Timer initializeDataTimer;
            AutoResetEvent initializeDataAutoEvent;

            initializeDataAutoEvent = new AutoResetEvent(false);
            initializeDataDelegate = new TimerCallback(this.ThreadJob);
            initializeDataTimer = new System.Threading.Timer(
                initializeDataDelegate,
                initializeDataAutoEvent,
                1000,
                System.Threading.Timeout.Infinite);
        }

    }
}