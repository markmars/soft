﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Business.Register;

namespace Zivsoft.Business.JpgSmaller.UI
{
    class RegDlg:RegUI
    {
    }
}
