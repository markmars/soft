﻿using System;
using System.Drawing;
using System.IO;
using Zivsoft.Log;


namespace Zivsoft.Business.JpgSmaller.Business
{
    class JpegConvertor
    {
        private string[] _picPaths;
        public JpegConvertor(string[] picPaths)
        {
            if (picPaths != null && picPaths.Length != 0)
            {
                _picPaths = picPaths;
            }
            else
            {
                _picPaths = new string[] { };
                Logger.LogWarning("picPaths is an empty string[] array");
            }
        }

        public string Error
        {
            get; set;
        }
        public Boolean Convert(string outFolder)
        {
            try
            {

                Bitmap bm = null;
                for (int i = 0, t = this._picPaths.Length; i < t; i++)
                {
                    string picPath = this._picPaths[i];
                    bm = new Bitmap(picPath);
                    bm.SetPixel(bm.Width/2, bm.Height/2, Color.White);
                    string fileName = Path.GetFileName(this._picPaths[i]);
                    bm.Save(Path.Combine(outFolder, fileName));
                }
                return true;
            }
            catch(Exception e)
            {
                this.Error = e.Message;
                return false;
            }
        }
    }
}