﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Data;

using Zivsoft.Business.Languages;
using Zivsoft.Data.ORM.Entity;
using Zivsoft.Localization;
using Zivsoft.Data;
using Zivsoft.Data.Entity;

/************************
 * 
 * Should load menu or tree by user role
 * 
 ************************/
namespace Zivsoft.Business.Core
{
    class MenuTree : IMenuTree
    {
        enum ConfigType
        {
            Db,
            Xml
        };
        private string _strExitText;
        private ConfigType _currentConfigType = ConfigType.Db;
        private const string STR_Localization_ModuleName = "Menu";
        private const string CONFIG_TREE_TYPE = "TreeType";
        private const string CONFIG_MENU_TYPE = "MenuType";


        /// <summary>
        /// 
        /// </summary>
        public void LoadMenu(Menu menu, string userId)
        {
            string modType = null;
            DataView dvTree=null;
            if (_currentConfigType == ConfigType.Xml)
            {
                modType = ConfigXml.GetConfigValue(CONFIG_MENU_TYPE);
            }
            else
            {
                Config c = new Config();
                c.ConfigId = CONFIG_MENU_TYPE;
                c.Load();
                modType = c.ConfigValue.Value;
            }
            dvTree = GetDataViewByRole(modType, userId).DefaultView;
            this.LoadMenu(menu,dvTree);
        }

        /// <summary>
        /// 
        /// </summary>
        public void LoadTree(TreeView tree, string userId, string strExitText)
        {
            this._strExitText = strExitText;
            string modType = ConfigXml.GetConfigValue(CONFIG_TREE_TYPE);
            DataView dvTree = GetDataViewByRole(modType, userId).DefaultView;
            this.LoadTree(tree, dvTree);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="menu"></param>
        /// <param name="lan"></param>
        /// <param name="dvTree"></param>
        public void LoadMenu(Menu menu, DataView dvTree)
        {
            menu.Items.Clear();
            MenuItem node1 = null;
            string text1 = "";
            int num1 = 0;
            int num2 = dvTree.Count;
            while (num1 < num2)
            {
                MenuItem node2 = new MenuItem();
                //Updated at 3/27/2008, because it needs to be localized.
                node2.Text = Resource.GetModule(STR_Localization_ModuleName)[dvTree[num1]["ModName"].ToString()];
                node2.NavigateUrl = dvTree[num1]["NavigateUrl"] + "";
                node2.ImageUrl = dvTree[num1]["ImageUrl"] + "";
                string mod_id = dvTree[num1]["ModId"].ToString();
                node2.Value = "node_" + mod_id;
                if (mod_id.Length == 3)
                {
                    menu.Items.Add(node2);
                    text1 = mod_id;
                    node1 = node2;
                }
                else if ((mod_id.Length > 3) && (mod_id.Substring(0, 3) == text1))
                {
                    node1.ChildItems.Add(node2);
                }
                num1++;
            }
            menu.DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="leftTreeView"></param>
        /// <param name="lan"></param>
        /// <param name="dvTree"></param>
        public void LoadTree(TreeView leftTreeView,DataView dvTree)
        {
            leftTreeView.Nodes.Clear();
            TreeNode node1 = null;
            string text1 = "";
            int num1 = 0;
            int num2 = dvTree.Count;
            while (num1 < num2)
            {
                TreeNode node2 = new TreeNode();
                //Updated at 3/27/2008, because it needs to be localized.
                node2.Text = Zivsoft.Localization.Resource.GetModule(STR_Localization_ModuleName)[dvTree[num1]["ModName"].ToString()];
                node2.NavigateUrl = dvTree[num1]["NavigateUrl"] + "";
                node2.ImageUrl = dvTree[num1]["ImageUrl"] + "";
                string mod_id = dvTree[num1]["ModId"].ToString();
                node2.Value = "node_" + mod_id;
                if (mod_id.Length == 3)
                {
                    leftTreeView.Nodes.Add(node2);
                    text1 = mod_id;
                    node1 = node2;
                }
                else if ((mod_id.Length > 3) && (mod_id.Substring(0, 3) == text1))
                {
                    node1.ChildNodes.Add(node2);
                }
                num1++;
            }

            TreeNode node3 = new TreeNode();
            node3.Text = _strExitText;
            node3.SelectAction = TreeNodeSelectAction.Select;
            leftTreeView.Nodes.Add(node3);
            leftTreeView.DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        public DataTable GetDataTable(string modType,string[] roleIds)
        {
            DataSet ds = new DataSet();
            ds.ReadXml(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Config\\ModInfo.xml");
            var dv = ds.Tables[0].DefaultView;
            //dv.RowFilter = string.Format("ModType='{0}' and IsValid='1'", modType);
            var ids = "";
            var i=0;
            var len=roleIds.Length;
            if (len != 0)
            {
                while (i < len)
                {
                    ids += "ModId='" + roleIds[i] + "'";
                    if (i < len - 1)
                    {
                        ids += " or ";
                    }
                    i++;
                }

            }
            dv.RowFilter = string.Format("ModType='{0}' and IsValid='1' and ({1})", modType,string.Format("{0}", ids));
            return dv.Table;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="modType"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataTable GetDataViewByRole(string modType, string userId)
        {
            var ds = new DataSet();
            UserInfo user = new UserInfo();
            user.UserId = userId;
            user.Load();
            if (_currentConfigType == ConfigType.Xml)
            {
                ds.ReadXml(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Config\\RoleAccess.xml");
                var dv = ds.Tables[0].DefaultView;
                dv.RowFilter = string.Format("RoleId='{0}'", user.RoleId);
                var len = dv.Count;//not the db.Table.Count
                string[] ids = new string[len];
                var i = 0;
                while (i < len)
                {
                    ids[i] = dv[i++]["ModId"] + "";
                }

                return GetDataTable(modType, ids);
            }
            else
            {
                string sql = "select modinfo.* from userinfo,roleaccess,modinfo where modtype='{0}' and userid='{1}' and isvalid='1' and userinfo.roleid=roleaccess.roleid and modinfo.modid=roleaccess.modid";
                sql = string.Format(sql, modType, userId);
                return DbFactory.DefaultDbOperator().Query4DataTable(sql);
            }
        }
    }
}
