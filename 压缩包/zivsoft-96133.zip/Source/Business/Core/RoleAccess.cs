﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace Zivsoft.Business.Core
{
    class RoleAccess
    {
        private static string _tableName;
        static RoleAccess()
        {
            _tableName = AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Config\\RoleAccess.xml";
        }
        public static string GetModId(string roleId)
        {
            XmlDocument xmlDoc1 = new XmlDocument();
            xmlDoc1.Load(_tableName);
            XElement xmlDoc = XElement.Parse(xmlDoc1.InnerXml);
            var results = from e in xmlDoc.Elements("Item")
                          where (string)e.Element("RoleId").Value == roleId
                          select e.Element("ModId");
            var config = "1";
            foreach (var xe in results)
            {
                config = xe.Value;
                break;
            }
            return config;
        }
    }
}
