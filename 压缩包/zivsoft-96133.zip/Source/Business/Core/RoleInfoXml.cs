﻿using System;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace Zivsoft.Business.Core
{
    class RoleInfoXml
    {
        private static string _tableName;
        static RoleInfoXml()
        {
            _tableName = AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Config\\RoleInfo.xml";
        }

        public static string GetRoleName(string roleId)
        {
            XmlDocument xmlDoc1 = new XmlDocument();
            xmlDoc1.Load(_tableName);
            XElement xmlDoc = XElement.Parse(xmlDoc1.InnerXml);
            var results = from e in xmlDoc.Elements("Item")
                          where (string)e.Element("RoleId").Value == roleId
                          select e.Element("RoleName");
            var config = "1";
            foreach (var xe in results)
            {
                config = xe.Value;
                break;
            }
            return config;
        }
    }
}
