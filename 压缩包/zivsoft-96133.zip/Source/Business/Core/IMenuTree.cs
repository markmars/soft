﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace Zivsoft.Business.Core
{
    interface IMenuTree
    {
        void LoadTree(TreeView tree, string userId, string strExitText);
        void LoadMenu(Menu menu, string userId);
    }
}
