﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

using Zivsoft.Log;

namespace Zivsoft.Business.Core
{
    class ConfigXml
    {
        private static string _tableName;
        static ConfigXml()
        {
            _tableName = AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Config\\Config.xml";
            Logger.LogDebug(_tableName);
        }

        public static string GetConfigValue(string configId)
        {
            XmlDocument xmlDoc1 = new XmlDocument();
            xmlDoc1.Load(_tableName);
            XElement xmlDoc = XElement.Parse(xmlDoc1.InnerXml);
            var results = from e in xmlDoc.Elements("Item")
                          where (string)e.Element("ConfigId").Value == configId
                          select e.Element("ConfigValue");
            var config = "1";
            foreach (var xe in results)
            {
                config = xe.Value;
                break;
            }
            return config;
        }
    }

}
