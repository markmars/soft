﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Zivsoft.Business.Install
{
    /// <summary>
    /// Form1 的摘要说明。
    /// </summary>
    class IIS
    {
        private static Mutex mutex = new Mutex();
        private static int poolFlag = 0;
        private const int maxThread = 3;//可执行线程最大数量
        private static string _winDir = null;//windows目录
        private static string _winVer = null;//windows版本
        private TextBox textDebug;


        private IIS(TextBox textBox)
        {
            this.textDebug = textBox;
        }

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        public static void Setup(TextBox textBox)
        {
            IIS iis = new IIS(textBox);
            iis.Load();
        }


        private void Load()
        {

            this.textDebug.Text = "Setup is running...\r\n";

            Thread trd = new Thread(new ThreadStart(this.GetWindowsVersion));
            trd.Start();
        }

        private void GetWindowsVersion()
        {
            //开始
            mutex.WaitOne();
            Interlocked.Increment(ref poolFlag);
            if (poolFlag != maxThread)//判断是否等于上限
            {
                mutex.ReleaseMutex();     //如果此线程达不到可执行线程上限,则继续开通,让后面的线程进来
            }
            Thread.Sleep(1000);

            //操作
            OSVerInfo osvi = new OSVerInfo();
            osvi.OSVersionInfoSize = Marshal.SizeOf(osvi);
            LibWrap.GetVersionEx(osvi);

            _winVer = OSHelper.OpSysName(osvi.MajorVersion, osvi.MinorVersion, osvi.PlatformId);
            this.textDebug.Text += "Getting current windows version:" + _winVer + " " + osvi.versionString + "\r\n";

            Thread.Sleep(1000);
            Thread getDir = new Thread(new ThreadStart(this.GetWinDir));
            getDir.Start();

            //结束
            Thread.Sleep(1000);
            Interlocked.Decrement(ref poolFlag);
        }

        private void GetWinDir()
        {
            mutex.WaitOne();
            Interlocked.Increment(ref poolFlag);
            if (poolFlag != maxThread)
            {
                mutex.ReleaseMutex();
            }

            //操作
            WindowsOperator oper = new WindowsOperator();
            string winDir = oper.GetWinDir();
            _winDir = winDir;


            //结束
            Thread.Sleep(1000);
            this.textDebug.Text += "Getting windows directory:" + winDir + ".\r\n";
            Interlocked.Decrement(ref poolFlag);

            Thread.Sleep(1000);
            Thread findfile = new Thread(new ThreadStart(this.FindFile));
            findfile.Start();
        }


        private void FindFile()
        {
            mutex.WaitOne();

            string filePath = _winDir + @"\inf\sysoc.inf";
            if (File.Exists(filePath))
            {
                this.textDebug.Text += "Checking file: " + filePath + "\r\n";
                Thread.Sleep(1000);
                this.textDebug.Text += "Reading file: " + filePath + "\r\n";
                Thread.Sleep(1000);
                Sysoc oc = new Sysoc(filePath);
                if (!oc.IsHide())
                {
                    this.textDebug.Text += "The iis config is correct in sysoc.inf!\r\n" + "It is " + oc.GetIISText() + ".\r\n";
                    this.ShowComponent(filePath);
                }
                else
                {
                    this.textDebug.Text += "文件中IIS配置为hide状态，安装程序正在修改IIS配置：\r\n";

                    Thread.Sleep(1000);
                    Sysoc sys = new Sysoc(filePath);
                    string s = sys.AddIISConfig();
                    if (s != string.Empty)
                    {
                        this.textDebug.Text += s + "\r\n";
                        Thread.Sleep(1000);
                        this.textDebug.Text += "安装失败！";
                        mutex.Close();
                        System.Windows.Forms.Application.ExitThread();
                        return;
                    }
                    this.textDebug.Text += Sysoc.IIS_CONFIG_TEXT + "\r\n";

                    string IISdll = "iis.dll";
                    string IISinf = "iis.inf";
                    string from = null, to = null;

                    Thread.Sleep(1000);
                    this.textDebug.Text += "正在解压缩IIS安装组件：\r\n";

                    if (_winVer == "Windows Server 2003 family")
                    {
                        from = AppDomain.CurrentDomain.BaseDirectory + @"win2003\iis.dl_";
                    }
                    else if (_winVer == "Windwos XP")
                    {
                        from = AppDomain.CurrentDomain.BaseDirectory + @"winxp\iis.dl_";
                    }
                    else if (_winVer == "Windwos 2000")
                    {
                        from = AppDomain.CurrentDomain.BaseDirectory + @"win2k\iis.dl_";
                    }
                    else
                    {
                        from = AppDomain.CurrentDomain.BaseDirectory + @"other\iis.dl_";
                    }

                    to = _winDir + @"\system32\setup\" + IISdll;
                    EXPand ex1 = new EXPand(from, to);
                    ex1.ExPandFile();

                    this.textDebug.Text += "正在解压文件到：" + to + "\r\n";

                    Thread.Sleep(1000);
                    if (_winVer == "Windows Server 2003 family")
                    {
                        from = AppDomain.CurrentDomain.BaseDirectory + @"win2003\iis.in_";
                    }
                    else if (_winVer == "Windwos XP")
                    {
                        from = AppDomain.CurrentDomain.BaseDirectory + @"winxp\iis.in_";
                    }
                    else if (_winVer == "Windwos 2000")
                    {
                        from = AppDomain.CurrentDomain.BaseDirectory + @"win2k\iis.in_";
                    }
                    else
                    {
                        from = AppDomain.CurrentDomain.BaseDirectory + @"other\iis.in_";
                    }
                    to = _winDir + @"\inf\" + IISinf;
                    EXPand ex2 = new EXPand(from, to);
                    ex2.ExPandFile();
                    this.textDebug.Text += "正在解压文件到：" + to + "\r\n";

                    Thread.Sleep(1000);
                    this.ShowComponent(filePath);
                }
            }
            else
            {
                this.textDebug.Text += "找不到" + filePath + "\r\n";
                mutex.Close();
                Thread.Sleep(1000);
                this.textDebug.Text += "安装失败！";
            }
        }

        private void ShowComponent(string filePath)
        {
            Thread.Sleep(1000);
            string fileName = _winDir + @"\system32\sysocmgr.exe";
            string argument = "/y /i:" + filePath;
            WindowStart start = new WindowStart(fileName, argument);
            int proccessId = start.OpenWindow();
            if (proccessId != -1)
            {
                this.textDebug.Text += "There is a new application was started,its id is:" + proccessId + "\r\n";
            }
            else
            {
                this.textDebug.Text += "启动IIS运行向导失败" + "\r\n";
            }
        }
    }
}
