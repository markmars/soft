using System.Diagnostics;
using System.IO;
/*
 * Created by ziv at 2007-1-10
 */
namespace Zivsoft.Business.Install
{
	/// <summary>
	/// EXPand��
	/// </summary>
	class EXPand
	{
		private string _from;
		private string _to;

		/// <summary>
		/// 
		public EXPand(string from,string to)
		{
			this._from=from;
			this._to=to;
		}

		public void ExPandFile()
		{
			if(File.Exists(this._from))
			{
				string argument=this._from+" "+this._to;
				Process.Start("EXPand",argument);
			}
			else
			{
				throw new FileNotFoundException("",this._from);
			}
		}
	}
}
