using System;
using System.Runtime.InteropServices;

namespace Zivsoft.Business.Install
{
	[ StructLayout( LayoutKind.Sequential )]
	class OSVerInfo 
	{
		public int OSVersionInfoSize;
		public int MajorVersion;
		public int MinorVersion;
		public int BuildNumber; 
		public int PlatformId;
		[ MarshalAs( UnmanagedType.ByValTStr, SizeConst=128 )]    
		public String versionString;
	}
}
