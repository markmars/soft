using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Zivsoft.Business.Install
{
	/// <summary>
	/// WindowsOperator ��ժҪ˵����
	/// </summary>
	class WindowsOperator
	{
		[DllImport("kernel32")] 
		public static extern void GetWindowsDirectory(StringBuilder WinDir,int count);
		public WindowsOperator()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
		public string GetWinDir()
		{
			const int nChars = 128;
			StringBuilder buff = new StringBuilder(nChars);
			GetWindowsDirectory(buff,nChars);
			return buff.ToString();
		}
	}
}
