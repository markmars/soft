using System.Runtime.InteropServices;

namespace Zivsoft.Business.Install
{
	class LibWrap 
	{
		[ DllImport( "kernel32" )]
		public static extern bool GetVersionEx( [In, Out] OSVerInfo osvi );
		[ DllImport( "kernel32", EntryPoint="GetVersionEx" )] 
		public static extern bool GetVersionExStruct( ref StructOSInfo osvi );  
	}
}
