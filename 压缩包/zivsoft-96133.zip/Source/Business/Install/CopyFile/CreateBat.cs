using System;
using System.IO;
using System.Windows.Forms;
/*
 * Created by ziv at 2006-6-29
 * ����bat�ļ�
 */
namespace CopyFile
{
	/// <summary>
	/// CreateBat ��ժҪ˵����
	/// </summary>
	public class CreateBat
	{
		private string fromPath;
		private string toPath;
		private const string BAT_FILE_PATH="c:\\tmp.bat";
		
		/// <summary>
		/// ���캯����ָ��·��
		/// </summary>
		public CreateBat(string from,string to)
		{
			this.fromPath=from;
			this.toPath=to;
		}

		/// <summary>
		/// ִ�д����ļ�����
		/// </summary>
		/// <returns>��ȷ�򷵻�null</returns>
		public string run()
		{
			try
			{
				FileStream fs=new FileStream(CreateBat.BAT_FILE_PATH,FileMode.Create);
				StreamWriter sw=new StreamWriter(fs);
				string text="xcopy /e/y "+this.fromPath+" "+this.toPath;
				MessageBox.Show("test:"+text);
				sw.WriteLine(text);
				sw.Close();
				fs.Close();
				return null;
			}
			catch(Exception err)
			{
				return err.Message;
			}
		}
	}
}
