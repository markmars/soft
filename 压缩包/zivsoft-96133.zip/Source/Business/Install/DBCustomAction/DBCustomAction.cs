using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.IO;
using System.Data.SqlClient;
using System.Reflection;
/*
 * Created by ziv at 2006-6-30
 */
namespace DBCustomAction
{
	/// <summary>
	/// DBCustomAction ��ժҪ˵����
	/// </summary>
	[RunInstaller(true)]
	public class DBCustomAction : Installer
	{

		private string strPass = "";

		public DBCustomAction()
		{
			InitializeComponent();
		}

		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{

		}

		public override void Install(System.Collections.IDictionary stateSaver)
		{
		
			//���
			strPass = this.Context.Parameters["strPass"];
			AddDBTable("OKCRM");//OKCRMΪ���ݿ�����

		}
		private string  GetSql(string strName)
		{
			try
			{
				//' Get the current assembly.
				Assembly Asm = Assembly.GetExecutingAssembly();
				// Resources are named using a fully qualified name
				
				Stream strm  = Asm.GetManifestResourceStream(Asm.GetName().Name + "." + strName);
				
				//Read the contents of the embedded file.
				StreamReader reader= new StreamReader(strm);//,System.Text.Encoding.Unicode);
			
				
				return reader.ReadToEnd();
			}
			catch(Exception err)
			{
				throw new InstallException("��ȡsql�ű��ļ�",err);
			}
																																	  
		}
		private void ExecuteSql(string DatabaseName , string Sql)
		{
            
			SqlConnection sqlConnection1 = new SqlConnection("user id=sa;password="+strPass+";database=master;server=(local)") ;
			SqlCommand Command  = new SqlCommand(Sql, sqlConnection1);
			Command.Connection.Open();
			Command.Connection.ChangeDatabase(DatabaseName);
			
			try
			{
				Command.ExecuteNonQuery();
			}
			catch(Exception err)
			{
				throw new InstallException("ִ��sql�ű��ļ�",err);
			}
			finally
			{
				// Finally, blocks are a great way to ensure that the connection 
				
				Command.Connection.Close();
			}
		
		}
		protected void  AddDBTable(string strDBName )
		{
			try
			{
				//Create the database.
				ExecuteSql("master", "CREATE DATABASE " + strDBName);
				// Create the tables.
				ExecuteSql(strDBName, GetSql("sql.sql"));
			}
			catch(Exception err)
			{
				throw new InstallException("�������ݿ��",err);
			}
		}

		private void RemoveDBTable(string strDBName)
		{
            this.ExecuteSql("master","DROP DATABASE "+strDBName);			
		}

		public override void Rollback(IDictionary savedState)
		{
			base.Rollback (savedState);
			//this.RemoveDBTable("OKCRM");
		}

		

	}
}
