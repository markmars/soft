using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Zivsoft.Business.Install
{
	/// <summary>
	/// WindowStart ��ժҪ˵����
	/// </summary>
	class WindowStart
	{
		private string _fileName;
		private string _argument;
		
		public WindowStart(string fileName,string argument)
		{
			this._fileName=fileName;
			this._argument=argument;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns>���ؽ���ID��-1Ϊ�����쳣</returns>
		public int OpenWindow()
		{
			try
			{
				Process p=Process.Start(_fileName,_argument);
				return p.Id;
			}
			catch(Exception e)
			{
				MessageBox.Show(e.Message);
				return -1;
			}
		}
	}
}
