using System;
using System.Runtime.InteropServices;
/*
 * Created by ziv at 2007-1-10
 */
namespace Zivsoft.Business.Install
{
	class OSHelper
	{
		public static int GetClassSize()
		{
			return Marshal.SizeOf(new OSVerInfo());
		}
		public static string GetOperationName()
		{
			OSVerInfo osvi=new OSVerInfo();
			osvi.OSVersionInfoSize=GetClassSize();
			LibWrap.GetVersionEx(osvi);
			return OpSysName(osvi.MajorVersion, osvi.MinorVersion,osvi.PlatformId);
		}

		public static string GetStructOSName()
		{
			StructOSInfo s=new StructOSInfo();
			s.OSVersionInfoSize=GetStructSize();
			LibWrap.GetVersionExStruct(ref s);
			return OpSysName(s.MajorVersion,s.MinorVersion,s.PlatformId);
		}

		public static int GetStructSize()
		{
			StructOSInfo osvi = new  StructOSInfo();
			return Marshal.SizeOf( osvi );
		}

		public static int GetPlatformId()
		{
			OSVerInfo osvi=new OSVerInfo();
			LibWrap.GetVersionEx(osvi);
			return osvi.PlatformId;
		}
		public static int GetPlatformId4Struct()
		{
			StructOSInfo s=new StructOSInfo();
			LibWrap.GetVersionExStruct(ref s);
			return s.PlatformId;
		}

		public static string GetVersion()
		{
			OSVerInfo osvi=new OSVerInfo();
			LibWrap.GetVersionEx(osvi);
			return osvi.versionString;
		}
		public static String OpSysName(int MajorVersion,int MinorVersion ,int PlatformId)
		{
			String str_opn =String.Format("{0}.{1}",MajorVersion,MinorVersion);
			switch(str_opn)
			{
				case "4.0":
					return win95_nt40(PlatformId);
				case "4.10":
					return "Windows 98";
				case "4.90":
					return "Windows Me";
				case "3.51":
					return "Windows NT 3.51";
				case "5.0":
					return "Windwos 2000";
				case "5.1":
					return "Windwos XP";
				case "5.2":
					return "Windows Server 2003 family";
				default:
					return "This windows version is not distinguish!";
			}
		}
		public static String win95_nt40(int PlatformId)
		{
			switch(PlatformId)
			{
				case 1:
					return "Windows 95";
				case 2:
					return "Windows NT 4.0";
				default:
					return "This windows version is not distinguish!";
			}
		}
	}
}
 
 
 
 
