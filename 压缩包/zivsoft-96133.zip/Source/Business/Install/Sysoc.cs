using System;
using System.IO;

namespace Zivsoft.Business.Install
{
	/// <summary>
	/// Sysoc ��ժҪ˵����
	/// </summary>
	class Sysoc
	{
		private string _filePath;
		private string _iisText;
		public const string IIS_CONFIG_TEXT="iis=iis.dll,OcEntry,iis.inf,,7";
		public const string IIS_HOME_COFIG="iis=iis.dll,OcEntry,iis.inf,hide,7";
		public Sysoc(string filePath)
		{
			this._filePath=filePath;
		}
		public bool IsHide()
		{
			bool flg=false;
			StreamReader  sr=new StreamReader(this._filePath);
			string text=sr.ReadLine();
			while(text!=null)
			{
				if(text.Trim().Trim().IndexOf(IIS_HOME_COFIG)!=-1)
				{
					//�ҵ�����hide״̬
					flg=true;
					this._iisText=text;
					break;
				}
				text=sr.ReadLine();
			}
			sr.Close();
			return flg;
		}

		public string GetIISText()
		{
			if(this.IsHide())
			{
				return IIS_HOME_COFIG;
			}
			else
			{
				return IIS_CONFIG_TEXT;
			}
		}

		public string AddIISConfig()
		{
			StreamReader  sr=new StreamReader(this._filePath);
			string text=sr.ReadToEnd();
			sr.Close();

			//�����ļ�
			StreamWriter bakSysoc=File.CreateText(@"C:\"+this.GetFileFormat()+"_sysoc.inf");
			bakSysoc.Write(text);
			bakSysoc.Close();
			
			if(text!=null)
			{
				text=text.Replace(IIS_HOME_COFIG,IIS_CONFIG_TEXT);
				StreamWriter sw=null;
				try
				{
					sw=new StreamWriter(this._filePath);
					sw.Write(text);
					sw.Close();
				}
				catch(Exception err)
				{
					return err.Message;
				}
			}
			return string.Empty;
		}

		/// <summary>
		/// ��ȡ�����ļ���ʽ
		/// </summary>
		private string GetFileFormat()
		{
			string hour=DateTime.Now.Hour.ToString();
			if(hour.Length==1)
			{
				hour="0"+hour;
			}
			string minute=DateTime.Now.Minute.ToString();
			if(minute.Length==1)
			{
				minute="0"+minute;
			}
			string second=DateTime.Now.Second.ToString();
			if(second.Length==1)
			{
				second="0"+second;
			}
			return hour+minute+second;
		}

	}
}
