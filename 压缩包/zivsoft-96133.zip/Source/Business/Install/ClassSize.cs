using System;
using System.Runtime.InteropServices;

namespace Zivsoft.Business.Install
{
	[StructLayout(LayoutKind.Sequential)]
	class ClassSize
	{
		public int Field1;
		public int Field2;
	}
}
