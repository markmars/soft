﻿using Zivsoft.Business.Users;
using Zivsoft.Business.Calculate;
using Zivsoft.Business.DbInterface;
using Zivsoft.Services;
using Zivsoft.IO;
using Zivsoft.IO.Security;
using Zivsoft.IO.Spider;
using Zivsoft.IO.Core;
using Zivsoft.IO.Users;
using Zivsoft.Business.Security;
using System.Windows.Forms;
using Zivsoft.Business.Register;
using Zivsoft.IO.Chess;
using Zivsoft.IO.Calculate;
using Zivsoft.IO.DbInterface;
/*
 * Author:ziv
 * Time:2006-12-1
 */
namespace Zivsoft.Business
{
    /// <summary>
    /// 业务入口
    /// </summary>
    class BusinessBH : BusinessHandler
    {
        /// <summary>
        /// 
        /// </summary>
        protected override Response PerformTask(Request request)
        {
            if (request is SecurityRequest) { 
                SecurityFactory sf=new SecurityFactory();
                return sf.DoTask(request);
            }

            if (request is MenuTreeRequest)
            {
                MenuTreeFactory bh = new MenuTreeFactory();
                return bh.DoTask(request);
            }

            if (request is LoginRequest)
            {
                LoginFactory p = new LoginFactory();
                return p.PerformTask(request as LoginRequest);
            }

            if (request is SpiderRequest)
            {
                SpiderFactory f = new SpiderFactory();
                return f.DoTask(request);
            }

            if (request is ChessRequest)
            {
                ChessFactory cf = new ChessFactory();
                return cf.DoTask(request);
            }

            if (request is CalculateRequest)
            {
                CalculateRequest req=request as CalculateRequest;
                string expression = req.Expression;
                CalculateResponse cr = new CalculateResponse();
                cr.Result = CalculateOperator.GetValue(expression).ToString();
                return cr;
            }

            if (request is AddAllViewFields)
            {
                return new AddAllViewFieldsResponse { Item = new ViewFieldsConfig().InitViewFields() };
            }

            if (request is RegisterUser)
            {
                RegisterUserInfo register = new RegisterUserInfo();
                var req = request as RegisterUser;
                int k = register.Register(req.UserId, req.Password,req.UserName);
                return new RegisterUserResponse { IsSuccess = (k == 1 ? true : false) };
            }

            return NoBusinessCode;
        }

        private static bool _isCert=false;
        /// <summary>
        /// 
        /// </summary>
        protected override bool Check(Request requset)
        {
            if (requset is BusinessRequest)
            {
                if (!_isCert)
                {
                    ISecurity cert = new SecurityHelper();
                    _isCert = cert.CheckCert();
                }
                if (!_isCert)
                {
                    this.CheckUnValidMessage = "软件未注册，请通过您的机器码(MachineCode)到www.zivsoft.com注册";
                    Application.Run(new RegUI());
                }
                return _isCert;
            }
            this.CheckUnValidMessage = "非法请求";
            return false;
        }
    }
}
