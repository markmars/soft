﻿using System;
using Zivsoft.Log;


namespace Zivsoft.Business.WebVisitor
{
    class Factory
    {
        public static void Main()
        {
            try
            {

            }
            catch (Exception e)
            {
                Logger.LogError(e);
            }
#if DEBUG
            Console.Read();
#endif
            
        }
    }
}
