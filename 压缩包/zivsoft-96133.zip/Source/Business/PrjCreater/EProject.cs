﻿namespace Zivsoft.Business.PrjCreater
{
    enum EProject
    {
        VC,
        VB,
        CS
    }
}