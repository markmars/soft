﻿using System;
using System.Reflection;
using System.IO;
using Zivsoft.Log;


/*
 * 
 * 
 * 
 * 
 * 
 */

namespace Zivsoft.Business.PrjCreater
{
    class PrjFactory
    {

        const string root = "[%RootNamespace%]";
        const string name = "[%AssemblyName%]";
        public static void Main()
        {
            OutputVersion();

            Console.WriteLine("Menu:");
            Console.WriteLine("1. Class Library");
            Console.WriteLine("2. Web Library");
            Console.WriteLine("3. New Console Application");
            Console.WriteLine("4. New Windows Application");
            Console.WriteLine("5. New WPF");
            Console.WriteLine("6. Win32 Library");
            Console.WriteLine("0. Exit");
            loop:
            Console.Write(">");
            var tag=Console.ReadLine();
            if (tag == "1")
            {
                Create("template.csproj.xml",EProject.CS);
            }
            else if (tag == "2")
            {
                Create("web.csproj.xml", EProject.CS);
            }
            else if (tag == "3")
            {
                Create("console.csproj.xml", EProject.CS);
            }
            else if (tag == "4")
            {
                Create("win.csproj.xml", EProject.CS);
            }
            else if (tag == "5")
            {
                Create("wpf.csproj.xml", EProject.CS);
            }
            else if (tag == "6")
            {
                Create("win32.vcproj.xml", EProject.VC);
            }
            else if (tag == "0")
            {
                return;
            }
            else
            {
                Console.WriteLine("Please input again:");
                goto loop;
            }
        }
        static void Create(string xml, EProject prj)
        {
            xml = typeof (PrjFactory).Namespace + "." + xml;
            Console.Write("Input the assembly name:");
            var assemblyName = Console.ReadLine();
            Console.Write("Input the namespace root:");
            var rootNamespace = Console.ReadLine();
            var s = Assembly.GetCallingAssembly().GetManifestResourceStream(xml);
            if (s != null)
            {
                var sr = new StreamReader(s);
                var content = sr.ReadToEnd().Replace(root, rootNamespace).Replace(name, assemblyName);
                var fs = File.Create(assemblyName + PrjConvertor.Single.GetExtName(prj));
                var sw = new StreamWriter(fs);
                sw.WriteLine(content);
                sw.Close();
                fs.Close();
                sr.Close();
                s.Close();
            }
            else
            {
                Logger.LogError("null {0}",xml);
            }
        }

        static void OutputVersion()
        {
            Console.Title = "Project Creater";
            Console.WriteLine("============================================");
            Console.WriteLine("               Version:{0}                   ", Assembly.GetExecutingAssembly().GetName().Version);
            Console.WriteLine("============================================");
        }
    }
}