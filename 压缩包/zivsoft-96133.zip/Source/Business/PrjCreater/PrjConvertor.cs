﻿using System;

namespace Zivsoft.Business.PrjCreater
{
    class PrjConvertor
    {
        private PrjConvertor()
        {
        }

        public static PrjConvertor Single
        {
            get
            {
                return new PrjConvertor();
            }
        }

        public string GetExtName(EProject prj)
        {
            switch (prj)
            {
                case EProject.CS:
                    return ".csproj";
                case EProject.VC:
                    return ".vcproj";
                default:
                    throw new NotImplementedException();
            }
        }
    }
}