﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;
using Zivsoft.IO.Mail;
using Zivsoft.Business.Mail;

namespace Zivsoft.Business
{
    class MailFactory:BusinessHandler
    {

        protected override Response PerformTask(Request request)
        {
            if (request is MailRequest)
            {
                var req=request as MailRequest;
                //MailHelper.Send("zorywa@163.com", "smtp.163.com", "zorywa@163.com", "83749598", "lihuaz@live.com", "spider", req.Message);
                MailHelper.Send();
                return new Response();
            }
            return NoBusinessCode;
        }

        protected override bool Check(Request request)
        {
            if (request is MailRequest)
            {
                return true;
            }
            return false;
        }
    }
}
