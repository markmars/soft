﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Zivsoft.Business.Security;
using Zivsoft.Services;
using Zivsoft.IO.Spider;
using Zivsoft.Business.Spider;

namespace Zivsoft.Business
{
    /// <summary>
    /// 
    /// </summary>
    class SpiderFactory : BusinessHandler
    {
        private static bool _isCert = false;
        protected override bool Check(Request request)
        {
            if (request is SpiderRequest)
            {
                if (!_isCert)
                {
                    ISecurity cert = new SecurityHelper();
                    _isCert = cert.CheckCert();
                }
                if (!_isCert)
                {
                    this.CheckUnValidMessage = "The current software is not registered, please go to the http://www.zivsoft.com for register code.";
                }
                return _isCert;
            }
            this.CheckUnValidMessage = "No permission.";
            return false;
        }

        protected override Response PerformTask(Request req)
        {
            if (req is MM211)
            {
                SpiderHelper.Crawl();
                return new SpiderResponse();
            }
            else if (req is Baidu)
            {
                SpiderHelper.LaunchBeautyLeg();
                return new Response();
            }
            else
            {
                return NoBusinessCode;
            }
        }

        internal string GetMachineCode()
        {
            SecurityHelper s = new SecurityHelper();
            return s.GetMachineCode();
        }
    }
}
