﻿
using Zivsoft.Services;
using Zivsoft.Business.Core;
using Zivsoft.IO.Core;

namespace Zivsoft.Business
{
    
    class MenuTreeFactory:BusinessHandler
    {
        private Response res = new Response();
        protected override Response PerformTask(Request request)
        {
            MenuTreeRequest req=request as MenuTreeRequest;
            IMenuTree menutree = new MenuTree();
            menutree.LoadMenu(req.Menu,req.UserId);
            menutree.LoadTree(req.Tree,req.UserId,req.ExitText);
            return res;
        }

        protected override bool Check(Request request)
        {
            if (request is MenuTreeRequest)
            {
                return true;
            }
            else {
                this.CheckUnValidMessage = "request is not MenuTreeRequest";
                return false;
            }
        }
    }
}
