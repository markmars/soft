﻿using System;
using System.Collections;

namespace Zivsoft.Business.Chess
{
    /// <summary>
    /// 象棋接口
    /// </summary>
    interface IChess
    {
        /// <summary>
        /// 
        /// </summary>
        int NextX { get; }
        /// <summary>
        /// 
        /// </summary>
        int NextY { get; }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        ArrayList GetNextLocation();
        /// <summary>
        /// 如果是红色返回为真
        /// </summary>
        /// <returns></returns>
        bool IsRedChess { get;  }
        /// <summary>
        /// 
        /// </summary>
        bool IsDogFall { get;  }
        /// <summary>
        /// 是否是进攻
        /// </summary>
        /// <returns></returns>
        bool IsAttack { get;  }
        /// <summary>
        /// 
        /// </summary>
        string Name { get; }
        /// <summary>
        /// 
        /// </summary>
        int X { get;  }
        /// <summary>
        /// 
        /// </summary>
        int Y { get;  }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        void Move(int x, int y);
        /// <summary>
        /// 移动
        /// </summary>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        /// <param name="obj"></param>
        void Move(int x, int y, object obj);
    }
}