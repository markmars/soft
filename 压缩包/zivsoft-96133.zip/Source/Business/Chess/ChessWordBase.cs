﻿using System;
using System.Collections;
using System.Windows.Forms;

namespace Zivsoft.Business.Chess
{
    /// <summary>
    /// 棋子
    /// </summary>
    internal abstract class ChessWordBase:IChess
    {
        public const int XBoardLength = 9;
        public const int YBoardLength = 10;
        public static ArrayList All = new ArrayList();


        /// <summary>
        /// 棋盘范围内
        /// </summary>
        /// <returns></returns>
        public virtual bool Check()
        {
            if ((this.X > 9) || (this.X < 1))
            {
                return false;
            }
            if ((this.Y > 10) || (this.Y < 1))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 被吃掉
        /// </summary>
        public virtual void Destroy()
        {
            this.IsDogFall = false;
            this.X = 0;
            this.Y = 0;
        }


        public virtual void Init()
        {
            this.IsDogFall = true;
            this.X = 0;
            this.Y = 0;
        }


        #region IChess Members
        /// <summary>
        /// 
        /// </summary>
        public bool IsRedChess
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsDogFall
        {
            get;
            set;
        }

        /// <summary>
        /// 进攻
        /// </summary>
        public bool IsAttack
        {
            get;
            set;
        }

        public int NextX
        {
            get;
            set;
        }

        public int NextY
        {
            get;
            set;
        }

        public int X
        {
            get;
            set;
        }

        public int Y
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string Name
        {
            get;
            set;
        }

        public abstract  ArrayList GetNextLocation();


        public void Move(int ix,int iy)
        {
            this.MoveNext();
            if (this.Check(ix, iy, GetNextLocation()))
            {
                X = ix;
                Y = iy;
            }
        }

        private void MoveNext()
        {
            this.NextX = this.X;
            this.NextY = this.Y;
        }

        public abstract bool Check(int x, int y, ArrayList al);

        public void Move(int iX, int iY, object qz)
        {
            if (qz == null)
            {
                this.Move(iX, iY);
            }
            else
            {
                this.MoveNext();
                if (this.Check(iX, iY, GetNextLocation()))
                {
                    X = iX;
                    Y = iY;
                    ((ChessWordBase)qz).Destroy();
                }
            }
        }

        #endregion
    }
}