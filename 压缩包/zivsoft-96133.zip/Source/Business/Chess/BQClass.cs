﻿using System;
using System.Collections;
using Zivsoft.Business.Chess.Black;
using Zivsoft.Business.Chess.Red;

/*
 * 
 * 
 * 
 */

namespace Zivsoft.Business.Chess
{
    static partial class BQClass
    {
        public static ArrayList AllChessWords = new ArrayList();

        /// <summary>
        /// 初始化期盼
        /// </summary>
        public static void Start()
        {
            InitRed();
            InitBlack();
            ChessWordBase.All = AllChessWords;
        }

        #region Black
        //black
        internal static BJu heiche = null;
        internal static BJu heiche2 = null;
        internal static BMa heima = null;
        internal static BMa heima2 = null;
        internal static BPao heipao = null;
        internal static BPao heipao2 = null;
        internal static BXiang heixiang = null;
        internal static BXiang heixiang2 = null;
        internal static BShi heishi = null;
        internal static BShi heishi2 = null;
        internal static BJiang heijiang = null;
        internal static BZu heizu = null;
        internal static BZu heizu2 = null;
        internal static BZu heizu3 = null;
        internal static BZu heizu4 = null;
        internal static BZu heizu5 = null;


        private static void InitBlack()
        {

            heiche = new BJu();
            heiche.Init(1, 10);
            AllChessWords.Add(heiche);
            heiche2 = new BJu();
            heiche2.Init(9, 10);
            AllChessWords.Add(heiche2);
            heima = new BMa();
            heima.Init(2, 10);
            heima2 = new BMa();
            heima2.Init(8, 10);
            AllChessWords.Add(heima);
            AllChessWords.Add(heima2);
            heixiang = new BXiang();
            heixiang.Init(3, 10);
            heixiang2 = new BXiang();
            heixiang2.Init(7, 10);
            AllChessWords.Add(heixiang);
            AllChessWords.Add(heixiang2);
            heishi = new BShi();
            heishi.Init(4, 10);
            heishi2 = new BShi();
            heishi2.Init(6, 10);
            AllChessWords.Add(heishi);
            AllChessWords.Add(heishi2);
            heijiang = new BJiang();
            heijiang.Init(5, 10);
            AllChessWords.Add(heijiang);
            heipao = new BPao();
            heipao.Init(2, 8);
            heipao2 = new BPao();
            heipao2.Init(8, 8);
            AllChessWords.Add(heipao);
            AllChessWords.Add(heipao2);

            heizu = new BZu();
            heizu.Init(1, 7);
            heizu2 = new BZu();
            heizu2.Init(3, 7);
            heizu3 = new BZu();
            heizu3.Init(5, 7);
            heizu4 = new BZu();
            heizu4.Init(7, 7);
            heizu5 = new BZu();
            heizu5.Init(9, 7);
            AllChessWords.Add(heizu);
            AllChessWords.Add(heizu2);
            AllChessWords.Add(heizu3);
            AllChessWords.Add(heizu4);
            AllChessWords.Add(heizu5);
        }
        #endregion

        #region Red
        //红方
        internal static RedJu hongche = null;
        internal static RedJu hongche2 = null;

        internal static RedMa hongma = null;
        internal static RedMa hongma2 = null;

        internal static RedXiang hongxiang = null;
        internal static RedXiang hongxiang2 = null;

        internal static RedShi hongshi = null;
        internal static RedShi hongshi2 = null;

        internal static RedPao hongpao = null;
        internal static RedPao hongpao2 = null;
        internal static RedShuai hongshuai = null;

        //兵
        internal static RedBing hongbin = null;
        internal static RedBing hongbin2 = null;
        internal static RedBing hongbin3 = null;
        internal static RedBing hongbin4 = null;
        internal static RedBing hongbin5 = null;


        private static void InitRed()
        {
            hongche = new RedJu();
            hongche.Init(1, 1);
            AllChessWords.Add(hongche);

            hongche2 = new RedJu();
            hongche2.Init(9, 1);
            AllChessWords.Add(hongche2);

            hongma = new RedMa();
            hongma.Init(2, 1);
            AllChessWords.Add(hongma);

            hongma2 = new RedMa();
            hongma2.Init(8, 1);
            AllChessWords.Add(hongma2);

            hongxiang = new RedXiang();
            hongxiang.Init(3, 1);
            AllChessWords.Add(hongxiang);

            hongxiang2 = new RedXiang();
            hongxiang2.Init(7, 1);
            AllChessWords.Add(hongxiang2);

            hongshi = new RedShi();
            hongshi.Init(4, 1);
            AllChessWords.Add(hongshi);

            hongshi2 = new RedShi();
            hongshi2.Init(6, 1);
            AllChessWords.Add(hongshi2);

            hongshuai = new RedShuai();
            hongshuai.Init(5, 1);
            AllChessWords.Add(hongshuai);

            hongpao = new RedPao();
            hongpao.Init(2, 3);
            AllChessWords.Add(hongpao);

            hongpao2 = new RedPao();
            hongpao2.Init(8, 3);
            AllChessWords.Add(hongpao2);

            hongbin = new RedBing();
            hongbin.Init(1, 4);
            hongbin2 = new RedBing();
            hongbin2.Init(3, 4);
            hongbin3 = new RedBing();
            hongbin3.Init(5, 4);
            hongbin4 = new RedBing();
            hongbin4.Init(7, 4);
            hongbin5 = new RedBing();
            hongbin5.Init(9, 4);

            AllChessWords.Add(hongbin);
            AllChessWords.Add(hongbin2);
            AllChessWords.Add(hongbin3);
            AllChessWords.Add(hongbin4);
            AllChessWords.Add(hongbin5);

        }
        #endregion
    }
}