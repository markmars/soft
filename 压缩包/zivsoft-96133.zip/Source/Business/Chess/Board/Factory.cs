﻿using System.Collections;
using System.Drawing;
using System.Reflection;
using System;

using Zivsoft.Log;
/*
 * 
 * 
 * 
 */
namespace Zivsoft.Business.Chess.Board
{
    /// <summary>
    /// 不能更改命名空间，由于引用到图片
    /// </summary>
    class Factory
    {
        // MVV/LVA每种子力的价值
        static byte[] cucMvvLva = 
        {
            0, 0, 0, 0, 0, 0, 0, 0,
            5, 1, 1, 3, 4, 3, 2, 0,
            5, 1, 1, 3, 4, 3, 2, 0
        };

        /// <summary>
        /// 
        /// </summary>
        public static bool IsTurnToRedChessWalking
        {
            get;
            set;
        }

        /// <summary>
        /// </summary>
        public static void TurnToRedChessWalking()
        {
            ArrayList al = BQClass.hongbin.GetNextLocation();
            int[] index = al[0] as int[];
            BQClass.hongbin.Move(index[0], index[1]);
        }

        public static ChessWord OldQiZhi = null;
        public static ArrayList AllChess = new ArrayList();
        public static ArrayList WeiZhi_AL = new ArrayList();

        /// <summary>
        /// 设置所有棋盘
        /// </summary>
        static public void SetAll()
        {
            //清除棋盘
            BQClass.AllChessWords.Clear();
            AllChess.Clear();
            //默认情况下用户先下（红方为机器）
            IsTurnToRedChessWalking = false;
            BQClass.Start();
            for (int i = 0; i < BQClass.AllChessWords.Count; i++)
            {
                IChess chess = (IChess)BQClass.AllChessWords[i];
                bool flag = ((IChess)BQClass.AllChessWords[i]).IsDogFall;
                string str = ((IChess)BQClass.AllChessWords[i]).Name;


                ChessWord chessWorld = new ChessWord();
                chessWorld.Chess = chess;
                chessWorld.BackgroundImage = Factory.GetBackgroundImage(chess.Name);
                AllChess.Add(chessWorld);
            }
        }

        public static Image GetBackgroundImage(string name)
        {
            var path = typeof(Factory).FullName.Replace(typeof(Factory).Name, "");
            var full = string.Format("{0}Image.{1}.jpg", path, name);
            var call = Assembly.GetCallingAssembly();
            Logger.LogDebug(call.ToString());
            if (call != null && !string.IsNullOrEmpty(full))
            {
                var s = call.GetManifestResourceStream(full);
                if (s != null)
                {
                    return Image.FromStream(s);
                }
                else
                {
                    throw new Exception("Can't find the pictures.");
                }
            }
            else
            {
                throw new Exception("Can't find the pictures.");
            }
        }


        internal static void ResponseMove()
        {
            SearchMain();
        }

        private static void SearchMain()
        {
            //BQClass.hongbin.Move(1, 3);
        }
    }
}