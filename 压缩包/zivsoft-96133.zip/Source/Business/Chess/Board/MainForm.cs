﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;
using System.Resources;
using System.Drawing;
using System.Reflection;

namespace Zivsoft.Business.Chess.Board
{
    class MainForm : Form
    {
        // Fields
        private Button btnUserFirst;
        private IContainer components;
        private Button btnClose;
        private Button btnCpuFirst;
        private Timer timer1;
        private ChessBoard qipan1;

        // Methods
        public MainForm()
        {
            this.InitializeComponent();
        }

        private void btnUserFirst_Click(object sender, EventArgs e)
        {
            this.Start();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Start();
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.qipan1 = new Zivsoft.Business.Chess.Board.ChessBoard();
            this.btnUserFirst = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCpuFirst = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // qipan1
            // 
            this.qipan1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("qipan1.BackgroundImage")));
            this.qipan1.DataSource = null;
            this.qipan1.Location = new System.Drawing.Point(0, 0);
            this.qipan1.Name = "qipan1";
            this.qipan1.SetQZColor = Zivsoft.Business.Chess.Board.EChessColor.Black;
            this.qipan1.Size = new System.Drawing.Size(717, 784);
            this.qipan1.TabIndex = 0;
            // 
            // button1
            // 
            this.btnUserFirst.Location = new System.Drawing.Point(737, 14);
            this.btnUserFirst.Name = "button1";
            this.btnUserFirst.Size = new System.Drawing.Size(80, 23);
            this.btnUserFirst.TabIndex = 1;
            this.btnUserFirst.Text = "UserF";
            this.btnUserFirst.Click += new System.EventHandler(this.btnUserFirst_Click);
            // 
            // button2
            // 
            this.btnClose.Location = new System.Drawing.Point(737, 43);
            this.btnClose.Name = "button2";
            this.btnClose.Size = new System.Drawing.Size(80, 22);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClosed_Click);
            // 
            // button3
            // 
            this.btnCpuFirst.Location = new System.Drawing.Point(738, 71);
            this.btnCpuFirst.Name = "button3";
            this.btnCpuFirst.Size = new System.Drawing.Size(79, 22);
            this.btnCpuFirst.TabIndex = 3;
            this.btnCpuFirst.Text = "CpuF";
            this.btnCpuFirst.UseVisualStyleBackColor = true;
            this.btnCpuFirst.Click += new System.EventHandler(this.btnCpuFirst_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(829, 780);
            this.Controls.Add(this.btnCpuFirst);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnUserFirst);
            this.Controls.Add(this.qipan1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chess";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        /// <summary>
        /// 启动象棋
        /// </summary>
        private void Start()
        {
            Factory.SetAll();
            this.qipan1.DataSource = Factory.AllChess;
            this.qipan1.StartDataBind();
        }

        private void btnClosed_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }


        private void btnCpuFirst_Click(object sender, EventArgs e)
        {
            Start();
            Factory.IsTurnToRedChessWalking = true;
            this.timer1.Enabled = true;
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //机器下棋（Red)
            BQClass.hongbin.Move(1, 4);
            this.timer1.Enabled = false;
        }
    }
}