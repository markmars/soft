﻿namespace Zivsoft.Business.Chess.Board
{
    enum EChessDraw
    {
        Null,
        Move,
        Click
    }
}