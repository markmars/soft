﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;
using System.Threading;
using Zivsoft.Business.Chess.Board;

namespace Zivsoft.Business.Chess.Board
{
    /// <summary>
    /// 象棋棋子
    /// </summary>
    class ChessBoard : UserControl
    {
        private EChessColor _SetQZColor;
        private Container components;
        private ArrayList dqs;
        private bool Isshow;
        private int x;
        private int X;
        private int y;
        private int Y;

        public ChessBoard()
        {
            this.components = null;
            this.dqs = null;
            this._SetQZColor = EChessColor.Black;
            this.Isshow = false;
            this.InitializeComponent();
        }

        public ChessBoard(EChessColor color)
        {
            this.components = null;
            this.dqs = null;
            this._SetQZColor = EChessColor.Black;
            this.Isshow = false;
            this.InitializeComponent();
            this.SetQZColor = color;
        }

        public void DataBind()
        {
            for (int i = 0; i < this.DataSource.Count; i++)
            {
                ChessWord hongche = (ChessWord) this.DataSource[i];
                if (!hongche.IsDogFall)
                {
                    base.Controls.Remove(hongche);
                }
                IChess iqizhi = (IChess) this.DataSource[i];
                int num2 = iqizhi.X;
                int num3 = iqizhi.Y;
                hongche.Location = new Point((num2 * 0x48) - 20, (num3 * 0x48) - 20);
                hongche.CurrentChessBoard = this;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.BackgroundImage = Factory.GetBackgroundImage("bg");
            base.Name = "棋盘";
            base.Size = new Size(0x2d7, 800);
            base.Click += new EventHandler(this.ChessBoard_Click);
            base.Paint += new PaintEventHandler(this.qipan_Paint);
            base.MouseMove += new MouseEventHandler(this.qipan_MouseMove);
        }

        /// <summary>
        /// 用户下棋事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChessBoard_Click(object sender, EventArgs e)
        {
            if (((this.X != 0) && (this.Y != 0)) && this.Isshow)
            {
                Factory.OldQiZhi.Move(this.X, this.Y);
                this.DataSource = Factory.AllChess;
                this.DataBind();
                Factory.IsTurnToRedChessWalking = !Factory.IsTurnToRedChessWalking;
                Factory.WeiZhi_AL.Clear();
                this.X = 0;
                this.Y = 0;
                this.Isshow = false;
            }
        }



        private void qipan_MouseMove(object sender, MouseEventArgs e)
        {
            if (Factory.WeiZhi_AL != null)
            {
                for (int i = 0; i < Factory.WeiZhi_AL.Count; i++)
                {
                    this.x = (((int[]) Factory.WeiZhi_AL[i])[0] * 0x48) - 10;
                    this.y = (((int[]) Factory.WeiZhi_AL[i])[1] * 0x48) - 10;
                    if (((e.X >= this.x) && (e.Y >= this.y)) && ((e.X <= (this.x + 30)) && (e.Y <= (this.y + 30))))
                    {
                        this.Isshow = true;
                        this.X = ((int[]) Factory.WeiZhi_AL[i])[0];
                        this.Y = ((int[]) Factory.WeiZhi_AL[i])[1];
                        break;
                    }
                    this.Isshow = false;
                    this.X = 0;
                    this.Y = 0;
                }
                this.Refresh();
            }
        }

        /// <summary>
        /// 画圆圈
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void qipan_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            if (this.Isshow)
            {
                graphics.DrawEllipse(new Pen(Color.Black, 2f), this.x, this.y, 30, 30);
            }
        }

        public void StartDataBind()
        {
            base.Controls.Clear();
            for (int i = 0; i < this.DataSource.Count; i++)
            {
                ChessWord hongche = (ChessWord) this.DataSource[i];
                IChess iqizhi = (IChess) this.DataSource[i];
                int num2 = iqizhi.X;
                int num3 = iqizhi.Y;
                hongche.Location = new Point((num2 * 0x48) - 20, (num3 * 0x48) - 20);
                hongche.CurrentChessBoard = this;
                base.Controls.Add(hongche);
            }
        }

        public ArrayList DataSource
        {
            get
            {
                return this.dqs;
            }
            set
            {
                this.dqs = value;
            }
        }

        public EChessColor SetQZColor
        {
            get
            {
                return this._SetQZColor;
            }
            set
            {
                this._SetQZColor = value;
            }
        }
    }
}