﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;
using Zivsoft.Business.Chess.Board;
using System.Threading;

namespace Zivsoft.Business.Chess.Board
{
    partial class ChessWord : UserControl,IChess
    {
        private Container _components = null;
        private EChessDraw _move = EChessDraw.Null;

        public ChessWord()
        {
            this.InitializeComponent();
        }

        private void Eat(bool b)
        {
            for (int i = 0; i < Factory.WeiZhi_AL.Count; i++)
            {
                int x = ((int[]) Factory.WeiZhi_AL[i])[0];
                int y = ((int[]) Factory.WeiZhi_AL[i])[1];
                if ((this.X == x) && (this.Y == y))
                {
                    if (b)
                    {
                        if (this._move != EChessDraw.Click)
                        {
                            this._move = EChessDraw.Move;
                        }
                    }
                    else
                    {
                        Factory.OldQiZhi.Move(x, y, this.Chess);
                        this.CurrentChessBoard.DataSource = Factory.AllChess;
                        this.CurrentChessBoard.DataBind();
                        Factory.IsTurnToRedChessWalking = !Factory.IsTurnToRedChessWalking;
                        Factory.WeiZhi_AL.Clear();
                    }
                    this.Refresh();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this._components != null))
            {
                this._components.Dispose();
            }
            base.Dispose(disposing);
        }


        private void InitializeComponent()
        {
            this.BackColor = SystemColors.Control;
            this.BackgroundImage = Factory.GetBackgroundImage("bg");
            base.Name = "hongche";
            base.Size = new Size(60, 60);
            //点击棋子
            base.Click += new EventHandler(this.ChessWordUserControl_Click);
            base.Paint += new PaintEventHandler(this.ChessWordUserControl_Paint);
            base.MouseEnter += new EventHandler(this.ChessWordUserControl_MouseEnter);
            base.MouseLeave += new EventHandler(this.ChessWordUserControl_MouseLeave);
        }


        public ChessBoard CurrentChessBoard
        {
            get; set;
        }

        internal IChess Chess
        {
            get; set;
        }

        public EChessColor ChessColor
        {
            get
            {
                return EChessColor.Red;
            }
        }
        #region IChess Members


        public ArrayList GetNextLocation()
        {
            return this.Chess.GetNextLocation();
        }


        public void Move(int X, int Y)
        {
            this.Chess.Move(X, Y);
        }

        public void Move(int X, int Y, object QZ)
        {
            this.Chess.Move(X, Y, QZ);
        }

        public int NextX
        {
            get { return Chess.NextX; }
        }

        public int NextY
        {
            get { return Chess.NextY; }
        }

        public bool IsRedChess
        {
            get { return Chess.IsRedChess; }
        }

        public bool IsDogFall
        {
            get { return Chess.IsDogFall; }
        }

        public bool IsAttack
        {
            get { return Chess.IsAttack; }
        }

        public int X
        {
            get { return Chess.X; }
        }

        public int Y
        {
            get { return Chess.Y; }
        }

        #endregion

        #region Event
        /// <summary>
        /// 被吃时调用，或吃子时调用
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChessWordUserControl_Click(object sender, EventArgs e)
        {
            //轮到红方下棋
            if (Factory.IsTurnToRedChessWalking)
            {
                //机器下棋（Red)
                if (this.IsRedChess)
                {
                    //红方（机器）
                    Factory.ResponseMove();
                }
                else
                {
                    //红方吃掉黑方
                    this.Eat(false);
                    return;
                }

            }
            else//轮到黑方下棋
            {
                //用户下棋
                if (this.IsRedChess)
                {
                    //黑方吃掉红方
                    this.Eat(false);

                    return;
                }
                else
                {
                    //黑方（用户）

                }
            }
            if (Factory.OldQiZhi != null)
            {
                Factory.OldQiZhi._move = EChessDraw.Null;
                Factory.OldQiZhi.Refresh();
            }
            Factory.WeiZhi_AL = this.GetNextLocation();
            Factory.OldQiZhi = this;
            this._move = EChessDraw.Click;
            this.Refresh();
        }

        private void ChessWordUserControl_MouseEnter(object sender, EventArgs e)
        {
            if (Factory.IsTurnToRedChessWalking)
            {
                if (!this.IsRedChess)
                {
                    this.Eat(true);
                    return;
                }
            }
            else if (this.IsRedChess)
            {
                this.Eat(true);
                return;
            }
            if (this._move != EChessDraw.Click)
            {
                this._move = EChessDraw.Move;
            }
            this.Refresh();
        }

        private void ChessWordUserControl_MouseLeave(object sender, EventArgs e)
        {
            if (this._move != EChessDraw.Click)
            {
                this._move = EChessDraw.Null;
            }
            this.Refresh();
        }

        private void ChessWordUserControl_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            if (this._move == EChessDraw.Move)
            {
                graphics.DrawEllipse(new Pen(Color.Black, 2f), 5, 5, 50, 50);
            }
            else if (this._move == EChessDraw.Click)
            {
                graphics.DrawEllipse(new Pen(Color.Black, 4f), 1, 1, 0x3a, 0x3a);
            }
        }
        #endregion

    }
}