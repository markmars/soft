﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.Business.Chess.Board
{
    class Jpg
    {
        public const string Jiang = "Jiang";
        public const string RedBing = "RedBing";              
        public const string RedXiang = "RedXiang";
        public const string RedJu = "RedJu";
        public const string RedPao = "RedPao";
        public const string RedMa = "RedMa";
        public const string RedShi = "RedShi";

        public const string Shuai = "Shuai";
        public const string BlackZu = "BlackZu";
        public const string BlackXiang = "BlackXiang";
        public const string BlackJu = "BlackJu";
        public const string BlackPao = "BlackPao";
        public const string BlackMa="BlackMa";
        public const string BackShi = "BackShi";

    }
}