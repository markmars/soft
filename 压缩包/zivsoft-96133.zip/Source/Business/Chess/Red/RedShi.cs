﻿using System;
using System.Collections;
using Zivsoft.Business.Chess;
using Zivsoft.Business.Chess.Board;

namespace Zivsoft.Business.Chess.Red
{
    internal class RedShi : RedChessBase,IChess
    {
        public override bool Check(int X, int Y, ArrayList al)
        {
            if (base.Check())
            {
                for (int i = 0; i < al.Count; i++)
                {
                    if ((((int[]) al[i])[0] == X) && (((int[]) al[i])[1] == Y))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public override ArrayList GetNextLocation()
        {
            ArrayList list = new ArrayList();
            if ((base.X == 4) && (base.Y == 1))
            {
                bool flag = false;
                for (int i = 0; i < ChessWordBase.All.Count; i++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[i]).Equals(this) && (((((ChessWordBase) ChessWordBase.All[i]).X == 5) && (((ChessWordBase) ChessWordBase.All[i]).Y == 2)) && ((ChessWordBase) ChessWordBase.All[i]).IsRedChess))
                    {
                        flag = true;
                    }
                }
                if (!flag)
                {
                    int[] numArray = new int[] { 5, 2 };
                    list.Add(numArray);
                }
                return list;
            }
            if ((base.X == 6) && (base.Y == 1))
            {
                bool flag2 = false;
                for (int j = 0; j < ChessWordBase.All.Count; j++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[j]).Equals(this) && (((((ChessWordBase) ChessWordBase.All[j]).X == 5) && (((ChessWordBase) ChessWordBase.All[j]).Y == 2)) && ((ChessWordBase) ChessWordBase.All[j]).IsRedChess))
                    {
                        flag2 = true;
                    }
                }
                if (!flag2)
                {
                    int[] numArray2 = new int[] { 5, 2 };
                    list.Add(numArray2);
                }
                return list;
            }
            if ((base.X == 5) && (base.Y == 2))
            {
                bool flag3 = false;
                bool flag4 = false;
                bool flag5 = false;
                bool flag6 = false;
                for (int k = 0; k < ChessWordBase.All.Count; k++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[k]).Equals(this))
                    {
                        if (((((ChessWordBase) ChessWordBase.All[k]).X == 4) && (((ChessWordBase) ChessWordBase.All[k]).Y == 1)) && ((ChessWordBase) ChessWordBase.All[k]).IsRedChess)
                        {
                            flag3 = true;
                        }
                        if (((((ChessWordBase) ChessWordBase.All[k]).X == 4) && (((ChessWordBase) ChessWordBase.All[k]).Y == 3)) && ((ChessWordBase) ChessWordBase.All[k]).IsRedChess)
                        {
                            flag4 = true;
                        }
                        if (((((ChessWordBase) ChessWordBase.All[k]).X == 6) && (((ChessWordBase) ChessWordBase.All[k]).Y == 1)) && ((ChessWordBase) ChessWordBase.All[k]).IsRedChess)
                        {
                            flag5 = true;
                        }
                        if (((((ChessWordBase) ChessWordBase.All[k]).X == 6) && (((ChessWordBase) ChessWordBase.All[k]).Y == 3)) && ((ChessWordBase) ChessWordBase.All[k]).IsRedChess)
                        {
                            flag6 = true;
                        }
                    }
                }
                if (!flag3)
                {
                    int[] numArray3 = new int[] { 4, 1 };
                    list.Add(numArray3);
                }
                if (!flag4)
                {
                    int[] numArray4 = new int[] { 4, 3 };
                    list.Add(numArray4);
                }
                if (!flag5)
                {
                    int[] numArray5 = new int[] { 6, 1 };
                    list.Add(numArray5);
                }
                if (!flag6)
                {
                    int[] numArray6 = new int[] { 6, 3 };
                    list.Add(numArray6);
                }
                return list;
            }
            if ((base.X == 4) && (base.Y == 3))
            {
                bool flag7 = false;
                for (int m = 0; m < ChessWordBase.All.Count; m++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[m]).Equals(this) && (((((ChessWordBase) ChessWordBase.All[m]).X == 5) && (((ChessWordBase) ChessWordBase.All[m]).Y == 2)) && ((ChessWordBase) ChessWordBase.All[m]).IsRedChess))
                    {
                        flag7 = true;
                    }
                }
                if (!flag7)
                {
                    int[] numArray7 = new int[] { 5, 2 };
                    list.Add(numArray7);
                }
                return list;
            }
            if ((base.X == 6) && (base.Y == 3))
            {
                bool flag8 = false;
                for (int n = 0; n < ChessWordBase.All.Count; n++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[n]).Equals(this) && (((((ChessWordBase) ChessWordBase.All[n]).X == 5) && (((ChessWordBase) ChessWordBase.All[n]).Y == 2)) && ((ChessWordBase) ChessWordBase.All[n]).IsRedChess))
                    {
                        flag8 = true;
                    }
                }
                if (!flag8)
                {
                    int[] numArray8 = new int[] { 5, 2 };
                    list.Add(numArray8);
                }
            }
            return list;
        }

       
        public override void Init()
        {
            base.Init();
            base.Name = Jpg.RedShi;
            base.IsAttack = false;
        }

        public override void Init(int QZ_X, int QZ_Y)
        {
            base.Init(QZ_X, QZ_Y);
            base.Name = Jpg.RedShi;
            base.IsAttack = false;
        }

    }
}