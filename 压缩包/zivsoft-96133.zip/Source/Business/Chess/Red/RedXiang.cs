﻿using System;
using System.Collections;
using Zivsoft.Business.Chess;
using Zivsoft.Business.Chess.Board;

namespace Zivsoft.Business.Chess.Red
{
    internal class RedXiang : RedChessBase, IChess
    {
        public override bool Check(int X, int Y, ArrayList al)
        {
            if (base.Check())
            {
                for (int i = 0; i < al.Count; i++)
                {
                    if ((((int[]) al[i])[0] == X) && (((int[]) al[i])[1] == Y))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public override ArrayList GetNextLocation()
        {
            ArrayList list = new ArrayList();
            if ((base.X == 3) && (base.Y == 1))
            {
                bool flag = false;
                bool flag2 = false;
                for (int i = 0; i < ChessWordBase.All.Count; i++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[i]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[i]).X == 2) && (((ChessWordBase) ChessWordBase.All[i]).Y == 2))
                        {
                            flag = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[i]).X == 4) && (((ChessWordBase) ChessWordBase.All[i]).Y == 2))
                        {
                            flag2 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[i]).X == 1) && (((ChessWordBase)ChessWordBase.All[i]).Y == 3)) && ((ChessWordBase)ChessWordBase.All[i]).IsRedChess)
                        {
                            flag = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[i]).X == 5) && (((ChessWordBase)ChessWordBase.All[i]).Y == 3)) && ((ChessWordBase)ChessWordBase.All[i]).IsRedChess)
                        {
                            flag2 = true;
                        }
                    }
                }
                if (!flag)
                {
                    int[] numArray = new int[] { 1, 3 };
                    list.Add(numArray);
                }
                if (!flag2)
                {
                    int[] numArray2 = new int[] { 5, 3 };
                    list.Add(numArray2);
                }
                return list;
            }
            if ((base.X == 1) && (base.Y == 3))
            {
                bool flag3 = false;
                bool flag4 = false;
                for (int j = 0; j < ChessWordBase.All.Count; j++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[j]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[j]).X == 2) && (((ChessWordBase) ChessWordBase.All[j]).Y == 2))
                        {
                            flag3 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[j]).X == 2) && (((ChessWordBase) ChessWordBase.All[j]).Y == 4))
                        {
                            flag4 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[j]).X == 3) && (((ChessWordBase)ChessWordBase.All[j]).Y == 1)) && ((ChessWordBase)ChessWordBase.All[j]).IsRedChess)
                        {
                            flag3 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[j]).X == 3) && (((ChessWordBase)ChessWordBase.All[j]).Y == 5)) && ((ChessWordBase)ChessWordBase.All[j]).IsRedChess)
                        {
                            flag4 = true;
                        }
                    }
                }
                if (!flag3)
                {
                    int[] numArray3 = new int[] { 3, 1 };
                    list.Add(numArray3);
                }
                if (!flag4)
                {
                    int[] numArray4 = new int[] { 3, 5 };
                    list.Add(numArray4);
                }
                return list;
            }
            if ((base.X == 3) && (base.Y == 5))
            {
                bool flag5 = false;
                bool flag6 = false;
                for (int k = 0; k < ChessWordBase.All.Count; k++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[k]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[k]).X == 2) && (((ChessWordBase) ChessWordBase.All[k]).Y == 4))
                        {
                            flag5 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[k]).X == 4) && (((ChessWordBase) ChessWordBase.All[k]).Y == 4))
                        {
                            flag6 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[k]).X == 1) && (((ChessWordBase)ChessWordBase.All[k]).Y == 3)) && ((ChessWordBase)ChessWordBase.All[k]).IsRedChess)
                        {
                            flag5 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[k]).X == 5) && (((ChessWordBase)ChessWordBase.All[k]).Y == 3)) && ((ChessWordBase)ChessWordBase.All[k]).IsRedChess)
                        {
                            flag6 = true;
                        }
                    }
                }
                if (!flag5)
                {
                    int[] numArray5 = new int[] { 1, 3 };
                    list.Add(numArray5);
                }
                if (!flag6)
                {
                    int[] numArray6 = new int[] { 5, 3 };
                    list.Add(numArray6);
                }
                return list;
            }
            if ((base.X == 5) && (base.Y == 3))
            {
                bool flag7 = false;
                bool flag8 = false;
                bool flag9 = false;
                bool flag10 = false;
                for (int m = 0; m < ChessWordBase.All.Count; m++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[m]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[m]).X == 4) && (((ChessWordBase) ChessWordBase.All[m]).Y == 2))
                        {
                            flag7 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[m]).X == 4) && (((ChessWordBase) ChessWordBase.All[m]).Y == 4))
                        {
                            flag8 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[m]).X == 6) && (((ChessWordBase) ChessWordBase.All[m]).Y == 2))
                        {
                            flag9 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[m]).X == 6) && (((ChessWordBase) ChessWordBase.All[m]).Y == 4))
                        {
                            flag10 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[m]).X == 3) && (((ChessWordBase)ChessWordBase.All[m]).Y == 1)) && ((ChessWordBase)ChessWordBase.All[m]).IsRedChess)
                        {
                            flag7 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[m]).X == 3) && (((ChessWordBase)ChessWordBase.All[m]).Y == 5)) && ((ChessWordBase)ChessWordBase.All[m]).IsRedChess)
                        {
                            flag8 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[m]).X == 7) && (((ChessWordBase)ChessWordBase.All[m]).Y == 1)) && ((ChessWordBase)ChessWordBase.All[m]).IsRedChess)
                        {
                            flag9 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[m]).X == 7) && (((ChessWordBase)ChessWordBase.All[m]).Y == 5)) && ((ChessWordBase)ChessWordBase.All[m]).IsRedChess)
                        {
                            flag10 = true;
                        }
                    }
                }
                if (!flag7)
                {
                    int[] numArray7 = new int[] { 3, 1 };
                    list.Add(numArray7);
                }
                if (!flag8)
                {
                    int[] numArray8 = new int[] { 3, 5 };
                    list.Add(numArray8);
                }
                if (!flag9)
                {
                    int[] numArray9 = new int[] { 7, 1 };
                    list.Add(numArray9);
                }
                if (!flag10)
                {
                    int[] numArray10 = new int[] { 7, 5 };
                    list.Add(numArray10);
                }
                return list;
            }
            if ((base.X == 7) && (base.Y == 1))
            {
                bool flag11 = false;
                bool flag12 = false;
                for (int n = 0; n < ChessWordBase.All.Count; n++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[n]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[n]).X == 6) && (((ChessWordBase) ChessWordBase.All[n]).Y == 2))
                        {
                            flag11 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[n]).X == 8) && (((ChessWordBase) ChessWordBase.All[n]).Y == 2))
                        {
                            flag12 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[n]).X == 5) && (((ChessWordBase)ChessWordBase.All[n]).Y == 3)) && ((ChessWordBase)ChessWordBase.All[n]).IsRedChess)
                        {
                            flag11 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[n]).X == 9) && (((ChessWordBase)ChessWordBase.All[n]).Y == 3)) && ((ChessWordBase)ChessWordBase.All[n]).IsRedChess)
                        {
                            flag12 = true;
                        }
                    }
                }
                if (!flag11)
                {
                    int[] numArray11 = new int[] { 5, 3 };
                    list.Add(numArray11);
                }
                if (!flag12)
                {
                    int[] numArray12 = new int[] { 9, 3 };
                    list.Add(numArray12);
                }
                return list;
            }
            if ((base.X == 7) && (base.Y == 5))
            {
                bool flag13 = false;
                bool flag14 = false;
                for (int num6 = 0; num6 < ChessWordBase.All.Count; num6++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[num6]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[num6]).X == 6) && (((ChessWordBase) ChessWordBase.All[num6]).Y == 4))
                        {
                            flag13 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[num6]).X == 8) && (((ChessWordBase) ChessWordBase.All[num6]).Y == 4))
                        {
                            flag14 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[num6]).X == 5) && (((ChessWordBase)ChessWordBase.All[num6]).Y == 3)) && ((ChessWordBase)ChessWordBase.All[num6]).IsRedChess)
                        {
                            flag13 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[num6]).X == 9) && (((ChessWordBase)ChessWordBase.All[num6]).Y == 3)) && ((ChessWordBase)ChessWordBase.All[num6]).IsRedChess)
                        {
                            flag14 = true;
                        }
                    }
                }
                if (!flag13)
                {
                    int[] numArray13 = new int[] { 5, 3 };
                    list.Add(numArray13);
                }
                if (!flag14)
                {
                    int[] numArray14 = new int[] { 9, 3 };
                    list.Add(numArray14);
                }
                return list;
            }
            if ((base.X == 9) && (base.Y == 3))
            {
                bool flag15 = false;
                bool flag16 = false;
                for (int num7 = 0; num7 < ChessWordBase.All.Count; num7++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[num7]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[num7]).X == 8) && (((ChessWordBase) ChessWordBase.All[num7]).Y == 2))
                        {
                            flag15 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[num7]).X == 8) && (((ChessWordBase) ChessWordBase.All[num7]).Y == 4))
                        {
                            flag16 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[num7]).X == 7) && (((ChessWordBase)ChessWordBase.All[num7]).Y == 1)) && ((ChessWordBase)ChessWordBase.All[num7]).IsRedChess)
                        {
                            flag15 = true;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[num7]).X == 7) && (((ChessWordBase)ChessWordBase.All[num7]).Y == 5)) && ((ChessWordBase)ChessWordBase.All[num7]).IsRedChess)
                        {
                            flag16 = true;
                        }
                    }
                }
                if (!flag15)
                {
                    int[] numArray15 = new int[] { 7, 1 };
                    list.Add(numArray15);
                }
                if (!flag16)
                {
                    int[] numArray16 = new int[] { 7, 5 };
                    list.Add(numArray16);
                }
            }
            return list;
        }


        public void Init()
        {
            base.Init();
            base.Name = Jpg.RedXiang;
            base.IsAttack = false;
        }

        public void Init(int QZ_X, int QZ_Y)
        {
            base.Init(QZ_X, QZ_Y);
            base.Name = Jpg.RedXiang;
            base.IsAttack = false;
        }


    }
}