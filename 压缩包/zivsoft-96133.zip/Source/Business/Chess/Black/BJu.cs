﻿using System.Collections;
using Zivsoft.Business.Chess;
using Zivsoft.Business.Chess.Board;

namespace Zivsoft.Business.Chess.Black
{
    internal class BJu : BlackChessBase, IChess
    {
        public override bool Check(int X, int Y, ArrayList al)
        {
            if (base.Check())
            {
                for (int i = 0; i < al.Count; i++)
                {
                    if ((((int[]) al[i])[0] == X) && (((int[]) al[i])[1] == Y))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

 
        public override ArrayList GetNextLocation()
        {
            ArrayList list = new ArrayList();
            if (base.Y != 10)
            {
                for (int i = base.Y + 1; i <= 10; i++)
                {
                    int[] numArray = new int[2];
                    numArray[0] = base.X;
                    bool flag = false;
                    for (int j = 0; j < ChessWordBase.All.Count; j++)
                    {
                        if (!((ChessWordBase) ChessWordBase.All[j]).Equals(this) && ((((ChessWordBase) ChessWordBase.All[j]).X == base.X) && (((ChessWordBase) ChessWordBase.All[j]).Y == i)))
                        {
                            if (((ChessWordBase)ChessWordBase.All[j]).IsRedChess)
                            {
                                numArray[1] = i;
                                list.Add(numArray);
                            }
                            flag = true;
                            break;
                        }
                    }
                    if (flag)
                    {
                        break;
                    }
                    numArray[1] = i;
                    list.Add(numArray);
                }
            }
            if (base.Y != 1)
            {
                for (int k = base.Y - 1; k >= 1; k--)
                {
                    int[] numArray2 = new int[2];
                    numArray2[0] = base.X;
                    bool flag2 = false;
                    for (int m = 0; m < ChessWordBase.All.Count; m++)
                    {
                        if (!((ChessWordBase) ChessWordBase.All[m]).Equals(this) && ((((ChessWordBase) ChessWordBase.All[m]).X == base.X) && (((ChessWordBase) ChessWordBase.All[m]).Y == k)))
                        {
                            if (((ChessWordBase)ChessWordBase.All[m]).IsRedChess)
                            {
                                numArray2[1] = k;
                                list.Add(numArray2);
                            }
                            flag2 = true;
                            break;
                        }
                    }
                    if (flag2)
                    {
                        break;
                    }
                    numArray2[1] = k;
                    list.Add(numArray2);
                }
            }
            if (base.X != 9)
            {
                for (int n = base.X + 1; n <= 9; n++)
                {
                    int[] numArray3 = new int[2];
                    numArray3[1] = base.Y;
                    bool flag3 = false;
                    for (int num6 = 0; num6 < ChessWordBase.All.Count; num6++)
                    {
                        if (!((ChessWordBase) ChessWordBase.All[num6]).Equals(this) && ((((ChessWordBase) ChessWordBase.All[num6]).Y == base.Y) && (((ChessWordBase) ChessWordBase.All[num6]).X == n)))
                        {
                            if (((ChessWordBase)ChessWordBase.All[num6]).IsRedChess)
                            {
                                numArray3[0] = n;
                                list.Add(numArray3);
                            }
                            flag3 = true;
                            break;
                        }
                    }
                    if (flag3)
                    {
                        break;
                    }
                    numArray3[0] = n;
                    list.Add(numArray3);
                }
            }
            if (base.X != 1)
            {
                for (int num7 = base.X - 1; num7 >= 1; num7--)
                {
                    int[] numArray4 = new int[2];
                    numArray4[1] = base.Y;
                    bool flag4 = false;
                    for (int num8 = 0; num8 < ChessWordBase.All.Count; num8++)
                    {
                        if (!((ChessWordBase) ChessWordBase.All[num8]).Equals(this) && ((((ChessWordBase) ChessWordBase.All[num8]).Y == base.Y) && (((ChessWordBase) ChessWordBase.All[num8]).X == num7)))
                        {
                            if (((ChessWordBase)ChessWordBase.All[num8]).IsRedChess)
                            {
                                numArray4[0] = num7;
                                list.Add(numArray4);
                            }
                            flag4 = true;
                            break;
                        }
                    }
                    if (flag4)
                    {
                        return list;
                    }
                    numArray4[0] = num7;
                    list.Add(numArray4);
                }
            }
            return list;
        }

       
        public void Init()
        {
            base.Init();
            base.Name = Jpg.BlackJu;
            base.IsAttack = true;
        }

        public void Init(int QZ_X, int QZ_Y)
        {
            base.Init(QZ_X, QZ_Y);
            base.Name = Jpg.BlackJu;
            base.IsAttack = true;
        }

    }
}