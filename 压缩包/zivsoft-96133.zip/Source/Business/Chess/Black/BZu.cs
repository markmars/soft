﻿using System.Collections;
using Zivsoft.Business.Chess;
using Zivsoft.Business.Chess.Board;

namespace Zivsoft.Business.Chess.Black
{
    internal class BZu : BlackChessBase, IChess
    {
        public override bool Check(int X, int Y, ArrayList al)
        {
            if (base.Check())
            {
                for (int i = 0; i < al.Count; i++)
                {
                    if ((((int[]) al[i])[0] == X) && (((int[]) al[i])[1] == Y))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public override ArrayList GetNextLocation()
        {
            var list = new ArrayList();
            if ((base.Y != 7) && (base.Y != 6))
            {
                if (base.Y < 6)
                {
                    bool flag2 = false;
                    bool flag3 = false;
                    bool flag4 = false;
                    for (int j = 0; j < ChessWordBase.All.Count; j++)
                    {
                        if (!((ChessWordBase)ChessWordBase.All[j]).Equals(this) && !((ChessWordBase)ChessWordBase.All[j]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[j]).X == base.X) && (((ChessWordBase) ChessWordBase.All[j]).Y == (base.Y - 1)))
                            {
                                flag2 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[j]).Y == base.Y) && (((ChessWordBase) ChessWordBase.All[j]).X == (base.X + 1)))
                            {
                                flag3 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[j]).Y == base.Y) && (((ChessWordBase) ChessWordBase.All[j]).X == (base.X - 1)))
                            {
                                flag4 = true;
                            }
                        }
                    }
                    if (!flag2)
                    {
                        int[] numArray2 = new int[] { base.X, base.Y - 1 };
                        list.Add(numArray2);
                    }
                    if (!flag3 && (base.X != 9))
                    {
                        int[] numArray3 = new int[] { base.X + 1, base.Y };
                        list.Add(numArray3);
                    }
                    if (!flag4 && (base.X != 1))
                    {
                        int[] numArray4 = new int[] { base.X - 1, base.Y };
                        list.Add(numArray4);
                    }
                }
                return list;
            }
            bool flag = false;
            for (int i = 0; i < ChessWordBase.All.Count; i++)
            {
                if (!((ChessWordBase)ChessWordBase.All[i]).Equals(this) && ((!((ChessWordBase)ChessWordBase.All[i]).IsRedChess && (((ChessWordBase)ChessWordBase.All[i]).X == base.X)) && (((ChessWordBase)ChessWordBase.All[i]).Y == (base.Y - 1))))
                {
                    flag = true;
                    break;
                }
            }
            if (!flag)
            {
                int[] numArray = new int[] { base.X, base.Y - 1 };
                list.Add(numArray);
            }
            return list;
        }

        
        public void Init()
        {
            base.Init();
            base.Name = Jpg.BlackZu;
            base.IsAttack = true;
        }

        public void Init(int QZ_X, int QZ_Y)
        {
            base.Init(QZ_X, QZ_Y);
            base.Name = Jpg.BlackZu;
            base.IsAttack = true;
        }




    }
}