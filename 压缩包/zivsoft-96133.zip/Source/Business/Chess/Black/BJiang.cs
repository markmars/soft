﻿using System.Collections;
using Zivsoft.Business.Chess;
using Zivsoft.Business.Chess.Board;
using System.Windows.Forms;

namespace Zivsoft.Business.Chess.Black
{
    internal  class BJiang : BlackChessBase
    {
        public override bool Check(int X, int Y, ArrayList al)
        {
            if (base.Check())
            {
                for (int i = 0; i < al.Count; i++)
                {
                    if ((((int[]) al[i])[0] == X) && (((int[]) al[i])[1] == Y))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public override ArrayList GetNextLocation()
        {
            ArrayList list = new ArrayList();
            if (((base.X == 4) || (base.X == 6)) || ((base.Y == 10) || (base.Y == 8)))
            {
                if ((base.X == 4) && (base.Y == 10))
                {
                    bool flag = false;
                    bool flag2 = false;
                    for (int i = 0; i < ChessWordBase.All.Count; i++)
                    {
                        if (!((ChessWordBase) ChessWordBase.All[i]).Equals(this) && !((ChessWordBase) ChessWordBase.All[i]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[i]).X == 4) && (((ChessWordBase) ChessWordBase.All[i]).Y == 9))
                            {
                                flag = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[i]).X == 5) && (((ChessWordBase) ChessWordBase.All[i]).Y == 10))
                            {
                                flag2 = true;
                            }
                        }
                    }
                    if (!flag)
                    {
                        int[] numArray = new int[] { 4, 9 };
                        list.Add(numArray);
                    }
                    if (!flag2)
                    {
                        int[] numArray2 = new int[] { 5, 10 };
                        list.Add(numArray2);
                    }
                    return list;
                }
                if ((base.X == 6) && (base.Y == 10))
                {
                    bool flag3 = false;
                    bool flag4 = false;
                    for (int j = 0; j < ChessWordBase.All.Count; j++)
                    {
                        if (!((ChessWordBase)ChessWordBase.All[j]).Equals(this) && !((ChessWordBase)ChessWordBase.All[j]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[j]).X == 5) && (((ChessWordBase) ChessWordBase.All[j]).Y == 10))
                            {
                                flag3 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[j]).X == 6) && (((ChessWordBase) ChessWordBase.All[j]).Y == 9))
                            {
                                flag4 = true;
                            }
                        }
                    }
                    if (!flag3)
                    {
                        int[] numArray3 = new int[] { 5, 10 };
                        list.Add(numArray3);
                    }
                    if (!flag4)
                    {
                        int[] numArray4 = new int[] { 6, 9 };
                        list.Add(numArray4);
                    }
                    return list;
                }
                if ((base.X == 6) && (base.Y == 8))
                {
                    bool flag5 = false;
                    bool flag6 = false;
                    for (int k = 0; k < ChessWordBase.All.Count; k++)
                    {
                        if (!((ChessWordBase)ChessWordBase.All[k]).Equals(this) && !((ChessWordBase)ChessWordBase.All[k]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[k]).X == 6) && (((ChessWordBase) ChessWordBase.All[k]).Y == 9))
                            {
                                flag5 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[k]).X == 5) && (((ChessWordBase) ChessWordBase.All[k]).Y == 8))
                            {
                                flag6 = true;
                            }
                        }
                    }
                    if (!flag5)
                    {
                        int[] numArray5 = new int[] { 6, 9 };
                        list.Add(numArray5);
                    }
                    if (!flag6)
                    {
                        int[] numArray6 = new int[] { 5, 8 };
                        list.Add(numArray6);
                    }
                    return list;
                }
                if ((base.X == 4) && (base.Y == 8))
                {
                    bool flag7 = false;
                    bool flag8 = false;
                    for (int m = 0; m < ChessWordBase.All.Count; m++)
                    {
                        if (!((ChessWordBase)ChessWordBase.All[m]).Equals(this) && !((ChessWordBase)ChessWordBase.All[m]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[m]).X == 4) && (((ChessWordBase) ChessWordBase.All[m]).Y == 9))
                            {
                                flag7 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[m]).X == 5) && (((ChessWordBase) ChessWordBase.All[m]).Y == 8))
                            {
                                flag8 = true;
                            }
                        }
                    }
                    if (!flag7)
                    {
                        int[] numArray7 = new int[] { 4, 9 };
                        list.Add(numArray7);
                    }
                    if (!flag8)
                    {
                        int[] numArray8 = new int[] { 5, 8 };
                        list.Add(numArray8);
                    }
                    return list;
                }
                if ((base.X == 4) && (base.Y == 9))
                {
                    bool flag9 = false;
                    bool flag10 = false;
                    bool flag11 = false;
                    for (int n = 0; n < ChessWordBase.All.Count; n++)
                    {
                        if (!((ChessWordBase)ChessWordBase.All[n]).Equals(this) && !((ChessWordBase)ChessWordBase.All[n]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[n]).X == 4) && (((ChessWordBase) ChessWordBase.All[n]).Y == 10))
                            {
                                flag9 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[n]).X == 4) && (((ChessWordBase) ChessWordBase.All[n]).Y == 8))
                            {
                                flag10 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[n]).X == 5) && (((ChessWordBase) ChessWordBase.All[n]).Y == 9))
                            {
                                flag11 = true;
                            }
                        }
                    }
                    if (!flag9)
                    {
                        int[] numArray9 = new int[] { 4, 10 };
                        list.Add(numArray9);
                    }
                    if (!flag10)
                    {
                        int[] numArray10 = new int[] { 4, 8 };
                        list.Add(numArray10);
                    }
                    if (!flag11)
                    {
                        int[] numArray11 = new int[] { 5, 9 };
                        list.Add(numArray11);
                    }
                    return list;
                }
                if ((base.X == 5) && (base.Y == 8))
                {
                    bool flag12 = false;
                    bool flag13 = false;
                    bool flag14 = false;
                    for (int num6 = 0; num6 < ChessWordBase.All.Count; num6++)
                    {
                        if (!((ChessWordBase)ChessWordBase.All[num6]).Equals(this) && !((ChessWordBase)ChessWordBase.All[num6]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[num6]).X == 4) && (((ChessWordBase) ChessWordBase.All[num6]).Y == 8))
                            {
                                flag12 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[num6]).X == 6) && (((ChessWordBase) ChessWordBase.All[num6]).Y == 8))
                            {
                                flag13 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[num6]).X == 5) && (((ChessWordBase) ChessWordBase.All[num6]).Y == 9))
                            {
                                flag14 = true;
                            }
                        }
                    }
                    if (!flag12)
                    {
                        int[] numArray12 = new int[] { 4, 8 };
                        list.Add(numArray12);
                    }
                    if (!flag13)
                    {
                        int[] numArray13 = new int[] { 6, 8 };
                        list.Add(numArray13);
                    }
                    if (!flag14)
                    {
                        int[] numArray14 = new int[] { 5, 9 };
                        list.Add(numArray14);
                    }
                    return list;
                }
                if ((base.X == 6) && (base.Y == 9))
                {
                    bool flag15 = false;
                    bool flag16 = false;
                    bool flag17 = false;
                    for (int num7 = 0; num7 < ChessWordBase.All.Count; num7++)
                    {
                        if (!((ChessWordBase)ChessWordBase.All[num7]).Equals(this) && !((ChessWordBase)ChessWordBase.All[num7]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[num7]).X == 6) && (((ChessWordBase) ChessWordBase.All[num7]).Y == 10))
                            {
                                flag15 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[num7]).X == 6) && (((ChessWordBase) ChessWordBase.All[num7]).Y == 8))
                            {
                                flag16 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[num7]).X == 5) && (((ChessWordBase) ChessWordBase.All[num7]).Y == 9))
                            {
                                flag17 = true;
                            }
                        }
                    }
                    if (!flag15)
                    {
                        int[] numArray15 = new int[] { 6, 10 };
                        list.Add(numArray15);
                    }
                    if (!flag16)
                    {
                        int[] numArray16 = new int[] { 6, 8 };
                        list.Add(numArray16);
                    }
                    if (!flag17)
                    {
                        int[] numArray17 = new int[] { 5, 9 };
                        list.Add(numArray17);
                    }
                    return list;
                }
                if ((base.X == 5) && (base.Y == 10))
                {
                    bool flag18 = false;
                    bool flag19 = false;
                    bool flag20 = false;
                    for (int num8 = 0; num8 < ChessWordBase.All.Count; num8++)
                    {
                        if (!((ChessWordBase)ChessWordBase.All[num8]).Equals(this) && !((ChessWordBase)ChessWordBase.All[num8]).IsRedChess)
                        {
                            if ((((ChessWordBase) ChessWordBase.All[num8]).X == 4) && (((ChessWordBase) ChessWordBase.All[num8]).Y == 10))
                            {
                                flag18 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[num8]).X == 6) && (((ChessWordBase) ChessWordBase.All[num8]).Y == 10))
                            {
                                flag19 = true;
                            }
                            if ((((ChessWordBase) ChessWordBase.All[num8]).X == 5) && (((ChessWordBase) ChessWordBase.All[num8]).Y == 9))
                            {
                                flag20 = true;
                            }
                        }
                    }
                    if (!flag18)
                    {
                        int[] numArray18 = new int[] { 4, 10 };
                        list.Add(numArray18);
                    }
                    if (!flag19)
                    {
                        int[] numArray19 = new int[] { 6, 10 };
                        list.Add(numArray19);
                    }
                    if (!flag20)
                    {
                        int[] numArray20 = new int[] { 5, 9 };
                        list.Add(numArray20);
                    }
                    return list;
                }
            }
            if ((base.X == 5) && (base.Y == 9))
            {
                bool flag21 = false;
                bool flag22 = false;
                bool flag23 = false;
                bool flag24 = false;
                for (int num9 = 0; num9 < ChessWordBase.All.Count; num9++)
                {
                    if (!((ChessWordBase)ChessWordBase.All[num9]).Equals(this) && !((ChessWordBase)ChessWordBase.All[num9]).IsRedChess)
                    {
                        if ((((ChessWordBase) ChessWordBase.All[num9]).X == 4) && (((ChessWordBase) ChessWordBase.All[num9]).Y == 9))
                        {
                            flag21 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[num9]).X == 6) && (((ChessWordBase) ChessWordBase.All[num9]).Y == 9))
                        {
                            flag22 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[num9]).X == 5) && (((ChessWordBase) ChessWordBase.All[num9]).Y == 10))
                        {
                            flag23 = true;
                        }
                        if ((((ChessWordBase) ChessWordBase.All[num9]).X == 5) && (((ChessWordBase) ChessWordBase.All[num9]).Y == 8))
                        {
                            flag24 = true;
                        }
                    }
                }
                if (!flag21)
                {
                    int[] numArray21 = new int[] { 4, 9 };
                    list.Add(numArray21);
                }
                if (!flag22)
                {
                    int[] numArray22 = new int[] { 6, 9 };
                    list.Add(numArray22);
                }
                if (!flag23)
                {
                    int[] numArray23 = new int[] { 5, 10 };
                    list.Add(numArray23);
                }
                if (!flag24)
                {
                    int[] numArray24 = new int[] { 5, 8 };
                    list.Add(numArray24);
                }
            }
            return list;
        }

        public override void Destroy()
        {
            base.Destroy();
            MessageBox.Show("红方胜");
        }

        public void Init()
        {
            base.Init();
            base.Name = Jpg.Jiang;
            base.IsAttack = false;
        }

        public void Init(int QZ_X, int QZ_Y)
        {
            base.Init(QZ_X, QZ_Y);
            base.Name = Jpg.Jiang;
            base.IsAttack = false;
        }


    }
}