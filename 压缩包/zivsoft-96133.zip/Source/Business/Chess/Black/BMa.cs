﻿using System.Collections;
using Zivsoft.Business.Chess;
using Zivsoft.Business.Chess.Board;

namespace Zivsoft.Business.Chess.Black
{
    internal class BMa : BlackChessBase, IChess
    {
        public override bool Check(int X, int Y, ArrayList al)
        {
            if (base.Check())
            {
                for (int i = 0; i < al.Count; i++)
                {
                    if ((((int[]) al[i])[0] == X) && (((int[]) al[i])[1] == Y))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public override ArrayList GetNextLocation()
        {
            ArrayList list = new ArrayList();
            if ((base.Y < 9) && (base.X > 1))
            {
                bool flag = false;
                for (int i = 0; i < ChessWordBase.All.Count; i++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[i]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[i]).X == base.X) && (((ChessWordBase) ChessWordBase.All[i]).Y == (base.Y + 1)))
                        {
                            flag = true;
                            break;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[i]).X == (base.X - 1)) && (((ChessWordBase)ChessWordBase.All[i]).Y == (base.Y + 2))) && !((ChessWordBase)ChessWordBase.All[i]).IsRedChess)
                        {
                            flag = true;
                            break;
                        }
                    }
                }
                if (!flag)
                {
                    int[] numArray = new int[] { base.X - 1, base.Y + 2 };
                    list.Add(numArray);
                }
            }
            if ((base.Y < 9) && (base.X < 9))
            {
                bool flag2 = false;
                for (int j = 0; j < ChessWordBase.All.Count; j++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[j]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[j]).X == base.X) && (((ChessWordBase) ChessWordBase.All[j]).Y == (base.Y + 1)))
                        {
                            flag2 = true;
                            break;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[j]).X == (base.X + 1)) && (((ChessWordBase)ChessWordBase.All[j]).Y == (base.Y + 2))) && !((ChessWordBase)ChessWordBase.All[j]).IsRedChess)
                        {
                            flag2 = true;
                            break;
                        }
                    }
                }
                if (!flag2)
                {
                    int[] numArray2 = new int[] { base.X + 1, base.Y + 2 };
                    list.Add(numArray2);
                }
            }
            if ((base.Y > 2) && (base.X > 2))
            {
                bool flag3 = false;
                for (int k = 0; k < ChessWordBase.All.Count; k++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[k]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[k]).X == base.X) && (((ChessWordBase) ChessWordBase.All[k]).Y == (base.Y - 1)))
                        {
                            flag3 = true;
                            break;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[k]).X == (base.X - 1)) && (((ChessWordBase)ChessWordBase.All[k]).Y == (base.Y - 2))) && !((ChessWordBase)ChessWordBase.All[k]).IsRedChess)
                        {
                            flag3 = true;
                            break;
                        }
                    }
                }
                if (!flag3)
                {
                    int[] numArray3 = new int[] { base.X - 1, base.Y - 2 };
                    list.Add(numArray3);
                }
            }
            if ((base.Y > 2) && (base.X < 9))
            {
                bool flag4 = false;
                for (int m = 0; m < ChessWordBase.All.Count; m++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[m]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[m]).X == base.X) && (((ChessWordBase) ChessWordBase.All[m]).Y == (base.Y - 1)))
                        {
                            flag4 = true;
                            break;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[m]).X == (base.X + 1)) && (((ChessWordBase)ChessWordBase.All[m]).Y == (base.Y - 2))) && !((ChessWordBase)ChessWordBase.All[m]).IsRedChess)
                        {
                            flag4 = true;
                            break;
                        }
                    }
                }
                if (!flag4)
                {
                    int[] numArray4 = new int[] { base.X + 1, base.Y - 2 };
                    list.Add(numArray4);
                }
            }
            if ((base.Y < 10) && (base.X > 2))
            {
                bool flag5 = false;
                for (int n = 0; n < ChessWordBase.All.Count; n++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[n]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[n]).X == (base.X - 1)) && (((ChessWordBase) ChessWordBase.All[n]).Y == base.Y))
                        {
                            flag5 = true;
                            break;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[n]).X == (base.X - 2)) && (((ChessWordBase)ChessWordBase.All[n]).Y == (base.Y + 1))) && !((ChessWordBase)ChessWordBase.All[n]).IsRedChess)
                        {
                            flag5 = true;
                            break;
                        }
                    }
                }
                if (!flag5)
                {
                    int[] numArray5 = new int[] { base.X - 2, base.Y + 1 };
                    list.Add(numArray5);
                }
            }
            if ((base.Y > 1) && (base.X > 2))
            {
                bool flag6 = false;
                for (int num6 = 0; num6 < ChessWordBase.All.Count; num6++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[num6]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[num6]).X == (base.X - 1)) && (((ChessWordBase) ChessWordBase.All[num6]).Y == base.Y))
                        {
                            flag6 = true;
                            break;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[num6]).X == (base.X - 2)) && (((ChessWordBase)ChessWordBase.All[num6]).Y == (base.Y - 1))) && !((ChessWordBase)ChessWordBase.All[num6]).IsRedChess)
                        {
                            flag6 = true;
                            break;
                        }
                    }
                }
                if (!flag6)
                {
                    int[] numArray6 = new int[] { base.X - 2, base.Y - 1 };
                    list.Add(numArray6);
                }
            }
            if ((base.Y < 10) && (base.X < 8))
            {
                bool flag7 = false;
                for (int num7 = 0; num7 < ChessWordBase.All.Count; num7++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[num7]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[num7]).X == (base.X + 1)) && (((ChessWordBase) ChessWordBase.All[num7]).Y == base.Y))
                        {
                            flag7 = true;
                            break;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[num7]).X == (base.X + 2)) && (((ChessWordBase)ChessWordBase.All[num7]).Y == (base.Y + 1))) && !((ChessWordBase)ChessWordBase.All[num7]).IsRedChess)
                        {
                            flag7 = true;
                            break;
                        }
                    }
                }
                if (!flag7)
                {
                    int[] numArray7 = new int[] { base.X + 2, base.Y + 1 };
                    list.Add(numArray7);
                }
            }
            if ((base.Y > 1) && (base.X < 8))
            {
                bool flag8 = false;
                for (int num8 = 0; num8 < ChessWordBase.All.Count; num8++)
                {
                    if (!((ChessWordBase) ChessWordBase.All[num8]).Equals(this))
                    {
                        if ((((ChessWordBase) ChessWordBase.All[num8]).X == (base.X + 1)) && (((ChessWordBase) ChessWordBase.All[num8]).Y == base.Y))
                        {
                            flag8 = true;
                            break;
                        }
                        if (((((ChessWordBase)ChessWordBase.All[num8]).X == (base.X + 2)) && (((ChessWordBase)ChessWordBase.All[num8]).Y == (base.Y - 1))) && !((ChessWordBase)ChessWordBase.All[num8]).IsRedChess)
                        {
                            flag8 = true;
                            break;
                        }
                    }
                }
                if (!flag8)
                {
                    int[] numArray8 = new int[] { base.X + 2, base.Y - 1 };
                    list.Add(numArray8);
                }
            }
            return list;
        }

        

        public void Init()
        {
            base.Init();
            base.Name = Jpg.BlackMa;
            base.IsAttack = true;
        }

        public void Init(int QZ_X, int QZ_Y)
        {
            base.Init(QZ_X, QZ_Y);
            base.Name = Jpg.BlackMa;
            base.IsAttack = true;
        }


    }
}