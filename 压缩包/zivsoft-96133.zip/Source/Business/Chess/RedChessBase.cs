﻿using System;
using System.Windows.Forms;
using System.Collections;

namespace Zivsoft.Business.Chess
{
    internal abstract class RedChessBase : ChessWordBase
    {
        public override bool Check()
        {
            if (!base.Check())
            {
                return false;
            }
            if (!base.IsAttack && (base.Y > 5))
            {
                return false;
            }
            for (int i = 0; i < ChessWordBase.All.Count; i++)
            {
                if (((((ChessWordBase) ChessWordBase.All[i]).IsRedChess
                      && !((ChessWordBase) ChessWordBase.All[i]).Equals(this)) 
                     && (((ChessWordBase) ChessWordBase.All[i]).IsDogFall
                         && (((ChessWordBase) ChessWordBase.All[i]).X == base.X)))
                    && (((ChessWordBase) ChessWordBase.All[i]).Y == base.Y))
                {
                    return false;
                }
            }
            return true;
        }

        public override void Init()
        {
            base.Init();
            base.Name = "红棋";
            base.IsRedChess = true;
        }

        public virtual void Init(int ix, int iy)
        {
            base.Init();
            base.Name = "红棋";
            base.X = ix;
            base.Y = iy;
            base.IsRedChess = true;
        }
    }
}