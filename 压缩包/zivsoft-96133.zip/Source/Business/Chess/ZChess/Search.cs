﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.Business.Chess.ZChess
{
    class Search
    {
        // 其他常数
        const int MAX_GEN_MOVES = 128; // 最大的生成走法数
        const int MAX_MOVES = 256;     // 最大的历史走法数
        const int LIMIT_DEPTH = 64;    // 最大的搜索深度
        const int MATE_VALUE = 10000;  // 最高分值，即将死的分值
        const int BAN_VALUE = MATE_VALUE - 100; // 长将判负的分值，低于该值将不写入置换表
        const int WIN_VALUE = MATE_VALUE - 200; // 搜索出胜负的分值界限，超出此值就说明已经搜索出杀棋了
        const int DRAW_VALUE = 20;     // 和棋时返回的分数(取负值)
        const int ADVANCED_VALUE = 3;  // 先行权分值
        const int RANDOM_MASK = 7;     // 随机性分值
        const int NULL_MARGIN = 400;   // 空步裁剪的子力边界
        const int NULL_DEPTH = 2;      // 空步裁剪的裁剪深度
        const int HASH_SIZE = 1 << 20; // 置换表大小
        const int HASH_ALPHA = 1;      // ALPHA节点的置换表项
        const int HASH_BETA = 2;       // BETA节点的置换表项
        const int HASH_PV = 3;         // PV节点的置换表项
        const int BOOK_SIZE = 16384;   // 开局库大小

        int mvResult;                  // 电脑走的棋
        int[] nHistoryTable = new int[65536];      // 历史表
        public static int[,] mvKillers = new int[LIMIT_DEPTH, 2]; // 杀手走法表
        HashItem[] HashTable = new HashItem[HASH_SIZE]; // 置换表
        int nBookSize;                 // 开局库大小
        BookItem[] BookTable = new BookItem[BOOK_SIZE]; // 开局库
    };

}
