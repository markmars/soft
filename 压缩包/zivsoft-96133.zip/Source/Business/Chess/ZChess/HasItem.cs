﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.Business.Chess.ZChess
{
    // 置换表项结构
    struct HashItem
    {
        byte ucDepth, ucFlag;
        short svl;
        int wmv, wReserved;
        int dwLock0, dwLock1;
    };
}
