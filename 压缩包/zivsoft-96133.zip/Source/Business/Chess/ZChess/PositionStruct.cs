﻿using System.ComponentModel;
namespace Zivsoft.Business.Chess.ZChess
{

    class PositionStruct
    {
        public const int MAX_MOVES = 256;
        public int sdPlayer;                   // 轮到谁走，0=红方，1=黑方
	    public byte[] ucpcSquares=new byte[256];          // 棋盘上的棋子
	    public int vlWhite, vlBlack;           // 红、黑双方的子力价值
	    public int nDistance, nMoveNum;        // 距离根节点的步数，历史走法数
	    public MoveStruct[] mvsList=new MoveStruct[MAX_MOVES];  // 历史走法信息列表
	    public ZobristStruct zobr;             // Zobrist

        // 清空棋盘
        public void ClearBoard() 
        {         
		    
        }

        public bool LegalMove(int mv){
            return true;
        }

        public int GenerateMoves(int[] mvs, bool bCapture)
        {
            return 0;
        }

        public int GenerateMoves(int[] mvs)
        {
            return GenerateMoves(mvs, false);
        }

    }
}