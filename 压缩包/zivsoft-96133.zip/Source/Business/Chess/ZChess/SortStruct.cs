﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.Business.Chess.ZChess
{
    // 与搜索有关的全局变量

    class SortStruct
    {
        PositionStruct pos = new PositionStruct();
        // 走法排序阶段
        const int PHASE_HASH = 0;
        const int PHASE_KILLER_1 = 1;
        const int PHASE_KILLER_2 = 2;
        const int PHASE_GEN_MOVES = 3;
        const int PHASE_REST = 4;
        const int MAX_GEN_MOVES = 128; // 最大的生成走法数
        int mvHash, mvKiller1, mvKiller2; // 置换表走法和两个杀手走法
        int nPhase, nIndex, nGenMoves;    // 当前阶段，当前采用第几个走法，总共有几个走法
        int[] mvs=new int[MAX_GEN_MOVES];           // 所有的走法
        // 初始化，设定置换表走法和两个杀手走法
        void Init(int mvHash_)
        {
            mvHash = mvHash_;
            mvKiller1 = Search.mvKillers[pos.nDistance,0];
            mvKiller2 = Search.mvKillers[pos.nDistance,1];
            nPhase = PHASE_HASH;
        }
        int Next()
        {
            int mv;
            switch (nPhase)
            {
                // "nPhase"表示着法启发的若干阶段，依次为：

                // 0. 置换表着法启发，完成后立即进入下一阶段；
                case PHASE_HASH:
                    nPhase = PHASE_KILLER_1;
                    if (mvHash != 0)
                    {
                        return mvHash;
                    }
                    break;
                // 技巧：这里没有"break"，表示"switch"的上一个"case"执行完后紧接着做下一个"case"，下同

                // 1. 杀手着法启发(第一个杀手着法)，完成后立即进入下一阶段；
                case PHASE_KILLER_1:
                    nPhase = PHASE_KILLER_2;
                    if (mvKiller1 != mvHash && mvKiller1 != 0 && pos.LegalMove(mvKiller1))
                    {
                        return mvKiller1;
                    }
                    break;

                // 2. 杀手着法启发(第二个杀手着法)，完成后立即进入下一阶段；
                case PHASE_KILLER_2:
                    nPhase = PHASE_GEN_MOVES;
                    if (mvKiller2 != mvHash && mvKiller2 != 0 && pos.LegalMove(mvKiller2))
                    {
                        return mvKiller2;
                    }
                    break;

                // 3. 生成所有着法，完成后立即进入下一阶段；
                case PHASE_GEN_MOVES:
                    nPhase = PHASE_REST;
                    nGenMoves = pos.GenerateMoves(mvs);
                    //qsort(mvs, nGenMoves, sizeof(int), CompareHistory);
                    nIndex = 0;
                    break;

                // 4. 对剩余着法做历史表启发；
                case PHASE_REST:
                    while (nIndex < nGenMoves)
                    {
                        mv = mvs[nIndex];
                        nIndex++;
                        if (mv != mvHash && mv != mvKiller1 && mv != mvKiller2)
                        {
                            return mv;
                        }
                    }
                    break;

                // 5. 没有着法了，返回零。
                default:
                    return 0;
            }
            return 0;
        }
    }
}
