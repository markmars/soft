﻿using System;
using System.Windows.Forms;
using System.Collections;

namespace Zivsoft.Business.Chess
{
    /// <summary>
    /// 
    /// </summary>
    internal abstract class BlackChessBase : ChessWordBase
    {
        public override bool Check()
        {
            if (!base.Check())
            {
                return false;
            }
            if (!base.IsAttack && (base.Y < 6))
            {
                return false;
            }
            for (int i = 0; i < ChessWordBase.All.Count; i++)
            {
                if (((!((ChessWordBase)ChessWordBase.All[i]).IsRedChess
                      && !((ChessWordBase)ChessWordBase.All[i]).Equals(this))
                     && (((ChessWordBase)ChessWordBase.All[i]).IsDogFall
                         && (((ChessWordBase)ChessWordBase.All[i]).X == base.X)))
                    && (((ChessWordBase)ChessWordBase.All[i]).Y == base.Y))
                {
                    return false;
                }
            }
            return true;
        }

        public override void Init()
        {
            base.Init();
            base.Name = "黑棋";
            base.IsRedChess = false;
        }

        public virtual void Init(int x, int y)
        {
            base.Init();
            base.Name = "黑棋";
            base.X = x;
            base.Y = y;
            base.IsRedChess = false;
        }

    }
}