﻿using Zivsoft.Services;
using Zivsoft.Business.Users;

using Zivsoft.IO.Users;

namespace Zivsoft.Business
{


    class LoginFactory
    {
        private LoginResponse response = new LoginResponse();
        public Response PerformTask(LoginRequest request)
        {
            Login login = new Login(request.UserId,request.Password);
            //User orm
            bool isLogin = login.Check();

            response.IsLogin = isLogin;
            if (isLogin)
            {

                login.Update(request.IP);
                response.Theme = login.GetUserTheme();
                response.UserName = login.GetUserName();
            }
            else
            {
                response.IsLogin = false;
            }
            return response;
        }
    }
}
