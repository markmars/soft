﻿using System;
using System.Drawing;
using System.Windows.Forms;

using System.Diagnostics;
using Zivsoft.Business.Security;
using Zivsoft.Log;

namespace Zivsoft.Business.Register
{
    /// <summary>
    /// 
    /// </summary>
    partial class RegUI : Form
    {

        private ISecurity _security = new SecurityHelper();

        public RegUI()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.progressBar1.Value = 0;
            this.lblProcess.ForeColor = this.ForeColor;
            this.lblProcess.Text = "Checking your register code...";
            if (string.IsNullOrEmpty(this.txtUCode.Text.Trim()))
            {
                this.progressBar1.Value = 100;
                this.lblProcess.ForeColor = Color.Red;
                this.lblProcess.Text = "The register code can not be empty!";
                this.txtUCode.Focus();
                return;
            }
            CheckInput();

        }

        private void CheckInput()
        {
            if (_security.CheckUCodeEntry(this.txtUCode.Text.Trim()))
            {
                this.progressBar1.Value = 50;
                if (_security.MakeCert(this.txtUCode.Text.Trim()))
                {
                    this.lblProcess.Text = "Checking your register code finished!";
                    this.progressBar1.Value = 100;
                    var r = MessageBox.Show("Register Successfully.", "Thanks", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (r == DialogResult.OK)
                    {
                        //Exit();
                        Application.Exit();
                    }
                }
                else
                {
                    this.progressBar1.Value = 100;
                    lblProcess.ForeColor = Color.Red;
                    this.lblProcess.Text = "Register failed!";
                }
            }
            else
            {
                this.progressBar1.Value = 100;
                lblProcess.ForeColor = Color.Red;
                lblProcess.Text = "Your register code is not correct.";
                this.txtUCode.Focus();
            }
        }



        private void button2_Click(object sender, EventArgs e)
        {
            Exit();
        }

        private static void Exit()
        {
            try
            {
                Application.ExitThread();
            }
            catch (Exception err1)
            {
                Logger.LogError("{0}",err1);
                try
                {
                    Application.Exit();
                }
                catch (Exception err)
                {
                    Logger.LogError("{0}",err);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Process.Start("http://www.zivsoft.com");
        }

        private void RegUI_Load(object sender, EventArgs e)
        {
            this.progressBar1.Value = 0;
            this.lblProcess.Text = "Analysing your machine ...";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            this.timer1.Enabled = false;
            this.progressBar1.Value = 50;
            this.lblProcess.Text = "Loading your machine code ...";
            LoadMachineCode();
        }

        private void LoadMachineCode()
        {
            this.txtMCode.Text = _security.GetMachineCode();
            this.txtUCode.Focus();
            this.progressBar1.Value = 100;
            this.lblProcess.Text = " Loading your machine code successfully!";

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Exit();
        }
    }
}