﻿using System;
/*
 * created by ziv at 2006-12-20
 * 日期格式转换
 */
namespace Zivsoft.Business.FormatAdapter
{
    /// <summary>
    /// 日期格式转换
    /// </summary>
    partial class DateFormatAdapter
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        private DateFormatAdapter()
        {
            
        }
        /// <summary>
        /// 获取“年-月-日”格式
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static string GetDate(string date)
        {
            DateTime dt = Convert.ToDateTime(date);
            int y = dt.Year;
            int m = dt.Month;
            int d = dt.Day;

            string s = null;
            s += y;
            if (m < 10)
            {
                s += "-" + m;
            }
            else
            {
                s += m;
            }
            if (d < 10)
            {
                s += "-" + d;
            }
            else
            {
                s += "-" + d;
            }
            return s;
        }

        public static string GetDate(object date)
        {
            DateTime dt = (DateTime)date;
            int y = dt.Year;
            int m = dt.Month;
            int d = dt.Day;

            string s = null;
            s += y;
            if (m < 10)
            {
                s += "-" + m;
            }
            else
            {
                s += m;
            }
            if (d < 10)
            {
                s += "-" + d + "-";
            }
            else
            {
                s += "-" + d + "-";
            }
            return s;
        }

        /// <summary>
        /// 获取中文week
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static string GetCnWeek(string date)
        {
            DateTime dt = Convert.ToDateTime(date);
            DayOfWeek week = dt.DayOfWeek;
            switch (week)
            {
                case DayOfWeek.Sunday:
                    return "星期日";
                case DayOfWeek.Monday:
                    return "星期一";
                case DayOfWeek.Tuesday:
                    return "星期二";
                case DayOfWeek.Wednesday:
                    return "星期三";
                case DayOfWeek.Thursday:
                    return "星期四";
                case DayOfWeek.Friday:
                    return "星期五";
                case DayOfWeek.Saturday:
                    return "星期六";
                default:
                    return "";
            }
        }
        public static string GetWeek(object date)
        {
            DateTime dt = (DateTime)date;
            DayOfWeek week = dt.DayOfWeek;
            switch (week)
            {
                case DayOfWeek.Sunday:
                    return "Sun";
                case DayOfWeek.Monday:
                    return "Mon";
                case DayOfWeek.Tuesday:
                    return "Tue";
                case DayOfWeek.Wednesday:
                    return "Wed";
                case DayOfWeek.Thursday:
                    return "Thu";
                case DayOfWeek.Friday:
                    return "Fri";
                case DayOfWeek.Saturday:
                    return "Sat";
                default:
                    return "";
            }
        }
        /// <summary>
        /// 格式化日期格式 YYYY-MM-DD HH:MM
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static string GetDateTime(DateTime? dateTime)
        {
            return GetDate(dateTime) +" "+ GetTime(dateTime);
        }

        /// <summary>
        /// 产生日期字符串
        /// </summary>
        /// <param name="dateTime">DateTime</param>
        /// <returns>YYYY-MM-DD</returns>
        public static string GetDate(DateTime? dateTime)
        {
            if(dateTime==null)
            {
                return null;
            }
            DateTime date = (DateTime) dateTime;
            string strYear = date.Year.ToString();
            string strMonth = date.Month.ToString();
            string strDay = date.Day.ToString();
            if(strYear.Length==1)
            {
                strYear = "0" + strYear;
            }
            if(strMonth.Length==1)
            {
                strMonth = "0" + strMonth;
            }
            if(strDay.Length==1)
            {
                strDay = "0" + strDay;
            }
            return strYear + "-" + strMonth + "-" + strDay;
        }
        
        /// <summary>
        /// 产生时间字符串
        /// </summary>
        /// <param name="dateTime">DateTime</param>
        /// <returns>HH:MM</returns>
        public static string GetTime(DateTime? dateTime)
        {
            if(dateTime==null)
            {
                return null;
            }
            DateTime date = (DateTime) dateTime;
            string strHour = date.Hour.ToString();
            string strMinute = date.Minute.ToString();
            
            if(strHour.Length==1)
            {
                strHour = "0" + strHour;
            }
            if(strMinute.Length==1)
            {
                strMinute = "0" + strMinute;
            }
            
            return strHour + ":" + strMinute;
        }
    }
}
