

/*
 * 
 * Created by ziv at 2007-1-29
 */
using Zivsoft.Data;
using Zivsoft.Data.Entity;

namespace Zivsoft.Business.DbInterface
{
	/// <summary>
	/// DbSequence ��ժҪ˵����
	/// </summary>
	class DbSequence
	{
		protected string _seqName;
		/// <summary>
		/// ���캯��
		/// </summary>
		public DbSequence(string seqName)
		{
			this._seqName = seqName;
            this.Init();
		}

		/// <summary>
		/// ��Sequence�ĵ�ǰֵ
		/// </summary>
		public long Current()
		{
			Sequence seq=new Sequence();
            seq.SeqName = this._seqName;
		    seq.Load();
            return seq.SeqNumber;
		}

		/// <summary>
		/// ��sequence�ĵ�ǰֵ,������1
		/// </summary>
		/// <returns></returns>
		public long Next()
		{
			long v = this.Current();
			Sequence seq=new Sequence();
            seq.SeqName = this._seqName;
            seq.SeqNumber = (v+1);
			seq.Update();
			return v;
		}
		/// <summary>
		/// ��ʼ����Sequence
		/// </summary>
		private void Init()
		{
		    Sequence seq=new Sequence();
            seq.SeqName = this._seqName;
		    if(seq.SelectCount()==0)
		    {
                seq.SeqNumber = 0;
		        seq.Insert();
		    }
		}
	    public  static DbSequence CreateSequence(string seqName)
	    {
            return new DbSequence(seqName);
	    }
	}
}
