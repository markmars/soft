﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Zivsoft.Data;
using Zivsoft.Data.Entity;
using Zivsoft.Data.ORM.Entity;


/*
 * Created by Lihua Zhou at 12/26/2007
 */
namespace Zivsoft.Business.DbInterface
{
    /// <summary>
    /// 
    /// </summary>
    class ViewFieldsConfig
    {
        /// <summary>
        /// 
        /// </summary>
        private ArrayList GetDbAllUserTables()
        {
            ArrayList al = new ArrayList();
            SysObjects sysObjs=new SysObjects();
            IResultSet rs = sysObjs.LoadResultSet();
                //DbFactory.DefaultDbOperator().Query4ResultSet("SELECT [name] FROM [sysobjects] WHERE [xtype] = 'U'");
            while (rs != null && rs.Next())
            {
                al.Add(rs.GetValue(0));
            }
            return al;
        }


        /// <summary>
        /// Init all viewfields configuration
        /// </summary>
        /// <returns>the items number that you insert by this method</returns>
        public int InitViewFields()
        {
            ArrayList tableList = this.GetDbAllUserTables();
            var count = 0;
            for (int i = 0, t = tableList.Count; i < t; i++)
            {
                SysColumns sysc = new SysColumns();

                ViewFields vf = new ViewFields();
                vf.IsQuery = true;
                vf.FieldType = sysc.XType;
                count += vf.Insert(); // DbFactory.DefaultDbOperator().ExcuteSql(this.GetSQL(tableList[i].ToString()));
            }
            return count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public string GetSQL(string tableName)
        {
            string sql = @"
                                declare @table varchar(10);
                                set @table='{0}';
                                insert viewfields (IsQuery,fieldtype,viewid,fieldid,fieldname,fieldenname,controllen,isnull,columnno,isvisible,isgridvisible)
                                (
                                select 1,xtype,@table,name,name,name,200,isnullable,colorder,1,1 from syscolumns
                                where id=
                                (
                                select id from sysobjects
                                where name=@table
                                )
                                )
                                ";
            return string.Format(sql, tableName);
        }
    }
}
