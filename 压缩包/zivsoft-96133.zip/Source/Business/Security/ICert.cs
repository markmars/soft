﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Security
{
    internal interface ICert
    {
        string Location { get;}
        string FileName { get; }
    }
}