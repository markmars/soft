﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Security
{
    class Binary
    {
        private readonly char[] HexChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

        public readonly char[] CharDigital = { 'A', 'Z', 'C', 'X', 'Q', 'R', 'M', 'T', 'U', 'S', 'B', 'G', 'K', 'N', 'P', 'D', 'H', 'W', 'J', 'Y', 'E', 'I', 'O', 'V', 'F', 'L' };

        public readonly char[] Alphabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };

        /// <summary>
        /// 2 string to 16 string
        /// @param b 
        /// @return hex :
        /// </summary>
        public string ByteToHex(byte[] b)
        {
            string hs = "";
            string stmp = "";
            for (int n = 0; n < b.Length; n++)
            {
                stmp = ToHexStr(b[n]);
                if (stmp.Length == 1) //less tha 2bit, add 0
                {
                    hs = hs + "0" + stmp;
                }
                else
                {
                    hs = hs + stmp;
                }
                if (n < b.Length - 1) //":"as splite
                {
                    hs = hs + ":";
                }
            }
            return hs.ToUpper();
        }


        /// <summary>
        /// byte Integer showing in String
        /// </summary>
        /// <param name="b"></param>
        /// <returns></returns>
        public string ToHexStr(byte b)
        {
            return "" + this.HexChar[b >> 4 & 0x0F] + this.HexChar[b & 0x0F];
        }

        /// <summary>
        /// 16Bit Integer showing in String
        /// </summary>
        /// <param name="int16"></param>
        /// <returns></returns>
        public string ToHexStr(Int16 int16)
        {
            byte byteH8 = (byte)(int16 >> 8 & 0X00FF);
            byte byteL8 = (byte)(int16 & 0x00FF);
            return this.ToHexStr(byteH8) + this.ToHexStr(byteL8);
        }

        /// <summary>
        /// 32Bit Integer showing in String
        /// </summary>
        public string ToHexStr(Int32 int32)
        {
            Int16 intH16 = (Int16)(int32 >> 16 & 0x0000FFFF);
            Int16 intL16 = (Int16)(int32 & 0x0000FFFF);
            return this.ToHexStr(intH16) + this.ToHexStr(intL16);
        }

        /// <summary>
        /// 4 chars to 4 int
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public int GetDigitalFromCode(string code)
        {
            if (null == code || code.Length != 4)
            {
                return 0;
            }
            int[] weight = { 4, 3, 2, 1 };
            int[] count = { 0, 0, 0, 0 };

            for (int i = 0; i < 4; i++)
            {
                char ch = code[i];
                int j = 0;
                for (; j < 26; j++)
                {
                    if (this.CharDigital[j] == ch)
                    {
                        count[i] = j;
                        break;
                    }
                }
                if (j == 26)
                {
                    count[i] = 0;
                }
            }
            return count[0] * weight[0] + count[1] * weight[1] + count[2] * weight[2] + count[3] * weight[3];
        }

        /// <summary>
        /// change data to 4 char
        /// </summary>
        /// <returns></returns>
        public string GetCodeFromDigital(int num)
        {
            if (num < 1 || num > 250)
            {
                return "0000";
            }

            int[] weight = { 4, 3, 2, 1 };
            int[] count = { 0, 0, 0, 0 };
            int idx = 0;
            while (num > 0)
            {
                if (idx == 4)
                {
                    idx = 0;
                }
                if (num >= weight[idx])
                {
                    count[idx]++;
                    num -= weight[idx];
                }
                idx++;
            }

            return "" + this.CharDigital[count[0]] + this.CharDigital[count[1]] + this.CharDigital[count[2]] + this.CharDigital[count[3]];
        }
    }
}