﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.Business.Security
{
    interface ISecurity
    {
        bool CheckCert();
        bool CheckUCodeEntry(string ucode);
        string GetMachineCode();
        bool MakeCert(string ucode);
        string GetRigsterCodeFromMachineCode(string machinecode, int limit);
        string MD5(string str);
    }
}
