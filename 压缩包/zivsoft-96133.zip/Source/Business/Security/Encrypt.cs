using System;
using System.Collections;
using System.IO;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web.Security;

/*
 * 
 * 
 */

namespace Zivsoft.Business.Security
{
    /// <summary>
    /// 
    /// </summary>
    sealed class Encrypt:IEncrypt
    {

        private static Object SynchronizeVariable = "Locking ClientCount"; 

        private static IEncrypt eu = null; 
        private const char BLANKCHAR = ' '; //blank space
        private SymmetricAlgorithm sa = null; //
        private readonly string Key = String.Empty; //readonly, avoid modifiing
        private readonly string IV = String.Empty; 

        private int clientSize = 0; 
        private int clientCount = 0;
        private Hashtable _alUsers = null; 
        private ArrayList _alStarts = null; 

        /// <summary>
        /// 
        /// </summary>
        internal static IEncrypt Single()
        {
            if (eu == null)
            {
                eu = new Encrypt();
            }
            return eu;
        }

        /// <summary>
        ///	
        /// </summary>
        private Encrypt()
        {
            this.sa = new RijndaelManaged();
            this.Key = "Guz(%&hj7x89H$yuBI0456FtmaT5&fvHUFCy76*h%(HilJ$lhj!y6&(*jkP87jH7";
            this.IV = "E4ghj*Ghg7!rNIfb&95GUY86GfghUb#er57HBh(u%g6HJ($jhWk7&!hg4ui%$hjk";

            this._alUsers = new Hashtable();
            this._alStarts = new ArrayList();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="strParam"></param>
        /// <returns></returns>
        public string EncryptText(string strParam)
        {
            if (strParam == null)
            {
                return null;
            }
            try
            {
                byte[] byteIn = UTF8Encoding.UTF8.GetBytes(strParam);
                MemoryStream ms = new MemoryStream();
                ICryptoTransform encrypto = sa.CreateEncryptor(this.GetLegalKey(), this.GetLegalIV());
                CryptoStream cs = new CryptoStream(ms, encrypto, CryptoStreamMode.Write);
                cs.Write(byteIn, 0, byteIn.Length);
                cs.FlushFinalBlock();
                ms.Close();
                byte[] bytOut = ms.ToArray();
                return Convert.ToBase64String(bytOut);
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strParam"></param>
        /// <returns></returns>
        public string DeEncrypt(string strParam)
        {
            if (strParam == null)
            {
                return null;
            }
            try
            {
                byte[] bytIn = Convert.FromBase64String(strParam);
                MemoryStream ms = new MemoryStream(bytIn, 0, bytIn.Length);
                ICryptoTransform encrypto = sa.CreateDecryptor(GetLegalKey(), GetLegalIV());
                CryptoStream cs = new CryptoStream(ms, encrypto, CryptoStreamMode.Read);
                StreamReader sr = new StreamReader(cs);
                return sr.ReadToEnd();
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private byte[] GetLegalKey()
        {
            string sTemp = this.Key;
            sa.GenerateKey();
            int keyLength = sa.Key.Length;
            if (sTemp.Length > keyLength)
            {
                sTemp = sTemp.Substring(0, keyLength);
            }
            else if (sTemp.Length < keyLength)
            {
                sTemp = sTemp.PadRight(keyLength, Encrypt.BLANKCHAR);
            }
            return ASCIIEncoding.ASCII.GetBytes(sTemp);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private byte[] GetLegalIV()
        {
            string sTemp = this.IV;
            sa.GenerateIV();
            int ivLength = sa.IV.Length;
            if (sTemp.Length > ivLength)
            {
                sTemp = sTemp.Substring(0, ivLength);
            }
            else if (sTemp.Length < ivLength)
            {
                sTemp = sTemp.PadRight(ivLength, Encrypt.BLANKCHAR);
            }
            return ASCIIEncoding.ASCII.GetBytes(sTemp);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="strInit"></param>
        /// <param name="strPwd"></param>
        /// <returns></returns>
        public bool verify(String strInit, String strPwd)
        {
            //if password is empty
            if (null == strPwd)
            {
                if (null == strInit) 
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            //if not empty
            if (strPwd.Equals(this.EncryptText(strInit)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="sid"></param>
        /// <returns></returns>
        public bool AddUser(string userName, string sid)
        {
            lock (Encrypt.SynchronizeVariable)
            {
                //Check ClientCount,if number
                if (null == userName || this.clientCount >= this.clientSize)
                {
                    return false;
                }

                if (!this._alUsers.ContainsKey(sid))
                {
                    this._alUsers.Add(sid, userName);
                }
                Interlocked.Increment(ref this.clientCount);
                return true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sid"></param>
        /// <returns></returns>
        public string getUserid(string sid)
        {
            if (this._alUsers.ContainsKey(sid))
            {
                return this._alUsers[sid] as string;
            }
            return String.Empty;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public bool ExistUser(string userName)
        {
            if (null == userName) 
            {
                return true;
            }
            return this._alUsers.ContainsValue(userName) && this._alUsers.Count == this.clientCount;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public void RemoveUser(string userName)
        {
            lock (Encrypt.SynchronizeVariable)
            {
                //if use count is 0
                if (this.clientCount == 0)
                {
                    return;
                }
                Interlocked.Decrement(ref this.clientCount);

                //if exist, remove
                if (null != userName && this._alUsers.ContainsValue(userName))
                {
                    this.Remove(userName);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        private void Remove(string user)
        {
            IDictionaryEnumerator enm = this._alUsers.GetEnumerator();
            while (enm.MoveNext())
            {
                if (user.Equals(enm.Value))
                {
                    this._alUsers.Remove(enm.Key);
                    break;
                }
            }
        }

        /// <summary>
        /// If use is exist, remove
        /// </summary>
        /// <param name="userName"></param>
        public void RemoveUserIfExist(string userName)
        {
            lock (Encrypt.SynchronizeVariable)
            {
                if (null != userName && this._alUsers.ContainsValue(userName))
                {
                    this.Remove(userName);
                    if (this.clientCount > 0)
                    {
                        Interlocked.Decrement(ref this.clientCount);
                    }
                }
            }
        }


        public bool MakeCertFile(string registerCode, string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    File.Delete(fileName);
                }
                catch(Exception e)
                {
                    throw e;
                }
            }
            string machineCode = this.GetMachineCode();
            string content = machineCode + "######" + registerCode;
            string deContent = this.EncryptText(content);
            //the last 4 bit,mean the client number
            Binary b = new Binary();
            int cs = b.GetDigitalFromCode(deContent.Substring(deContent.Length - 4));
            return MakeCertFile(machineCode, fileName, cs);
        }

        /// <summary>
        /// If file not exist, then return false
        /// if yes, verify the content
        /// </summary>
        /// <param name="filePath"></param>
        public bool VerifyCertFile(string fileName)
        {

            if (this.clientSize > 0)
            {
                return true;
            }

            if (!File.Exists(fileName))
            {
                return false;
            }

            //
            FileStream fs = new FileStream(fileName, FileMode.Open);
            int size = (int)fs.Length;
            if (size < 8 || size >= int.MaxValue)
            {
                fs.Close();
                return false;
            }

            byte[] bts = new byte[size];
            fs.Read(bts, 0, size);
            fs.Close();

            string content = UTF8Encoding.UTF8.GetString(bts);
            string deContent = this.DeEncrypt(content);
            int pos = deContent.IndexOf("######");
            if (pos == -1)
            {
                fs.Close();
                return false;
            }

            //the last 4 bit,mean the client number
            Binary b = new Binary();
            this.clientSize = b.GetDigitalFromCode(deContent.Substring(deContent.Length - 4));

            //get CheckCode
            string checkCode = deContent.Substring(0, pos);
            string regCode = this.GetMachineCode();

            if (checkCode.Equals(regCode))
            {
                fs.Close();
                return true;
            }

            //if no, then the time is 0
            this.clientSize = 0;
            fs.Close();
            return false;
        }


        /// <summary>
        ///
        /// </summary>
        /// <param name="checkCode"></param>
        /// <param name="fileName"></param>
        public bool MakeCertFile(string checkCode, string fileName, int clientSize)
        {

            FileStream fs = null;
            try
            {
                fs = new FileStream(fileName, FileMode.CreateNew, FileAccess.Write, FileShare.Read);
            }
            catch
            {
                return false;
            }
            string content = checkCode + "######" + this.GetRigsterCodeFromMachineCode(checkCode, clientSize);
            string enContent = this.EncryptText(content);
            byte[] bts = UTF8Encoding.UTF8.GetBytes(enContent);
            fs.Write(bts, 0, bts.Length);
            fs.Close();
            FileInfo fi = new FileInfo(fileName);
            fi.Attributes = FileAttributes.Hidden;
            if (File.Exists(fileName))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sid"></param>
        public void setStart(string sid)
        {
            if (null == sid)
            {
                return;
            }
            if (this._alStarts.Contains(sid))
            {
                return;
            }
            this._alStarts.Add(sid);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sid"></param>
        public void endStart(string sid)
        {
            if (null == sid)
            {
                return;
            }
            if (!this._alStarts.Contains(sid))
            {
                return;
            }
            this._alStarts.Remove(sid);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="sid"></param>
        /// <returns></returns>
        public bool isStart(string sid)
        {
            if (null == sid)
            {
                return false;
            }
            return this._alStarts.Contains(sid);
        }

        /// <summary>
        /// Getting the limit of cert file
        /// </summary>
        /// <returns></returns>
        public int ClientSize
        {
            get { return this.clientSize; }
        }

        /// <summary>
        /// Current use count
        /// </summary>
        public int ClientCount
        {
            get { return this.clientCount; }
        }


        /// <summary>
        /// </summary>
        /// <param name="checkCode"></param>
        /// <returns></returns>
        public string GetRigsterCodeFromMachineCode(string checkCode, int cs)
        {
            if (checkCode == null || checkCode.Length != 16)
            {
                return "0000-0000-0000-0000";
            }
            //How to get register code from machine code?
            //1.if integer,get CharDigital instead
            //2.if letter,get the position of CharDigital and then enclode each char
            string registerCode = String.Empty;
            Binary b = new Binary();
            for (int i = 0; i < 16; i++)
            {
                if (char.IsDigit(checkCode, i))
                { 
                    //if integer
                    int digital = Int32.Parse(checkCode.Substring(i, 1));
                    
                    registerCode += b.CharDigital[digital];
                }
                else
                {
                    int k = 0;
                    for (; k < 26; k++)
                    {
                        if (b.CharDigital[k] == checkCode[i])
                        {
                            if (k < 16)
                            { 
                                //show in hex
                                string strHex = b.ToHexStr(k);
                                registerCode += strHex[7];
                            }
                            else
                            {
                                registerCode += b.Alphabet[k];
                            }
                            break;
                        }
                    }

                    if (k == 26)
                    { 
                        //if not integar and not Caps letter
                        registerCode += '#';
                    }
                }
                if ((i + 1) % 4 == 0)
                {
                    registerCode += '-';
                }
            }
            registerCode += b.GetCodeFromDigital(cs);

            return registerCode;
        }

        /// <summary>
        /// Get machine code
        /// </summary>
        /// <returns></returns>
        public string GetMachineCode()
        {
            CPU cpu = new CPU();
            string orgCode = cpu.GetCpuid();
            if (orgCode == String.Empty)
            { 
                //if not get cpu id
                orgCode = cpu.GetNetcardMac();
                if (orgCode == String.Empty)
                {
                    return orgCode;
                }
            }
            return orgCode.PadRight(16, '0');
        }

    }
}