﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Security;
using System.IO;
using System.Net;


using Zivsoft.Log;

namespace Zivsoft.Business.Security
{
    /// <summary>
    /// This class is used to check the products permission.
    /// </summary>
    class SecurityHelper : ISecurity
    {
        /// <summary>
        /// This method is the final check for the product permission.
        /// </summary>
        /// <returns></returns>
        public bool CheckCert()
        {
            //beat
            Stream s = null;
            var uri = new Uri("http://www.zivsoft.com/documents/z.cert");
            var req = (HttpWebRequest)WebRequest.Create(uri);
            WebResponse res = null;
            try
            {
                res = req.GetResponse();
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
            }
            s = res.GetResponseStream();
            var sr = new StreamReader(s);
            var strHtml = sr.ReadToEnd();

            //neetn't check cert
            if (strHtml.Trim() == "0")
            {
                return true;
            }
            else//need check cert
            {

                ICert cert = new Cert();
                return Encrypt.Single().VerifyCertFile(cert.ToString());
            }
        }

        public bool CheckUCodeEntry(string ucode)
        {
            var mCode = Encrypt.Single().GetMachineCode();
            var u = Encrypt.Single().GetRigsterCodeFromMachineCode(mCode, 0);
            if (u == ucode)
            {
                return true;
            }
            return false;
        }

        public string GetMachineCode()
        {
            return Encrypt.Single().GetMachineCode();
        }

        public bool MakeCert(string ucode)
        {
            ICert cert = new Cert();
            return Encrypt.Single().MakeCertFile(ucode, cert.ToString());
        }

        public string MD5(string str)
        {
            string str2;
            if (str == "")
                str2 = "";
            else
                str2 = FormsAuthentication.HashPasswordForStoringInConfigFile(str, "md5");
            return str2;
        }

        public string GetRigsterCodeFromMachineCode(string machinecode, int limit)
        {
            return Encrypt.Single().GetRigsterCodeFromMachineCode(machinecode, limit);
        }
    }
}
