﻿using System;
using System.Collections.Generic;
using System.Text;

using System.IO;

namespace Zivsoft.Business.Security
{
    internal sealed class Cert:ICert
    {
        public string Location {
            get
            {
                var location=AppDomain.CurrentDomain.BaseDirectory;
                return location;
            }
        }
        public string FileName
        {
            get
            {
                return "z.cert";
            }
        }

        public override string ToString()
        {
            return Path.Combine(Location, FileName);
        }
    }
}