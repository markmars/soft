﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Management;

namespace Zivsoft.Business.Security
{
    class CPU
    {
        /// <summary>
        /// Get CPU ID,CPU Number
        /// </summary>
        /// <returns></returns>
        public string GetCpuid()
        {
            try
            {
                ManagementClass mc = new ManagementClass("Win32_Processor");
                ManagementObjectCollection moc = mc.GetInstances();

                foreach (ManagementObject mo in moc)
                {
                    PropertyData pd = mo.Properties["ProcessorId"];
                    if (null != pd)
                    {
                        return pd.Value.ToString();
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception("EncryUtils-getCpuuid： ", e);
            }
            return String.Empty;
        }

        /// <summary>
        /// MAC
        /// </summary>
        /// <returns></returns>
        public string GetNetcardMac()
        {
            ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection moc = mc.GetInstances();

            //mac number 
            foreach (ManagementObject mo in moc)
            {
                if ((bool)mo["IPEnabled"])
                {
                    return mo["MacAddress"].ToString().Replace(":", "");
                }
                mo.Dispose();
            }

            return String.Empty;

        }
    }
}