﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Security
{
    interface IEncrypt
    {
        string GetMachineCode();
        string GetRigsterCodeFromMachineCode(string machineCode, int limit);
        bool VerifyCertFile(string fileLocation);
        bool MakeCertFile(string registerCode, string fileLocation);
    }
}