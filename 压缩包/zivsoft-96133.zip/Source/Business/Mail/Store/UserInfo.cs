﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Zivsoft.Business.Mail.Store
{
        /**/
    /***************************************
********  里奥特在线邮件收发系统  *****
***************************************/
    namespace Lyout.WebMail
    {
        /// <summary>
        /// 用户信息操作
        /// </summary>
        public class UserHelper
        {
            private static readonly string UserIDKey = "UCO_USERIDKEY";

            /**/
            /// <summary>
            /// 删除
            /// </summary>
            /// <param name="cookies"></param>
            public static void Delete(HttpCookieCollection cookies)
            {
                cookies.Remove(UserIDKey);
            }

            /**/
            /// <summary>
            /// 从缓存中取出用户数据
            /// </summary>
            /// <param name="cookies"></param>
            /// <returns></returns>
            public static UserInfo GetUserInfo(HttpCookieCollection cookies)
            {
                if (cookies[UserIDKey] != null)
                {
                    string cookiedata = cookies[UserIDKey].Value;
                    if (!string.IsNullOrEmpty(cookiedata))
                    {
                        // 反序列化用户信息
                        string userData = HttpContext.Current.Server.UrlDecode(cookiedata);
                        byte[] bt = Convert.FromBase64String(userData);
                        using (Stream smNew = new MemoryStream(bt))
                        {
                            IFormatter fmNew = new BinaryFormatter();
                            return (UserInfo)fmNew.Deserialize(smNew);
                        }
                    }
                }
                return null;
            }

            /**/
            /// <summary>
            /// 把用户信息存储到缓存中
            /// </summary>
            /// <param name="cookies"></param>
            /// <param name="info"></param>
            public static void StoreUserInfo(HttpCookieCollection cookies, UserInfo info)
            {
                if (cookies != null)
                {
                    IFormatter fm = new BinaryFormatter();
                    MemoryStream sm = new MemoryStream();

                    // 序列化用户信息
                    fm.Serialize(sm, info);
                    sm.Seek(0, SeekOrigin.Begin);

                    // 转为 base64 格式
                    byte[] byt = new byte[sm.Length];
                    byt = sm.ToArray();
                    string userData = Convert.ToBase64String(byt);
                    sm.Flush();

                    cookies.Remove(UserIDKey);
                    // 存储到 Cookie 中
                    HttpCookie cookie = new HttpCookie(UserIDKey);
                    cookie.Value = HttpContext.Current.Server.UrlEncode(userData);
                    // 有效期一天
                    cookie.Expires = DateTime.Now.AddDays(1);
                    cookies.Add(cookie);
                }
            }

            public static void StoreUserInfo(HttpCookieCollection cookies, int userID)
            {
                StoreUserInfo(cookies, new UserInfo(userID));
            }

            public static void StoreUserInfo(HttpCookieCollection cookies, int userID, string username)
            {
                StoreUserInfo(cookies, new UserInfo(userID, username));
            }

            public static void StoreUserInfo(HttpCookieCollection cookies, int userID, string username, DateTime loginDate)
            {
                StoreUserInfo(cookies, new UserInfo(userID, username, loginDate));
            }
        }

        /**/
        /// <summary>
        /// 用户信息
        /// </summary>
        [Serializable]
        public class UserInfo
        {
            private DateTime loginDate;
            private int userID;
            private string username;
            private string nickname;
            private int roleID = 0;

            public UserInfo()
            {
            }

            public UserInfo(int userID)
            {
                this.userID = userID;
                this.username = string.Empty;
                this.nickname = string.Empty;
                this.loginDate = DateTime.Now;
            }

            public UserInfo(int userID, string username)
            {
                this.userID = userID;
                this.username = username;
                this.nickname = username;
                this.loginDate = DateTime.Now;
            }

            public UserInfo(int userID, string username, string nickname)
                : this(userID, username)
            {
                this.nickname = nickname;
            }

            public UserInfo(int userID, string username, DateTime loginDate)
            {
                this.userID = userID;
                this.username = username;
                this.nickname = username;
                this.loginDate = loginDate;
            }

            public UserInfo(int userID, string username, string nickname, DateTime loginDate)
                : this(userID, username, loginDate)
            {
                this.nickname = nickname;
            }
            /**/
            /// <summary>
            /// 登录日期
            /// </summary>
            public DateTime LoginDate
            {
                get
                {
                    return this.loginDate;
                }
                set
                {
                    this.loginDate = value;
                }
            }
            /**/
            /// <summary>
            /// 用户ID
            /// </summary>
            public int UserID
            {
                get
                {
                    return this.userID;
                }
                set
                {
                    this.userID = value;
                }
            }
            /**/
            /// <summary>
            /// 登录名
            /// </summary>
            public string UserName
            {
                get
                {
                    return this.username;
                }
                set
                {
                    this.username = value;
                }
            }
            /**/
            /// <summary>
            /// 呢称
            /// </summary>
            public string NickName
            {
                get
                {
                    return this.nickname;
                }
                set
                {
                    this.nickname = value;
                }
            }
            /**/
            /// <summary>
            /// 角色ID
            /// </summary>
            public int RoleID
            {
                get
                {
                    return roleID;
                }
                set
                {
                    roleID = value;
                }
            }
        }
    }


}
