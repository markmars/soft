using System.Collections;
using System.IO;
using System.Threading;

namespace Zivsoft.Business.Mail
{

	class MutilSenderUtil
	{

        public static void SendMail(string fileAddressList, string fileHtmlContent, string fileAttachment)
		{
			ArrayList alList=new ArrayList(100);
			StreamReader reader = File.OpenText(fileAddressList);
			string line = null;
			while((line=reader.ReadLine()) != null)
			{
				string[] s = line.Split('\t');
				User u = new User();
				u.Name = s[0];
				u.Phone = s[1];
				u.Email = s[2];
				u.Birth = s[3];
				alList.Add(u);
			}
			reader.Close();

			reader = File.OpenText(fileHtmlContent);
			string content = reader.ReadToEnd();

			SmtpClient sc = new SmtpClient("smtp.163.com","zorywa","612896");
			MailMessage msg = new MailMessage();
			msg.From = new MailAddress("lihuazhou@microsoft.com","Lihua Zhou");
			msg.Subject = "How are you?";
			msg.Notification = true;
			msg.Charset = "utf-8";
			ArrayList toList = new ArrayList();
			foreach(User u in alList)
			{
				if(u.Email==null || u.Email == "") continue;
				toList.Clear();
				toList.Add(new MailAddress(u.Email,u.Name));
				msg.TO = toList;
				msg.HtmlBody = content.Replace("Name",u.Name);
				msg.Attachments.Clear();
				msg.AddAttachment(fileAttachment);
				sc.SendMail(msg);
				Thread.Sleep(1000);
			}
		}
	}
}
