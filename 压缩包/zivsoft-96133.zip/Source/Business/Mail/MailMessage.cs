using System;
using System.Collections;
using System.IO;
using System.Text;

namespace Zivsoft.Business.Mail
{
	/// <summary>
	/// 
	/// </summary>
	class MailMessage
	{
		private MailAddress _from;
		private MailAddress _replyTo;
		private ArrayList _recipientList;
		private ArrayList _ccList;
		private ArrayList _bccList;
		private ArrayList _attachments;
		private string _subject;
		private string _body;
		private string _htmlBody;
		private string _mixedBoundary;
		private string _altBoundary;
		private string _relatedBoundary;
		private string _charset = "ISO-8859-1";
		private bool _notification;
		private string _priority;
		private ArrayList _customHeaders;
		private ArrayList _images;

		/// <summary>
		/// ���캯��
		/// </summary>
		public MailMessage()
		{
			this._charset = "ISO-8859-1";
			this._recipientList = new ArrayList(2);
			this._ccList = new ArrayList(3);
			this._bccList = new ArrayList(3);
			this._attachments = new ArrayList(5);
			this._images = new ArrayList(5);
			this._customHeaders = new ArrayList(5);
			this._mixedBoundary = GenerateMixedMimeBoundary();
			this._altBoundary = GenerateAltMimeBoundary();
			this._relatedBoundary = GenerateRelatedMimeBoundary();
		}
		/// <summary>
		/// ���캯��
		/// </summary>
		public MailMessage(MailAddress sender, MailAddress recipient) : this()
		{
			this._from = sender;
			this._recipientList.Add(recipient);
		}
		/// <summary>
		/// ���캯��
		/// </summary>
		public MailMessage(string senderAddress, string recipientAddress)
			: this(new MailAddress(senderAddress), new MailAddress(recipientAddress))
		{
		}
		/// <summary>
		/// �ظ�
		/// </summary>
		public MailAddress ReplyTo
		{
			get { return this._replyTo != null ? this._replyTo : this._from; }
			set { this._replyTo = value; }
		}
		/// <summary>
		/// ����
		/// </summary>
		public MailAddress From
		{
			get { return this._from; }
			set { this._from = value; }
		}
		/// <summary>
		/// ������
		/// </summary>
		public ArrayList TO
		{
			get { return this._recipientList; }
			set { this._recipientList = value; }
		}
		/// <summary>
		/// ����
		/// </summary>
		public string Subject
		{
			get { return this._subject; }
			set { this._subject = value; }
		}
		/// <summary>
		/// �ʼ����ı�����
		/// </summary>
		public string Body
		{
			get { return this._body; }
			set { this._body = value; }
		}
		/// <summary>
		/// �ʼ���HTML����
		/// </summary>
		public string HtmlBody
		{
			get { return this._htmlBody; }
			set { this._htmlBody = value; }
		}
		/// <summary>
		/// ���ȼ�
		/// </summary>
		public string Priority
		{
			get { return this._priority; }
			set { this._priority = value; }
		}
		/// <summary>
		/// �Ƿ����Ķ�֪ͨ
		/// </summary>
		public bool Notification
		{
			get { return this._notification; }
			set { this._notification = value; }
		}
		/// <summary>
		/// ���͵�ַ
		/// </summary>
		public ArrayList CC
		{
			get { return this._ccList; }
			set { this._ccList = value; }
		}
		/// <summary>
		/// ���͵�ַ
		/// </summary>
		public ArrayList BCC
		{
			get { return this._bccList; }
			set { this._bccList = value; }
		}
		/// <summary>
		/// �ַ���
		/// </summary>
		public string Charset
		{
			get { return this._charset; }
			set { this._charset = value; }
		}
		/// <summary>
		/// �����б�
		/// </summary>
		public ArrayList Attachments
		{
			get { return this._attachments; }
			set { this._attachments = value; }
		}
		/// <summary>
		/// �Զ����ʼ�ͷ
		/// </summary>
		public ArrayList CustomHeaders
		{
			get { return this._customHeaders; }
			set { this._customHeaders = value; }
		}
		/// <summary>
		/// ��MIME����֮���Boundary�ָ��ַ���
		/// </summary>
		internal string AltBoundary
		{
			get { return this._altBoundary; }
			set { this._altBoundary = value; }
		}
		/// <summary>
		/// ��MIME����֮���Boundary�ָ��ַ���
		/// </summary>
		internal string MixedBoundary
		{
			get { return this._mixedBoundary; }
			set { this._mixedBoundary = value; }
		}
		/// <summary>
		/// �����ʼ�������
		/// </summary>
		/// <param name="address"></param>
		/// <param name="type"></param>
		public void AddRecipient(MailAddress address, EAddressType type)
		{
			try
			{
				switch (type)
				{
					case EAddressType.TO:
						this._recipientList.Add(address);
						break;
					case EAddressType.CC:
						this._ccList.Add(address);
						break;
					case EAddressType.BCC:
						this._bccList.Add(address);
						break;
				}
			}
			catch (Exception e)
			{
				throw new ApplicationException("Exception in AddRecipient: " + e.ToString());
			}
		}
		/// <summary>
		/// �����ʼ�������
		/// </summary>
		/// <param name="address"></param>
		/// <param name="type"></param>
		public void AddRecipient(string address, EAddressType type)
		{
			MailAddress email = new MailAddress(address);
			AddRecipient(email, type);
		}
		/// <summary>
		/// ���Ӹ���
		/// </summary>
		/// <param name="filepath"></param>
		public void AddAttachment(string filepath)
		{
			AddAttachment(filepath, NewCid());
		}
		/// <summary>
		/// ���Ӹ���
		/// </summary>
		/// <param name="content"></param>
		/// <param name="filename"></param>
		/// <returns></returns>
		public string AddAttachment(byte[] content, string filename)
		{
			string cid = NewCid();
			AddAttachment(content, filename, cid);
			return cid;
		}
		/// <summary>
		/// ����ͼƬ
		/// </summary>
		/// <param name="filepath"></param>
		public void AddImage(string filepath)
		{
			AddImage(filepath, NewCid());
		}
		/// <summary>
		/// ����ͼƬ
		/// </summary>
		/// <param name="filepath"></param>
		/// <param name="cid"></param>
		public void AddImage(string filepath, string cid)
		{
			if (filepath != null)
			{
				MailAttachment image = new MailAttachment(filepath);
				image.ContentId = cid;
				this._images.Add(image);
			}
		}
		/// <summary>
		/// �½�һ��CID
		/// </summary>
		/// <returns></returns>
		private string NewCid()
		{
			int attachmentid = this._attachments.Count + this._images.Count + 1;
			return "att" + attachmentid;
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		/// <param name="content"></param>
		/// <param name="filename"></param>
		/// <param name="cid"></param>
		public void AddAttachment(byte[] content, string filename, string cid)
		{
			if (content.Length > 0 && filename.Length > 0)
			{
				MailAttachment attachment = new MailAttachment(content, filename);
				attachment.ContentId = cid;
				this._attachments.Add(attachment);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		/// <param name="filepath"></param>
		/// <param name="cid"></param>
		public void AddAttachment(string filepath, string cid)
		{
			if (filepath != null)
			{
				MailAttachment attachment = new MailAttachment(filepath);
				attachment.ContentId = cid;
				this._attachments.Add(attachment);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		/// <param name="attachment"></param>
		public void AddAttachment(MailAttachment attachment)
		{
			if (attachment != null)
			{
				this._attachments.Add(attachment);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		/// <param name="stream"></param>
		public void AddAttachment(Stream stream)
		{
			if (stream != null)
			{
				this._attachments.Add(stream);
			}
		}
		/// <summary>
		/// �����Զ����ʼ�ͷ
		/// </summary>
		/// <param name="name"></param>
		/// <param name="b"></param>
		public void AddCustomHeader(string name, string b)
		{
			if (name != null && b != null)
			{
				AddCustomHeader(new MailHeader(name, b));
			}
		}
		/// <summary>
		/// �����Զ����ʼ�ͷ
		/// </summary>
		/// <param name="mailheader"></param>
		public void AddCustomHeader(MailHeader mailheader)
		{
			if (mailheader.Name != null && mailheader.Body != null)
			{
				this._customHeaders.Add(mailheader);
			}
		}
		/// <summary>
		/// ���ļ��л�ȡ����
		/// </summary>
		/// <param name="filePath"></param>
		public void GetBodyFromFile(string filePath)
		{
			this._body = GetFileAsString(filePath);
		}
		/// <summary>
		/// ���ļ��л�ȡHTML����
		/// </summary>
		/// <param name="filePath"></param>
		public void GetHtmlBodyFromFile(string filePath)
		{
			this._htmlBody = GetFileAsString(filePath);
		}
		/// <summary>
		/// ��������
		/// </summary>
		public void Reset()
		{
			this._from = null;
			this._replyTo = null;
			this._recipientList.Clear();
			this._ccList.Clear();
			this._bccList.Clear();
			this._customHeaders.Clear();
			this._attachments.Clear();
			this._subject = null;
			this._body = null;
			this._htmlBody = null;
			this._priority = null;
			this._mixedBoundary = null;
			this._altBoundary = null;
			this._charset = null;
			this._notification = false;
		}
		/// <summary>
		/// �������󱣴浽һ���ļ�
		/// </summary>
		/// <param name="filePath"></param>
		public void Save(string filePath)
		{
			StreamWriter sw = File.CreateText(filePath);
			sw.Write(ToString());
			sw.Close();
		}
		/// <summary>
		/// ����MIME��ʽ���ʼ�����Ϣ
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			StringBuilder sbMsg = new StringBuilder();
			sbMsg.Append("Reply-To: ");
			if (!String.IsNullOrEmpty(ReplyTo.Name)) 
				sbMsg.Append(MailEncoder.ConvertHeaderToQP(ReplyTo.Name, this._charset));
			sbMsg.Append(" <" + ReplyTo.Address + ">\r\n");

			sbMsg.Append("From: ");
			if (!String.IsNullOrEmpty(this._from.Name))
				sbMsg.Append(MailEncoder.ConvertHeaderToQP(this._from.Name, this._charset));
			sbMsg.Append(" <" + this._from.Address + ">\r\n");

			sbMsg.Append(this.CreateAddressList(this._recipientList,EAddressType.TO));
			sbMsg.Append(this.CreateAddressList(this._ccList,EAddressType.CC));
			sbMsg.Append(this.CreateAddressList(this._bccList,EAddressType.BCC));

			if (!String.IsNullOrEmpty(this._subject))
				sbMsg.Append("Subject: " + MailEncoder.ConvertHeaderToQP(this._subject, this._charset) + "\r\n");

			sbMsg.Append("Date: " + DateTime.Now.ToUniversalTime().ToString("R") + "\r\n");
			sbMsg.Append(MailConfig.X_MAILER_HEADER + "\r\n");

			if (this._notification)
			{
				sbMsg.Append("Disposition-Notification-To: ");
				if (!String.IsNullOrEmpty(ReplyTo.Name))
					sbMsg.Append(MailEncoder.ConvertHeaderToQP(ReplyTo.Name, this._charset));
				sbMsg.Append("Disposition-Notification-To: <" + ReplyTo.Address + ">\r\n");
			}

			if (this._priority != null)
				sbMsg.Append("X-Priority: " + this._priority + "\r\n");

			for (IEnumerator i = this._customHeaders.GetEnumerator(); i.MoveNext();)
			{
				MailHeader m = (MailHeader) i.Current;
				sbMsg.Append(m.Name+":");
				if (m.Body.Length >= 0)
					sbMsg.Append(MailEncoder.ConvertHeaderToQP(m.Body, this._charset));
				sbMsg.Append(m.Name + ":\r\n");
			}

			sbMsg.Append("MIME-Version: 1.0\r\n");

			//�����ʼ���
			this.GetMessageBody(sbMsg);
			
			return sbMsg.ToString();
		}

		/// <summary>
		/// ��¡һ������
		/// </summary>
		/// <returns></returns>
		public MailMessage Copy()
		{
			return (MailMessage) MemberwiseClone();
		}

		/// <summary>
		/// UTF7���뷽ʽ��ȡ�ļ�����
		/// </summary>
		/// <param name="filePath"></param>
		/// <returns></returns>
		private string GetFileAsString(string filePath)
		{
			FileStream fin = new FileStream(filePath, FileMode.Open, FileAccess.Read);
			int size = (int)fin.Length;
			byte[] bin = new byte[size];
			long rdlen = 0;
			int len;
			StringBuilder sb = new StringBuilder();
			while (rdlen < size)
			{
				len = fin.Read(bin, 0, size);
				sb.Append(Encoding.UTF7.GetString(bin, 0, len));
				rdlen += rdlen + len;
			}

			fin.Close();
			return sb.ToString();
		}

		/// <summary>
		/// ��ȥ�ʼ���MIME�ı�
		/// </summary>
		/// <returns></returns>
		private void GetMessageBody(StringBuilder sbMsg)
		{
			int count = this._attachments.Count;
			if (count>0)
			{
				sbMsg.Append("Content-Type: multipart/mixed;");
				sbMsg.Append("boundary=\"" + this._mixedBoundary + "\"");
				sbMsg.Append("\r\n\r\nThis is a multi-part message in MIME format.");
				sbMsg.Append("\r\n\r\n--" + this._mixedBoundary + "\r\n");
			}

			this.GetInnerMessageBody(sbMsg);
			
			//���Ӹ���
			if (count > 0)
			{
				foreach (MailAttachment attachment in this._attachments)
				{
					sbMsg.Append("\r\n\r\n--" + this._mixedBoundary + "\r\n");
					try
					{
						sbMsg.Append(attachment.ToMime());
					}
					catch (Exception e)
					{
						throw new Exception("SMTP  MailMessage.cs  GetMessageBody���Ӹ������ʼ������"+ e);
					}
				}
				sbMsg.Append("\r\n\r\n--" + this._mixedBoundary + "--\r\n");
			}
		}
		/// <summary>
		/// ��ȡ�ڲ���Ϣ��
		/// </summary>
		/// <returns></returns>
		private void GetInnerMessageBody(StringBuilder sbMsg)
		{
			if (this._images.Count > 0)
			{
				sbMsg.Append("Content-Type: multipart/related;");
				sbMsg.Append("boundary=\"" + this._relatedBoundary + "\"");
				sbMsg.Append("\r\n\r\n--" + this._relatedBoundary + "\r\n");
			}

			this.GetReadableMessageBody(sbMsg);

			if (this._images.Count > 0)
			{
				foreach (MailAttachment image in this._images)
				{
					sbMsg.Append("\r\n\r\n--" + this._relatedBoundary + "\r\n");
					try
					{
						sbMsg.Append(image.ImageToMime());
					}
					catch (Exception e)
					{
						throw new Exception("SMTP  MailMessage.cs  GetInnerMessageBody������ǶͼƬ���ʼ������"+ e);
					}
				}
				sbMsg.Append("\r\n\r\n--" + this._relatedBoundary + "--\r\n");
			}
		}
		/// <summary>
		/// ��ȡ�ɶ����ʼ�������
		/// </summary>
		/// <returns></returns>
		private void GetReadableMessageBody(StringBuilder sbMsg)
		{
			bool alter = this._body != null && this._htmlBody!=null;
			if(alter)
			{
				sbMsg.Append("Content-Type: multipart/alternative;");
				sbMsg.Append("boundary=\"" + this._altBoundary + "\"");
				sbMsg.Append("\r\n\r\nThis is a multi-part message in MIME format.");
				sbMsg.Append("\r\n\r\n--" + this._altBoundary + "\r\n");
			}
			if(this._body!=null)
			{
				sbMsg.Append("Content-Type: text/plain;\r\n");
				sbMsg.Append(" charset=\"" + this._charset + "\"\r\n");
				sbMsg.Append("Content-Transfer-Encoding: base64\r\n\r\n");
				sbMsg.Append(MailEncoder.ConvertToBase64(this._body));
			}
			if(alter) sbMsg.Append("\r\n\r\n--" + this._altBoundary + "\r\n");
			if(this._htmlBody!=null)
			{
				sbMsg.Append("Content-Type: text/html;\r\n");
				sbMsg.Append(" charset=\"" + this._charset + "\"\r\n");
				sbMsg.Append("Content-Transfer-Encoding: base64\r\n\r\n");
				sbMsg.Append(MailEncoder.ConvertToBase64(this._htmlBody));
			}
			if(alter) sbMsg.Append("\r\n\r\n--" + this._altBoundary + "--\r\n");
		}
		/// <summary>
		/// �ֿ��б�
		/// </summary>
		/// <param name="list"></param>
		/// <returns></returns>
		private string CreateAddressList(ArrayList list,EAddressType at)
		{
			if(list.Count==0) return String.Empty;
			StringBuilder sb = new StringBuilder();
			switch(at)
			{
				case EAddressType.TO:sb.Append("To: ");break;
				case EAddressType.CC:sb.Append("CC: ");break;
				case EAddressType.BCC:sb.Append("BCC: ");break;
				default:return String.Empty;
			}
			for (int i=0,size=list.Count;i<size;i++)
			{
				MailAddress a = (MailAddress)list[i];
				if(!String.IsNullOrEmpty(a.Name))
					sb.Append(MailEncoder.ConvertHeaderToQP(a.Name, this._charset));
				sb.Append("<" + a.Address + ">");
				sb.Append(";");
			}
			sb.Remove(sb.Length-1,1);
			sb.Append("\r\n");
			return sb.ToString();
		}
		/// <summary>
		/// ����һ��MixedMimeBoundary
		/// </summary>
		/// <returns></returns>
		private static string GenerateMixedMimeBoundary()
		{
			// Below generates uniqe boundary for each message. These are used to separate mime parts in a message.
			return
				"Part." + Convert.ToString(new Random(unchecked((int) DateTime.Now.Ticks)).Next()) + "." +
				Convert.ToString(new Random(~unchecked((int) DateTime.Now.Ticks)).Next());
		}
		/// <summary>
		/// ����һ��AltMimeBoundary
		/// </summary>
		/// <returns></returns>
		private static string GenerateAltMimeBoundary()
		{
			// Below generates uniqe boundary for each message. These are used to separate mime parts in a message.
			return
				"Part." + Convert.ToString(new Random(~unchecked((int) DateTime.Now.AddDays(1).Ticks)).Next()) + "." +
				Convert.ToString(new Random(unchecked((int) DateTime.Now.AddDays(1).Ticks)).Next());
		}
		/// <summary>
		/// ����һ����ص�MimeBoundary
		/// </summary>
		/// <returns></returns>
		private static string GenerateRelatedMimeBoundary()
		{
			// Below generates uniqe boundary for each message. These are used to separate mime parts in a message.
			return
				"Part." + Convert.ToString(new Random(~unchecked((int) DateTime.Now.AddDays(2).Ticks)).Next()) + "." +
				Convert.ToString(new Random(unchecked((int) DateTime.Now.AddDays(1).Ticks)).Next());
		}
	}
}
