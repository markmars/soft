using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Mail
{
    struct User
    {
        public string Name;
        public string Phone;
        public string Email;
        public string Birth;
    }
}
