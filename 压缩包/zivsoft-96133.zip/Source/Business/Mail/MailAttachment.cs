using System;
using System.IO;
using System.Text;
using Microsoft.Win32;
/**
 * 
 * Created By Lihua At 2006-11-07
 * �����ʼ���������
 * 
 */

namespace Zivsoft.Business.Mail
{
	/// <summary>
	/// MailAttachment ��ժҪ˵����
	/// </summary>
	class MailAttachment
	{
		private string _name;
		private string _mimeType;
		private string _encoding = "base64";
		private string _filePath;
		private int _size = 0;
		private string _encodedFilePath;
		private string _contentid = null;
		/// <summary>
		/// ��ʼ��
		/// </summary>
		private MailAttachment()
		{
			this._encoding = "base64";
			this._encodedFilePath = Path.GetTempFileName();
		}
		/// <summary>
		/// ���캯��
		/// </summary>
		/// <param name="filePath"></param>
		public MailAttachment(string filePath):this()
		{
			this._filePath = filePath;
			if (filePath.Length > 0)
			{
				try
				{
					FileInfo fileInfo = new FileInfo(filePath);
					if (fileInfo.Exists)
					{
						this._mimeType = getMimeType(fileInfo.Extension);
						this._name = fileInfo.Name;
						this._size = (int) fileInfo.Length;
						MailEncoder.ConvertToBase64(filePath, this._encodedFilePath);
					}
				}
				catch (ArgumentNullException)
				{
					throw new ApplicationException("Attachment file does not exist or path is incorrect.");
				}
			}
		}
		/// <summary>
		/// ���캯��
		/// </summary>
		public MailAttachment(byte[] content, string fileName):this()
		{
			try
			{
				this._mimeType = this.getMimeType(fileName.Substring(fileName.Length-3));
				this._name = fileName;
				this._size = content.Length;
				MailEncoder.ConvertToBase64(content, this._encodedFilePath);;
			}
			catch (ArgumentNullException)
			{
				throw new ApplicationException("Attachment file does not exist or path is incorrect.");
			}
		}

		/// <summary>
		/// ���캯��
		/// </summary>
		public MailAttachment(Stream stream, string fileName):this()
		{
			try
			{
				this._mimeType = this.getMimeType(fileName.Substring(fileName.Length-3));
				this._name = fileName;
				this._size = (int) stream.Length;
				MailEncoder.ConvertToBase64(stream, this._encodedFilePath);
			}
			catch (ArgumentNullException)
			{
				throw new ApplicationException("Attachment file does not exist or path is incorrect.");
			}
		}
		/// <summary>
		/// ��������,ɾ����ʱ�������ļ�
		/// </summary>
		~MailAttachment()
		{
			try
			{
				if(null!=this._encodedFilePath && File.Exists(this._encodedFilePath)) 
					File.Delete(this._encodedFilePath);
			}catch{}
		}
		/// <summary>
		/// ����
		/// </summary>
		public string Name
		{
			get { return this._name; }
			set { this._name = value; }
		}
		/// <summary>
		/// ������ţ�����Ƕʱ������
		/// </summary>
		public string ContentId
		{
			get { return this._contentid; }
			set { this._contentid = value; }
		}
		/// <summary>
		/// ý������
		/// </summary>
		public string MimeType
		{
			get { return this._mimeType; }
			set { this._mimeType = value; }
		}
		/// <summary>
		/// ���뷽ʽ,һ����base64
		/// </summary>
		public string Encoding
		{
			get { return this._encoding; }
		}
		/// <summary>
		/// ԭʼ�ļ�·�������ͨ��·��ָ���ķ�ʽ
		/// </summary>
		public string FilePath
		{
			get { return this._filePath; }
		}
		/// <summary>
		/// ������С
		/// </summary>
		public int Size
		{
			get { return this._size; }
		}
		/// <summary>
		/// ��ű�������ļ�·��
		/// </summary>
		internal string EncodedFilePath
		{
			get { return this._encodedFilePath; }
		}
		/// <summary>
		/// ��ȡý������
		/// </summary>
		/// <param name="fileExtension"></param>
		/// <returns></returns>
		private string getMimeType(string fileExtension)
		{
			RegistryKey extKey = Registry.ClassesRoot.OpenSubKey(fileExtension);
			if(null == extKey)
			{
				return "application/octet-stream"; 
			}
			object contentType = extKey.GetValue("Content Type");
			if (contentType != null)
			{
				return contentType.ToString();
			}
			else
			{
				return "application/octet-stream";
			}
		}
		/// <summary>
		/// �Ƚϸ����Ƿ���ͬ���������ƱȽ�
		/// </summary>
		/// <param name="attachment"></param>
		/// <returns></returns>
		public int CompareTo(object attachment)
		{
			MailAttachment att = attachment as MailAttachment;
			if(null == att)
			{
				throw new ArgumentException("�Ƚ��˴�������!");
			}
			return Name.CompareTo(att.Name);
		}
		/// <summary>
		/// һ�㸽��ר����Mime�ı�
		/// </summary>
		/// <returns></returns>
		public string ToMime()
		{
			return this.ToMime("attachment");
		}
		/// <summary>
		/// ͼƬת����Mime�ı�
		/// </summary>
		/// <returns></returns>
		public string ImageToMime()
		{
			return this.ToMime("images");
		}
		/// <summary>
		/// ������������Mime���ݷ���
		/// </summary>
		/// <param name="disposition"></param>
		/// <returns></returns>
		private string ToMime(string disposition)
		{
			StringBuilder sb = new StringBuilder();
			if (ContentId != null)
			{
				sb.AppendFormat("Content-ID: <{0}>\r\n",ContentId);
			}
			sb.AppendFormat("Content-Type: {0};\r\n",this._mimeType);
			sb.AppendFormat(" name=\"{0}\"\r\n",this._name);
			sb.AppendFormat("Content-Transfer-Encoding: {0}\r\n",this._encoding);
			sb.AppendFormat("Content-Disposition: {0};\r\n",disposition);
			sb.AppendFormat(" filename=\"{0}\"\r\n\r\n",this._name);
			FileStream fin = new FileStream(this._encodedFilePath, FileMode.Open, FileAccess.Read);
			byte[] bin;
			while (fin.Position != fin.Length)
			{
				//Լ���ʼ�76���ֽ�Ϊһ��
				bin = new byte[76];
				int len = fin.Read(bin, 0, 76);
				sb.Append(System.Text.Encoding.Default.GetString(bin, 0, len) + "\r\n");
			}
			fin.Close();
			return sb.ToString();
		}
	}
}