using System;
using System.Collections;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

/**
 * 
 * Created By Lihua At 2006-11-08
 * ����POP�ʼ����ܿͻ���
 * 
 */

namespace Zivsoft.Business.Mail
{
	/// <summary>
	/// PopClient ��ժҪ˵����
	/// </summary>
	sealed class PopClient
	{
		//ͨ�ſ�ʼ
		public event EventHandler CommunicationBegan;
		//ͨ�ŷ���
		public event EventHandler CommunicationOccured;
		//ͨ�Ŷ�ʧ
		public event EventHandler CommunicationLost;
		//��֤��ʼ
		public event EventHandler AuthenticationBegan;
		//��֤����
		public event EventHandler AuthenticationFinished;
		//��Ϣ���俪ʼ
		public event EventHandler MessageTransferBegan;
		//��Ϣ�������
		public event EventHandler MessageTransferFinished;
		//���ݵ����¼�
		public event DataEventHandler DataArrival;
		//�����¼�����
		public delegate void DataEventHandler(int mailsize);

		private TcpClient _tcp;
		private StreamReader _reader;
		private StreamWriter _writer;
		private NetworkStream _netstream;
		private string _error;
		private int _recvTimeOut;
		private int _sendTimeOut;
		private int _sleepTime;
		private string _basePath;
		private bool _autoDecodeMSTNEF;
		private string _popTimestamp;
		private string _cmdResponse;
		private int _bufferSize;
		private string _host;
		private int _port;
		private string _user;
		private string _pwd;
		private EAuthMethod _method;

		/// <summary>
		/// ���캯��
		/// </summary>
		public PopClient()
		{
			this._error = String.Empty;
			this._recvTimeOut = 60000;
			this._sendTimeOut = 60000;
			this._autoDecodeMSTNEF=true;
			this._sleepTime=500;
			this._cmdResponse = "";

			this._bufferSize = 4096;

			this._host = String.Empty;
			this._port = 110;
		}
		/// <summary>
		/// ���캯��
		/// </summary>
		public PopClient(string host,int port,string user,string passwd,EAuthMethod am):this()
		{
			this._host = host;
			this._port = port;
			this._user = user;
			this._pwd = passwd;
			this._method = am;
			this.Login();
		}
		/// <summary>
		/// ��½
		/// </summary>
		private void Login()
		{
			this.Connect(this._host, this._port);
			this.Authenticate(this._user,this._pwd,this._method);
		}
		/// <summary>
		/// ������Ϣ��ʾ
		/// </summary>
		public string Error
		{
			get{return this._error;}
		}
		/// <summary>
		/// POP��������ʱ���
		/// </summary>
		public string APOPTimestamp
		{
			get{return this._popTimestamp;}
		}
		/// <summary>
		/// ���������ڼ�ļ�Ъʱ��
		/// </summary>
		public int SleepTime
		{
			get{return this._sleepTime;}
			set{this._sleepTime=value;}
		}
		/// <summary>
		/// �Զ�����MSTNEF
		/// </summary>
		public bool AutoDecodeMSTNEF
		{
			get{return this._autoDecodeMSTNEF;}
			set{this._autoDecodeMSTNEF=value;}
		}
		/// <summary>
		/// ��·��
		/// </summary>
		public string BasePath
		{
			get
			{
				return this._basePath;
			}
			set
			{
				try
				{
					if(value.EndsWith("\\"))
						this._basePath=value;
					else
						this._basePath=value+"\\";
				}
				catch
				{
				}
			}
		}
		/// <summary>
		/// ���ܵ�ʱ��ȴ��
		/// </summary>
		public int ReceiveTimeOut
		{
			get{return this._recvTimeOut;}
			set{this._recvTimeOut=value;}
		}
		/// <summary>
		/// ����ʱ��ȴ��
		/// </summary>
		public int SendTimeOut
		{
			get{return this._sendTimeOut;}
			set{this._sendTimeOut=value;}
		}
		/// <summary>
		/// ��������С
		/// </summary>
		public int BufferSize
		{
			get{return this._bufferSize;}
			set{this._bufferSize=value;}
		}
		/// <summary>
		/// �����ϴη��������ص���Ϣ
		///		�����Ǵ�����Ϣ.
		/// </summary>
		public string LastResponse
		{
			get{return this._cmdResponse;}
		}
		/// <summary>
		/// ��ȡʱ���
		/// </summary>
		/// <param name="strResponse"></param>
		private void ExtractApopTimestamp(string strResponse)
		{
			Match match = Regex.Match(strResponse, "<.+>");
			if (match.Success)
			{
				this._popTimestamp = match.Value;
			}
		}
		/// <summary>
		/// ����һ�����POP������
		///		��������
		///		�Ƿ����������ʾ
		/// </summary>
		/// <returns>true if server responded "+OK"</returns>
		private bool SendCommand(string cmd, bool slient)
		{
			try
			{
				this._writer.WriteLine(cmd);
				return this.CheckReply();
			}
			catch(Exception e)
			{
				if(!slient) this._error = cmd + ":" +e.Message;
				this.Login();
				return false;
			}
		}
		/// <summary>
		/// ��������
		///		Ĭ��û�д����Ӧ
		/// </summary>
		private bool SendCommand(string cmd)
		{
			return SendCommand(cmd,false);
		}
		/// <summary>
		/// ��������
		///		���Ͳ��ɹ�����0
		/// </summary>
		/// <returns></returns>
		private int SendCommandIntResponse(string cmd)
		{
			if(SendCommand(cmd))
			{
				try
				{
					return System.Int32.Parse(this._cmdResponse.Split(' ')[1]);
				}
				catch(Exception e)
				{
                    throw e;
				}
			}
			return 0;
		}
		/// <summary>
		/// У���������Ӧ�Ƿ�����
		/// </summary>
		private bool CheckReply()
		{
			int count=0;
			while(count++<10)
			{
				if(this._netstream.DataAvailable) break;
				else Thread.Sleep(this._sleepTime);
			}
			this._cmdResponse = this._reader.ReadLine();
			if(null!=this._cmdResponse && this._cmdResponse.Length>0 && this._cmdResponse.StartsWith(MailReply.RESPONSE_OK)) return true;
			return false;
		}
		/// <summary>
		/// ���ӵ�������
		/// </summary>
		public void Connect(string host,int port)
		{
			if(this.CommunicationBegan !=null) this.CommunicationBegan(this,EventArgs.Empty);
			this._tcp = new TcpClient();
			this._tcp.ReceiveTimeout = this._recvTimeOut;
			this._tcp.SendTimeout = this._sendTimeOut;
			this._tcp.ReceiveBufferSize = this._bufferSize;
			this._tcp.SendBufferSize = this._bufferSize;
			try
			{
				this._tcp.Connect(host,port);				
			}
			catch(SocketException e)
			{				
				throw new Exception("�޷�����POP������",e);
			}
			this._netstream = this._tcp.GetStream();
			this._reader = new StreamReader(this._netstream,Encoding.Default,true);
			this._writer = new StreamWriter(this._netstream);
			this._writer.AutoFlush = true;
            if (this.CheckReply()) this.ExtractApopTimestamp(this._cmdResponse);
            else {
                throw new Exception(_cmdResponse); 
            }
			if(this.CommunicationOccured != null) this.CommunicationOccured(this,EventArgs.Empty);
		}

		/// <summary>
		/// ��������
		/// </summary>
		~PopClient()
		{
			this.Quit();
			this._tcp.Close();
			if(this.CommunicationLost != null) this.CommunicationLost(this,EventArgs.Empty);
		}
		/// <summary>
		/// ��֤�û���/����
		/// </summary>
		public void Authenticate(string user,string passwd)
		{
			this.Authenticate(user,passwd,EAuthMethod.USERPASS);
		}
		/// <summary>
		/// ��֤�û���/����
		/// </summary>
		private void Authenticate(string user,string passwd,EAuthMethod am)
		{
			if(am==EAuthMethod.USERPASS) this.AuthenticateUsingUSER(user,passwd);
			else if(am==EAuthMethod.APOP) this.AuthenticateUsingAPOP(user,passwd);
			else if(am==EAuthMethod.TRYBOTH)
			{
				try
				{
					AuthenticateUsingUSER(user,passwd);
				}
				catch
				{
					AuthenticateUsingAPOP(user,passwd);
				}
			}
		}
		/// <summary>
		/// ��֤�û���/����
		/// </summary>
		private void AuthenticateUsingUSER(string user,string passwd)
		{
			if(this.AuthenticationBegan != null) this.AuthenticationBegan(this,EventArgs.Empty);

			if(!SendCommand("USER " + user))
			{
				throw new Exception("����");
			}
			if(!SendCommand("PASS " + passwd))
			{
				//if(this._cmdResponse.ToLower().IndexOf("lock")!=-1) throw new MailException("");
				throw new Exception("");
			}
			if(this.AuthenticationFinished != null) this.AuthenticationFinished(this,EventArgs.Empty);
		}

		/// <summary>
		/// ��֤�û���/����
		/// </summary>
		private void AuthenticateUsingAPOP(string user,string passwd)
		{
			if(this.AuthenticationBegan != null) this.AuthenticationBegan(this,EventArgs.Empty);
			if(!SendCommand("APOP " + user + " " + MailEncoder.GetMD5HashHex(passwd)))throw new Exception("");
			if(this.AuthenticationFinished != null) this.AuthenticationFinished(this,EventArgs.Empty);
		}

		/// <summary>
		/// ��ȡ�ʼ�����
		/// </summary>
		public int GetMessageCount()
		{			
			return SendCommandIntResponse("STAT");
		}
		/// <summary>
		/// ��ȡĳ���ʼ��ĳߴ�
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		public int GetMailSize(int index)
		{
			return SendCommandIntResponse("LIST " + index.ToString());
		}
		/// <summary>
		/// ��ȡ�����ʼ��Ĵ�С
		///		ע�⣺����ù���û���ʼ���ɾ��
		/// </summary>
		public ArrayList GetMailSize()
		{
			ArrayList sizes=new ArrayList();
			if(SendCommand("LIST"))
			{
				string text=this._reader.ReadLine();
				while (text!=null&&text!=".")
				{
					sizes.Add(int.Parse(text.Split(' ')[1]));
					text=this._reader.ReadLine();
				}
				return sizes;
			}
			else return new ArrayList(0);
		}
		/// <summary>
		/// �����˳�����
		/// </summary>
		/// <returns></returns>
		public bool Quit()
		{
			return SendCommand("QUIT");
		}
		/// <summary>
		/// ���ַ������
		/// </summary>
		/// <returns></returns>
		public bool Noop()
		{
			return SendCommand("NOOP");
		}
		/// <summary>
		/// ���÷�����
		/// </summary>
		/// <returns></returns>
		public bool Rset()
		{
			return SendCommand("RSET");
		}
		/// <summary>
		/// ��ȡָ���ʼ���UID
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		public string GetMessageUID(int index)
		{
			if(SendCommand("UIDL " + index)) 
			{
				string[] arr = this._cmdResponse.Split(' ');
				if(arr.Length>2) return arr[2];
			}
			return String.Empty;			
		}
		/// <summary>
		/// ��ȡ���е��ʼ�UID�б�
		/// </summary>
		/// <returns></returns>
		public ArrayList GetMessageUIDs()
		{
			ArrayList uids=new ArrayList();
			if(SendCommand("UIDL"))
			{
				string text=this._reader.ReadLine();
				while (text!=null && text!=".")
				{
					uids.Add(text.Split(' ')[1]);
					text = this._reader.ReadLine();
				}
				return uids;
			}
			else return new ArrayList(0);
		}

		/// <summary>
		/// ��ȡ�ʼ���Ϣ
		/// </summary>
		public string GetMessage(int index)
		{			
			if(this.MessageTransferBegan != null) this.MessageTransferBegan(this,EventArgs.Empty);
			string msg = this.FetchMessage(index,false);
			if(this.MessageTransferFinished != null) this.MessageTransferFinished(this,EventArgs.Empty);
			return msg;
		}
		/// <summary>
		/// ������Ż�ȡ�ʼ�ͷ
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		public string GetMessageHeader(int index)
		{
			if(this.MessageTransferBegan != null) this.MessageTransferBegan(this,EventArgs.Empty);
			string msg =this.FetchMessage(index, true);
			if(this.MessageTransferFinished != null) this.MessageTransferFinished(this,EventArgs.Empty);
			return msg;
		}
		/// <summary>
		/// ��ȡ�ʼ�
		/// </summary>
		/// <param name="onlyHeader"></param>
		/// <returns></returns>
		private string FetchMessage(int index,bool onlyHeader)
		{
			string cmd="RETR ";
			if(onlyHeader) cmd = "TOP ";
			cmd += index;
			if(!SendCommand(cmd)) return null;
			StringBuilder sbMsg = new StringBuilder();
			string text = this._reader.ReadLine();
			bool flag = this.DataArrival != null;
			while (text!=".")
			{
				sbMsg.Append(text + "\r\n");
				if(flag) this.DataArrival(sbMsg.Length);
				text = this._reader.ReadLine();
			}
			sbMsg.Append(".\r\n");
			return sbMsg.ToString();
		}
		/// <summary>
		/// ����UIDɾ���ʼ�
		/// </summary>
		public bool DeleteMessage(int intMessageIndex) 
		{
			return SendCommand("DELE " + intMessageIndex.ToString());
		}
		/// <summary>
		/// ɾ��������ȫ���ʼ�
		/// </summary>
		/// <returns></returns>
		public bool DeleteAllMessages() 
		{
			int messageCount=GetMessageCount();
			for(int messageItem=messageCount;messageItem>0;messageItem--)
			{
				if (!DeleteMessage(messageItem))
					return false;
			}
			return true;
		}
	}
}
