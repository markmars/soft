using System.IO;
/**
 * 
 * Created By Lihua At 2006-11-07
 * �ʼ����õĻ�����Ϣ
 * 
 */

namespace Zivsoft.Business.Mail
{
	/// <summary>
	/// MailConfig ��ժҪ˵����
	/// </summary>
	class MailConfig
	{
		private MailConfig()
		{
		}
		public static string[] MailHeadKeywords = {
														"TO", "CC", "BCC", "FROM", "CHARSET", "REPORT-TYPE", "REPLY-TO",
														"BOUNDARY", "KEYWORDS", "RECEIVED", "IMPORTANCE",
														"DISPOSITION-NOTIFICATION-TO", "MIME-VERSION", "SUBJECT",
														"THREAD-TOPIC", "RETURN-PATH", "MESSAGE-ID", "DATE",
														"CONTENT-LENGTH", "CONTENT-TRANSFER-ENCODING", "CONTENT-TYPE",
														"X-ORIGINATING-IP", "USER-AGENT", "X-MAILER", "X-REMOVE",
														"X-PRIORITY", "X-BRIGHTMAIL-TRACKER", "DELIVERED-TO", "FILENAME", "NAME"
													};
		public static string[] PictureExts = {".jpg",".bmp",".ico",".gif",".png"};
		/// <summary>
		/// SMTP������
		/// </summary>
		public static string SmtpHost = "localhost";
		/// <summary>
		/// �˿�
		/// </summary>
		public static int SmtpPort = 25;
		/// <summary>
		/// ��ʱĿ¼
		/// </summary>
		public static string TempPath = Path.GetTempPath();
		/// <summary>
		/// �����ַ
		/// </summary>
		public static bool VerifyAddresses = false;
		/// <summary>
		/// �汾
		/// </summary>
		public static readonly string Version = " 1.0 ";
		/// <summary>
		/// ������ǩ��
		/// </summary>
		public static string X_MAILER_HEADER = "X-Mailer:  OKCRM ";
	}
}
