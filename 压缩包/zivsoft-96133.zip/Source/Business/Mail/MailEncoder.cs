using System;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Zivsoft.Utils;

/**
 * 
 * Created By Lihua At 2006-11-07
 * �����ʼ��������
 * 
 */
namespace Zivsoft.Business.Mail
{
	/// <summary>
	/// MailEncoder ��ժҪ˵����
	/// </summary>
	class MailEncoder
	{
		private MailEncoder()
		{
		}
		/// <summary>
		/// �Ƿ���QP�����
		/// </summary>
		/// <param name="ctEncoding"></param>
		/// <returns></returns>
		public static bool IsQuotedPrintable(string ctEncoding)
		{
			if (ctEncoding != null) return (ctEncoding.ToLower() == "quoted-printable");
			return false;
		}
		/// <summary>
		/// �Ƿ���Base64����
		/// </summary>
		/// <param name="ctEncoding"></param>
		/// <returns></returns>
		public static bool IsBase64(string ctEncoding)
		{
			if (ctEncoding != null) return (ctEncoding.ToLower() == "base64");
			return false;
		}
		/// <summary>
		/// </summary>
		public static bool SaveByteContentToFile(string fileName, byte[] bs)
		{
			return FileUtils.SaveStringAsFile(Encoding.Default.GetString(bs), fileName);
		}
		/// <summary>
		/// </summary>
		public static bool SavePlainTextToFile(string strFile, string strText, bool blnReplaceExists)
		{
			if (blnReplaceExists)
			{
				return FileUtils.SaveStringAsFile(strText, strFile);
			}
			return false;
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="strText"></param>
		/// <returns></returns>
		public static string[] SplitOnSemiColon(string strText)
		{
			if (strText == null)
				throw new ArgumentNullException("strText", "Argument was null");

			int indexOfColon = strText.IndexOf(";");
			if (indexOfColon == -1)
			{
				return new string[]{strText};
			}
			return MailEncoder.GetColonValue(strText, indexOfColon);
		}
		/// <summary>
		/// �ı��ı��ı����ַ���
		/// </summary>
		public static string Change(string text, string charset)
		{
			if (String.IsNullOrEmpty(charset))
			{
				return text;
			}
			byte[] bs = Encoding.Default.GetBytes(text);
			return Encoding.GetEncoding(charset).GetString(bs);
		}
		/// <summary>
		/// ��ȡBoundary��βλ��
		/// </summary>
		public static int GetAttBoundaryEnd(string body, string boundary, int start)
		{
			int intReturn = body.IndexOf(boundary, start);
			//�ҵ�boundary�ı߽�󣬻���20���ַ���������20���ַ������Ƿ��лس����з�
			//����еĻ����س����з����ʼ����ݵı߽�
			int rollBack = intReturn - 20;
			if (rollBack > 0)
			{
				string toSearchBoudary = body.Substring(rollBack, 20);
				int flag = toSearchBoudary.LastIndexOf("\r\n");
				if (flag != -1)
				{
					toSearchBoudary = toSearchBoudary.Substring(0, flag);
					bool bolFlag = toSearchBoudary.EndsWith("\r\n");
					while (bolFlag)
					{
						toSearchBoudary = toSearchBoudary.Substring(0, (toSearchBoudary.Length - "\r\n".Length));
						flag -= ("\r\n".Length);
						bolFlag = toSearchBoudary.EndsWith("\r\n");
					}
				}
				intReturn = (intReturn - 20 + flag);
			}
			return intReturn;
		}
		/// <summary>
		/// ��ȡ�ʼ�ͷ��ֵ
		/// </summary>
		public static string[] GetHeadersValue(string strRawHeader)
		{
			if (strRawHeader == null)
				throw new ArgumentNullException("strRawHeader", "Argument was null");
			int indexOfColon = strRawHeader.IndexOf(":");
			if (indexOfColon == -1)
			{
				indexOfColon = strRawHeader.IndexOf("=");
			}
			return GetColonValue(strRawHeader, indexOfColon);
		}
		/// <summary>
		/// ��ȡ���õ��ı�
		/// </summary>
		public static string GetQuotedValue(string strText, string strSplitter, string strTag)
		{
			if (strText == "")
				return "";
			if (strText == null)
				throw new ArgumentNullException("strText", "Argument was null");

			try
			{
				int indexOfstrSplitter = strText.IndexOf(strSplitter);
				string str1 = strText.Substring(0, indexOfstrSplitter).Trim();
				string str2 = "";
				if (str1.ToLower() != strTag)
				{
					return str2;
				}
				if (indexOfstrSplitter < strText.Length - 1)
				{
					str2 = strText.Substring(indexOfstrSplitter + 1).Trim();
					int pos = str2.IndexOf("\"");
					if (pos != -1)
					{
						int pos2 = str2.IndexOf("\"", pos + 1);
						str2 = str2.Substring(pos + 1, pos2 - pos - 1);
					}
				}
				return str2;
			}
			catch
			{
				return "";
			}
		}
		/// <summary>
		/// ��ȡͷ��ֵ
		/// </summary>
		private static string[] GetColonValue(string strRawHeader, int index)
		{
			string[] array = new string[2] {"", ""};
			if (index == -1)
			{
				return array;
			}
			array[0] = strRawHeader.Substring(0, index).Trim();
			if (index < strRawHeader.Length - 1)
			{
				array[1] = strRawHeader.Substring(index + 1).Trim();
			}
			return array;
		}
		/// <summary>
		/// ��ĳ��λ�ÿ�ʼ����Quoted-Printable������ַ���
		/// </summary>
		public static string ConvertHexContent(string hexstr, Encoding encode, int start)
		{
			if (start >= hexstr.Length) return hexstr;
			StringBuilder sbEncoded = new StringBuilder();
			while (start < hexstr.Length)
			{
				string strHex = "";
				string temp = hexstr.Substring(start, 3);
				bool isBegin = false;
				int count = 0;
				while (start < hexstr.Length)
				{
					if (temp[0] == '=')
					{
						if (!temp.EndsWith("3D"))
						{
							strHex = String.Concat(strHex,temp);
							isBegin = true; //we reach Quoted-Printable string, put it into buffer
							count++;
						}
						else //if it ends with 3D, it is "="
						{
							if (isBegin && (count%2 == 0)) break;
							if(!temp.EndsWith("\r\n")) sbEncoded.Append("=");
						}
						start += 3;
					}
					else
					{
						if (isBegin) break;
						sbEncoded.Append(temp[0]); //not Quoted-Printable string, put it into buffer
						start++;
					}
				}
				//decode Quoted-Printable string
				sbEncoded.Append(MailEncoder.ConvertHexToString(strHex, encode));
			}
			return sbEncoded.ToString();
		}
		/// <summary>
		/// ����Quoted-Printable�ִ�
		/// </summary>
		public static string ConvertHexToString(string hexstr, string encoding)
		{
			try
			{
				return ConvertHexToString(hexstr, System.Text.Encoding.GetEncoding(encoding));
			}
			catch
			{
				return ConvertHexContent(hexstr);
			}
		}
		/// <summary>
		/// ����Quoted-Printable�ִ�
		/// </summary>
		public static string ConvertHexToString(string hexstr, Encoding encode)
		{
			if (hexstr == null || hexstr.Length==0) return "";
			if (hexstr.StartsWith("=")) hexstr = hexstr.Substring(1);
			string[] aHex = hexstr.Split('=');
			int size = aHex.Length;
			byte[] abyte = new Byte[size];
			for (int i = 0; i < size; i++) 
			{
				try{
					abyte[i]=byte.Parse(aHex[i],NumberStyles.HexNumber);
				}catch{
					abyte[i] = 0;
				}
			}
			return encode.GetString(abyte);
		}
		/// <summary>
		/// ��λ��0��ʼ��Ĭ�ϱ��뷽ʽ����Quoted-Printable�����ִ�
		///		Quoted-Printable������ַ���
		/// </summary>
		public static string ConvertHexContent(string hexstr)
		{
			if (String.IsNullOrEmpty(hexstr)) return hexstr;
			return ConvertHexContent(hexstr, Encoding.Default, 0);
		}
		/// <summary>
		/// �Ƴ���Base64�����ַ�
		/// �ж��ַ����ĳ����ܷ�4����.�������,��˵��BASE64������ַ���������.
		/// �ȰѲ����λ�ò���'=' ,���ж����4λ�Ƿ��� '=' ,����� ,��ȥ��
		/// ����ܱ�4����,���߲�����=��β,ֱ�ӷ����ַ���
		/// </summary>
		public static string RemoveNonB64(string text)
		{
			if(null == text) return "";
			text = text.Replace("\0", "");
			int len = text.Length;
			int residual = len%4;
			if (residual == 0) return text;
			string tail = text.Substring(len-residual);
			string e4="====";
			if(e4.StartsWith(tail)) return text.Substring(0,len-residual);
			return String.Concat(text,e4.Substring(residual));
		}
		/// <summary>
		/// ����Base64�ִ�=��Ĭ���ַ����ִ�
		/// </summary>
		public static string DecodeB64Default(string text)
		{
			return Encoding.Default.GetString(MailEncoder.DecodeB64(text));
		}

		/// <summary>
		/// ָ���ַ�������Base64�ִ�,���û���ҵ��ַ���
		/// �����Ĭ���ַ���
		/// </summary>
		public static string DecodeB64(string text, string encoding)
		{
			try
			{
				return Encoding.GetEncoding(encoding).GetString(MailEncoder.DecodeB64(text));
			}
			catch
			{
				return MailEncoder.DecodeB64Default(text);
			}
		}
		/// <summary>
		/// Base64������ַ����ֽڻ�
		///		���ڴ��ı����Ƚ��е���ת�����������ת��ʧ��
		///		����ȫ��ת��
		/// </summary>
		/// <param name="text"></param>
		/// <returns></returns>
		public static byte[] DecodeB64(string text)
		{
			if(String.IsNullOrEmpty(text)) return new byte[0];
			byte[] bs = new byte[text.Length/4*3];
			int index = 0;
			int flag = 0;
			try
			{
				///��\r\nΪ�ָ����ÿ�е���ת����byte ��Ϊȫ��ת����
				/// ���ֹ�����û�����⣬��ת�����˵����
				StringReader reader = new StringReader(text);
				while(true)
				{
					string line = reader.ReadLine();
					if(line==null) break;
					if(line == "") continue;
					byte[] temp = Convert.FromBase64String(MailEncoder.RemoveNonB64(line));
					Array.Copy(temp,0,bs,index,temp.Length);
					index += temp.Length;
				}
			}catch (Exception e)
			{
				flag = 1;
				throw new Exception("DecodeB64():"+e);
			}
			//������н���ʧ�ܣ�������ȫ������
			if (flag == 1)
			{
				try
				{
					bs = Convert.FromBase64String(MailEncoder.RemoveNonB64(text));
				}
				catch (Exception e)
				{
					bs = Encoding.Default.GetBytes(text);
					throw new Exception("deCodeB64():"+e);
				}
			}
			return bs;
		}
		/// <summary>
		/// ����һ���ı�
		/// </summary>
		/// <param name="strText">Encoded text</param>
		/// <returns>Decoded text</returns>
		public static string DecodeLine(string strText)
		{
			return DecodeText(RemoveWhiteBlanks(strText));
		}
		/// <summary>
		/// ɾ������ʾ�ַ�
		/// </summary>
		public static string RemoveWhiteBlanks(string text)
		{
			return text.Replace("\0", "").Replace("\r\n", "");
		}
		/// <summary>
		/// ɾ�������ַ�
		/// </summary>
		public static string RemoveQuote(string text)
		{
			if (text.StartsWith("\"")) text = text.Substring(1);
			if (text.EndsWith("\"")) text = text.Substring(0, text.Length - 1);
			return text;
		}
		/// <summary>
		/// ��ͷ�н�����ʱ��
		/// </summary>
		/// <param name="strDate">Encoded MIME date time</param>
		/// <returns>Decoded date time info</returns>
		public static string ParseEmailDate(string strDate)
		{
			string strRet = strDate.Trim();

			try
			{
				DateTime dt=Convert.ToDateTime(strRet);
				return strRet;
			}
			catch
			{
			}

			try
			{

				int indexOfTag = strRet.IndexOf(",");
				if (indexOfTag != -1)
				{
					strRet = strRet.Substring(indexOfTag + 1);
				}
			
				//�п��ܻ�+- ��GMT��CSTͬʱ���������ж�2��
				if (strRet.IndexOf("+") != -1
					|| strRet.IndexOf("-") != -1
					|| strRet.IndexOf("GMT") != -1
					|| strRet.IndexOf("CST") != -1)
					strRet = strRet.Substring(0, strRet.LastIndexOf(" "));

				if (strRet.IndexOf("+") != -1
					|| strRet.IndexOf("-") != -1
					|| strRet.IndexOf("GMT") != -1
					|| strRet.IndexOf("CST") != -1)
					strRet = strRet.Substring(0, strRet.LastIndexOf(" "));
			}
			catch
			{

			}
			return strRet.Trim();
		}
		/// <summary>
		/// Parse file name from MIME header
		/// </summary>
		/// <param name="strHeader">MIME header</param>
		/// <returns>Decoded file name</returns>
		public static string ParseFileName(string strHeader)
		{
			string strTag = "filename=";
			int intPos = strHeader.ToLower().IndexOf(strTag);
			if (intPos == -1)
			{
				strTag = "name=";
				intPos = strHeader.ToLower().IndexOf(strTag);
			}
			string strRet = String.Empty;
			if (intPos != -1)
			{
				strRet = strHeader.Substring(intPos + strTag.Length);
				intPos = strRet.ToLower().IndexOf(";");
				if (intPos != -1)
					strRet = strRet.Substring(1, intPos - 1);
				strRet = RemoveQuote(strRet);
			}

			strRet.Replace("\"", "");
			return strRet;
		}
		/// <summary>
		/// ���ʼ�ͷ�л�ȡ�ʼ���ַ
		/// </summary>
		public static bool ParseEmailAddress(string strEmailAddress, ref string strUser, ref string strAddress)
		{
			int indexOfAB = strEmailAddress.Trim().LastIndexOf("<");
			int indexOfEndAB = strEmailAddress.Trim().LastIndexOf(">");
			strUser = strEmailAddress;
			strAddress = strEmailAddress;
			if (indexOfAB >= 0 && indexOfEndAB >= 0)
			{
				if (indexOfAB > 0)
				{
					strUser = strUser.Substring(0, indexOfAB - 1);
					strUser = DecodeString(strUser);
				}
				strUser = strUser.Trim();
				strUser = strUser.Trim('\"');
				strAddress = strAddress.Substring(indexOfAB + 1, indexOfEndAB - (indexOfAB + 1));
			}
			else
			{
				if (strAddress.IndexOf("@") == -1)
				{
					strAddress = "";
				}
			}
			strUser = strUser.Trim();
			strUser = DecodeText(strUser);
			strAddress = strAddress.Trim();

			return true;
		}
		/// <summary>
		/// �����ı�
		/// </summary>
		public static string DecodeText(string strText)
		{
			try
			{
				string strRet = "";
				string[] strParts = Regex.Split(strText, "\r\n");
				string strBody = "";
				const string strRegEx = @"\=\?(?<Charset>\S+)\?(?<Encoding>\w)\?(?<Content>\S+)\?\=";
				Match m = null;

				for (int i = 0; i < strParts.Length; i++)
				{
					m = Regex.Match(strParts[i], strRegEx);
					if (m.Success)
					{
						strBody = m.Groups["Content"].Value;

						switch (m.Groups["Encoding"].Value.ToUpper())
						{
							case "B":
								strBody = MailEncoder.DecodeB64(strBody, m.Groups["Charset"].Value);
								break;
							case "Q":
								//	strBody=DecodeQP.ConvertHexContent(strBody);//, m.Groups["Charset"].Value);
								strBody = MailEncoder.ConvertHexContent(strBody, Encoding.GetEncoding(m.Groups["Charset"].Value), 0);
								break;
							default:
								break;
						}
						strRet += strBody;
					}
					else
					{
						if (!IsValidMIMEText(strParts[i]))
							strRet += strParts[i];
						else
						{
							//blank text
						}
					}
				}
				return strRet;
			}
			catch
			{
				return strText;
			}
		}
		/// <summary>
		/// �����Ƿ�ϸ��Mime�ı�
		/// </summary>
		private static bool IsValidMIMEText(string text)
		{
			int intPos = text.IndexOf("=?");
			return (intPos != -1 && text.IndexOf("?=", intPos + 6) != -1 && text.Length > 7);
		}
		/// <summary>
		/// ת����Base64����
		/// </summary>
		public static void ConvertToBase64(string inputFilePath, string outputFilePath)
		{
			//Create the file streams to handle the input and output files.
			FileStream fin = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read);
			ConvertToBase64(fin, outputFilePath);
			fin.Close();
		}

		/// <summary>
		/// ת����Base64����
		/// </summary>
		public static void ConvertToBase64(Stream inputStream, string outputFilePath)
		{
			//Create the file streams to handle the input and output files.
			FileStream fout = new FileStream(outputFilePath, FileMode.OpenOrCreate, FileAccess.Write);
			fout.SetLength(0);

			ToBase64Transform transformer = new ToBase64Transform();

			//Create variables to help with read and write below.
			//This is intermediate storage for the encryption:
			byte[] bin = new byte[inputStream.Length/transformer.InputBlockSize*transformer.OutputBlockSize];
			long rdlen = 0; //This is the total number of bytes written.
			long totlen = inputStream.Length; //This is the total length of the input file.
			int len; //This is the number of bytes to be written at a time.

			CryptoStream encStream = new CryptoStream(fout, transformer, CryptoStreamMode.Write);

			//Read from the input file, then encrypt and write to the output file.
			while (rdlen < totlen)
			{
				len = inputStream.Read(bin, 0, (int) inputStream.Length);
				encStream.Write(bin, 0, len);
				//inputBlock size(3)
				rdlen = (rdlen + ((len/transformer.InputBlockSize)*transformer.OutputBlockSize));
			}

			encStream.Close();
			fout.Close();
		}

		/// <summary>
		/// ת����Base64����
		/// </summary>
		public static void ConvertToBase64(byte[] content, string outputFilePath)
		{
			FileStream fout = new FileStream(outputFilePath, FileMode.OpenOrCreate, FileAccess.Write);
			fout.SetLength(0);

			ToBase64Transform transformer = new ToBase64Transform();

			CryptoStream encStream = new CryptoStream(fout, transformer, CryptoStreamMode.Write);

			encStream.Write(content, 0, content.Length);

			encStream.Close();
			fout.Close();
		}
		/// <summary>
		/// ת����Base64����
		/// </summary>
		public static string ConvertToBase64(string s)
		{
			return Convert.ToBase64String(Encoding.GetEncoding("gb2312").GetBytes(s));
		}
		/// <summary>
		/// ת������Base64����
		/// </summary>
		public static string ConvertFromBase64(string s)
		{
			byte[] ret = Convert.FromBase64String(s);
			return Encoding.Default.GetString(ret, 0, ret.Length);
		}
		/// <summary>
		/// ת������Base64����
		/// </summary>
		internal static void ConvertFromBase64(string inputFilePath, string outputFilePath)
		{
			//Create the file streams to handle the input and output files.
			FileStream fin = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read);
			FileStream fout = new FileStream(outputFilePath, FileMode.OpenOrCreate, FileAccess.Write);
			fout.SetLength(0);

			FromBase64Transform transformer = new FromBase64Transform();

			//Create variables to help with read and write below.
			//This is intermediate storage for the decryption:
			byte[] bin = new byte[fin.Length/transformer.InputBlockSize*transformer.OutputBlockSize];
			long rdlen = 0; //This is the total number of bytes written.
			long totlen = fin.Length; //This is the total length of the input file.
			int len; //This is the number of bytes to be written at a time.

			CryptoStream encStream = new CryptoStream(fout, transformer, CryptoStreamMode.Write);

			//Read from the input file, then decrypt and write to the output file.
			while (rdlen < totlen)
			{
				len = fin.Read(bin, 0, (int) fin.Length);
				encStream.Write(bin, 0, len);
				rdlen = (rdlen + ((len/transformer.InputBlockSize)*transformer.OutputBlockSize));
			}

			encStream.Close();
			fout.Close();
			fin.Close();
		}

		/// <summary>
		/// ת����Quoted-Printable����
		/// </summary>
		internal static string ConvertToQP(string s, string charset)
		{
			if (s == null)
			{
				return null;
			}
			char[] nl = Environment.NewLine.ToCharArray();

			// source char array
			char[] source = s.ToCharArray();

			// result char array
			char[] result = new char[(s.Length*2)];


			// check for newline char
			char ch;
			int didx = 1,
				cnt = 0;

			StringBuilder sb = new StringBuilder();
			Encoding oEncoding = Encoding.GetEncoding(charset);

			for (int sidx = 0; sidx < s.Length; sidx++)
			{
				ch = Convert.ToChar(source[sidx]);

				// RULE # 4
				if (ch == nl[0])
				{
					// if char is preceded by space char add =20
					// RULE #3
					if (result[didx - 1] == ' ')
					{
						sb.Append("=20");
					}

					// if char is preceded by tab char add =20
					// RULE #3
					if (result[didx - 1] == '\t')
					{
						sb.Append("=90");
					}

					sb.Append("\r\n");
					sidx += nl.Length - 1;
					cnt = didx;
				}
					// RULE #1 and #2
				else if (ch > 126 || (ch < 32 && ch != '\t') || ch == '=' || ch == '?')
				{
					byte[] outByte = new byte[10];
					int iCount = oEncoding.GetBytes("" + ch, 0, 1, outByte, 0);

					for (int i = 0; i < iCount; i ++)
					{
						sb.Append("=" + Convert.ToString(outByte[i], 16));
					}

					//sb.Append("=" + Convert.oString((byte)ch, 16));
				}
				else
				{
					sb.Append(ch);

					// RULE #5
					if (didx > cnt + 70)
					{
						sb.Append("=\r\n");
						cnt = didx;
					}
				}
			}

			return sb.ToString();
		}

		/// <summary>
		/// Convert to Quoted Printable if necessary
		/// </summary>
		/// <param name="s"></param>
		/// <param name="charset"></param>
		/// <param name="forceconversion">force a conversion</param>
		/// <returns></returns>
		internal static string ConvertHeaderToQP(string s, string charset, bool forceconversion)
		{
			if (!forceconversion)
			{
				bool needsconversion = false;
				for (int i = 0; i < s.Length; i++)
				{
					if (s[i] > 126 || s[i] < 32)
					{
						needsconversion = true;
						break;
					}
				}
				if (!needsconversion)
				{
					return s;
				}
			}
			return "=?" + charset + "?Q?" + ConvertToQP(s, charset) + "?=";
		}

		/// <summary>
		/// Convert to Quoted printable if necessary.
		/// </summary>
		/// <param name="s"></param>
		/// <param name="charset"></param>
		/// <returns></returns>
		internal static string ConvertHeaderToQP(string s, string charset)
		{
			return ConvertHeaderToQP(s, charset, false);
		}

		/// <summary>
		/// Qoted Print����ת��
		/// </summary>
		/// <param name="s"></param>
		/// <returns></returns>
		internal static string ConvertFromQP(string s)
		{
			if (s == null) return null;
			// source char array:
			char[] source = s.ToCharArray();
			// result char array:
			char[] result = new char[(int) (s.Length*1.1)];
			// environment newline char:
			char[] nl = Environment.NewLine.ToCharArray();

			int last = 0,didx = 0,slen = s.Length;

			for (int sidx = 0; sidx < slen;)
			{
				char ch = source[sidx++];

				if (ch == '=')
				{
					// Premature EOF
					if (sidx >= slen - 1)
					{
						throw new ApplicationException("Premature EOF");
					}

					// RULE # 5
					if (source[sidx] == '\n' || source[sidx] == '\r')
					{
						sidx++;
						if (source[sidx - 1] == '\r' && source[sidx] == '\n')
						{
							sidx++;
						}
					}
						// RULE # 1
					else
					{
						char repl;
						int hi = Int32.Parse(Convert.ToString(source[sidx]), NumberStyles.HexNumber);
						int lo = Int32.Parse(Convert.ToString(source[sidx + 1]), NumberStyles.HexNumber);

						if ((hi | lo) < 0)
						{
							throw new ApplicationException(new String(source, sidx - 1, 3) + " is an invalid code");
						}
						else
						{
							repl = (char) (hi << 4 | lo);
							sidx += 2;
						}

						result[didx++] = repl;
					}

					last = didx;

					// RULE # 4
					if (ch == '\n' || ch == '\r')
					{
						if (ch == '\r' && sidx < slen && source[sidx] == '\n')
						{
							sidx++;

							for (int idx = 0; idx < nl.Length; idx++)
							{
								result[last++] = nl[idx];
								didx = last;
							}
						}
						else
						{
							result[didx++] = ch;
							// RULE # 3
							if (ch != ' ' && ch != '\t')
							{
								last = didx;
							}
						}

						if (didx > result.Length - nl.Length - 2)
						{
							char[] newCharArray = new char[(result.Length + 500)];
							Array.Copy(result, newCharArray, result.Length);
							result = newCharArray;
						}
					}
				}
			}
			return new String(result, 0, didx);
		}

		/// <summary>
		/// �Ƿ���ASCII�ַ���
		/// </summary>
		/// <param name="s"></param>
		/// <returns></returns>
		public static bool IsAscii(string s)
		{
			for (int sidx = 0; sidx < s.Length; sidx++)
			{
				if (Convert.ToInt32(s[sidx]) > 127) return false;
			}
			return true;
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static string GetMD5Hash(string input)
		{
			MD5 md5=new MD5CryptoServiceProvider();
			//the GetBytes method returns byte array equavalent of a string
			byte []res=md5.ComputeHash(Encoding.Default.GetBytes(input),0,input.Length);
			char []temp=new char[res.Length];
			//copy to a char array which can be passed to a String constructor
			System.Array.Copy(res,temp,res.Length);
			//return the result as a string
			return new String(temp);
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static string GetMD5HashHex(string input)
		{
			MD5 md5=new MD5CryptoServiceProvider();
			//			DES des=new DESCryptoServiceProvider();
			//the GetBytes method returns byte array equavalent of a string
			byte []res=md5.ComputeHash(Encoding.Default.GetBytes(input),0,input.Length);

			String returnThis="";

			for(int i=0;i<res.Length;i++)
			{
				returnThis+=System.Uri.HexEscape((char)res[i]);
			}
			returnThis=returnThis.Replace("%","");
			returnThis=returnThis.ToLower();

			return returnThis;
		}

		
		/// <summary>
		/// this._from�е��û�����ʱ������޷���������
		/// �������������_from����
		/// </summary>
		/// <param name="str"></param>
		/// <returns></returns>
		public static string DecodeString(string str)
		{
			return DecodeAttName(str);
		}

		/// <summary>
		/// �Ը���������Base64����
		/// </summary>
		/// <param name="attName"></param>
		/// <returns></returns>
		public static string DecodeAttName(string attName)
		{
			if (attName == null || attName == "")
			{
				return "";
			}
			string encoding = "";
			string att = attName;
			int begin = att.IndexOf("?=");
			if (begin == -1)
			{
				int attLen = attName.Length;
				string end = attName.Substring(attLen - 1, 1);
				if (end != "?")
				{
					return attName;
				}
				else
				{
					att = att.Substring(0, att.Length - 1);
					if (att.IndexOf("=?") == -1)
					{
						return attName;
					}
					else
					{
						att = att.Replace("=?", "");
						begin = att.IndexOf("?", 0);
						if (begin == -1)
						{
							return attName;
						}
						else
						{
							encoding = att.Substring(0, begin);
						}
						att = att.Replace(encoding + "?", "");
						string flag = att.Substring(0, 1);
						att = att.Replace(flag + "?", "");
						flag = flag.ToLower();
						//Base64����
						if (flag == "b")
						{
							byte[] bytes = Convert.FromBase64String(att);
							att = Encoding.GetEncoding(encoding).GetString(bytes);
						}
					}
				}
			}
			else
			{
				att = att.Replace("?=", "");
				int end = att.IndexOf("=?");
				if (end == -1)
				{
					return attName;
				}
				else
				{
					att = att.Replace("=?", "");
					att = att.Replace("\"", "");
					begin = att.IndexOf("?", 0);
					if (begin == -1)
					{
						return attName;
					}
					else
					{
						encoding = att.Substring(0, begin);
					}
					att = att.Replace(encoding + "?", "");
					string flag = att.Substring(0, 1);
					att = att.Replace(flag + "?", "");
					flag = flag.ToLower();
					if (flag == "b")
					{
						//���������ܻ���� .�ȼ����쳣����,����֮
						try
						{
							byte[] bytes = Convert.FromBase64String(att);
							att = Encoding.GetEncoding(encoding).GetString(bytes);
						}
						catch (Exception e)
						{
                            throw e;
						}
					}
					if (flag == "q")
					{
						att = att.Substring(1);
						att = MailEncoder.ConvertHexToString(att, "gb2312");
					}
				}
			}
			return att;
		}
	}
}
