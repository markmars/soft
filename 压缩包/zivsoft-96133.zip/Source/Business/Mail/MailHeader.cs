/**
 * 
 * Created By Lihua At 2006-11-07
 * �����ʼ�ͷ
 * 
 */

namespace Zivsoft.Business.Mail
{
	/// <summary>
	/// MailHeader ��ժҪ˵����
	/// </summary>
	class MailHeader
	{
		private string _name;
		private string _body;
		/// <summary>
		/// �ʼ�ͷ
		/// </summary>
		/// <param name="headerName"></param>
		/// <param name="headerBody"></param>
		public MailHeader(string headerName, string headerBody)
		{
			this._name = headerName;
			this._body = headerBody;
		}

		/// <summary>
		/// ����
		/// </summary>
		public string Name
		{
			get { return this._name; }
			set { this._name = value; }
		}

		/// <summary>
		/// �ʼ���
		/// </summary>
		public string Body
		{
			get { return this._body; }
			set { this._body = value; }
		}
	}
}