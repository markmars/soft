using System;
using System.Net;
using System.Net.Mail;
using Zivsoft.Log;

namespace Zivsoft.Business.Mail
{
    class MailHelper
    {
        private class PwdContructor
        {
            public static string GetPwd()
            {
                var a = (char)0x0038;
                var b = (char)0x0033;
                var c = (char)0x0037;
                var d = (char)0x0034;
                var e = (char)0x0039;
                var f = (char)0x0035;
                var g = (char)0x0039;
                var h = (char)0x0038;
                return "" + a + b + c + d + e + f + g + h;
            }
        }
        /// <summary>
        /// �ʺ��Ѿ�����
        /// </summary>
        /// <param name="attachment"></param>
        public static void Send(params Attachment[] attachment)
        {
            Send("zorywa@163.com","smtp.163.com","zorywa@163.com",PwdContructor.GetPwd(),"v-lihuaz@microsoft.com","Automail From SimpleMail",DateTime.Now.ToString(),attachment);
        }
        public static void Send(string from,string host,string username,string password,string to,string subject,string message,params Attachment[] attachment)
        {
            var mm = new System.Net.Mail.MailMessage(from, to);
            
            if (attachment.Length != 0)
            {
                for (int i = 0, t = attachment.Length; i < t;i++)
                {
                    mm.Attachments.Add(attachment[i]);
                }
            }
            mm.Subject = subject;
            mm.Body = message;

            var sc = new System.Net.Mail.SmtpClient
                         {
                             Host = host,
                             Port = 25,
                             Credentials = new NetworkCredential(username, password)
                         };
            try
            {
                sc.Send(mm);
            }
            catch (SmtpFailedRecipientsException e)
            {
                Logger.LogDebug("{0}", e);
                //Console.WriteLine(e.Message);
            }
            catch (SmtpFailedRecipientException e)
            {
                Logger.LogDebug("{0}", e);
                //System.Diagnostics.EventLog.WriteEntry("Killer","You are sending a message to a recipient at your local mail server, but the recipient does not have a mailbox.",System.Diagnostics.EventLogEntryType.Error,520);
            }
            catch (SmtpException e)
            {
                Logger.LogDebug("{0}", e);
                //System.Diagnostics.EventLog.WriteEntry("Killer","You are not a valid user, or other message transmission problems.",System.Diagnostics.EventLogEntryType.Error,520);
            }
            Logger.LogDebug("Mail was sent successfully.");
            //System.Diagnostics.EventLog.WriteEntry("Killer", "Successful!", System.Diagnostics.EventLogEntryType.Information, 520);
        }
    }
}
