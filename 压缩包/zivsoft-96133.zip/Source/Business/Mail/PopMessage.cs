using System;
using System.Collections;
using System.IO;
using Zivsoft.Utils;

/**
 * 
 * 
 */

namespace Zivsoft.Business.Mail
{
	/// <summary>
	/// </summary>
	class PopMessage
	{
		protected string _uid;
		protected string _raw;
		protected MessageEntity _msg;
		protected ArrayList _alPrimitives;
		/// <summary>
		/// </summary>
		public PopMessage(string raw)
		{
			this.Init();
			this._raw = raw;
		}
		/// <summary>
		/// </summary>
		public PopMessage(string uid,string raw):this(raw)
		{
			this._uid = uid;
		}
		/// <summary>
		/// </summary>
		~PopMessage()
		{
            //if(Directory.Exists(this._path))
            //{
            //    string[] files = Directory.GetFiles(this._path);
            //    foreach(string file in files)
            //    {
            //        File.Delete(file);
            //    }
            //    Directory.Delete(this._path);
            //}
            //this._msg = null;
		}
		/// <summary>
		/// </summary>
		protected virtual void Init()
		{
			this._msg = new MessageEntity("begin");
			this._path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,Path.Combine("email",DateTime.Now.Ticks.ToString()));
			this._atts = new ArrayList(5);
			this._text = String.Empty;
			this._html = String.Empty;
			this._alPrimitives = new ArrayList(10);
			//���û��Ŀ¼����Ŀ¼
			if(!Directory.Exists(this._path)) Directory.CreateDirectory(this._path);
		}
		/// <summary>
		/// ����
		/// </summary>
		public bool Parse()
		{
			if(String.IsNullOrEmpty(this._raw)) return false;
			StringReader sr = new StringReader(this._raw);
			string line="--begin";
			while(line != null)
			{
				int result = 0;
				if(line == ".") result = this._msg.Parse("--begin--");
				else result = this._msg.Parse(line);
				if(result==2) break;
				line = sr.ReadLine();
			}

			this.Tidyup(this._msg);
			return true;
		}
		/// <summary>
		/// </summary>
		protected void Tidyup(MessageEntity root)
		{
			if(null == root) return;
			switch(root.EntityType)
			{
				case EEntityType.Empty:return;
				case EEntityType.Composite:				
					MessageEntity[] sons = root.Entities;
					foreach(MessageEntity entity in sons)
					{
						if(null == entity) break;
						this.Tidyup(entity);
					}
					break;
				case EEntityType.Text:
					this._text = root.GetDisplay(this._path);
					this._alPrimitives.Add(root);
					break;
				case EEntityType.Html:
					this._html = root.GetDisplay(this._path);
					this._alPrimitives.Add(root);
					break;
				case EEntityType.Attachment:
					this._atts.Add(root.GetDisplay(this._path));
					this._alPrimitives.Add(root);
					break;
				case EEntityType.InnerNest:
					this._alPrimitives.Insert(0,root);
					break;
				default:break;
			}
		}
		/// <summary>
		/// </summary>
		public string UID
		{
			get
			{
				return this._uid;
			}
			set
			{
				this._uid = value;
			}
		}
		/// <summary>
		/// </summary>
		protected string _path;
		public string GetPath()
		{
			return this._path;
		}
		/// <summary>
		/// </summary>
		public string GetSubject()
		{
			return EncoderUtil.DecodeText(this._msg.GetHead("subject"));
		}
		/// <summary>
		/// </summary>
		public string GetSender()
		{
			return EncoderUtil.DecodeText(this._msg.GetHead("from"));
		}
		/// <summary>
		/// </summary>
		/// <returns></returns>
		public string GetReceiver()
		{
			return EncoderUtil.DecodeText(this._msg.GetHead("to"));
		}
		/// <summary>
		/// </summary>
		protected ArrayList _atts;
		public ArrayList GetAttachments()
		{
			return this._atts;
		}
		/// <summary>
		/// </summary>
		protected string _text;
		public string GetText()
		{
			return this._text;
		}
		/// <summary>
		/// </summary>
		protected string _html;
		public string GetHtml()
		{
			if(null==this._html || ""==this._html) return String.Empty;
			foreach(MessageEntity entity in this._alPrimitives)
			{
				if(entity.EntityType == EEntityType.InnerNest)
				{
					string obj = "cid:"+entity.ContentID;
					this._html = this._html.Replace(obj,entity.GetDisplay(this._path));
				}
			}
			return this._html;
		}
	}
}
