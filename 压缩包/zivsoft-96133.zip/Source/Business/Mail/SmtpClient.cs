using System;
using System.Collections;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Zivsoft.Business.Mail
{
	/// <summary>
	/// 
	/// </summary>
	class SmtpClient
	{
		private TcpClient _tcp;
		private NetworkStream _stream;
		private string _host;
		private int _port;
		private string _name;
		private string _password;

		private int _sendTimeout;
		private int _recieveTimeout;
		private int _receiveBufferSize;
		private int _sendBufferSize;
		private int _waitForResponseInterval;

		private byte[] _readBuffer;
		public SmtpClient()
		{
			this._port = 25;
			this._sendTimeout = 500000;
			this._recieveTimeout = 500000;
			this._receiveBufferSize = 1024;
			this._sendBufferSize = 1024;
			this._waitForResponseInterval = 500;
			this._readBuffer = new byte[1024];
		}
		/// <summary>
		/// ���캯��
		/// </summary>
		public SmtpClient(string host, string name, string password):this()
		{
			this._host = host;
			this._name = name;
			this._password = password;
		}
		/// <summary>
		/// ���캯��
		/// </summary>
		public SmtpClient(string host, string name, string password, int port):this(host,name,password)
		{
			this._port = port;
		}
		/// <summary>
		/// ����
		/// </summary>
		public string Host
		{
			get{return this._host;}
			set{this._host =value;}
		}
		/// <summary>
		/// �û���
		/// </summary>
		public string Name
		{
			get{return this._name;}
			set{this._name =value;}
		}
		/// <summary>
		/// ����
		/// </summary>
		public string Password
		{
			get{return this._password;}
			set{this._password =value;}
		}
		/// <summary>
		/// �����
		/// </summary>
		public int SendTimeout
		{
			get { return this._sendTimeout; }
			set { this._sendTimeout = value; }
		}
		/// <summary>
		/// �ȴ�ʱ��
		/// </summary>
		public int WaitForResponseInterval
		{
			get { return this._waitForResponseInterval; }
			set { this._waitForResponseInterval = value; }
		}
		/// <summary>
		/// �����
		/// </summary>
		public int RecieveTimeout
		{
			get { return this._recieveTimeout; }
			set { this._recieveTimeout = value; }
		}
		/// <summary>
		/// �����Ϸ�����ʱ
		/// </summary>
		public event EventHandler Connected;
		/// <summary>
		/// �Ͽ�������ʱ
		/// </summary>
		public event EventHandler Disconnected;
		/// <summary>
		/// ��֤�ɹ�ʱ
		/// </summary>
		public event EventHandler Authenticated;
		/// <summary>
		/// ���ݿ�ʼ����ʱ
		/// </summary>
		public event EventHandler StartedMessageTransfer;
		/// <summary>
		/// ���ݴ������ʱ
		/// </summary>
		public event EventHandler EndedMessageTransfer;

		/// <summary>
		/// �����ʼ�
		/// </summary>
		public void SendMail(string from, string to, string subject, string body)
		{
			MailMessage msg = new MailMessage(from, to);
			msg.Subject = subject;
			msg.Body = body;
			SendMail(msg);
		}
		/// <summary>
		/// �����ʼ�
		/// </summary>
		public void SendMail(MailMessage msg, string host, int port)
		{
			this._host = host;
			this._port = port;
			SendMail(msg);
		}
		/// <summary>
		/// �����ʼ�
		/// </summary>
		public void SendMail(MailMessage msg)
		{
			string data = msg.ToString() + "\r\n.\r\n"; 
			//����һ������,����ȡһ��������������
			this.GetConnection();
			this.CheckReply(MailReply.HELO_REPLY);

			this.WriteToStream("HELO " + this._host + "\r\n");
			this.CheckReply(MailReply.OK);

			//��½
			this.AuthLogin();

			//������
			this.WriteToStream("MAIL FROM: <" + msg.From.Address.Trim() + ">\r\n");
			this.CheckReply(MailReply.OK);

			//���ͽ�����,����,�ܳ�
			this.SendRecipientList(msg.TO);
			this.SendRecipientList(msg.CC);
			this.SendRecipientList(msg.BCC);

			//�������ݿ�ʼ
			this.WriteToStream("DATA\r\n");
			this.CheckReply(MailReply.START_INPUT);

			if(this.StartedMessageTransfer != null) this.StartedMessageTransfer(this,EventArgs.Empty);
			this.WriteToStream(data);
			this.CheckReply(MailReply.OK);
			if(this.EndedMessageTransfer != null) this.EndedMessageTransfer(this,EventArgs.Empty);

			//�˳�
			this.WriteToStream("QUIT\r\n");
			this.CheckReply(MailReply.QUIT);

			//�ر�����
			this.CloseConnection();
		}

		/// <summary>
		/// ���ø���
		/// </summary>
		public void Reset()
		{
			this._host = null;
			this._port = 25;
			this._name = null;
			this._password = null;
			CloseConnection();
		}

		/// <summary>
		/// ��������
		/// </summary>
		/// <returns></returns>
		private void GetConnection()
		{
			try
			{
				if (this._host == null) this._host = MailConfig.SmtpHost;
				if (this._port == 0) this._port = MailConfig.SmtpPort;

				this._tcp = new TcpClient(this._host, this._port);
				this._tcp.ReceiveTimeout = this._recieveTimeout;
				this._tcp.SendTimeout = this._sendTimeout;
				this._tcp.ReceiveBufferSize = this._receiveBufferSize;
				this._tcp.SendBufferSize = this._sendBufferSize;

				LingerOption lingerOption = new LingerOption(true, 10);
				this._tcp.LingerState = lingerOption;
			}
			catch (SocketException e)
			{
				throw new Exception("can't connect(" + this._host + ":" + this._port + ").",e);
			}

			if(this.Connected != null) this.Connected(this,EventArgs.Empty);
			this._stream = this._tcp.GetStream();
		}

		/// <summary>
		/// �ر�����
		/// </summary>
		private void CloseConnection()
		{
			if(this.Disconnected != null) this.Disconnected(this,EventArgs.Empty);
			if (this._tcp != null) this._tcp.Close();
		}
		/// <summary>
		/// ��֤��½
		/// </summary>
		/// <returns></returns>
		private void AuthLogin()
		{
			if (this._name != null && this._name.Length > 0 && this._password != null && this._password.Length > 0)
			{
				this.WriteToStream("AUTH LOGIN\r\n");
				this.CheckReply(MailReply.SERVER_CHALLENGE);
				this.WriteToStream(Convert.ToBase64String(Encoding.Default.GetBytes(this._name)) + "\r\n");
				this.CheckReply(MailReply.SERVER_CHALLENGE);
				this.WriteToStream(Convert.ToBase64String(Encoding.Default.GetBytes(this._password)) + "\r\n");
				this.CheckReply(MailReply.AUTH_SUCCESSFUL);
				if(this.Authenticated != null) this.Authenticated(this,EventArgs.Empty);
			}
		}
		/// <summary>
		/// ���ͽ���������
		/// </summary>
		/// <param name="recipients"></param>
		private void SendRecipientList(ArrayList recipients)
		{
			for (IEnumerator i = recipients.GetEnumerator(); i.MoveNext();)
			{
				MailAddress recipient = (MailAddress) i.Current;
				this.WriteToStream("RCPT TO: <" + recipient.Address + ">\r\n");
				this.CheckReply(MailReply.OK);
			}
		}
		/// <summary>
		/// д����
		/// </summary>
		/// <param name="line"></param>
		private void WriteToStream(string line)
		{
			try
			{
				byte[] arrToSend = Encoding.Default.GetBytes(line);
				this._stream.Write(arrToSend, 0, arrToSend.Length);
			}
			catch (Exception)
			{
				throw new Exception("Write to Stream threw an System.Exception");
			}
		}
		/// <summary>
		/// �����ж�ȡ��Ϣ
		/// </summary>
		/// <returns></returns>
		private void CheckReply(string code)
		{
			int count = 0;
			while(count++<10)
			{
				int length = this._stream.Read(this._readBuffer,0,1024);
				if(length>0)
				{
					string res = Encoding.Default.GetString(this._readBuffer, 0, length);
					if(res.IndexOf(code) == -1)
					{
						string str = "ERROR - Expecting: " + code + ". Recieved: " + res;
						throw new Exception(str);
					}
					return;
				}
				Thread.Sleep(this._waitForResponseInterval);
			}
			throw new Exception("ERROR - No Reply");
		}
	}
}