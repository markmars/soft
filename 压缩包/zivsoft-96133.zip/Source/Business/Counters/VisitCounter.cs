﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Zivsoft.Data;
using Zivsoft.Data.Entity;
using Zivsoft.Data.ORM.Entity;


/*
 * 
 * Created by Lihua Zhou at 2008-5-28
 * 
 */
namespace Zivsoft.Business.Counters
{
    /// <summary>
    /// 
    /// </summary>
    partial class VisitCounter
    {
        public void Add()
        {
            string sql = "UPDATE [COUNTER] SET [VALUE]='{0}'";
            Counter count = new Counter();
            count.Load();
            count.Value.Value++;
            count.Update();
            //DbFactory.DefaultDbOperator().ExcuteSql(string.Format(sql,GetCount()+1));
        }

        public long GetCount()
        {
            Counter c = new Counter();
            c.Load();
            return c.Value.Value;
        }

        public static int GetCount(string tableName)
        {
            VisitCounter visit = new VisitCounter();
            //DbFactory.DefaultDbOperator().ExcuteSql(string.Format("update [{0}] set Total=Total+1",tableName));
            Counter c = new Counter();
            visit.Add();
            DataSet ds = c.Query4DataSet(); //DbFactory.DefaultDbOperator().Query4DataSet("select Total from [Visitcount]");
            return Convert.ToInt32(ds.Tables[0].Rows[0]["Total"]);
        }
    }
}
