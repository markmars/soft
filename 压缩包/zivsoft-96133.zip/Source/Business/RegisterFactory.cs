﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Services;
using Zivsoft.IO.Register;

namespace Zivsoft.Business
{
    class RegisterFactory : BusinessHandler
    {
        protected override bool Check(Request request)
        {
            if (request is RegisterRequest)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        protected override Response PerformTask(Request request)
        {
            if (request is RegDialog)
            {
                Response res = new Response();
                System.Windows.Forms.Application.Run(new Zivsoft.Business.Register.RegUI());
                return res;
            }
            else
            {
                return NoBusinessCode;
            }
        }
    }
}
