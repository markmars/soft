﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Zivsoft.Data.Entity;
using Zivsoft.Data.ORM.Entity;


namespace Zivsoft.Business.ITWeb
{
    class KindUtil
    {
        private string _name;
        public string Name
        {
            get
            {
                return this._name;
            }
            set
            {
                this._name = value;
            }
        }

        private string _id;
        public string ID
        {
            get
            {
                return this._id;
            }
            set
            {
                this._id = value;
            }
        }

        public bool Insert()
        {
            bool success = false;
            string sql = "INSERT INTO [Kind] ([ID],[DealMethod]) VALUES('{0}','{1}')";
            sql = string.Format(sql, this._id, this._name);

            if (!this.IsExist(this._name))
            {
                Kind kind = new Kind();
                kind.Id = this._id;
                kind.Name = this._name;
                int i = kind.Insert();
                success = (i == 1);
            }
            return success;
        }

        private bool IsExist(string name)
        {
            bool success = false;
            string sql = "SELECT [DealMethod] FROM [Kind] WHERE [DealMethod]='{0}'";
            sql = string.Format(sql, name);
            Kind kind=new Kind();

            DataSet ds = kind.Query4DataSet();//DbFactory.DefaultDbOperator().Query4DataSet(sql);
            if (ds.Tables[0].Rows.Count == 1)
            {
                success = true;
            }
            else
            {
                success = false;
            }
            return success;
        }
    }
}
