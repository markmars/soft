﻿using System;
using System.IO;
using System.Net;

namespace Zivsoft.Business.ITWeb
{
    /// <summary>
    /// 蜘蛛爬虫网络引擎
    /// </summary>
    class HtmlSaver
    {
        /// <summary>
        /// 执行开始
        /// </summary>
        public void Run(string strUrl)
        {
            string BoardStream;//下载内容存入此变量
            
            var url = new Uri( strUrl);//将下载地址转换为Uri类型
            
            var requestPage = ( HttpWebRequest )WebRequest.Create( url );
            WebResponse response = requestPage.GetResponse();
            Stream stream = response.GetResponseStream();//获取页面流
            if( response.ContentType.ToLower().StartsWith( "text/" ) )//如果获得成功（即为文本格式）
            {
                StreamReader reader = new StreamReader( stream , System.Text.Encoding.UTF8 );//读取获得内容流

                
                BoardStream = reader.ReadToEnd();//将内容流转换为文本并存入变量BoardStream，即为所需要的数据流
            }
            
            StreamWriter saveAPage = new StreamWriter( @"C:\a.html" , false , System.Text.Encoding.GetEncoding( "gb2312" ) );//实例化写入类，保存路径假设为C:\a.html

            saveAPage.Write(true);//创建写入任务
            
            saveAPage.Flush();//写入文件（即清理缓存流）
            
            saveAPage.Close();//关闭写入类的对象


        }
    }
}