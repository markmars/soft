﻿using System;
using Zivsoft.Data;
using Zivsoft.Data.Entity;
using Zivsoft.Data.ORM.Entity;


namespace Zivsoft.Business.ITWeb
{
    /// <summary>
    /// </summary>
    class IPCollector
    {
        private const string IPVALUE = "IPValue";
        private const string TABLENAME = "IP";
        private const string UpdateDate = "LastAccessDate";
        /// <summary>
        /// 添加IP
        /// </summary>
        /// <param name="ip">XXX.XXX.XXX.XXX</param>
        public int Do(string ip)
        {
            IP t = new IP();
            t.IPValue = ip;
            int queryResult = t.SelectCount(); 
            if (queryResult == 0)
            {
                return this.Add(ip);
            }
            else//数据库已经存在此用户的纪录
            {
                return this.Update(ip);
            }
        }
        #region private methods
        /// <summary>
        /// 添加IP
        /// </summary>
        /// <param name="strIP">XXX.XXX.XXX.XXX</param>
        /// <returns></returns>
        private int Add(string strIP)
        {
            var ip = new IP();
            ip.IPValue = strIP;
            ip.LastAccessDate = DateTime.Now;
            return ip.Insert();
        }

        /// <summary>
        /// 更新最后访问的时间
        /// </summary>
        /// <param name="strIP"></param>
        /// <returns></returns>
        private int Update(string strIP)
        {
            string strSQL = string.Format("UPDATE [{0}] SET [{1}]='{2}' WHERE [{3}]='{4}'",TABLENAME,UpdateDate,DateTime.Now.ToString(),IPVALUE,strIP);
            var ip = new IP();
            ip.IPValue = strIP;
            ip.LastAccessDate = DateTime.Now;
            return ip.Update();
        }
        #endregion
    }
}