﻿using System.Data;
using Zivsoft.Data;
using Zivsoft.Data.ORM.Entity;


namespace Zivsoft.Business.ITWeb
{
    /// <summary>
    /// 
    /// </summary>
    class TInfo
    {
        private IResultSet _rs;
        public TInfo()
        {
            Info info = new Info();

            _rs = info.LoadResultSet();

        }
        public bool Next()
        {
            if (_rs.Next())
            {
                this._date = _rs.GetValue("CreateDate") + "";
                this._title = _rs.GetValue("Title") + "";
                this._content = _rs.GetValue("Content") + "";
                return true;
            }
            else
            {
                return false;
            }
        }

        private string _date;
        public string Date
        {
            get
            {
                return this._date;
            }
        }
        private string _title;
        public string Title
        {
            get
            {
                return this._title;
            }
        }
        private string _content;
        public string Conent
        {
            get
            {
                return _content;
            }
        }
        private DataSet GetDataSet()
        {
            //string sql = "SELECT [Id],[Title], [CreateDate],[Content] FROM [Info] ORDER BY [CreateDate] DESC";
            Info info = new Info();
            return info.Query4DataSet();
        }

        public DataView GetDataView()
        {
            DataTable dt = this.GetDataSet().Tables[0];
            int j=dt.Rows.Count;
            for (int i = 0; i < j; i++)
            {
                string title = dt.Rows[i].ItemArray[1].ToString();
                if (title.Length > 30)
                {
                    title = title.Remove(30);
                    dt.Rows[i]["Title"] = title+"……";
                }
                dt.AcceptChanges();
            }
            return dt.DefaultView;
        }

        public static string CutTitle(string title)
        {
            if (title.Length > 30)
            {
                title = title.Remove(30);
                return title + "……";
            }
            return title;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public static bool DelInfoById(string Id)
        {
            string sql = "DELETE FROM [Info] WHERE [Id]='{0}'";
            sql = string.Format(sql, Id.ToString());
            var info=new Info();
            info.Id = Id;
            int i = info.Delete();  //DbFactory.DefaultDbOperator().ExcuteSql(sql);
            if (i == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}