﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Runtime.CompilerServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Zivsoft.Business")]
[assembly: AssemblyDescription("All frameworks designed by Lihua")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Zivsoft")]
[assembly: AssemblyProduct("Zivsoft \u00AE Solutions Framework")]
[assembly: AssemblyCopyright("Copyright © Zivsoft 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("ce6d08dd-394b-45c5-956e-d33f52a18549")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("0.5.1.3")]

//[assembly: ReflectionPermission(SecurityAction.RequestMinimum)]
//[assembly: UIPermission(SecurityAction.RequestMinimum)]
[assembly: AssemblyFileVersionAttribute("2.0.0.9")]
//[assembly: InternalsVisibleTo("Zivsoft.Business.Register,PublicKey=00240000048000009400000006020000002400005253413100040000010001003114b04b96b7f52c3b96a7e7dfd256a05791ebda6de20cdf864306f5a7d6b3ce1dbd1f606cf726951e5a01a10514d106139fce29a1d2e20cfb9826ce4d0290a9ae41a912e35a23af884760c12645850f909f1f60e069d37372af5089d94a734f3eb23c9afced2f7487cf80fca5722c078034338a36641b9bd6f85883de29efac")]
//[assembly: InternalsVisibleTo("Zivsoft.Business,PublicKey=00240000048000009400000006020000002400005253413100040000010001003114b04b96b7f52c3b96a7e7dfd256a05791ebda6de20cdf864306f5a7d6b3ce1dbd1f606cf726951e5a01a10514d106139fce29a1d2e20cfb9826ce4d0290a9ae41a912e35a23af884760c12645850f909f1f60e069d37372af5089d94a734f3eb23c9afced2f7487cf80fca5722c078034338a36641b9bd6f85883de29efac")]
[assembly: InternalsVisibleTo("Zivsoft.Products.Register,PublicKey=002400000480000094000000060200000024000052534131000400000100010045a1a53657b89220313598a44001f2c449895689b53158f102f7d0b4c51c9129dd0d430e12040e353500ef7207858f6408390078e15e924fb7b8d1ba6ae40086c7510ee80d755034e80734f1af504dc7da755b806c7808133a7e7b68f33764ecd0261a1583ba787b054e7b950035ae963e91783293c5219fa6b1fa9e6ac69eaa")]
[assembly: InternalsVisibleTo("Zivsoft.Services.SOA,PublicKey=00240000048000009400000006020000002400005253413100040000010001004d4453ca20c3916d118c16fe2ba3aedb4be927229997f17215492a1db10cb765a10fbca29b80a9aa3785907e9a00e964d9f969f8dc44e6e20615ef2f225f5709705fcd1f91f9c862c441029cef3928389cdbce6b6894abdad932b006f08b7373642e6f3eef3f49ce580c0d9fbbcbe12ee8bb72ea9e1425c330515c6ddd7045a4")]
[assembly: InternalsVisibleTo("TestCases,PublicKey=0024000004800000940000000602000000240000525341310004000001000100873144551726407bc5e1b33c0d4078958d3e8f0659a361a0959f807a3e20bf0e773af7b56a31a04ec0261dfeb511c1b9feab890857cc3cf05fa10f9c0821d64a8a71f62784de6bd01176d133e841e224e6f61951dda31fb44821a8a9b655ea7fb201001a141a23492228f554102d6acfe400632eba2b63db71c73f9e9872f0d3")]
[assembly: InternalsVisibleTo("Zivsoft.AjaxControl,PublicKey=0024000004800000940000000602000000240000525341310004000001000100873144551726407bc5e1b33c0d4078958d3e8f0659a361a0959f807a3e20bf0e773af7b56a31a04ec0261dfeb511c1b9feab890857cc3cf05fa10f9c0821d64a8a71f62784de6bd01176d133e841e224e6f61951dda31fb44821a8a9b655ea7fb201001a141a23492228f554102d6acfe400632eba2b63db71c73f9e9872f0d3")]

