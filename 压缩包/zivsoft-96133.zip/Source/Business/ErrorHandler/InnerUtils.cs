﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
/*
 * Created by ziv at 2007-2-10
 */
namespace Zivsoft.Business.ErrorHandler
{
    /// <summary>
    /// Get the inner resource
    /// </summary>
    class InnerUtils
    {
        /// <summary>
        /// Get inner resource
        /// </summary>
        public static string LoadInnerXmlResource4String(string resourceName)
        {
            StreamReader reader = new StreamReader(LoadInnerXmlResource4Stream(resourceName));
            return reader.ReadToEnd();
        }

        /// <summary>
        /// Get innser reource
        /// </summary>
        /// <param name="resourceName">resource file name</param>
        /// <returns>return stream</returns>
        public static Stream LoadInnerXmlResource4Stream(string resourceName)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            string fullName = assembly.GetName().Name + "." + resourceName;
            Stream stream=assembly.GetManifestResourceStream(fullName);
            return stream;
        }
    }
}
