using System;
using System.Collections;
using System.Configuration;
using System.Xml;

namespace Zivsoft.Business.ErrorHandler
{
	/// <summary>
	/// ErrorCode
	/// </summary>
	 sealed class ErrorCodeOperator
	{
		//�����뻺����
		private Hashtable _errorCodeConfig;
		/// <summary>
		/// ���캯��˽�л�
		/// </summary>
		private ErrorCodeOperator()
		{
            this.Init();
		}
		/// <summary>
		/// ��ʼ��,���������ļ�
		/// </summary>
		private void Init()
		{
			this._errorCodeConfig = new Hashtable();
			this.Load();
		}

		private void Load()
		{
			XmlDocument xmlDoc = new XmlDocument();
			try
			{
				xmlDoc.Load(InnerUtils.LoadInnerXmlResource4Stream(XmlConfigurationFile.ErrorCodeXml));
				XmlNode root = xmlDoc.DocumentElement;

				for (int i = 0, size = root.ChildNodes.Count; i < size; i++)
				{
					XmlNode entry = root.ChildNodes.Item(i);
					if(entry.Name != "error")
					{
						continue;
					}
					string code = entry.FirstChild.InnerText;
					string desc = entry.LastChild.InnerText;
					if(!this._errorCodeConfig.ContainsKey(code))
					{
						this._errorCodeConfig.Add(code,desc);
					}
				}
			}
			catch (Exception e)
			{
				this._errorCodeConfig.Clear();
                throw new Exception("It was failed to load "+XmlConfigurationFile.ErrorCodeXml +".",e);
			}
		}
		//�쳣��ʵ��
		private static ErrorCodeOperator _errorCode = null;
		/// <summary>
		/// ����
		/// </summary>
		public static ErrorCodeOperator Single()
		{
			if(null == ErrorCodeOperator._errorCode)
			{
				ErrorCodeOperator._errorCode = new ErrorCodeOperator();
			}
			return ErrorCodeOperator._errorCode;
		}
		/// <summary>
		/// �����쳣��
		/// </summary>
        /// <example>
        /// <add key="ErrorCodeFile" value="ErrorCode.xml"/>
        /// </example>
		/// <returns>��������</returns>
		public string getDescByCode(string code)
		{
			return this._errorCodeConfig[code] as string;
		}
	}
}
