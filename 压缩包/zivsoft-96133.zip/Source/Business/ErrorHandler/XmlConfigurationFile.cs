using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.ErrorHandler
{
    sealed class XmlConfigurationFile
    {
        public const string ErrorCodeXml="ErrorCode.xml";
        public const string CodeXml = "Code.xml";
        public const string ResourceXml = "Resource.xml";
    }
}
