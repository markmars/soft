﻿using System;

/*
 * Created by Lihua at 11/09/2007
 */

namespace Zivsoft.Business.Helper
{
    class DateFormat
    {
        public static string GetByMMDDYYYY(DateTime datetime)
        {
            return GetFormat("{1}/{2}/{0} {3}:{4}:{5}.{6}", datetime);
        }
        public static string Get(DateTime datetime)
        {
            return GetFormat("{0}-{1}-{2} {3}:{4}:{5}:{6}", datetime);
        }

        private static string GetFormat(string format,DateTime datetime)
        {
            string year = datetime.Year.ToString();

            string month = datetime.Month.ToString();
            if (month.Length == 1)
            {
                month = "0" + month;
            }

            string day = datetime.Day.ToString();
            if (day.Length == 1)
            {
                day = "0" + day;
            }

            string hour = datetime.Hour.ToString();
            if (hour.Length == 1)
            {
                hour = "0" + hour;
            }

            string minute = datetime.Minute.ToString();
            if (minute.Length == 1)
            {
                minute = "0" + minute;
            }

            string second = datetime.Second.ToString();
            if (second.Length == 1)
            {
                second = "0" + second;
            }

            string millisecond = datetime.Millisecond.ToString();
            if (millisecond.Length == 3)
            {
                millisecond = "0" + millisecond;
            }
            else if (millisecond.Length == 2)
            {
                millisecond = "00" + millisecond;
            }
            else if (millisecond.Length == 1)
            {
                millisecond = "000" + millisecond;
            }

            return string.Format(format, year, month, day, hour, minute, second, millisecond);
        }
    }
}