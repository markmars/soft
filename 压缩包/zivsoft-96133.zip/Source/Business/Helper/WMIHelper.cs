﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management;

namespace Zivsoft.Business.Helper
{
    class WMIHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="strQuery">SELECT * FROM Win32_OperatingSystem</param>
        /// <param name="machineName"></param>
        /// <param name="userName"></param>
        /// <param name="strPwd"></param>
        public ManagementObjectCollection ExecuteWMIQuery(string strQuery,string machineName,string userName,string strPwd)
        {
            //必须是\\{MachineName}\root\cimv2，注意在C#中要注意转义
            string path = @"\\" + machineName + @"\root\cimv2";
            ConnectionOptions oConn = new ConnectionOptions { Username = userName, Password = strPwd };
            
            System.Management.ManagementScope scope = new System.Management.ManagementScope(path, oConn);
            scope.Connect();

            ObjectQuery query = new ObjectQuery(strQuery);
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query);

            ManagementObjectCollection queryCollection = searcher.Get();
            return queryCollection;            
        }

        public string ParseMachineDomain(string machineName)
        {
            return (machineName.Split(new char[] { '.' }, 2))[1];
            if (machineName.Contains("."))//full name
            {
                return (machineName.Split(new char[] { '.' }, 2))[1];
            }
            else
            {
                //tell testers
                throw new Exception("Use the full machine name like XXXX.redmond.corp.microsoft.com");
            }
        }


    }
}
