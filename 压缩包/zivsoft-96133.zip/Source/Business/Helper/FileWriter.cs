﻿using System.IO;

namespace Zivsoft.Business.Helper
{
    class FileWriter
    {
        private string _fileName;
        public FileWriter(string fileName)
        {
            this._fileName = fileName;
        }

        public void WriteText(string message)
        {
            var fs = File.Open(this._fileName,FileMode.CreateNew);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(message);
            sw.Close();
            fs.Close();
        }
    }
}