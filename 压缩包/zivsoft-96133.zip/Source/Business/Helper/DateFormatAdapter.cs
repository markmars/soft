﻿using System;
/*
 * created by ziv at 2006-12-20
 * 日期格式转换
 */
namespace Zivsoft.Business.Helper
{
    /// <summary>
    /// 日期格式转换
    /// </summary>
    class DateFormatAdapter
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        private DateFormatAdapter()
        {
            
        }
        
        /// <summary>
        /// 格式化日期格式 YYYY-MM-DD HH:MM
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static string GetDateTime(DateTime? dateTime)
        {
            return GetDate(dateTime) +" "+ GetTime(dateTime);
        }

        /// <summary>
        /// 产生日期字符串
        /// </summary>
        /// <param name="dateTime">DateTime</param>
        /// <returns>YYYY-MM-DD</returns>
        public static string GetDate(DateTime? dateTime)
        {
            if(dateTime==null)
            {
                return null;
            }
            DateTime date = (DateTime) dateTime;
            string strYear = date.Year.ToString();
            string strMonth = date.Month.ToString();
            string strDay = date.Day.ToString();
            if(strYear.Length==1)
            {
                strYear = "0" + strYear;
            }
            if(strMonth.Length==1)
            {
                strMonth = "0" + strMonth;
            }
            if(strDay.Length==1)
            {
                strDay = "0" + strDay;
            }
            return strYear + "-" + strMonth + "-" + strDay;
        }
        
        /// <summary>
        /// 产生时间字符串
        /// </summary>
        /// <param name="dateTime">DateTime</param>
        /// <returns>HH:MM</returns>
        public static string GetTime(DateTime? dateTime)
        {
            if(dateTime==null)
            {
                return null;
            }
            DateTime date = (DateTime) dateTime;
            string strHour = date.Hour.ToString();
            string strMinute = date.Minute.ToString();
            
            if(strHour.Length==1)
            {
                strHour = "0" + strHour;
            }
            if(strMinute.Length==1)
            {
                strMinute = "0" + strMinute;
            }
            
            return strHour + ":" + strMinute;
        }
    }
}
