﻿using System;
/*
 * Created by ziv at 2006-1226
 */

namespace Zivsoft.Business.Helper
{
    /// <summary>
    /// </summary>
    class WeekFormatAdapter
    {
        /// <summary>
        /// </summary>
        public static  string ToCnWeek(DayOfWeek week)
        {

            switch (week)
            {
                case DayOfWeek.Sunday:
                    return "星期日";
                case DayOfWeek.Monday:
                    return "星期一";
                case DayOfWeek.Tuesday:
                    return "星期二";
                case DayOfWeek.Wednesday:
                    return "星期三";
                case DayOfWeek.Thursday:
                    return "星期四";
                case DayOfWeek.Friday:
                    return "星期五";
                case DayOfWeek.Saturday:
                    return "星期六";
                default:
                    return null;
            }
        }
    }
}