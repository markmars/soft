/**********************************************************
Copyright (c) 2005 Zivsoft Corporation
Module DealMethod:
    DataBaseHelper
Abstract:
    Database helper class to backup and restore DB

Author:
    Lihua Zhou
Revision History:
    29-Aug-2006 |   Created
***********************************************************/

using System;
using System.IO;
using System.Globalization;
using System.Data.SqlClient;

namespace Zivsoft.Business.Helper
{
    /// <summary>
    /// This class can be used to backup and restore a Database.
    /// </summary>
    class DatabaseHelper
    {
        /// <summary>
        /// Default constructor - Private
        /// </summary>
        private DatabaseHelper()
        {
            dbName = String.Empty;
            serverInstance = String.Empty;
        }

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="serverInstance"></param>
        /// <param name="dbName"></param>
        public DatabaseHelper(string serverInstance, string dbName) : this()
        {
            if(null == serverInstance || serverInstance.Trim().Length <= 0)
            {
                throw new ArgumentException("The argument serverinstance gets en exception.");
            }
            if(null == dbName || dbName.Trim().Length <= 0)
            {
                throw new ArgumentException("The argument dbName gets en exception.");
            }

            this.serverInstance = serverInstance;
            this.dbName = dbName;
        }
        /// <summary>
        /// ����ACCESSS���ݿ�
        /// </summary>
        /// <param name="sourceFile"></param>
        /// <param name="targetFile"></param>
        public static void BackupDb(string sourceFile,string targetFile)
        {
            File.Copy(sourceFile, targetFile, true);
        }

        /// <summary>
        /// Backup data to disk
        /// </summary>
        /// <param name="backupFile"></param>
        public void BackupDBToDisk(string backupFile)
        {
            if(null == backupFile || backupFile.Trim().Length <= 0)
            {
                throw new ArgumentException("The argument backupFile gets en exception.");
            }

            SqlConnection connection = null;
            SqlCommand command = null;

            try
            {
                connection = new SqlConnection();
                connection.ConnectionString = String.Format(CultureInfo.CurrentUICulture, "Server={0};Integrated Security=SSPI;DataBase=master", this.serverInstance);

                command = new SqlCommand(String.Format(CultureInfo.CurrentUICulture, "BACKUP DATABASE {0} TO DISK='{1}'", this.dbName, backupFile));
                command.Connection = connection;
                command.CommandTimeout = 900;

                connection.Open();
                command.ExecuteNonQuery();
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Restore DB from disk - no file move
        /// </summary>
        /// <param name="backupFile"></param>
        public void RestoreDBFromDisk(string backupFile)
        {
            if(null == backupFile || backupFile.Trim().Length <= 0)
            {
                throw new ArgumentException("The argument backupFile gets en exception.");
            }

            SqlConnection connection = null;
            SqlCommand command = null;

            try
            {
                connection = new SqlConnection();
                connection.ConnectionString = String.Format(CultureInfo.CurrentUICulture, "Server={0};Integrated Security=SSPI;DataBase=master", this.serverInstance);

                command = new SqlCommand(String.Format(CultureInfo.CurrentUICulture, "RESTORE DATABASE {0} FROM DISK='{1}' WITH FILE = 1", this.dbName, backupFile));
                command.Connection = connection;
                command.CommandTimeout = 900;

                connection.Open();
                command.ExecuteNonQuery();
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Restore DB from disk with file move
        /// </summary>
        /// <param name="backupFile"></param>
        /// <param name="dataFilePath"></param>
        /// <param name="logFilePath"></param>
        public void RestoreDBFromDisk(string backupFile, string dataFilePath, string logFilePath)
        {
            if(null == backupFile || backupFile.Trim().Length <= 0)
            {
                throw new ArgumentException("The argument backupFile gets en exception.");
            }
            if(null == dataFilePath || dataFilePath.Trim().Length <= 0)
            {
                throw new ArgumentException("The argument dataFilePath gets en exception.");
            }
            if(null == logFilePath || logFilePath.Trim().Length <= 0)
            {
                throw new ArgumentException("The argument logFilePath gets en exception."); 
            }

            SqlConnection connection = null;
            SqlCommand fileListCommand = null;
            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                connection = new SqlConnection();
                connection.ConnectionString = String.Format(CultureInfo.CurrentUICulture, "Server={0};Integrated Security=SSPI;DataBase=master", this.serverInstance);

                fileListCommand = new SqlCommand(String.Format(CultureInfo.CurrentUICulture, "RESTORE FILELISTONLY FROM DISK = '{0}'", backupFile));
                fileListCommand.Connection = connection;
                
                string restoreCommand = String.Empty;
            
                connection.Open();
                
                // Get filelist to build restore with move file command
                // 
                using (reader = fileListCommand.ExecuteReader())
                {
                    restoreCommand = String.Format(CultureInfo.CurrentUICulture, "RESTORE DATABASE {0} FROM DISK='{1}' WITH FILE = 1", this.dbName, backupFile);
                    while (reader.Read())
                    {
                        if (String.Compare(reader["Type"].ToString(), "L", true, CultureInfo.CurrentUICulture) == 0)
                        {
                            restoreCommand = String.Format(CultureInfo.CurrentUICulture, "{0}, MOVE '{1}' TO '{2}\\{3}'"
                                , restoreCommand
                                , reader["LogicalName"].ToString()
                                , logFilePath
                                , Path.GetFileName(reader["PhysicalName"].ToString()));
                        }
                        else
                        {
                            restoreCommand = String.Format(CultureInfo.CurrentUICulture, "{0}, MOVE '{1}' TO '{2}\\{3}'"
                                , restoreCommand
                                , reader["LogicalName"].ToString()
                                , dataFilePath
                                , Path.GetFileName(reader["PhysicalName"].ToString()));
                        }
                    }
                }

                // Command to restore DB with move file option.
                // 
                command = new SqlCommand(restoreCommand);
                command.Connection = connection;
                command.CommandTimeout =900;
                command.ExecuteNonQuery();
            }
            finally
            {
                connection.Close();
            }
        }

        private string serverInstance;
        private string dbName;
     }
}