using System.Windows.Forms;
using System.Web.UI;

namespace Zivsoft.Business.Helper
{
    class MsgBox
    {
        public static void ShowError(string message)
        {
            MessageBox.Show(message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        public static void ShowInfo(string message) {
            MessageBox.Show(message, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        /// <summary>
        /// no refresh
        /// </summary>
        public static void ShowWarning(string msg, Page page)
        {
#pragma warning disable 618,612
            page.RegisterStartupScript("", "<script>window.alert('" + msg + "');</script>");
#pragma warning restore 618,612
        }
    }
}