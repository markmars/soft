﻿using System.Threading;
using System.Diagnostics;
/*
 * Created by Lihua at 11/09/2007
 */

namespace Zivsoft.Business.Helper
{
    class FileExecute
    {
        public static void ExecuteFile(string fileName)
        {
            ProcessStartInfo psInfo = new ProcessStartInfo(fileName);
            Process p = Process.Start(psInfo);
            while (!p.HasExited)
            {
                Thread.Sleep(1000);
            }
        }
    }
}