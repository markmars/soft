﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Zivsoft.Utils;

namespace Zivsoft.Business.OfficeLogManager
{
    class OfficeLogManager:IOfficeLogManager
    {
        #region IOfficeLogManager Members

        public string[] GetAllSubNodeNames(string path)
        {
            try
            {
                var paths = Directory.GetDirectories(path);
                string[] data=new string[paths.Length];
                var i=0;
                if (paths.Length == 0) { return null; }
                else
                {
                    var result = from p in paths
                                 select Path.GetFileName(Path.GetDirectoryName(p+"\\"));
                    foreach(var p in result){
                        data[i++]=p;
                    }
                    return data;
                }
            }
            catch
            {
                return null;
            }
        }



        public bool CreateNode(string path)
        {
            try
            {
                Directory.CreateDirectory(path);
                if (!FileUtils.Exists(FileUtils.CombinePath(path, FileUtils.GetDirectory(path) + ".txt"))) { 
                    FileUtils.SaveStringAsFile("",FileUtils.CombinePath(path, FileUtils.GetDirectory(path) + ".txt"));
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool RenameNode(string path,string newPath)
        {
            try
            {
                Directory.Move(path, newPath);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteNode(string path)
        {
            try
            {
                Directory.Delete(path, true);
                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion
    }
}
