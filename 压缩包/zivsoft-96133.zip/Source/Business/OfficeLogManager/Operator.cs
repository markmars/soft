﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using Zivsoft.Utils;

namespace Zivsoft.Business.OfficeLogManager
{
    class Operator:IOperator
    {
        #region IOperator Members

        public void Click(TreeView treeView1, TextBox textBox1)
        {
            var name = FileUtils.CombinePath(treeView1.SelectedNode.Name, treeView1.SelectedNode.Text, treeView1.SelectedNode.Text + ".txt");
            if (!FileUtils.Exists(name))
            {
                FileUtils.SaveStringAsFile(textBox1.Text, name);
            }
            else
            {
                textBox1.Text = FileUtils.ReadFile4String(name);
            }
        }

        #endregion

        IOfficeLogManager oper = new OfficeLogManager();
        public void Load(TreeView treeView1)
        {
            
            treeView1.CollapseAll();
            var root = oper.GetAllSubNodeNames(AppDomain.CurrentDomain.BaseDirectory);
            LoadTree(treeView1.Nodes, root, AppDomain.CurrentDomain.BaseDirectory, 0);

        }


        private void LoadTree(TreeNodeCollection treeNode, string[] root, string parent, int level)
        {
            if (!root.IsNullOrEmpty())
            {

                foreach (var r in root)
                {
                    TreeNode tn = new TreeNode(r);
                    tn.Name = parent;
                    treeNode.Add(tn);
                    var p = FileUtils.CombinePath(parent, r);
                    LoadTree(tn.Nodes, oper.GetAllSubNodeNames(p), p, ++level);
                }
            }
        }
        TreeView treeView1;
        TextBox textBox1;
        public void New()
        {
            //save the
            var newnode = this.treeView1.SelectedNode.Nodes.Add("untitled");
            newnode.BackColor = Color.Blue;
            var node = FileUtils.CombinePath(treeView1.SelectedNode.Name, "untitled");
            oper.CreateNode(node);
        }

        public void TextChanged()
        {
            FileUtils.SaveStringAsFile(this.textBox1.Text, GetCurrentEditFileFullName());
        }


        private string GetCurrentEditFileFullName()
        {
            return FileUtils.CombinePath(this.treeView1.SelectedNode.Name, this.treeView1.SelectedNode.Text, this.treeView1.SelectedNode.Text + ".txt");
        }
    }
}
