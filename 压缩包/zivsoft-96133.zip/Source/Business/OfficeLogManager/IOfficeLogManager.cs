﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Zivsoft.Business.OfficeLogManager
{
    /// <summary>
    /// filename=foldername
    /// every folder, a file in it, the same as its name.
    /// </summary>
    interface IOfficeLogManager
    {
        string[] GetAllSubNodeNames(string parentDir);
        bool CreateNode(string path);
        bool RenameNode(string path,string newpath);
        bool DeleteNode(string path);
    }
    interface IOperator
    {
        void Click(TreeView treeView, TextBox textBox);
    }
}
