﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Files
{
    class NameCreater
    {
        public static string CreateDateTimeName()
        {
            return DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + "_"+DateTime.Now.Millisecond;
        }
    }
}
