﻿using System;
using System.IO;

namespace Zivsoft.Business.Files
{
    class FileSaver
    {
        public static void SaveToHtml(string text)
        {
            var fs=File.Create(AppDomain.CurrentDomain.BaseDirectory + NameCreater.CreateDateTimeName()+".html");
            var sw = new StreamWriter(fs);
            sw.Write(text);
        }
    }
}
