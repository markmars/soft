﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Calculate
{
    class CalculateOperator
    {
        /// <summary>
        /// 根据运算表达式计算结果
        /// </summary>
        /// <param name="expression">四则运算表达式</param>
        /// <returns>返回结果</returns>
        public static object GetValue(string expression)
        {
            if (expression==null||expression.Trim()=="")
            {
                return null;
            }
            CalculateOperator cal = new CalculateOperator(expression);
            return cal.DoCal();
        }
        /// <summary>
        /// 算术符栈
        /// </summary>
        private ArrayList HList;
        /// <summary>
        /// 数值栈
        /// </summary>
        public ArrayList Vlist;
        /// <summary>
        /// 读算试工具
        /// </summary>
        private CalUtility cu;
        /// <summary>
        /// 运算操作器工厂
        /// </summary>
        private OperFactory of;
        /// <summary>
        /// 构造方法
        /// </summary>
        /// <param name="expression">算式</param>
        public CalculateOperator(string expression)
        {
            HList = new ArrayList();
            Vlist = new ArrayList();
            of = new OperFactory();
            cu = new CalUtility(expression);
        }

        /// <summary>
        /// 开始计算
        /// </summary>

        public object DoCal()
        {
            string strTmp = cu.getItem();
            while (true)
            {
                if (cu.IsNum(strTmp))
                {
                    //如果是数值，则写入数据栈
                    Vlist.Add(strTmp);
                }
                else
                {
                    //数值
                    Cal(strTmp);
                }
                if (strTmp.Equals(""))
                    break;
                strTmp = cu.getItem();
            }
            if (Vlist.Count == 0)
            {
                return null;
            }
            else
            {
                return Vlist[0];
            }
        }

        /// <summary>
        /// 计算
        /// </summary>
        /// <param name="str">计算符</param>

        private void Cal(string str)
        {
            //符号表为空，而且当前符号为""，则认为已经计算完毕
            if (str.Equals("") && HList.Count == 0)
                return;
            if (HList.Count > 0)
            {
                //符号是否可以对消？
                if (HList[HList.Count - 1].ToString().Equals("(") && str.Equals(")"))
                {
                    HList.RemoveAt(HList.Count - 1);
                    if (HList.Count > 0)
                    {
                        str = HList[HList.Count - 1].ToString();
                        HList.RemoveAt(HList.Count - 1);
                        Cal(str);
                    }
                    return;
                }
                if (cu.Compare(HList[HList.Count - 1].ToString(), str))
                {
                    IOper p = of.CreateOper(HList[HList.Count - 1].ToString());
                    if (p != null&&Vlist.Count>1)
                    {
                        Vlist[Vlist.Count - 2] = p.Oper(Vlist[Vlist.Count - 2], Vlist[Vlist.Count - 1]);
                        HList.RemoveAt(HList.Count - 1);
                        Vlist.RemoveAt(Vlist.Count - 1);
                        Cal(str);
                    }
                    return;
                }
                if (!str.Equals(""))
                    HList.Add(str);
            }
            else
            {
                if (!str.Equals(""))
                    HList.Add(str);
            }
        }
    }

}
