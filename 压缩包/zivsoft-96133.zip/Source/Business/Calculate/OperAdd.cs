﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Zivsoft.Business.Calculate
{

    /// <summary>
    /// Opers 的摘要说明。
    /// 各类计算符的接口实现，加减乘除
    /// </summary>

    class OperAdd : IOper
    {
        public OperAdd()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
        #region IOper 成员

        public object Oper(object o1, object o2)
        {
            Decimal d1 = Decimal.Parse(o1.ToString());
            Decimal d2 = Decimal.Parse(o2.ToString());
            return d1 + d2;
        }

        #endregion


    }
}
