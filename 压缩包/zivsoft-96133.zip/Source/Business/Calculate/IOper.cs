﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Calculate
{
    /// <summary>
    /// 
    /// </summary>

    interface IOper
    {
        object Oper(object o1, object o2);
    }
}
