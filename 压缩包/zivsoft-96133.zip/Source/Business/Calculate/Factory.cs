﻿using System;
using Zivsoft.Log;


namespace Zivsoft.Business.Calculate
{
    class Factory
    {
        public static void Main()
        {
            try
            {
                var str = Console.ReadLine();
                var val = CalculateOperator.GetValue(str);
                Console.WriteLine(val);
            }
            catch(Exception e)
            {
                Logger.LogError(e);

            }
#if DEBUG
            Console.Read();
#endif
        }
    }
}
