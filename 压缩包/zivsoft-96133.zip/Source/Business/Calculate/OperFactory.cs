﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Calculate
{
    /// <summary>
    /// OperFactory Summary
    /// operator factory
    /// </summary>
    class OperFactory
    {
        public OperFactory()
        {

        }

        public IOper CreateOper(string Oper)
        {
            if (Oper.Equals("+"))
            {
                IOper p = new OperAdd();
                return p;
            }
            if (Oper.Equals("-"))
            {
                IOper p = new OperDec();
                return p;
            }
            if (Oper.Equals("*"))
            {
                IOper p = new OperRide();
                return p;
            }
            if (Oper.Equals("/"))
            {
                IOper p = new OperDiv();
                return p;
            }
            return null;
        }
    }
}
