﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Zivsoft.Business.Calculate
{

    class OperDiv : IOper
    {
        public OperDiv()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
        #region IOper 成员

        public object Oper(object o1, object o2)
        {
            Decimal d1 = Decimal.Parse(o1.ToString());
            Decimal d2 = Decimal.Parse(o2.ToString());
            object result = null;
            try
            {
                result = d1 / d2;
            }
            catch
            {
                result = null;
            }
            return result;
        }

        #endregion
    }
}
