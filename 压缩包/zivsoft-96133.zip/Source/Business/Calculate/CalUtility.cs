﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zivsoft.Business.Calculate
{
    /// <summary>
    /// CalUtility 的摘要说明。
    /// 读算式辅助工具
    /// </summary>

    class CalUtility
    {
        StringBuilder StrB;
        private int iCurr = 0;
        private int iCount = 0;

        /// <summary>
        /// 构造方法
        /// </summary>

        public CalUtility(string calStr)
        {
            StrB = new System.Text.StringBuilder(calStr.Trim());
            iCount = System.Text.Encoding.Default.GetByteCount(calStr.Trim());
        }

        /// <summary>
        /// 取段，自动分析数值或计算符
        /// </summary>
        /// <returns></returns>

        public string getItem()
        {
            //结束了
            if (iCurr == iCount)
                return "";
            char ChTmp = StrB[iCurr];
            bool b = IsNum(ChTmp);
            if (!b)
            {
                iCurr++;
                return ChTmp.ToString();
            }
            string strTmp = "";
            while (IsNum(ChTmp) == b && iCurr < iCount)
            {
                ChTmp = StrB[iCurr];
                if (IsNum(ChTmp) == b)
                    strTmp += ChTmp;
                else
                    break;
                iCurr++;
            }
            return strTmp;
        }

        /// <summary>
        /// 是否是数字
        /// </summary>
        /// <param name="c">内容</param>
        /// <returns></returns>

        public bool IsNum(char c)
        {
            if ((c >= '0' && c <= '9') || c == '.')
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 是否是数字
        /// </summary>
        /// <param name="c">内容</param>
        /// <returns></returns>

        public bool IsNum(string c)
        {
            if (c.Equals(""))
                return false;
            if ((c[0] >= '0' && c[0] <= '9') || c[0] == '.')
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 比较str1和str2两个运算符的优先级，ture表示str1高于str2，false表示str1低于str2
        /// </summary>
        /// <param name="str1">计算符1</param>
        /// <param name="str2">计算符2</param>
        /// <returns></returns>

        public bool Compare(string str1, string str2)
        {
            return getPriority(str1) >= getPriority(str2);
        }

        /// <summary>
        /// 取得计算符号的优先级
        /// </summary>
        /// <param name="str">计算符</param>
        /// <returns></returns>

        public int getPriority(string str)
        {
            if (str.Equals(""))
            {
                return -1;
            }
            if (str.Equals("("))
            {
                return 0;
            }
            if (str.Equals("+") || str.Equals("-"))
            {
                return 1;
            }
            if (str.Equals("*") || str.Equals("/"))
            {
                return 2;
            }
            if (str.Equals(")"))
            {
                return 0;
            }
            return 0;
        }
    }


}
