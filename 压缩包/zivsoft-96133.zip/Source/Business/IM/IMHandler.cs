using System;
using System.Threading;

namespace Zivsoft.Business.IM
{
    class IMHandler
    {
        private static Guid _session = Guid.Empty;
        public static Guid Session
        {
            get
            {
                if (_session == Guid.Empty)
                {
                    _session=Guid.NewGuid();
                }
                return _session;
            }
        }

        public static void Send(string message)
        {
            var c = new Server();
            c.Send(message);
        }

        [STAThread]
        public static void Main()
        {
            var tsServer = new ThreadStart(StartServer);
            var tsClient = new ThreadStart(StartClient);
            var tsS = new Thread(tsServer);
            var tsC = new Thread(tsClient);
            tsS.Start();
            tsC.Start();

        }

        private static void StartServer()
        {
            var server = new Server();
            server.Start();
            do
            {
                server.Send(Console.ReadLine());
                if (server.NumberOfConnections > 0)
                {
                    Thread.Sleep(2500);
                }
                else
                {
                    Thread.Sleep(2000);
                }

            } while (true);
        }
        private static void StartClient()
        {

            var c = new Client();
            Thread.Sleep(2500);
            while (true)
            {
                c.Start(1);
                while (c.Running)
                {
                    Thread.Sleep(2500);
                }
                Thread.Sleep(3000);
            }
        }
    }
}
