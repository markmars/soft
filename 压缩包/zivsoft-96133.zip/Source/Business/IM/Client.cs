using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace Zivsoft.Business.IM
{

    class Client
    {
        TcpClient _client;
        private bool _isRunning;
        public bool Running { get { return _isRunning; } }
        public Client()
        {
        }
        public void Start(int numberOfConnections)
        {
            _isRunning = true;
            for (int i = 0; i <= numberOfConnections; i++)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(this.ProcessClientThread));
            }
            _isRunning = false;
        }
        public void ProcessClientThread(object nothing)
        {
            try
            {
                using (_client = new TcpClient(IPAddress.Loopback.ToString(), 12345))
                {

                    _client.ReceiveTimeout = int.MaxValue;
                    var ns = _client.GetStream();
                    var sr = new StreamReader(ns);
                    string s = sr.ReadToEnd();
                    if (s != null && s.ToString().Trim() != "")
                    {
                        MessageBox.Show(s);
                    }
                    sr.Close();
                }
            }
            catch(Exception e)
            {
                throw e;
            }
        }
    }
}
