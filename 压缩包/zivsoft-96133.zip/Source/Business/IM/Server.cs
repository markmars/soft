using System;
using System.IO;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace Zivsoft.Business.IM
{
    
    class Server
    {
        private string _message = null;
        private TcpListener _listener;
        private bool _running;
        private int _numOfConnections;
        public int NumberOfConnections { get { return this._numOfConnections; } }
        /// <summary>
        /// 
        /// </summary>
        public Server()
        {
            _listener = new TcpListener(IPAddress.Loopback,12345);
            _running = false;
            _numOfConnections = 0;
        }
        public void Send(string message) {
            this._message = message;
        }
        public void Start()
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(StartServer));
        }
        public void Stop()
        {
            _running = false;
        }
        public void StartServer(object nothing)
        {
            _running = true;
            _listener.Start();
            while (_running)
            {
                TcpClient client = _listener.AcceptTcpClient();
                _numOfConnections++;
                ThreadPool.QueueUserWorkItem(new WaitCallback(this.ProcessClient), client);
            }
        }
        public void ProcessClient(object clientObject)
        {
            using (TcpClient client = clientObject as TcpClient)
            {
                if (this._message != null)
                {
                    using (StreamWriter sw = new StreamWriter(client.GetStream()))
                    {
                        sw.WriteLine(this._message);
                        this._message = null;
                        sw.Flush();
                    }
                }
            }
            _numOfConnections--;
        }
    }
}
