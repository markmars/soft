﻿using System.Web.Security;
using Zivsoft.IO.Security;

using Zivsoft.Services;
using Zivsoft.Business.Security;

namespace Zivsoft.Business
{
    class SecurityFactory : BusinessHandler
    {
        ISecurity cert = new SecurityHelper();
        protected override bool Check(Request request)
        {
            if (request is SecurityRequest)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        protected override Response PerformTask(Request req)
        {
            if (req is CheckCert)
            {
                SecurityRequest request = req as CheckCert;
                var res = new SecurityResponse();
                ISecurity cert = new SecurityHelper();
                res.Cert = cert.CheckCert();
                return res;
            }
            else
            {
                return NoBusinessCode;
            }
        }
    }

}