﻿using System;
using System.Collections.Generic;
using System.Text;
using Zivsoft.Business.Security;

namespace Zivsoft.Business.Users
{
    class MD5
    {
        public static string Get(string str)
        {
            ISecurity sec = new SecurityHelper();
            return sec.MD5(str);
        }
    }
}
