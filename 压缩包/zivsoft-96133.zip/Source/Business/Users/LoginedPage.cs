using System.Web.UI;

namespace Zivsoft.Business.Logins
{
    class LoginedPage
    {
        public bool Verify(Page p)
        {
            if (p.Session["LoginedID"] == null)
            {
                return false;
            }
            this._userName = p.Session["LoginedID"].ToString();
            return true;
        }

        private string _userName;
        public string UserName
        {
            get
            {
                return this._userName;
            }
        }
    }
}
