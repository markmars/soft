﻿using System;
using Zivsoft.Data.ORM.Entity;

namespace Zivsoft.Business.Users
{
    /// <summary>
    /// User Login
    /// </summary>
    class Login
    {

        private string _user;
        private string _pwd;
        private UserInfo _userInfo;
        private RoleInfo _roleInfo;
        
        public Login(string strUser, string strPass)
        {
            this._user = strUser;
            this._pwd = strPass;
        }

        private UserInfo CheckLogin()
        {
            UserInfo user = new UserInfo();
            user.UserId = this._user;
            user.Load();
            if (user.Password.Value ==MD5.Get(this._pwd)) 
            {
                return user;
            }
            else
            {
                return null;
            }
        }

        public bool Check()
        {
            UserInfo user = this.CheckLogin();
            if (user != null)
            {
                this._userInfo = user;
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Update(string ip) {
            RoleInfo role = new RoleInfo();
            role.RoleId = this._userInfo.RoleId;
            role.Load();
            this._roleInfo = role;

            UserInfo updateUser = new UserInfo();
            updateUser.UserId = this._user;
            updateUser.IP = ip;
            updateUser.LoginTime = DateTime.Now;
            updateUser.Update();
            return true;
        }
        public string GetUserTheme()
        {
            return this._userInfo.Theme.Value;
        }
        public string GetUserName()
        {
            return this._userInfo.UserName.Value;
        }
        
        public string GetRoleName() {
            return this._roleInfo.RoleName.Value;
        }
    }
}
