﻿using System;
using System.Collections.Generic;
using System.Text;
using Zivsoft.Data;
using Zivsoft.Data.Entity;
using Zivsoft.Data.ORM.Entity;


/*****************
 * Updated by Lihua Zhou at 11/13/2008
 * We need the updated Zivsoft.Register.dll
 * 
 ******************/
namespace Zivsoft.Business.Users
{
    class ChangePasswordRequest
    {
        private string _userId;
        public string CurrentUserId
        {
            set {
                _userId = value;
            }
        }

        private string _newpwd;
        public string NewPWD
        {
            set
            {
                _newpwd = value;
            }
        }
        private const string SQL_CHANGE_PASSWORD = "update [userinfo] set [password]='{1}' where [userid]='{0}'";
        private bool Change(string userId, string newPassword)
        {
            try
            {
                UserInfo userInfo = new UserInfo();
                userInfo.UserId = userId;
                userInfo.Password = MD5.Get(newPassword);

                int i = userInfo.Update();//DbOper.Default.ExcuteSql(string.Format(SQL_CHANGE_PASSWORD, userId,MD5.Get(newPassword)));
                if (i == 1) { return true; }
                else { return false; }
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public ChangePasswordRepnose GetResponse()
        {
            ChangePasswordRepnose res = new ChangePasswordRepnose();
            bool b = Change(this._userId, this._newpwd);
            res.IsChange = b;
            return res;
        }

    }
    class ChangePasswordRepnose
    {
        private bool _isError;
        public bool IsError
        {
            get
            {
                return _isError;
            }
            set
            {
                this._isError = value;
            }
        }

        private string _errorMessage=null;
        public string ErrorMessage
        {
            get
            {
                return _errorMessage;
            }
        }

        private bool _isChange;
        public bool IsChange
        {
            get
            {
                return _isChange;
            }
            set
            {
                _isChange = value;
            }
        }
    }
}
