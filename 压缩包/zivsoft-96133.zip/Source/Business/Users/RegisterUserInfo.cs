﻿using System;
using System.Collections.Generic;
using System.Text;
using Zivsoft.Business.Security;
using Zivsoft.Data;
using Zivsoft.Data.Entity;
using Zivsoft.Data.ORM.Entity;


namespace Zivsoft.Business.Users
{
    class RegisterUserInfo
    {
        public int Register(string userId,string password,string userName)
        {
            UserInfo userInfo = new UserInfo();
            userInfo.UserId=userId;
            userInfo.Password=MD5.Get(password);
            userInfo.UserName=userName;
            try
            {
                userInfo.Insert();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
    }
}
