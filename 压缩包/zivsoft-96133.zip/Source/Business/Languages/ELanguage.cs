namespace Zivsoft.Business.Languages
{
	/// <summary>
	/// ELanguage
	/// </summary>
	enum ELanguage
	{
        Default,
		Chinese,
		English
	}
}
