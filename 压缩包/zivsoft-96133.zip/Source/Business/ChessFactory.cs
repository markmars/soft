﻿using System;
using System.Windows.Forms;

using Zivsoft.Business.Chess.Board;
using Zivsoft.Business.Finance.Helper;
using Zivsoft.Log;
using Zivsoft.Services;


namespace Zivsoft.Business
{
    class ChessFactory :BusinessHandler
    {

        protected override Response PerformTask(Request request)
        {
            try
            {
                Application.Run(new MainForm());
            }
            catch (Exception e)
            {
                ErrorDialogs.Show(e.Message);
                Logger.LogError(e);
            }
            return new Response();
        }

        protected override bool Check(Request request)
        {
            return true;
        }
    }
}
