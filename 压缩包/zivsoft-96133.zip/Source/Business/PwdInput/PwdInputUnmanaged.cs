﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Permissions;
using System.Collections;

namespace Zivsoft.Business.PwdInput
{
    static partial class PwdInputer
    {

        public static void Try()
        {
            var i = 0;
            while (i < 10)
            {
                i++;
                ReadKey();
            }
        }

        static void ReadKey()
        {
            Win32Native.InputRecord record;
            IntPtr i = new IntPtr(3);
            int numEventsRead;
            do
            {
                if (!Win32Native.ReadConsoleInput(i, out record, 1, out numEventsRead))
                {
                    throw new InvalidOperationException("InvalidOperation_ConsoleReadKeyOnFile");
                }
            }
            while (!PwdInputUnmanaged.IsKeyDownEvent(record) || ((record.keyEvent.uChar == '\0') && PwdInputUnmanaged.IsModKey(record.keyEvent.virtualKeyCode)));

        }
        /// <summary>
        /// no display
        /// </summary>
        public static void InputNativePwd()
        {
            char[] chars = new char[] { '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '+', '|', '\\', '/', '\'', '\"', '[', ']', '{', '}', ',', '.' };
            Console.Write("Input your password (identifier,!,@,#,$,%,^,&,*,(,),-,+,|,\\,/,',\",[,],{,})");
            ConsoleKeyInfo keyInfo = PwdInputUnmanaged.ReadKey();
            string s = null;
            while (keyInfo.Key != ConsoleKey.Enter)
            {
                if (char.IsNumber(keyInfo.KeyChar) || char.IsLetter(keyInfo.KeyChar) || keyInfo.KeyChar == '_')
                {
                    s += keyInfo.KeyChar;
                }
                else
                {

                    IEnumerable cs = from c in chars select c;
                    foreach (char c in cs)
                    {
                        if (c == keyInfo.KeyChar)
                        {
                            s += keyInfo.KeyChar;
                        }
                    }
                }
                keyInfo = Console.ReadKey(true);
            }
            Console.WriteLine();
            Console.WriteLine("{0}", s);
        }
    }

    class PwdInputUnmanaged
    {
        private static Win32Native.InputRecord _cachedInputRecord;
        private static IntPtr _consoleInputHandle;


        private static IntPtr ConsoleInputHandle
        {
            get
            {
                if (_consoleInputHandle == IntPtr.Zero)
                {
                    _consoleInputHandle = Win32Native.GetStdHandle(-10);
                }
                return _consoleInputHandle;
            }
        }



        [HostProtection(SecurityAction.LinkDemand, UI = true)]
        public static ConsoleKeyInfo ReadKey()
        {
            bool intercept = true;
            Win32Native.InputRecord record;
            int numEventsRead = -1;
            if (_cachedInputRecord.eventType == 1)
            {
                record = _cachedInputRecord;
                if (_cachedInputRecord.keyEvent.repeatCount == 0)
                {
                    _cachedInputRecord.eventType = -1;
                }
                else
                {
                    _cachedInputRecord.keyEvent.repeatCount = (short)(_cachedInputRecord.keyEvent.repeatCount - 1);
                }
            }
            else
            {
                do
                {
                    if (!Win32Native.ReadConsoleInput(ConsoleInputHandle, out record, 1, out numEventsRead) || (numEventsRead == 0))
                    {
                        throw new InvalidOperationException("InvalidOperation_ConsoleReadKeyOnFile");
                    }
                }
                while (!IsKeyDownEvent(record) || ((record.keyEvent.uChar == '\0') && IsModKey(record.keyEvent.virtualKeyCode)));
                if (record.keyEvent.repeatCount > 1)
                {
                    record.keyEvent.repeatCount = (short)(record.keyEvent.repeatCount - 1);
                    _cachedInputRecord = record;
                }
            }
            ControlKeyState controlKeyState = (ControlKeyState)record.keyEvent.controlKeyState;
            bool shift = (controlKeyState & ControlKeyState.ShiftPressed) != 0;
            bool alt = (controlKeyState & (ControlKeyState.LeftAltPressed | ControlKeyState.RightAltPressed)) != 0;
            bool control = (controlKeyState & (ControlKeyState.LeftCtrlPressed | ControlKeyState.RightCtrlPressed)) != 0;
            ConsoleKeyInfo info = new ConsoleKeyInfo(record.keyEvent.uChar, (ConsoleKey)record.keyEvent.virtualKeyCode, shift, alt, control);
            if (!intercept)
            {
                Write(record.keyEvent.uChar);
            }
            return info;
        }

        internal static bool IsKeyDownEvent(Win32Native.InputRecord ir)
        {
            return ((ir.eventType == 1) && ir.keyEvent.keyDown);
        }

        [HostProtection(SecurityAction.LinkDemand, UI = true)]
        public static void Write(char value)
        {
            System.Console.Out.Write(value);
        }

        public static bool IsModKey(short keyCode)
        {
            if (((keyCode < 0x10) || (keyCode > 0x12)) && ((keyCode != 20) && (keyCode != 0x90)))
            {
                return (keyCode == 0x91);
            }
            return true;
        }

    }

    [Flags]
    internal enum ControlKeyState
    {
        CapsLockOn = 0x80,
        EnhancedKey = 0x100,
        LeftAltPressed = 2,
        LeftCtrlPressed = 8,
        NumLockOn = 0x20,
        RightAltPressed = 1,
        RightCtrlPressed = 4,
        ScrollLockOn = 0x40,
        ShiftPressed = 0x10
    }
}
