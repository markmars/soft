﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.Business.PwdInput
{
    static partial class PwdInputer
    {

        /// <summary>
        /// no display
        /// </summary>
        public static string InputPasswordWithNoDisplay()
        {
            char[] chars = new char[] { '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '+', '|', '\\', '/', '\'', '\"', '[', ']', '{', '}', ',', '.' };
            //Console.Write("Input your password (identifier,!,@,#,$,%,^,&,*,(,),-,+,|,\\,/,',\",[,],{,})");
            ConsoleKeyInfo keyInfo = Console.ReadKey(true);
            string s = null;
            while (keyInfo.Key != ConsoleKey.Enter)
            {
                if (char.IsNumber(keyInfo.KeyChar) || char.IsLetter(keyInfo.KeyChar) || keyInfo.KeyChar == '_')
                {
                    s += keyInfo.KeyChar;
                }
                else
                {

                    IEnumerable cs = from c in chars select c;
                    foreach (char c in cs)
                    {
                        if (c == keyInfo.KeyChar)
                        {
                            s += keyInfo.KeyChar;
                        }
                    }
                }
                keyInfo = Console.ReadKey(true);
            }
            //Console.WriteLine();
            //Console.WriteLine("{0}", s);
            return s;
        }

        /// <summary>
        /// Input the identifier
        /// </summary>
        public static void InputIdentifier()
        {
            Console.Write("Input identifier (_,0-9,a-z,A-Z,the first letter mustn't be 0-9): ");
            ConsoleKeyInfo keyInfo = Console.ReadKey(true);
            string s = null;
            while (keyInfo.Key != ConsoleKey.Enter)
            {
                //if the first time, and the char is the number, ignore this entry
                if (s == null && char.IsNumber(keyInfo.KeyChar))
                {
                    goto c;
                }

                if (('A' <= keyInfo.KeyChar && keyInfo.KeyChar <= 'Z') || ('a' <= keyInfo.KeyChar && keyInfo.KeyChar <= 'z') || ('0' <= keyInfo.KeyChar && keyInfo.KeyChar <= '9') || keyInfo.KeyChar == '_')
                {
                    s += keyInfo.KeyChar;
                    Console.Write('*');
                }

                c: keyInfo = Console.ReadKey(true);

            }
            Console.WriteLine();
            Console.WriteLine("{0}", s);
        }
    }
}