﻿using System;
using System.Diagnostics;
using System.Reflection;

namespace Zivsoft.Business.Run
{
    /// <summary>
    /// Your log assembly name must be Log.dll
    /// </summary>
    class RunReflection
    {
        private static Assembly assembly;
        static RunReflection()
        {
            try
            {
                assembly = Assembly.GetExecutingAssembly();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }
        
        private static void GetInstance(string member, string message, params object[] args)
        {
            if (assembly != null)
            {
                var t = assembly.GetTypes();
                foreach (var type in t)
                {
                    if (type.BaseType.Name == "IRunner")
                    {
                        var objArgs = new object[] { message, args };
                        try
                        {
                            type.InvokeMember(member, BindingFlags.InvokeMethod, null, null, objArgs);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                            if (e.InnerException != null)
                            {
                                Debug.WriteLine(e.InnerException.Message);
                            }

                        }
                    }
                }
            }
        }
    }
}