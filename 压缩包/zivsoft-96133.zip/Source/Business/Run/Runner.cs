﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.Security;

using Zivsoft.Log;
using Zivsoft.Business.PwdInput;


namespace Zivsoft.Business.Run
{
    class Runner
    {
        unsafe public static void Main(string[] args)
        {
            if (args.Length >= 1)
            {
                var path = ConfigurationManager.AppSettings[args[0]];
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo(path);
                    if (args.Length>1&&args[1].Contains("/admin"))
                    {

                        Console.Write("UserName");
                        string strUserName = Console.ReadLine();

                        psi.UserName = strUserName;

                        Console.Write("\bPassword");
                        string pwd = PwdInputer.InputPasswordWithNoDisplay();

                        SecureString ss = new SecureString(GetCharPoint(pwd), pwd.Length);
                        psi.Password = ss;
                        psi.UseShellExecute = false;

                    }
                    Process.Start(psi);
                }
                catch (Exception e)
                {
                    Logger.LogError(e);
                }
            }
            else
            {
                Logger.LogWarning("args' lenght does not equal 1");
            }
            Console.Read();
        }

        unsafe static char* GetCharPoint(string str)
        {
            char* p;
            fixed (char* tp = str)
            {
                p = tp;
            }
            //while (*p!= '\0')
            //{
            //    Console.Write("{0}", *p);
            //    p++;
            //}
            return p;
        }
    }
}