﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using Zivsoft.Business.Security;

/**********************************
 * Register Tool
 **********************************/

namespace Zivsoft.Products.Register
{
    partial class Reg : Form
    {
        private ISecurity _security = new SecurityHelper();
        public Reg()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.progressBar1.Value = 10;
            this.LoadMachineCode();
        }

        private void LoadMachineCode()
        {
            this.progressBar1.Value = 60;
            try
            {
                this.textBox1.Text = _security.GetMachineCode();
                this.progressBar1.Value = 100;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "")
            {
                MessageBox.Show("Machine code can not be empty.","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                this.textBox1.Focus();
            }
            else if (this.txtLimit.Text == "")
            {
                MessageBox.Show("Limit can not be empty.","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                this.txtLimit.Focus();
            }
            else
            {
                try
                {
                    this.textBox2.Text = _security.GetRigsterCodeFromMachineCode(this.textBox1.Text, Convert.ToInt32((string) this.txtLimit.Text));
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://www.zivsoft.com");
        }
    }
}