﻿using System;
using System.Windows.Forms;

/*
 * 
 * 
 */

namespace Zivsoft.Products.Register
{
    internal static class RegServerFactory
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Launch()
        {
            try
            {
                Application.Run(new Reg());
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}