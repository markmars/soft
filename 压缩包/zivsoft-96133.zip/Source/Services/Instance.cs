﻿using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;

/***************************
 * 
 * Updated by Lihua Zhou at 11/13/2008:
 * 1.Check if read registry failed.
 * 
 ***************************/

namespace Zivsoft.Services
{
    class Instance
    {
        private string _businessHandler;

        public Instance(string businessHandler)
        {
            _businessHandler = businessHandler;
        }

        private string GetClass()
        {
            Debug.WriteLine("Getting class ...");
            var classname = ServiceHandler.Single().GetBusinessHandlerClass(this._businessHandler);
            if (string.IsNullOrEmpty(classname))
            {
                Debug.WriteLine("class name is null or empty");
            }
            Debug.WriteLine("Class name: {0}", classname);
            return classname;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private string GetAssemebly()
        {
            Debug.WriteLine("Getting assembly ...");
            var assemblyname = ServiceHandler.Single().GetBusinessHandlerAssmebly(_businessHandler);
            if (string.IsNullOrEmpty(assemblyname))
            {
                Debug.WriteLine("assembly file full name is null or empty");
            }
            Debug.WriteLine("Assembly name: {0}", assemblyname);
            return assemblyname;
        }

        /// <summary>
        /// Get Instance From Assembly file by calss name
        /// </summary>
        /// <returns>failed, return null</returns>
        public object GetBusinessObject()
        {

            Debug.WriteLine("Getting business object ...");
            var className = GetClass();
            var assemblyName = GetAssemebly();
            if (string.IsNullOrEmpty(className) || string.IsNullOrEmpty(assemblyName))
            {
                throw new Exception("className or assemblyName is null or empty");
            }
            if (File.Exists(assemblyName))
            {
                return Activator.CreateInstanceFrom(assemblyName, className).Unwrap();
            }
            var businessLogic = AppDomain.CurrentDomain.BaseDirectory + assemblyName;
            //=============================Finding in Bin==============================//
            if (!File.Exists(businessLogic))
            {
                businessLogic = AppDomain.CurrentDomain.BaseDirectory + "bin\\" + assemblyName;
            }
            if (!File.Exists(businessLogic))
            {
                Debug.WriteLine(businessLogic + " not found.");
                Assembly asm = Assembly.Load(assemblyName);
                return asm.CreateInstance(className);
            }
            else
            {
                return Activator.CreateInstanceFrom(businessLogic, className).Unwrap();
            }

        }
    }
}