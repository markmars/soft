﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using System.Configuration;
using System.Xml;
using Microsoft.Win32;
using System.Diagnostics;


/*
 * Created by ziv at 2007-2-10
 * Updated by Lihua at 7/30/2008
 */

namespace Zivsoft.Services
{
    /// <summary>
    /// Get the inner resource
    /// </summary>
    public class XmlStreamReader
    {
        /// <summary>
        /// Load Services.Principle.Services.xml From Services.Principle.dll
        /// </summary>
        /// <param name="resourceName"></param>
        /// <returns></returns>
        public Stream ReadStream(string resourceName)
        {
            //if exist the xml

            if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "Service.xml"))
            {
                return LoadFromFile(AppDomain.CurrentDomain.BaseDirectory + "Service.xml");
            }
            else if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "bin\\Service.xml"))
            {
                return LoadFromFile(AppDomain.CurrentDomain.BaseDirectory + "bin\\Service.xml");
            }
            else if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Business\\Service.xml"))
            {
                return LoadFromFile(AppDomain.CurrentDomain.BaseDirectory+"App_Data\\Business\\Service.xml");
            }

            //if xml does not exist
            Debug.WriteLine("Loading stream {0}", resourceName);

            var bin = AppDomain.CurrentDomain.BaseDirectory + Principle.Dll;
            if (!File.Exists(bin))
            {
                bin = AppDomain.CurrentDomain.BaseDirectory + "bin\\" + Principle.Dll;
            }

            if (!File.Exists(bin))
            {
                throw new FileNotFoundException(bin + " not found.");
            }

            var assembly = Assembly.LoadFrom(bin);

            var fullName = string.Format(Principle.Path, resourceName);

            var stream = assembly.GetManifestResourceStream(fullName);
            if (stream == null)
            {
                Debug.WriteLine("Get {0} failed.", fullName);
                throw new Exception(string.Format("Path {0} failed.", fullName));
            }
            return stream;
        }

        private Stream LoadFromFile(string fullpath)
        {
            return File.Open(fullpath, FileMode.Open);
        }
    }
}