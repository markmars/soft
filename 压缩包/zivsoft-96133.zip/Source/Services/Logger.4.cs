﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;
/********************************
 * Updated by Lihua at 03/13/2009
 * 
 * 更新功能：
 * 1. 升级到C#4.0，加入dynamic代替反射
 * 2. 如果Zivsoft.Log.dll不存在，日志不输出
 * 3. 项目编译不依赖于Zivsoft.Log.dll
 ****************************************/
namespace Zivsoft.Services
{
    /// <summary>
    /// 只提供持久数据层框架里的类使用
    /// </summary>
    internal class Logger
    {
        private static Assembly _assemblyFile;
        private static dynamic _logger;
        /// <summary>
        /// 初始化一次
        /// </summary>
        static Logger()
        {
            var strDllFile = AppDomain.CurrentDomain.BaseDirectory + "log.dll";
            if (File.Exists(strDllFile))
            {
                _assemblyFile = Assembly.LoadFile(strDllFile);
                try
                {
                    _logger = _assemblyFile.CreateInstance("Zivsoft.Log.Logger", false, BindingFlags.CreateInstance, null, null, null, null);
                }
                catch
                {
                    _logger = null;
                }
            }
        }

        public static void LogInfo(string message, params object[] args)
        {
            if (null != _logger)
            {
                _logger.LogInfo(message, args);
            }
        }

        public static void LogWarning(string message, params object[] args)
        {
            if (null != _logger)
            {
                _logger.LogWarning(message, args);
            }
        }

        public static void LogError(string message, params object[] args)
        {
            if (null != _logger)
            {
                _logger.LogError(message, args);
            }
        }

        public static void LogDebug(string message, params object[] args)
        {
            if (null != _logger)
            {
                _logger.LogDebug(message, args);
            }
        }

        public static void LogError(Exception e)
        {
            LogError("{0}", e);
        }
    }
}
