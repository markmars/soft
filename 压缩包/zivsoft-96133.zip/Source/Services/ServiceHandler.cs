using System;
using System.Collections;
using System.IO;
using System.Xml;
using System.Configuration;
using System.Collections.Generic;
using System.Security.Permissions;
using System.Diagnostics;
using Zivsoft.Log;


/*
 *
 * Craeted by Lihua Zhou at 2006-11-18
 * 
 */

namespace Zivsoft.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class ServiceHandler
    {
        private string _businessHandler;
        private string _dealMethod;
        private Hashtable _response;
        private XmlNode _moduleNode;
        private Hashtable _request;
        /// <summary>
        /// Store the deal method node from service.xml
        /// </summary>
        protected List<string> _lsDealMethod;
        private static ServiceHandler _cfg;
        /// <summary>
        /// Store the business handler node from service.xml
        /// </summary>
        protected Hashtable _htBusinessHandler;
        /// <summary>
        /// Only get all business handlers from service.xml
        /// </summary>
        public static List<string> BusinessHandlerList
        {
            get
            {
                List<string> list = new List<string>();
                ServiceHandler s = new ServiceHandler();
                s.InitXmlConfig();
                ICollection keys = s._htBusinessHandler.Keys;
                foreach (string key in keys)
                {
                    list.Add(key);
                }
                return list;
            }
        }

        /// <summary>
        /// Only get all deal methods from service.xml
        /// </summary>
        public static List<string> DealMethodList
        {
            get
            {
                ServiceHandler s = new ServiceHandler();
                s.Read4SchemaExport();
                return s._lsDealMethod;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal static ServiceHandler Single()
        {
            if (null == ServiceHandler._cfg)
            {
                ServiceHandler._cfg = new ServiceHandler();
            }
            return ServiceHandler._cfg;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="assemblyName"></param>
        /// <returns></returns>
        public string GetBusinessHandlerClass(string assemblyName)
        {
            try
            {
                if (this._htBusinessHandler.Count == 0)
                {
                    this.InitXmlConfig();
                }
                if (this._htBusinessHandler.Contains(assemblyName))
                {
                    string moduleConfigType = this._htBusinessHandler[assemblyName] as string;
                    //change , to ; because
                    if (moduleConfigType.IndexOf(';') != -1)
                    {
                        string className = moduleConfigType.Split(';')[0];
                        return className;
                    }
                    else
                    {
                        Logger.LogInfo("GetClassByModule(string moduleName)");
                        return string.Empty;
                    }
                }
                else
                {
                    Logger.LogInfo("Does not exist the business handler {0}.dll file.", assemblyName);
                    return string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="businessHanlder"></param>
        /// <returns></returns>
        internal string GetBusinessHandlerAssmebly(string businessHanlder)
        {
            if (this._htBusinessHandler.Count == 0)
            {
                this.InitXmlConfig();
            }
            var configType = this._htBusinessHandler[businessHanlder] as string;

            if (null != configType && configType.IndexOf(';') != -1)
            {
                //the full assembly, can read from GAC
                return configType.Split(';')[1];
            }
            else
            {
                Logger.LogInfo("{0} has no assembly mapping", businessHanlder);
                return string.Empty;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public Hashtable Request
        {
            get
            {
                return this._request;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public Hashtable Response
        {
            get
            {
                return this._response;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="businessHandler"></param>
        /// <param name="dealMethod"></param>
        public ServiceHandler(string businessHandler, string dealMethod)
        {
            _businessHandler = businessHandler;
            this._dealMethod = dealMethod;
            this.LoadBusinessHandler();
            this._request = new Hashtable(0);
            this._response = new Hashtable(0);
        }

        /// <summary>
        /// Find related resource
        /// This is the core method to read service.xml
        /// </summary>
        public void FindDealMethod()
        {
            Debug.WriteLine("finding deal method [{0}] ...", _dealMethod);
            bool hasMethod = false;
            for (int i = 0, size = this._moduleNode.ChildNodes.Count; i < size; i++)
            {
                XmlNode method = this._moduleNode.ChildNodes.Item(i);
                //method.Attributes[0].Value is 0, because just get the first value.
                if (method.NodeType != XmlNodeType.Comment && method.Attributes.Count != 0 && method.Attributes[0].Value == this._dealMethod)
                {
                    hasMethod = true;

                    for (int k = 0, t = method.ChildNodes.Count; k < t; k++)
                    {
                        XmlNode req_res = method.ChildNodes[k];
                        if (req_res.Name == "Request")
                        {
                            for (int j = 0, count = req_res.ChildNodes.Count; j < count; j++)
                            {
                                XmlNode property = req_res.ChildNodes[j];
                                if (property.Name == "Property")
                                {
                                    this._request.Add(property.InnerText.Trim(), property.Attributes["type"].Value);
                                }
                            }
                        }
                        else if (req_res.Name == "Response")
                        {
                            for (int j = 0, count = req_res.ChildNodes.Count; j < count; j++)
                            {
                                XmlNode property = req_res.ChildNodes[j];
                                if (property.Name == "Property")
                                {
                                    this._response.Add(property.InnerText.Trim(), property.Attributes["type"].Value);
                                }
                            }
                        }
                        else
                        {
                            throw new Exception(string.Format("{0} can't be found", _dealMethod));
                        }
                    }
                    //Method was found, needn't to continue finding.
                    break;
                }
            }
            if (!hasMethod)
            {
                throw new Exception(string.Format("{0} can't be found", _dealMethod));
            }
        }

        private ServiceHandler()
        {
            this.Init();
        }
        private void InitXmlConfig()
        {
            Debug.WriteLine("Begin to initialize service.xml to xmldocument ...");
            var xmlDoc = new XmlDocument();
            var loader = new XmlStreamReader();
            var stream = loader.ReadStream(Principle.Xml);
            xmlDoc.Load(stream);

            var root = xmlDoc.DocumentElement;

            for (int i = 0, size = root.ChildNodes.Count; i < size; i++)
            {
                XmlNode entry = root.ChildNodes.Item(i);
                if (entry.NodeType != XmlNodeType.Comment && entry.Attributes.Count > 1)
                {
                    string name = null;
                    string type = null;
                    XmlAttributeCollection properties = entry.Attributes;
                    foreach (XmlAttribute s in properties)
                    {
                        if (s.Name == "name")
                        {
                            name = s.Value;
                        }
                        if (s.Name == "type")
                        {
                            type = s.Value;
                        }
                    }
                    if (name == null || type == null)
                    {
                        Debug.WriteLine("name == null || type == null");
                        return;
                    }

                    if (!this._htBusinessHandler.Contains(name))
                    {
                        this._htBusinessHandler.Add(name, type);
                    }
                    else
                    {
                        this._htBusinessHandler[name] = type;
                    }
                }
            }
            stream.Close();
            Debug.WriteLine("End to initialize the services.xml to xmldocument.");
        }
        /// <summary>
        /// Load the related module
        /// </summary>
        private void LoadBusinessHandler()
        {
            Debug.WriteLine("loading business handler [{0}]...", _businessHandler);
            bool isFind = false;
            var xmlDoc = new XmlDocument();
            var loader = new XmlStreamReader();
            var s = loader.ReadStream(Principle.Xml);
            xmlDoc.Load(s);

            var root = xmlDoc.DocumentElement;
            for (int i = 0, size = root.ChildNodes.Count; i < size; i++)
            {
                var itemNode = root.ChildNodes.Item(i);
                if (itemNode.Attributes != null && itemNode.NodeType != XmlNodeType.Comment && itemNode.Attributes.Count > 0 && itemNode.Attributes["name"].Value == _businessHandler)
                {
                    this._moduleNode = itemNode;
                    isFind = true;
                    break;
                }
            }
            if (!isFind)
            {
                s.Close();
                throw new Exception("related module can't not be found.");
            }
            s.Close();
        }
        private void Init()
        {
            this._htBusinessHandler = new Hashtable();
            this._lsDealMethod = new List<string>();
        }
        /// <summary>
        /// Do not use this method, it is used for SchemaExport.cs
        /// </summary>
        [PermissionSet(SecurityAction.Demand)]
        private void Read4SchemaExport()
        {
            Debug.WriteLine("readding xml for schema export...");
            var xmlDoc = new XmlDocument();
            var loader = new XmlStreamReader();
            var s = loader.ReadStream(Principle.Xml);
            xmlDoc.Load(s);

            var root = xmlDoc.DocumentElement;
            if (root.Name != "Business")
            {
                throw new XmlException(string.Format("{0} root element is not [Business].", Principle.Xml));
            }
            var bhList = root.ChildNodes;
            for (int i = 0, size = bhList.Count; i < size; i++)
            {
                var bh = bhList[i];
                if (bh.Name != "BusinessHandler" || bh.NodeType != XmlNodeType.Element)
                {
                    continue;
                }
                var dmList = bh.ChildNodes;
                for (int j = 0, dmCount = dmList.Count; j < dmCount; j++)
                {
                    var dm = dmList[j];
                    if (dm.NodeType != XmlNodeType.Comment && dm.Attributes.Count != 0)
                    {
                        string dmName = dm.Attributes["name"].Value;
                        if (!this._lsDealMethod.Contains(dmName)) { this._lsDealMethod.Add(dmName); }
                    }
                }
            }
            s.Close();
        }

    }
}