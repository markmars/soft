﻿using System;
using System.Collections;
using System.Configuration;
using System.Runtime.Remoting;
using System.IO;
using System.Web.Services;
using System.Xml.Serialization;


using Zivsoft.Log;


/*
 * Created by ziv at 2006-11-22
 */
namespace Zivsoft.Services
{

    /// <summary>
    /// All service will be requested from this class
    /// </summary>
    public class Request 
    {
        /// <summary>
        /// If you use this constructor, you must use DealMethod and BusinessHandler
        /// </summary>
        private Request()
        {
            //just for web service
        }

        private object[] _objValues;

       
        private string _dealMethod;
        /// <summary>
        /// Businesshandler name for a service
        /// </summary>
        internal protected string DealMethod
        {
            get
            {
                return this._dealMethod;
            }
        }

        private string _businessHandler;
        /// <summary>
        /// Module name, request from whom
        /// </summary>
        internal protected string BusinessHandler
        {
            get
            {
                return this._businessHandler;
            }
        }

        private Hashtable _property;

        private Hashtable _req;
        internal Hashtable ReqPropertyName
        {
            get
            {
                return this._req;
            }
            set
            {
                this._req = value;
            }
        }

        private Hashtable _res;

        internal Hashtable ResPropertyName
        {
            get
            {
                return this._res;
            }
            set
            {
                this._res = value;
            }
        }
      
        /// <summary>
        /// Request service by businessHandler and dealMethod
        /// </summary>
        /// <param name="businessHandler">BH...</param>
        /// <param name="dealMethod">DM...</param>
        public Request (string businessHandler,string dealMethod)
        {
            this._businessHandler = businessHandler;
            this._dealMethod = dealMethod;            
            this._property=new Hashtable(0);
        }
       
        /// <summary>
        /// Get Response (Execute the service that you request)
        /// </summary>
        /// <example>
        /// <add key="BusinessHandler" value="Module"/>
        /// <add key="DealMethod" value="Event"/>
        /// </example>
        /// <returns>Response</returns>
        [WebMethod]
        public Response GetResponse()
        {

            Logger.LogInfo("Getting response ...");
            Logger.LogInfo(string.Format("BusinessHandler: {0}; DealMethod: {1}", _businessHandler, _dealMethod));
            Response res = new Response();
            try
            {
                Instance ins = new Instance(this._businessHandler);
                object obj = ins.GetBusinessObject();
                if (null == obj)
                {
                    throw new Exception("Get business object failed.");
                }

                if (!(obj is BusinessHandler))
                {
                    throw new Exception(obj.GetType() + " is not the " + typeof(BusinessHandler));
                }

                //do
                BusinessHandler bHandler = obj as BusinessHandler;
                ServiceHandler server = new ServiceHandler(this._businessHandler, this._dealMethod);
                server.FindDealMethod();
                this._req = server.Request;
                this._res = server.Response;
                if (this._objValues != null && this._objValues.Length != _req.Count)
                {
                    throw new Exception("Request parameters:" + this._objValues.Length + ",Configuration has the number " + _req.Count + ", the number is not the same.");
                }
                else if (this._objValues != null && this._objValues.Length == this._req.Count)
                {

                    ICollection keys = this._req.Keys;
                    int index = 0;
                    foreach (string key in keys)
                    {
                        this._property.Add(key, this._objValues[index]);
                        index++;
                    }
                }
                else if (!CompareByHashtableKeys(this._req, this._property))
                {
                    string allKeys = null;
                    ICollection keys = this._property.Keys;
                    foreach (string key in keys)
                    {
                        allKeys += key + ",";
                    }
                    if (allKeys != null)
                    {
                        allKeys = allKeys.Remove(allKeys.Length - 1, 1);
                    }

                    string allMaps = null;
                    ICollection maps = this._req.Keys;
                    foreach (string map in maps)
                    {
                        allMaps += map + ",";
                    }
                    if (allMaps != null)
                    {
                        allMaps = allMaps.Remove(allMaps.Length - 1, 1);
                    }

                    throw new Exception(string.Format("Mapping Error:\nActual:{0}\nExpected:{1}", allKeys, allMaps));
                }

                ICollection keysRequestProperty = this._req.Keys;
                foreach (string key in keysRequestProperty)
                {
                    if (this[key] != null && this[key].GetType().Name != this._req[key].ToString())
                    {
                        throw new Exception(string.Format("Key:{0}\n{1}\nKeyType{2}", key, this._req[key].ToString(), this[key].GetType().Name));
                    }
                }
                res = bHandler.DoTask(this);

                ICollection keysResponseProperty = this._res.Keys;
                foreach (string key in keysResponseProperty)
                {
                    if (res[key] != null && res[key].GetType().Name != this._res[key].ToString())
                    {
                        throw new Exception("The type for response " + key + ":" + this._res[key] + " is different to" + res[key].GetType().Name + ".");
                    }
                }
                return res;
            }
            catch (System.Exception err)
            {
                res.IsError = true;
                //only short message to user
                res.ErrorMessage = err.Message;
                //show detailed message to log
                Logger.LogInfo(string.Format("{0}", err));
                Logger.LogError(err);
                return res;
            }
            finally
            {
                Logger.LogInfo("End to get response.");
            }
        }

        /// <summary>
        /// IO Objects
        /// </summary>
        /// <param name="keyName">Property for request</param>
        /// <returns>object</returns>
        protected object this[object key]
        {
            get
            {
                string keyName = key.ToString();
                if (this._property.Contains(keyName))
                {
                    return this._property[keyName];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                string keyName = key.ToString();
                if (this._property.Contains(keyName))
                {
                    this._property[keyName] = value;
                }
                else
                {
                    this._property.Add(keyName, value);
                }
            }
        }
        private static bool CompareByHashtableKeys(Hashtable ht1, Hashtable ht2)
        {
            if (ht1.Count != ht2.Count)
            {
                return false;
            }
            //详细比较
            ICollection key1 = ht1.Keys;
            ArrayList al1 = new ArrayList();
            foreach (string key in key1)
            {
                al1.Add(key.Trim());
            }
            al1.Sort();

            ICollection key2 = ht2.Keys;
            ArrayList al2 = new ArrayList();
            foreach (string key in key2)
            {
                al2.Add(key.Trim());
            }
            al2.Sort();

            //开始比较
            for (int i = 0, t = al1.Count; i < t; i++)
            {
                string s1 = al1[i].ToString();
                string s2 = al2[i].ToString();
                if (s1 != s2)
                {
                    return false;
                }
            }
            return true;
        }
    }
}