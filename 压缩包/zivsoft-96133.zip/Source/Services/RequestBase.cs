﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zivsoft.Services
{
    public class RequestBase:Request
    {
        public RequestBase(string businessHandler, string dealMethod) : base(businessHandler, dealMethod) { }


        /// <summary>
        /// 采用泛型抽象转换
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T GetResponse<T>(T t) where T : Response
        {
            Response res = base.GetResponse();
            if (null == res || res.IsError)
            {
                t.IsError = res.IsError;
                t.ErrorMessage = res.ErrorMessage;
                return t;
            }
            else if (res is T)
            {
                return res as T;
            }
            else
            {
                return new Response { IsError = true, ErrorMessage = "业务逻辑没有实现" } as T;

            }
        }
    }
}
