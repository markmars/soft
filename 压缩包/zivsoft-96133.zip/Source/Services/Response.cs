﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Web.Services;

namespace Zivsoft.Services
{
    public class Response
    {
        public Response()
        {
            this._property=new Hashtable();
        }
        private Hashtable _property;
        /// <summary>
        /// 
        /// </summary>
        public string ErrorMessage
        {
            get; set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DefaultValue(false)]
        public bool IsError
        {
            get; set;
        }
        
        internal protected object this[object key]
        {
            get
            {
                string keyName = key.ToString();

                if (this._property.Contains(keyName))
                {
                    return this._property[keyName];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                string keyName = key.ToString();
                if (this._property.Contains(keyName))
                {
                    this._property[keyName] = value;
                }
                else
                {
                    this._property.Add(keyName, value);
                }
            }
        }
    }
}
