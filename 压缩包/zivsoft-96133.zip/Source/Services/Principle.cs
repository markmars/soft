﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.Reflection;

namespace Zivsoft.Services
{
    /// <summary>
    /// 
    /// </summary>
    class Principle
    {
        private static string AssemblyName
        {
            get
            {
                return Assembly.GetCallingAssembly().GetName().Name;
            }

        }
        /// <summary>
        /// 注意默认Dll名称为<c>Zivsoft.Services.Principle.dll</c>，但依然可以另外配置<c>ServerMapping</c>
        /// </summary>
        public static string Dll
        {
            get
            {
                //默认规则文件
                string defaultDll = "Zivsoft.Services.Principle.dll";
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ServerMapping"]))
                {
                    defaultDll = ConfigurationManager.AppSettings["ServerMapping"];
                }
                return defaultDll;
            }
        }

        /// <summary>
        /// Service.xml
        /// </summary>
        public const string Xml = "Service.xml";
        /// <summary>
        /// Xml's full location in assembly
        /// </summary>
        public static string Path
        {
            get
            {
                var @namespace = typeof(Request).FullName.Replace(typeof(Request).Name, "");
                return @namespace + "Principle." + Xml;
            }
        }
    }
}