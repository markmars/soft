using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;


/*
 * Created by ziv at 2006-11-19
 * Updated by Lihua Zhou at 07/30/2008
 * Function:
 * Business code handler
 */
namespace Zivsoft.Services
{
	/// <summary>
	/// BaseBusinessHandler
    /// This is a class to be used to call the business code
	/// </summary>
	public abstract class BusinessHandler
	{
        /// <summary>
        /// Used to init the Nobusiness exception
        /// </summary>
        private Request _request;
	    /// <summary>
	    /// 
	    /// </summary>
        public string CheckUnValidMessage
        {
            get;
            set;
        }
		/// <summary>
		/// Constructor
		/// </summary>
		public BusinessHandler(){}
		/// <summary>
		/// 
		/// </summary>
        protected abstract Response PerformTask(Request request);
		/// <summary>
		/// 
		/// </summary>
        protected abstract bool Check(Request request);
	    /// <summary>
	    /// 
	    /// </summary>
	    public Response DoTask(Request request)
	    {
            Debug.WriteLine(string.Format("begin to do task [{0}-{1}]",request.BusinessHandler,request.DealMethod));
            _request = request;
            if (this.Check(request))
            {
                return this.PerformTask(request);
            }
	        else
            {
                Response res = new Response();
                res.IsError = true;
                res.ErrorMessage = this.CheckUnValidMessage;
                return res;
            }
	    }

        /// <summary>
        /// 
        /// </summary>
        protected Response NoBusinessCode
        {
            get
            {
                Response res = new Response();
                res.IsError = true;
                res.ErrorMessage=string.Format("Software Factory does not create this business {0}-{1}",_request.BusinessHandler,_request.DealMethod);
                return res;
            }
        }
	}
}
