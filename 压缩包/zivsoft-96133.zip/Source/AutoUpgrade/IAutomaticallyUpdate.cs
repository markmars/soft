﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Zivsoft.AutoUpgrade
{
    interface IAutomaticallyUpdate
    {
        /// <summary>
        /// Unless you're using the AutoUpgrade class to generate a manifest file, use one of the Create() functions to create an instance of the AutoUpgrade class instead of using the default constructor. There are several overloads of the Create() function so you can read the manifest file from a Web service, from a Web site, from a local file (when an upgrade is being performed by the upgrade stub), or from a string.
        /// </summary>
        void Create();
        /// <summary>
        /// The IsUpgradeAvailable function compares all the files listed in the manifest with those on the local file system, and optionally (depending on the value of blnStartUpgrade), starts the upgrade stub executable, which performs the upgrade. If this method returns True, and you're using the upgrade stub, your application should terminate immediately to avoid file in use exceptions during the upgrade.
        /// </summary>
        /// <param name="blnStartUpgrade"></param>
        /// <returns></returns>
        bool IsUpgradeAvailable(bool blnStartUpgrade);
        /// <summary>
        /// The StartUpgradeStub method saves the manifest file to the upgrade-cache subdirectory, downloads new versions of the AutoUpgrade components, and starts the upgrade stub executable. This method can be called by IsUpgradeAvailable automatically, but you may wish to call IsUpgradeAvailable with blnStartUpgrade set to False, and then call StartUpgradeStub yourself, after giving your end-user the opportunity to choose whether to upgrade.
        /// </summary>
        void StartUpgradeStub();
        void Upgrade();
        /// <summary>
        /// The ManifestFiles property returns an ArrayList that contains all the files to check in order to determine the availability of an upgrade. If you're writing code to generate an AutoUpgrade manifest file automatically, use the Add method to add AutoUpgrade.File objects to this collection.
        /// </summary>
        ArrayList ManifestFiles { get;  }
        ArrayList UpgradeFiles { get;  }
        void GenerateManifest();
        void Save();
        /// <summary>
        /// The UpgradeProgress event provides status notifications during the upgrade. Add a handler for this event to display progress information to the end user.
        /// </summary>
        //event UpgradeProgress;
    }
}
