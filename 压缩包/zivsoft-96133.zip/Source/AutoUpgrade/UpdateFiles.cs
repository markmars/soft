﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Zivsoft.AutoUpgrade
{
    public class UpdateFiles:IAutomaticallyUpdate
    {
        public void Update(string version)
        {
            Zivsoft.Utils.FileUtils.SaveStringAsFile(version,"version.txt");

        }

        public void Create()
        {
            throw new NotImplementedException();
        }

        public bool IsUpgradeAvailable(bool blnStartUpgrade)
        {
            throw new NotImplementedException();
        }

        public void StartUpgradeStub()
        {
            throw new NotImplementedException();
        }

        public void Upgrade()
        {
            throw new NotImplementedException();
        }

        public System.Collections.ArrayList ManifestFiles
        {
            get { throw new NotImplementedException(); }
        }

        public System.Collections.ArrayList UpgradeFiles
        {
            get { throw new NotImplementedException(); }
        }

        public void GenerateManifest()
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
