﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using Zivsoft.Log;
using System.Net;
using System.Xml.Linq;
using System.Reflection;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using Zivsoft.AutoUpgrade;

namespace Zivsoft.AutoUpgrade
{
    public class SiderUpgrade:Form
    {
        public static string Version;

        static XElement _xElement;

        public SiderUpgrade()
        {
            InitializeComponent();
        }


        private static SiderUpgrade _current;
        public static SiderUpgrade Current
        {
            get
            {
                if (_current == null)
                {
                    _current = new SiderUpgrade();
                    _current.Create();
                }
                return _current;
            }
        
        }

        private System.Windows.Forms.Timer timer1;
        private IContainer components;
        private Label label1;


        const string ServerVersion = "http://zivsoft.com/Documents/update.xml";
        public void Create()
        {
            string strSource = GetHtmlSourceText();

            //If no internet, no update.
            if (string.IsNullOrEmpty(strSource))
            {
                IsUpgradeAvailable = false;
                return;
            }
            _xElement = XElement.Parse(strSource);

            this.label1.Text = "Getting file version from server...";
            this.progressBar1.Value = 10;

            var results = from e in _xElement.Elements("version")
                          //where (string)e.Element("version") == Assembly.GetEntryAssembly().GetName().Version.ToString()
                          select e;
            bool isUpdate = true;
            foreach (var xe in results)
            {
                Version = xe.Value;
                this.label1.Text = xe.Value;


                //if (xe.Value == Assembly.GetEntryAssembly().GetName().Version.ToString())
                if(!File.Exists("version.txt"))
                {
                    isUpdate=true;

                }
                else if (xe.Value == Utils.FileUtils.ReadFile4String("version.txt"))
                {
                    isUpdate = false;
                }
                else
                {
                    isUpdate = true;
                }
            }
            IsUpgradeAvailable = isUpdate;
        }



        private void Upgrade()
        {
            if (null == _xElement)
            {
                this.label1.Text = "Server has no update.";
                this.progressBar1.Value = 100;
                return;
            }

            var results = from e in _xElement.Elements("files")
                          select e;
                
            foreach (var xe in results)
            {
                var r1 = from e in xe.Elements("item")
                              select e;
                foreach (var r in r1)
                {
                    Files.Add(r.Value);
                }
            }
            Download();
            UpdateFiles u = new UpdateFiles();
            u.Update(Version);
            this.progressBar1.Value = 100;
            this.label1.Text = "Update successful.";
        }

        private void Download()
        {
            for (int i = 0; i < Files.Count; i++)
            {
                string url = Files[i] + "";

                Stream s = null;
                var uri = new Uri(url);
                var req = (HttpWebRequest)WebRequest.Create(uri);
                WebResponse res = null;
                try
                {
                    res = req.GetResponse();
                }
                catch (Exception e)
                {
                    Logger.LogError(e.Message);
                    continue;
                }
                s = res.GetResponseStream();
                
                string filename = Zivsoft.Utils.FileUtils.GetFileName(url);
                filename = filename.Replace(".dl_", ".dll").Replace(".ex_", ".exe").Replace(".confi_",".config");

                StreamToFile sf = new StreamToFile();
                sf.Save(s, filename);
                this.progressBar1.Value = i;
            }
                
        }

        private void ReadWriteStream(Stream readStream, Stream writeStream)
        {
            int Length = 256;
            Byte[] buffer = new Byte[Length];
            int bytesRead = readStream.Read(buffer, 0, Length);
            // write the required bytes
            while (bytesRead > 0)
            {
                writeStream.Write(buffer, 0, bytesRead);
                bytesRead = readStream.Read(buffer, 0, Length);
            }
            readStream.Close();
            writeStream.Close();
        } 

        public  bool IsUpgradeAvailable
        {
            get;
            set;
        }

        public ArrayList Files
        {
            get;
            set;
        }
        /// <summary>
        /// Get inner html content from url
        /// </summary>
        /// <param name="url">url</param>
        /// <returns>return the html source</returns>
        private string GetHtmlSourceText()
        {
            Stream s = null;
            var uri = new Uri(ServerVersion);
            var req = (HttpWebRequest)WebRequest.Create(uri);
            WebResponse res = null;
            try
            {
                res = req.GetResponse();
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                return "";
            }
            s = res.GetResponseStream();
            var sr = new StreamReader(s);
            var strHtml = sr.ReadToEnd();
            return strHtml;
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 32);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(488, 23);
            this.progressBar1.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 1;
            // 
            // AutoUpgrade
            // 
            this.ClientSize = new System.Drawing.Size(521, 67);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.progressBar1);
            this.MaximizeBox = false;
            this.Name = "AutoUpgrade";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Updating...";
            this.Load += new System.EventHandler(this.AutoUpgrade_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private ProgressBar progressBar1;

        private void AutoUpgrade_Load(object sender, EventArgs e)
        {
            this.timer1.Enabled = true;
        }

        public void Init()
        {
            Files = new ArrayList();
            this.label1.Text = "Initial sever files list...";
            this.progressBar1.Value = 1;
            Create();
            this.progressBar1.Value = 20;
            this.Upgrade();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.timer1.Enabled = false;
            Init();
        }

    }
}
