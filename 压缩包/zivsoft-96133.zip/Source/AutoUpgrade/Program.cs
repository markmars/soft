﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Threading;

/*************************
 * 
 * Updated 2009-07-23
 * Any comment please use English
 * 
 *************************/
namespace Zivsoft.AutoUpgrade
{
    class Program
    {


        /// <summary>
        /// 
        /// </summary>
        [STAThread]
        public static void Main()
        {
            try
            {
                var u = new SiderUpgrade();
                Application.Run(u);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
