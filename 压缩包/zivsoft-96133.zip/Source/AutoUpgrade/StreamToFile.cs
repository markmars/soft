﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Zivsoft.Log;
using System.Windows.Forms;

namespace Zivsoft.AutoUpgrade
{
    class StreamToFile
    {
        // readStream is the stream you need to read
        // writeStream is the stream you want to write to
        private void ReadWriteStream(Stream readStream, Stream writeStream)
        {
            int Length = 256;
            Byte[] buffer = new Byte[Length];
            int bytesRead = readStream.Read(buffer, 0, Length);
            // write the required bytes
            while (bytesRead > 0)
            {
                writeStream.Write(buffer, 0, bytesRead);
                bytesRead = readStream.Read(buffer, 0, Length);
            }
            readStream.Close();
            writeStream.Close();
        }

        public void Save(Stream readStream, string saveTo)
        {

            try
            {
                //To call this method, just do something like this:
                // create a write stream
                FileStream writeStream = new FileStream(saveTo, FileMode.Create, FileAccess.Write);
                // write to the stream
                ReadWriteStream(readStream, writeStream); 
            }
            catch(Exception e)
            {

                MessageBox.Show(e.Message);
                Logger.LogError("File has already opened.");
            }
            
        }

    }
}
