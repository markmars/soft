﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.Mvc;
using Zivsoft.Web.Mvc.Controller.Shared;

namespace Zivsoft.Products.Salary
{
    public abstract class BaseView:BaseViewPage
    {
        protected Label Label1;
        protected Label Label2;
        protected Label Label3;
        protected Label Label4;
        protected Label Label5;
        protected Label Label6;
        protected Label Label7;
        protected Label Label8;
        protected Label Label9;
        protected Label Label10;
        protected Label Label11;
        protected Label Label12;
        protected Label Label13;
        protected Label Label14;
        protected Label Label15;
        protected Label Label16;
        protected Label Label17;
        protected Label Label18;
        protected Label Label19;
        protected Label Label20;
        protected Label Label21;
        protected Label Label22;
        protected Label Label23;
        protected Label Label24;
        protected Label Label25;
        protected Label Label26;
        protected Label Label27;
        protected Label Label28;
        protected Label Label29;
        protected Label Label30;
        protected Label Label31;


        protected DropDownList DropDownList1;
        protected DropDownList DropDownList2;
        protected DropDownList DropDownList3;
        protected DropDownList DropDownList4;
        protected DropDownList DropDownList5;
        protected DropDownList DropDownList6;


        protected TextBox TextBox1;
        protected TextBox TextBox2;
        protected TextBox TextBox3;
        protected TextBox TextBox4;
        protected TextBox TextBox5;
        protected TextBox TextBox6;
        protected TextBox TextBox7;
        protected TextBox TextBox8;
        protected TextBox TextBox9;
        protected TextBox TextBox10;
        protected TextBox TextBox11;
        protected TextBox TextBox12;
        protected TextBox TextBox13;
        protected TextBox TextBox14;
        protected TextBox TextBox15;
        protected TextBox TextBox16;
        protected TextBox TextBox17;
        protected TextBox TextBox18;
        protected TextBox TextBox19;
        protected TextBox TextBox20;
        protected TextBox TextBox21;
        protected TextBox TextBox22;
        protected TextBox TextBox23;
        protected TextBox TextBox24;

        protected DataGrid DataGrid1;

        protected Button Button1;
        protected Button Button2;
        protected Button Button3;

        protected GridView GridView1;
        protected GridView GridView2;
        protected GridView GridView3;
        protected GridView GridView4;
        protected GridView GridView5;

        protected SqlDataSource SqlDataSource1;
        protected SqlDataSource SqlDataSource2;
        protected SqlDataSource SqlDataSource3;
    }
}
