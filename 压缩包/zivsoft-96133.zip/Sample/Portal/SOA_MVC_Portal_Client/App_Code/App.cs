﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
namespace Zivsoft.Products.Salary
{
    public class App
    {
        public static string WebPath
        {
            get
            {
                return "~/" + VirtualPath + "/";
            }
        }
        public static string WebName
        {
            get
            {
                return "/" + VirtualPath + "/";
            }
        }

        public static string VirtualPath
        {
            get
            {
                return ConfigurationManager.AppSettings["VirtualPath"];
            }
        }
    }
}

