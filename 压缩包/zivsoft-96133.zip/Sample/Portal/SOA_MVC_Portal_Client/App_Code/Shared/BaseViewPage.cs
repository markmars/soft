﻿using System;
using System.Web.Security;
using System.Web.UI;

/*
 * Created by ziv at 2007-1-2
 */

namespace Zivsoft.Web.Mvc.Controller.Shared
{
    /// <summary>
    /// Need permission
    /// </summary>
    public abstract class BaseViewPage : SharedViewPage
    {
        protected override void OnInit(EventArgs e)
        {
            
        }

        public override string Theme
        {
            get
            {
                return UserSessionManager.Current.UserTheme;
            }
        }
        public override string StyleSheetTheme
        {
            get
            {
                return UserSessionManager.Current.UserTheme;
            }
        }

        public string UserId
        {
            get
            {
                return UserSessionManager.Current.UserId;
            }
        }

        public string ModId
        {
            get
            {
                return this.Session["modid"] + "";
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            //base.OnLoad(e); 
            try
            {
                if (UserSessionManager.Current.UserId == null || UserSessionManager.Current.UserId.Trim() == "")
                {
                    this.Response.StatusCode = 403;
                    FormsAuthentication.RedirectToLoginPage();
                }
                InitView();
            }
            catch (Exception err)
            {
                this.Response.Write(err.Message);
            }
        }

        protected abstract void InitView();

        public void SignOut()
        {
            FormsAuthentication.SignOut();

            UserSessionManager.Current.RemoveUserId();
            FormsAuthentication.RedirectToLoginPage();

        }
    }
}