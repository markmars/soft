﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Mvc;
using Zivsoft.Localization;

namespace Zivsoft.Web.Mvc.Controller.Shared
{
    /// <summary>
    /// 
    /// </summary>
    public class BaseMasterPage : ViewMasterPage
    {
        public BaseMasterPage()
        {

        }

        public void SignOut()
        {
            FormsAuthentication.SignOut();

            UserSessionManager.Current.RemoveUserId();
            FormsAuthentication.RedirectToLoginPage();
        }
        protected string GetValue(string module, string key)
        {
            return Resource.GetModule(module).GetKey(key);
        }
    }
}