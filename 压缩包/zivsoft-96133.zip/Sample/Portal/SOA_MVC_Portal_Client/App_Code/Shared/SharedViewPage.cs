﻿using System;
using System.Web.Security;
using System.Web.UI;
using Zivsoft.Localization;

/*
 * Created by ziv at 2007-1-2
 */

namespace Zivsoft.Web.Mvc.Controller.Shared
{
    public class SharedViewPage : System.Web.Mvc.ViewPage
    {
         
        public void Show(string message)
        {
            string script = "<script>window.alert('" + message + "');</script>";
            this.Page.ClientScript.RegisterStartupScript(typeof(string), "show", script);
        }

        public void Show(string message, params object[] param)
        {
            this.Show(string.Format(message, param));
        }

        public string GetValue(string module, string key)
        {
            return Resource.GetModule(module)[key];
        }

        protected string CultureId
        {
            get
            {
                return Resource.CultureId;
            }
        }
    }
}