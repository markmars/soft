﻿using System.Web;
using Zivsoft.Utils;

namespace Zivsoft.Web.Mvc.Controller.Shared
{
    /// <summary>
    /// Store the current user
    /// </summary>
    public class UserSessionManager
    {
        private UserSessionManager()
        {

        }
        private static UserSessionManager user;

        public static UserSessionManager Current
        {
            get
            {

                user = new UserSessionManager();
                return user;
            }
        }

        public string UserId
        {

            get
            {
                return HttpContext.Current.Session.GetCurrentUserId();
            }
            set
            {
                HttpContext.Current.Session.SetCurrentUserId(value);
            }
        }

        public string UserName
        {
            get
            {
                return HttpContext.Current.Session["user_name"] + "";
            }
            set
            {
                HttpContext.Current.Session["user_name"] = value;
            }
        }

        public string UserTheme
        {
            get
            {
                return HttpContext.Current.Session["user_theme"] + "";
            }
            set
            {
                HttpContext.Current.Session["user_theme"] = value;
            }
        }

        public string RoleName
        {
            get
            {
                return HttpContext.Current.Session["RoleName"] + "";
            }
            set
            {
                HttpContext.Current.Session["RoleName"] = value;
            }
        }

        public void RemoveUserId()
        {
            HttpContext.Current.Session.RemoveUserId();
        }

    }
}