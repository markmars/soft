﻿using System.Web.UI;
using Zivsoft.Localization;

/*
 * Created by ziv at 2006-12-28
 * 
 */

namespace Zivsoft.Web.Mvc.Controller.Shared
{
    /// <summary>
    /// 
    /// </summary>
    public class AppInfo
    {
        private Page _page;
        public AppInfo(Page page)
        {
            this._page = page;
        }
        /// <summary>
        /// 
        /// </summary>
        public static string Title
        {
            get
            {
                if (UserSessionManager.Current.UserId != null && UserSessionManager.Current.UserId != "")
                {
                    return Resource.GetModule("Product").GetKey("IndexTitle");
                }
                return Resource.GetModule("Product").GetKey("IndexTitle");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Theme
        {
            get
            {
                return "Spring";
            }
        }

    }
}