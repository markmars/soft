﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Zivsoft.Web.Mvc.Controller
{
    public class HelpController : System.Web.Mvc.Controller
    {
        public ActionResult FileNotFound()
        {
            return View("FileNotFound");
        }
        public ActionResult Error()
        {
            return base.View("Error");
        }

        public ActionResult NoAccess()
        {
            return base.View("NoAccess");
        }
    }
}