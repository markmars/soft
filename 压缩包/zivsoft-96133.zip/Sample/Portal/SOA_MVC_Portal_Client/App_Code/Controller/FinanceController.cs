﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Zivsoft.Web.Mvc.Controller
{
    public class FinanceController : System.Web.Mvc.Controller
    {
        public ActionResult Summary()
        {
            return View();
        }
        public ActionResult Detail()
        {
            return View("Default");
        }
    }
}