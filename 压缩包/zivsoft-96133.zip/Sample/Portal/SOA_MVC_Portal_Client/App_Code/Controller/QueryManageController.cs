﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Zivsoft.Web.Mvc.Controller
{
    public class QueryManageController:System.Web.Mvc.Controller
    {
        public ActionResult QueryCheckForm()
        {
            return View();
        }
        public ActionResult QueryCheckPrint()
        {
            return View();
        }
        public ActionResult QueryDepartmentForm()
        {
            return View();
        }
        public ActionResult QueryDepartmentPrint()
        {
            return View();
        }
        public ActionResult QueryMemberForm()
        {
            return View();
        }
        public ActionResult QueryMemberPrint()
        {
            return View();
        }
        public ActionResult QuerySalaryPrint()
        {
            return View();
        }
        public ActionResult QuerySalaryForm()
        {
            return View();
        }

    }
}
