﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Zivsoft.Web.Mvc.Controller
{
    public class SalaryManageController: System.Web.Mvc.Controller
    {
        public ActionResult ComputeForm()
        {
            return View();
        }

        public ActionResult PayForm()
        {
            return View();
        }
    }
}
