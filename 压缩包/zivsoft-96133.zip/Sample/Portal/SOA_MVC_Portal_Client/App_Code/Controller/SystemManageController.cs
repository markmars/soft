﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Zivsoft.Web.Mvc.Controller
{
    public class SystemManageController:System.Web.Mvc.Controller
    {
        public ActionResult Login()
        {
            return View();
        }

        public ActionResult RegisterUser()
        {
            return View();
        }

        public ActionResult AllErrorHelp()
        {
            return View();
        }
        public ActionResult CompanyForm()
        {
            return View();
        }
        public ActionResult Logout()
        {
            return View();
        }
        public ActionResult OperatorForm()
        {
            return View();
        }
        public ActionResult UserInfo()
        {
            return View();
        }
        public ActionResult UserPassword()
        {
            return View();
        }
        public ActionResult PasswordRecovery()
        {
            return View();

        }
        public ActionResult DepartmentForm()
        {
            return View();

        }

    }
}
