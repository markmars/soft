﻿using System.Web.Mvc;
using Zivsoft.Localization;

namespace Zivsoft.Web.Mvc.Controller
{
    [HandleError]
    public class HomeController : System.Web.Mvc.Controller
    {

        public ActionResult New()
        {
            return View("New");
        }

        public ActionResult Index()
        {
            this.ViewData["Title"] = Resource.GetModule("Menu")["Home"];
            return View();
        }


        public ActionResult About()
        {
            this.ViewData["Title"] = Resource.GetModule("Menu")["About"];
            return View();
        }
    }
}