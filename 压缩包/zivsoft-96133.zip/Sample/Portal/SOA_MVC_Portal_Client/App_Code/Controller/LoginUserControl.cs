﻿using System;
using Zivsoft.Utils;
using Zivsoft.Web.Mvc.Controller.Shared;

namespace Zivsoft.Web.Mvc.Controller
{
    public class LoginUserControl : BaseControl
    {
        public bool IsAuthenticated
        {
            get
            {
                return !string.IsNullOrEmpty(this.Page.GetCurrentUserId());
            }
        }

        public void Page_Load(object sender, EventArgs e)
        {
            ViewData["UserInfo"] = UserSessionManager.Current.UserName;
        }
    }

}