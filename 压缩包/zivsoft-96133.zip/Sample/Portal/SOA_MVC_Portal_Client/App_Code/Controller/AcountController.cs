﻿using System.Web.Mvc;
using System.Web.Security;
using System.Web.UI;
using Zivsoft.Web.Mvc.Controller.Shared;

namespace Zivsoft.Web.Mvc.Controller
{
    [HandleError]
    [OutputCache(Location = OutputCacheLocation.None)]
    public class AccountController : System.Web.Mvc.Controller
    {


        public ActionResult Users()
        {

            return View("UserInfo");
        }

        public ActionResult Login()
        {

            ViewData["Title"] = "Login";

            return View();
        }


        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();

            UserSessionManager.Current.RemoveUserId();
            return RedirectToAction("Index", "Home");
        }


        public ActionResult Register()
        {

            ViewData["Title"] = "Register";

            return View();
        }
    }
}