﻿using System.Web.Mvc;

namespace Zivsoft.Web.Mvc.Controller
{
    public class AdminController : System.Web.Mvc.Controller
    {

        public ActionResult Homepage()
        {
            return View("Homepage");
        }

        public ActionResult Show()
        {
            return View("Show");
        }

        public ActionResult Login()
        {
            return View("Login");
        }

        public ActionResult ChangePassword()
        {
            return View("ChangePassword");
        }
        public ActionResult DailyFinance()
        {
            return View("DailyFinance");
        }
    }
}