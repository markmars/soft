﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Zivsoft.Web.Mvc.Controller
{
    public class FileManageController:System.Web.Mvc.Controller
    {

        public ActionResult PersonnelForm()
        {
            return View();
        }
        public ActionResult ArchievementForm()
        {
            return View();
        }
        public ActionResult FamilyForm()
        {
            return View();
        }
        public ActionResult ResumeForm()
        {
            return View();
        }
        public ActionResult RewardsForm()
        {
            return View();
        }
        public ActionResult TrainingForm()
        {
            return View();
        }
        public ActionResult LeaveForm()
        {
            return View();
        }
    }
}
