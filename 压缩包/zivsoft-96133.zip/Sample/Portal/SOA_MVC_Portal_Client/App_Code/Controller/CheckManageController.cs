﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Zivsoft.Web.Mvc.Controller
{
    public class CheckManageController:System.Web.Mvc.Controller
    {

        public ActionResult MonthCheckForm(){
            return View();
        }
        public ActionResult YearCheckPrint()
        {
            return View();
        }
        public ActionResult YearCheckForm()
        {
            return View();
        }
        public ActionResult MonthCheckPrint()
        {
            return View();

        }
    }
}
