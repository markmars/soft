﻿using System;
using System.Web.UI.WebControls;


using Zivsoft.Web.Mvc.Controller.Shared;

/// <summary>
/// Summary description for ChangePassword
/// </summary>
public partial class ChangePassword : BaseViewPage
{
    protected override void InitView()
    {
        this.btnOK.Text = this.GetValue("ChangePassword", "OK");
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
        bool b = Change(this.txtNewPwd.Text);
        if (b)
        {
            this.Show(this.GetValue("ChangePassword", "Success"));
        }
        else
        {
            this.Show(this.GetValue("ChangePassword", "Fail"));
        }
    }

    public bool Change(string newPassword)
    {
        var r = false;
        ZSF.Default def = new ZSF.Default();
        var t = def.ChangePassword(UserSessionManager.Current.UserId, this.txtNewPwd.Text);
        //Zivsoft.Business.Users.ChangePasswordRequest req = new Zivsoft.Business.Users.ChangePasswordRequest();
        //req.NewPWD = this.txtNewPwd.Text;
        //req.CurrentUserId = UserSessionManager.Current.UserId;
        //var t=req.GetResponse();
        if (t.IsError)
        {
            Show(t.ErrorMessage);
        }
        else
        {
            r = t.IsChange;
            Show(t.IsChange.ToString());
        }
        return r;
    }
}

