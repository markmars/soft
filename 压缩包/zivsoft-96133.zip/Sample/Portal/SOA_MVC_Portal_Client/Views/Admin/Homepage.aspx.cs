﻿using System;
using System.Globalization;
using Zivsoft.Web.Mvc.Controller.Shared;
using System.Web.UI.WebControls;


public partial class Homepage : BaseViewPage
{
    protected override void InitView()
    {
        this.lblTitle.Text = this.GetValue("Product", "Title");
        this.lblContent.Text = this.GetValue("Product", "SubTitle");

        try
        {
            this.Calendar1.Page.Culture = this.CultureId;
        }
        catch
        {
            this.Calendar1.Page.Culture = CultureInfo.CurrentCulture.Name;
        }

    }

}
