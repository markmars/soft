﻿using System;
using System.Globalization;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Data;

using Zivsoft.Web.Mvc.Controller.Shared;

/// <summary>
/// Summary description for Login
/// </summary>
public partial class Login : SharedViewPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.Login1.TitleText = this.GetValue("Login", "Title");
            this.Login1.UserNameLabelText = this.GetValue("Login", "UserName");
            this.Login1.PasswordLabelText = this.GetValue("Login", "Password");
            this.Login1.LoginButtonText = this.GetValue("Login", "Login");
            this.Title = this.GetValue("Login", "PageTitle");
        }
        try
        {
            this.Page.Culture = this.CultureId;
        }
        catch
        {
            this.Page.Culture = CultureInfo.CurrentCulture.Name;
        }
    }

    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        ZSF.Default client = new ZSF.Default();
        var r = client.CheckLoginByWebService(Login1.UserName, Login1.Password, this.Request.UserHostAddress);
        //var req = new LoginRequest() { UserId = this.Login1.UserName, Password = this.Login1.Password, IP =this.Request.UserHostAddress  };
        //var rr = req.GetResponse();
        if (r.IsError)
        {
            this.Login1.FailureText = r.ErrorMessage;
            e.Authenticated = false;
            return;
        }
        //var r = rr as LoginResponse;
        if (r.IsLogin)
        {
            //
            e.Authenticated = true;

            SetSessions();
            //Success ID
            UserSessionManager.Current.UserId = this.Login1.UserName;
            UserSessionManager.Current.UserName = r.UserName;
            //UI Theme
            UserSessionManager.Current.UserTheme = r.Theme;
            //Redirect
            FormsAuthentication.RedirectFromLoginPage(this.Login1.UserName, false);
        }
        else if (r.IsError)
        {
            this.Login1.FailureText = r.ErrorMessage;
            e.Authenticated = false;
        }
        else
        {
            e.Authenticated = false;
        }
    }


    protected void SetSessions()
    {
        Session["MyUserName"] = this.Login1.UserName;
    }
}

