﻿using System;
using System.Text;
using System.IO;
using System.Web.UI.WebControls;

using Zivsoft.Web.Mvc.Controller.Shared;
using Zivsoft.Utils;

/*
 * 
 */
public partial class GlobalUI : BaseMasterPage
{
    private string Exit
    {
        get
        {
            return this.GetValue("ButtonText", "Exit");
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            ZSF.Default d = new ZSF.Default();
            //var res = d.LoadMenu(this.Exit);
            //var req = new MenuTreeRequest() { UserId = this.Page.GetCurrentUserId(), Menu = this.Menu1, Tree = this.TreeView1, ExitText = this.Exit };
            //var res = req.GetResponse();
            //if (res.IsError)
            //{
            //    this.Response.Write(res.ErrorMessage);
            //}
            string strUserId = Page.GetCurrentUserId();
            if (!string.IsNullOrEmpty(strUserId))//如果用户没有登陆,不加载
            {
                MenuTree menuTree = new MenuTree();
                menuTree.LoadMenu(this.Menu1, d.GetDataViewByRole(ZSF.ConfigType.Xml,strUserId,ZSF.MenuTreeTYPE.MENU).DefaultView);
                menuTree.LoadTree(this.TreeView1, d.GetDataViewByRole(ZSF.ConfigType.Xml, strUserId,ZSF.MenuTreeTYPE.TREE).DefaultView, this.Exit);
            }
            //link
            var link = new StringBuilder();
            link.AppendFormat(@"<link href='{0}' type='text/css' rel='Stylesheet' />", Path.Combine(Request.ApplicationPath, "css/datagrid.css"));
            link.AppendFormat(@"<link href='{0}' type='text/css' rel='Stylesheet' />", Path.Combine(Request.ApplicationPath, "css/datainput.css"));
            this.ViewData["Link"] = link.ToString();
        }
        this.Menu1.DataSourceID = this.SiteMapDataSource1.ID;
        this.lblUser.Text = UserSessionManager.Current.UserName;
        this.lblTheme.Text = String.IsNullOrEmpty(UserSessionManager.Current.UserTheme) == true ? "" : this.GetValue("Theme", UserSessionManager.Current.UserTheme);
        this.lblCopyright.Text = this.GetValue("Product", "Copyright");
        this.Page.Title = AppInfo.Title;

        //logo
        this.Logo.Visible = false;
        this.Logo.ImageUrl = "~/Images/logo.gif";


    }

    protected void TreeView1_SelectedNodeChanged(object sender, EventArgs e)
    {
        if (this.TreeView1.SelectedValue == this.Exit)
        {
            this.SignOut();
        }
    }
}
