var DataGrid ={
	MouseOver:function(row){
		//if(row.style.backgroundColor!='White'){
		//	row.style.backgroundColor='Silver';
		//}
		row.style.oldcolor = row.style.backgroundColor;
		row.style.backgroundColor='Silver';
	},
	
	MouseOut:function(row){
		//if(row.style.backgroundColor!='White'){
		//	row.style.backgroundColor='White';
		//}
		row.style.backgroundColor = row.style.oldcolor;
	},
	
	SelectOneRow:function(chkB,index){
		if(typeof chkB != "object"){
			chkB = document.getElementById(chkB);
			chkB.checked = true;
		}
		var dgId = DataGrid.GetDataGridID(chkB.id);
		var xState=chkB.checked;
		if(xState){
			chkB.parentElement.parentElement.style.backgroundColor='White';
			DataGrid.AddHiddenValue(index,dgId);
		}else{
			chkB.parentElement.parentElement.style.backgroundColor='White';
			DataGrid.RemoveHiddenValue(index,dgId);
		}
	},
	
	SetBackColor:function(dgId){
		var arrCb = DataGrid.GetAllCheckBox(dgId);
		for(i=0;i<arrCb.length;i++){
			if(arrCb[i].checked){
				arrCb[i].parentElement.parentElement.style.backgroundColor='White';
			}
		}
	},
	
	SelectAllCheckboxes:function (spanChk){
		var xState=spanChk.checked;
		var arrCb = DataGrid.GetAllCheckBox(spanChk.id);
		for(i=0;i<arrCb.length;i++){
			if(arrCb[i].checked != xState){
				arrCb[i].click();
			}
		}
	},
	
	SelectAll:function(tf,dgId){
		var arrCb = DataGrid.GetAllCheckBox(dgId);
		for(i=0;i<arrCb.length;i++){
			if(arrCb[i].checked != tf){
				arrCb[i].click();
			}
		}
	},
	
	GetAllCheckBox:function(headerId){
		var dgId = DataGrid.GetDataGridID(headerId);
		var allId = DataGrid.GetAllCheckBoxID();
		var elm=document.forms[0].elements;
		var arrCb = new Array();
		var index = 0;
		for(i=0;i<elm.length;i++){
			var cbId = elm[i].id;
			if(elm[i].type=="checkbox" && cbId != headerId){
				if(elm[i].id.indexOf(allId) > 0 && elm[i].id.indexOf(dgId+"_") >= 0){
					arrCb[index++] = elm[i];
				}
			}
		}
		return arrCb;
	},
	
	GetDataGridID:function(cbId){
		var arr = cbId.split('_');
		for(var i=0;i<arr.length;i++){
			if(arr[i] == "" && arr[i+1].indexOf('ct')>=0){
				return arr[i-1];
			}
		}
	},
	
	GetAllCheckBoxID:function(){
		return "DGCheckBoxID";
	},
	
	GetHiddenControl:function(dgId){
		var hidId = dgId+"CheckBoxColumn_Selected";
		return document.getElementById(hidId);
	},
	
	GetHiddenValue:function(dgId){
		var hid = DataGrid.GetHiddenControl(dgId);
		if(hid){
			return hid.value;
		}else{
			return "";
		}
	},
	
	SetHiddenValue:function(val,dgId){
		var hid = DataGrid.GetHiddenControl(dgId);
		if(hid){
			hid.value = val;
		}
	},
	
	ExistHiddenValue:function(val,dgId){
		var hidValue = DataGrid.GetHiddenValue(dgId);
		if(hidValue == ""){
			return false;
		}
		var arr = hidValue.split("|");
		for(var i=0;i<arr.length;i++){
			if(arr[i] == val){
				return true;
			}
		}
		return false;
	},
	
	AddHiddenValue:function(val,dgId){
		if(!val || val==""){
			return;
		}
		if(DataGrid.ExistHiddenValue(val,dgId)){
			return;
		}
		var hidValue = DataGrid.GetHiddenValue(dgId);
		if(hidValue == ""){
			DataGrid.SetHiddenValue(val,dgId);
		}else{
			DataGrid.SetHiddenValue(hidValue+"|"+val,dgId);
		}
	},
	
	RemoveHiddenValue:function(val,dgId){
		if(!val || val==""){
			return;
		}
		if(!DataGrid.ExistHiddenValue(val,dgId)){
			return;
		}
		var hidValue = DataGrid.GetHiddenValue(dgId);
		if(hidValue == ""){
			return;
		}
		var arr = hidValue.split("|");
		hidValue = "";
		for(var i=0;i<arr.length;i++){
			if(arr[i] != val){
				if(hidValue == ""){
					hidValue = arr[i];
				}else{
					hidValue += "|"+arr[i];
				}
			}
		}
		DataGrid.SetHiddenValue(hidValue,dgId);
	},
	
	BatchUpdate:function(dgId,viewId){
		if(DataGrid.GetHiddenValue(dgId) == ""){
			alert('No Any Selected Rows!');
			return;
		}
		var url = "../UserControl/OKBatchDG.aspx?viewid="+viewId;
		var prop = "dialogLeft:300px;dialogTop:300px;dialogWidth:200px;dialogHeight:200px;resizable:true";
		var res = window.showModalDialog(url,'',prop);
		if(typeof res == "undefined" || res == "" || res=="1===1"){
			return;
		}
		__doPostBack(dgId,'B-'+res);
	},
	
	CellMove:function(tbox){
		var code = event.keyCode;
		var left = 37;
		var up = 38;
		var right = 39;
		var down = 40;
		
		if(code!=up && code!=down){
			return;
		}
		
		var ctrls = document.getElementsByTagName(tbox.tagName);
		if(ctrls.length < 2) return;
		
		var ctrlName = tbox.name;
		
		var pos = ctrlName.lastIndexOf(":");
		var pre = ctrlName.substr(0,pos);
		var col = ctrlName.substr(pos+1);
		
		var objs = new Array();
		
		//��������ң�ȡǰ׺��ͬ
		if(code==left || code==right){
			for(var i=0;i<ctrls.length;i++){
				if(ctrls[i].name.indexOf(pre+":") == 0){
					objs.push(ctrls[i]);
				}
			}
		}
		
		//�������£�ȡ������ͬ
		if(code==up || code==down){
			for(var i=0;i<ctrls.length;i++){
				if(ctrls[i].name.substr(ctrls[i].name.lastIndexOf(":")+1) == col){
					objs.push(ctrls[i]);
				}
			}
		}
		
		//Ѱ�ҵ�ǰ�ؼ�λ��
		var selfPos = -1;
		for(var i=0;i<objs.length;i++){
			if(objs[i].name == ctrlName){
				selfPos = i;
			}
		}
		
		//���������
		if(code==left || code==up){
			if(selfPos<1) selfPos = objs.length;
			objs[selfPos-1].focus();
		}
		
		//���һ�����
		if(code==right || code==down){
			if(selfPos>=(objs.length-1)) selfPos = -1;
			objs[selfPos+1].focus();
		}
	}
}













