﻿// JScript 文件

//禁止右键
function click() {
    if (event.button==2) {
        window.alert("右键禁用");
    }
}
document.onmousedown=click