/*****************************
*updated by Lihua Zhou at 12/04/2008
*
***************************/


var Encoder = new EncodeUtils();
var AjaxClient = {
    DoMethod: function() {
        var callback = AjaxClient.DoMethod.arguments[0];
        var async = typeof (callback) == 'function';
        var pstart = 0;
        if (async) {
            pstart = 1;
        }

        var reqData = AjaxClient.DoMethod.arguments[pstart];
        var req = AjaxClient.GetRequest();
        if (async) {
            req.onreadystatechange = function() {
                if (req.readyState == 4) {
                    if (req.status == 200) {
                        callback(req.responseText);
                    }
                    else {
                        //alert('ajax error: ' + req.responseText);
                        document.write(req.responseText);
                    }
                }
            }
        }

        //window.location.host
        var url = "/Web/Ajax"; //Do this on .NET MVC Framework
        req.open("POST", url, async);
        req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
        while (reqData.indexOf('/') != -1) reqData = reqData.replace('/', '%2F');
        reqData = reqData.replace(/\</g, "%3D");
        reqData = reqData.replace(/\>/g, "%3E");
        //req.setRequestHeader("Content-Data",reqData);
        req.send(reqData);
        if (!async) {
            if (req.status == 200) {
                return req.responseText;
            }
            else {
                document.write(req.responseText);
            }
        }
    },

    GetRequest: function() {
        if (window.XMLHttpRequest) {
            return new XMLHttpRequest();
        }
         else {
            if (window.caoxhua_xmlhttp) {
                return new ActiveXObject(window.caoxhua_xmlhttp);
            }
            var progIDs = ["Msxml2.XMLHTTP.5.0", "Msxml2.XMLHTTP.4.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"];
            for (var i = 0; i < progIDs.length; ++i) {
                var progID = progIDs[i];
                try {
                    window.caoxhua_xmlhttp = progID;
                    return new ActiveXObject(progID);
                } catch (e) { }
            }
        }
        return null;
    }
};