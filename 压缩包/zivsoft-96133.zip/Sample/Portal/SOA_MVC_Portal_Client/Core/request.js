function Request(){
	this._values = "";
	this._eventName = "onclick";
	this._eventSource = "";
	this._control = "";
	this._form = null;
}

Request.create = function(){
};

Request.prototype.setValues=function(){
	this._values = "";
	var utils = new EncodeUtils();
	for(var i=0;i<this._form.all.length;i++){
		var ctrl = this._form.all[i];
		if(!ctrl.id) continue;
		var tag = ctrl.tagName.toLowerCase();
		var type = "";
		var cValue = ctrl.value?ctrl.value:"";
		 
		if(tag == "input"){
			type = ctrl.type;
		}else if(tag == "select"){
			type = "select";
		}else if(tag == "textarea"){
			type = "text";
		}else if(tag == "span"){
			type = ctrl.type;
		}
		if(type=="") continue;
		if(type=="checkbox"){
			if(ctrl.checked) cValue = "1";
			else cValue = "0";
		}
		if(type == "label"){
			cValue = ctrl.innerText;
		}
		this._values += '<data type="'+type+'" id="'+ctrl.id+'">'+utils.EncodeB64(cValue)+'</data>';
	}
};

Request.prototype.setEvent=function(){
	this._eventName = "on"+window.event.type;
	var com = event.srcElement;
	this._eventSource = com.id;
	while(com){
		if(com.tagName.toLowerCase() == "form"){
			this._form = com;
			this._control = com.action;
			break;
		}
		com = com.parentElement;
	}
};

Request.prototype.getXml=function(){
	if(this._control=="") this.setEvent();
	if(this._values=="") this.setValues();
	var xml = "<request>";
	xml += "<form>"+this._form.id+"</form>";
	xml += "<control>"+this._control+"</control>";
	xml += "<event>"+this._eventName+"</event>";
	xml += "<source>"+this._eventSource+"</source>";
	xml += "<values>"+this._values+"</values>";
	xml += "</request>";
	return xml;
};