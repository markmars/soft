function EncodeUtils(){
	this.keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
}

EncodeUtils.create=function(){};

EncodeUtils.prototype.EncodeB64=function(rawStr) {
	var escapedStr = encodeURIComponent(rawStr);
	var count = 0;
	var ints = new Array();
	var b64Str = "";
	for(var i=0,size=escapedStr.length;i<size;i++){
		var ch = escapedStr.charAt(i);
		if(ch=='%'){
			ints.push(parseInt(escapedStr.charAt(i+1),16)*16+parseInt(escapedStr.charAt(i+2),16));
			i += 2;
		}else{
			ints.push(ch.charCodeAt());
		}
		if(count++ == 2){
			b64Str += this.GetB64Str(ints);
			count = 0;
			ints.length = 0;
		}
	}
	b64Str += this.GetB64Str(ints);
	return b64Str;
};

EncodeUtils.prototype.GetB64Str=function(ints){
	if(ints.length==0) return "";
	var rawLen = ints.length;
	while(ints.length<3){
		ints.push(0);
	}
	var ch1 = this.keyStr.charAt(ints[0] >> 2);
	var ch2 = this.keyStr.charAt(((ints[0] & 3) << 4) | (ints[1] >> 4));
	var ch3 = this.keyStr.charAt(((ints[1] & 15) << 2) | (ints[2] >> 6));
	var ch4 = this.keyStr.charAt(ints[2] & 63);
	if(rawLen==1){ch3='=';ch4='=';}
	if(rawLen==2){ch4='=';}
	return ch1+ch2+ch3+ch4;
};