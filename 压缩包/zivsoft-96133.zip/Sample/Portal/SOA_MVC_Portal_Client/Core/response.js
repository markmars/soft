function Response(){
}

Response.create = function(){
};

/**
*
*�ο�BaseControl.GetResultData��������
*
*/
Response.prototype.apply=function(res){
	var xml = xmlParse(res);
	var toChecks = ["data","style","vision","exec"];
	var funcs = [this.setValue,this.setStyle,this.setVision,this.setExec];
	for(var index=0;index<toChecks.length;index++){
		var datas = xml.getElementsByTagName(toChecks[index]);
		for(var i=0;i<datas.length;i++){
			var node = datas[i];
			var id="";
			var type="";
			var value=xmlValue(node);
			for(var k=0;k<node.attributes.length;k++){
				if(node.attributes[k].nodeName == "id") id = node.attributes[k].nodeValue;
				if(node.attributes[k].nodeName == "type") type = node.attributes[k].nodeValue;
			}
			funcs[index](id,type,unescape(value));
		}
	}
	
	var sels = xml.getElementsByTagName("select");
	for(var i=0;i<sels.length;i++){
		var node = sels[i];
		var id=this.getAttribute(node,"id");
		var type=this.getAttribute(node,"type");
		var sel = document.getElementById(id);
		if(!sel) continue;
		sel.options.length = node.childNodes.length;
		for(var num=0;num<node.childNodes.length;num++){
			sel.options[num].value = this.getAttribute(node.childNodes[num],"value");
			sel.options[num].text = xmlValue(node.childNodes[num]);
		}
	}
	var links = xml.getElementsByTagName("hyperlink");
	for(var i=0;i<links.length;i++){
		var node = links[i];
		var hyperlink = document.getElementById(this.getAttribute(node,"id"));
		if(!hyperlink) continue;
		hyperlink.href = xmlValue(node);
	}
	
	var alerts = xml.getElementsByTagName("alert");
	for(var i=0;i<alerts.length;i++){
		window.alert(xmlValue(alerts[i]));
	}
};

Response.prototype.setValue=function(id,type,value){
	var target = document.getElementById(id);
	if(!target) return;
	switch(type){
		case "checkbox":target.checked=(value.toLowerCase()=="true"||value.toLowerCase()=="1");break;
		case "label":target.innerText = value;break;
		case "hyperlink":target.innerText = value;break;
		case "richtext":target.src=value;break;
		case "progressbar":SetProgressBar(target,value);break;
		default:target.value = value;
	}
};

Response.prototype.setStyle=function(id,type,value){
	var target = document.getElementById(id);
	if(!target) return;
	target.className = value;
};

Response.prototype.setVision=function(id,type,value){
	var target = document.getElementById(id);
	if(!target) return;
	var show = value.toLowerCase()=="true"||value.toLowerCase()=="1";
	target.style.display = show?"block":"none";
};

Response.prototype.setExec=function(id,type,value){
	document.write("<script>"+value+"</script>");
};

Response.prototype.getAttribute=function(node,name){
	if(!node) return "";
	for(var k=0;k<node.attributes.length;k++){
		if(node.attributes[k].nodeName == name) return node.attributes[k].nodeValue;
	}
	return "";
};

function SetProgressBar(pbar,per){
	if(!pbar) return;
	pbar.value = per;
	pbar.title = "Finished:" + per + "%";
	pbar.innerHTML = "";
	var width = new Number(pbar.style.width.substr(0,pbar.style.width.length-2));
	pbar.insertAdjacentHTML("BeforeEnd","<span style='width:"+(width*per)/100+"px;height:1px;background-color:#0000FF;'></span>");
}