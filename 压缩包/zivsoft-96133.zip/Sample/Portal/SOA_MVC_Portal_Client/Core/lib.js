document.writeln("<script src='../Core/misc.js'></script>");
document.writeln("<script src='../Core/dom.js'></script>");
document.writeln("<script src='../Core/encodeutils.js'></script>");
document.writeln("<script src='../Core/request.js'></script>");
document.writeln("<script src='../Core/ajax.js'></script>");
document.writeln("<script src='../Core/response.js'></script>");
function DealWithResult(xml) {
    var res = new Response();
    res.apply(xml);
}
function CallAjax() {
    var req = new Request();
    if (CallAjax.arguments.length == 3) {
        req._eventName = CallAjax.arguments[0];
        req._eventSource = CallAjax.arguments[1];
        var com = document.getElementById(req._eventSource);
        while (com) {
            if (com.tagName.toLowerCase() == "form") {
                req._form = com;
                req._control = com.action;
                break;
            }
            com = com.parentElement;
        }
        if (!CallAjax.arguments[2]) req._values = ' ';
        AjaxClient.DoMethod(DealWithResult, req.getXml());
    } else {
        AjaxClient.DoMethod(DealWithResult, req.getXml());
    }
}