﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Xml.Serialization;
using System.Data;

using Zivsoft.Services;
using Zivsoft.IO.Security;
using Zivsoft.IO;
using Zivsoft.IO.Spider;
using Zivsoft.IO.Core;
using Zivsoft.IO.Users;
using Zivsoft.Data;
using Zivsoft.Data.ORM.Entity;
using Zivsoft.Business.Core;


/// <summary>
/// Web Service by Lihua Zhou
/// </summary>
[WebService(Namespace = "http://zivsoft.com/",Description=".NET Web Services")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class Default : WebService
{

    /// <summary>
    /// 测试用
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <returns></returns>
    [WebMethod]
    public int Add(int x, int y)
    {
        return x + y;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="modType"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    [WebMethod]
    public DataTable GetDataViewByRole(ConfigType currentConfig,string userId,MenuTreeTYPE enumMenuTree)
    {
        if(string.IsNullOrEmpty(userId)){
            return new DataTable();
        }

        const string CONFIG_TREE_TYPE = "TreeType";
        const string CONFIG_MENU_TYPE = "MenuType";
        string type = null;
        if (enumMenuTree == MenuTreeTYPE.MENU)
        {
            type = CONFIG_MENU_TYPE;
        }
        else
        {
            type = CONFIG_TREE_TYPE;
        }
        string modType = null;
        if (currentConfig == ConfigType.Xml)
        {
            modType = ConfigXml.GetConfigValue(type);
        }
        else
        {
            Config c = new Config();
            c.ConfigId = type;
            c.Load();
            modType = c.ConfigValue.Value;
        }

        var ds = new DataSet();
        Zivsoft.Data.ORM.Entity.UserInfo user = new Zivsoft.Data.ORM.Entity.UserInfo();
        user.UserId = userId;
        user.Load();
        if (currentConfig == ConfigType.Xml)
        {
            ds.ReadXml(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Config\\RoleAccess.xml");
            var dv = ds.Tables[0].DefaultView;
            dv.RowFilter = string.Format("RoleId='{0}'", user.RoleId.Value);
            var len = dv.Count;//not the db.Table.Count
            string[] ids = new string[len];
            var i = 0;
            while (i < len)
            {
                ids[i] = dv[i++]["ModId"] + "";
            }
            Zivsoft.Business.Core.MenuTree menu = new Zivsoft.Business.Core.MenuTree();
            return menu.GetDataTable(modType, ids);
        }
        else
        {
            string sql = "select modinfo.* from userinfo,roleaccess,modinfo where modtype='{0}' and userid='{1}' and isvalid='1' and userinfo.roleid=roleaccess.roleid and modinfo.modid=roleaccess.modid";
            sql = string.Format(sql, modType, userId);
            return DbFactory.DefaultDbOperator().Query4DataTable(sql);
        }
    }

    [WebMethod]
    public int ExecuteSql(string sql)
    {
        return DbFactory.DefaultDbOperator().ExecuteSql(sql);
    }

    [WebMethod]
    public DataSet Query4DataSet(string sql)
    {
        return DbFactory.DefaultDbOperator().Query4DataSet(sql);
    }

    [WebMethod]
    public DataTable Query4DataTable(string sql)
    {
        return DbFactory.DefaultDbOperator().Query4DataTable(sql);
    }

    [WebMethod]
    public UserInfo ChangePassword(string userId, string newPwd)
    {
        return new UserInfo { IsError = false,IsChange=false };
    }

    [WebMethod]
    public Spider DownloadFromMM211()
    {
        MM211 mm = new MM211();
        var res=mm.GetResponse();
        if (res.IsError)
        {
            return new Spider { IsError = true, ErrorMessage = res.ErrorMessage };
        }
        else
        {
            return new Spider { IsError = false };
        }
    }

    [WebMethod]
    public MenuTree LoadMenu(string exitText)
    {
        MenuTreeRequest req = new MenuTreeRequest() { ExitText = exitText };
        var res=req.GetResponse();
        return new MenuTree { ErrorMessage = res.ErrorMessage, IsError = res.IsError };
    }

    /// <summary>
    /// 简洁模式登陆
    /// </summary>
    /// <param name="strUserId">用户帐号</param>
    /// <param name="strPassword">用户加密前密码</param>
    /// <param name="strClientIP">客户端IP</param>
    /// <returns>返回序列化后的登陆对象</returns>
    [WebMethod]
    public Login CheckLoginByWebService(string strUserId, string strPassword, string strClientIP)
    {
        LoginRequest request = new LoginRequest() { UserId = strUserId, Password = strPassword, IP = strClientIP };
        LoginResponse response = request.GetResponse();
        if (response.IsError)//业务调用失败
        {
            return new Login { IsLogin = false, IsError = true, ErrorMessage = response.ErrorMessage };
        }
        else if (response.IsLogin)//登陆成功
        {
            return new Login { IsLogin = true, IsError = false, ErrorMessage = response.ErrorMessage, UserName = response.UserName, Theme = response.Theme };
        }
        else//登陆失败
        {
            return new Login { IsLogin = false, IsError = false, ErrorMessage = "登陆失败" };
        }
    }

    ///// <summary>
    ///// 以传统模式请求业务
    ///// </summary>
    ///// <param name="userid"></param>
    ///// <param name="password"></param>
    ///// <param name="strip"></param>
    ///// <returns></returns>
    //[WebMethod]
    //public Login CheckLogin(string userid, string password, string strip)
    //{
    //    Zivsoft.Services.Request request = new Request("IndexBH", "LoginByGlobal");
    //    request["UserId"] = userid;
    //    request["UserPwd"] = password;
    //    request["IP"] = strip;
    //    var t = request.GetResponse();
    //    if (t.IsError)
    //    {
    //        return new Login { IsLogin = false, IsError = true, ErrorMessage = t.ErrorMessage };
    //    }
    //    else if (Convert.ToBoolean(t["IsLogin"]))
    //    {
    //        return new Login { IsLogin = true, IsError = false, ErrorMessage = t.ErrorMessage, UserName = t["UserName"] + "", Theme = t["Theme"] + "" };
    //    }
    //    else//登陆失败
    //    {
    //        return new Login { IsLogin = false, IsError = true, ErrorMessage = t.ErrorMessage };

    //    }

    //}


    /// <summary>
    /// 一个权限认证的服务方法
    /// </summary>
    /// <returns>返回系列化后的对象</returns>
    [WebMethod]
    public Cert CheckCert()
    {
        //调用后台业务
        SecurityRequest request = SecurityRequest.CheckCert();
        //获取处理后数据
        SecurityResponse response = request.GetResponse();

        if (response.IsError)
        {
            //匿名类型
            return new Cert() { IsError = true, ErrorMessage = response.ErrorMessage, IsCert = false };
        }
        else if (response.Cert)
        {
            //匿名类型
            return new Cert { IsError = false, IsCert = true };
        }
        else//认证失败
        {
            return new Cert { IsError = false, ErrorMessage = "未注册", IsCert = false };
        }
    }
}

#region 序列化输出及响应
public enum ConfigType
{
    Db,
    Xml
};
/// <summary>
/// 序列化输出对象
/// </summary>
public class Cert
{
    public bool IsError { get; set; }
    public string ErrorMessage { get; set; }
    public bool IsCert { get; set; }
}
public class Login
{
    public bool IsLogin { get; set; }
    public string ErrorMessage { get; set; }
    public bool IsError { get; set; }
    public string Theme { get; set; }
    public string UserName { get; set; }
}

public class MenuTree
{
    public string ErrorMessage { get; set; }
    public bool IsError { get; set; }
    public string ExitText { get; set; }
}
public class Spider
{
    public bool IsError { get; set; }
    public string ErrorMessage { get; set; }
}

public class UserInfo:Spider 
{

    //public bool IsError { get; set; }
    //public string ErrorMessage { get; set; }
    public bool IsChange { get; set; }
}

public enum MenuTreeTYPE
{
    TREE,
    MENU

}
#endregion


