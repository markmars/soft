﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

using Zivsoft.Log;
using Zivsoft.IO;
using Zivsoft.IO.Security;
using Zivsoft.IO.Register;
using Zivsoft.IO.Spider;
using Zivsoft.IO.Mail;
using Zivsoft.Products.Spider.Properties;
/*************************
 * 
 * update：2009-03-12
 * 
 *************************/
namespace Zivsoft.Products.Spider
{
    class Program
    {

        /// <summary>
        /// </summary>
        [STAThread]
        static void Main()
        {

            try
            {
                CheckCert checkCert = new CheckCert();
                var response = checkCert.GetResponse();
                if (response.Cert)
                {
                    Helper.Run();
                }
                else
                {
                    RegDialog regDialog = new RegDialog();
                    var res = regDialog.GetResponse();
                    if (res.IsError)
                    {
                        Helper.ShowError(res.ErrorMessage);
                        Helper.Pause();
                    }
                }
            }
            catch (Exception e)
            {
                Helper.ShowError(e.Message);
                Helper.Pause();

            }
        }


    }
}
