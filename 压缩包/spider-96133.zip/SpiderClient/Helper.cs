﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zivsoft.Products.Spider.Properties;
using Zivsoft.Log;
using System.Windows.Forms;
using System.Diagnostics;
using Zivsoft.IO.Spider;

namespace Zivsoft.Products.Spider
{
    class Helper
    {
        public static void Pause()
        {
            Console.Write(Resource.UnhandledException);
            Console.Read();
        }

        public static void Run()
        {
            if (Zivsoft.AutoUpgrade.SiderUpgrade.Current.IsUpgradeAvailable)
            {
                if (DialogResult.Yes == MessageBox.Show(Resource.Update, Resource.Title, MessageBoxButtons.YesNo, MessageBoxIcon.Information)) Process.Start("Zivsoft.AutoUpgrade.exe");
            }
            else
            {
                OutputCopyright();
                Console.Title = Resource.Title;

                Console.WriteLine("1------------------" + Resource.Menu1);
                Console.WriteLine("2------------------" + Resource.Menu2);
                Console.WriteLine("0------------------" + Resource.Menu0);
                while (true)
                {
                    try
                    {
                        Console.Write(Resource.Menu);
                        string input = Console.ReadLine();
                        switch (input)
                        {
                            case "0":
                                Environment.Exit(0);
                                break;
                            case "1":
                                Console.Title = Resource.Menu1;
                                MM211 mm = new MM211();
                                var mmRes = mm.GetResponse();
                                if (mmRes.IsError)
                                {
                                    ShowError(mmRes.ErrorMessage);
                                }
                                else
                                {
                                    ShowInfo(Resource.Finished);
                                }
                                break;
                            case "2":
                                Console.Title = Resource.Menu2;
                                Baidu b = new Baidu();
                                var bs = b.GetResponse();
                                if (bs.IsError)
                                {
                                    ShowError(bs.ErrorMessage);
                                }
                                else
                                {
                                    ShowInfo(Resource.Finished);
                                }
                                break;
                            default:
                                ShowError(Resource.UnknownChoice);
                                break;
                        }

                    }
                    catch (Exception e)
                    {
                        Logger.LogError("{0}", e);
                    }
                }

            }
        }
        /// <summary>
        /// >
        private static void OutputCopyright()
        {
            Console.WriteLine("======================" + Resource.Title + "==================");
            Console.WriteLine(Resource.Copyright);
        }

        public static void ShowInfo(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Logger.LogInfo(message);
            Console.WriteLine(message);
            Console.ResetColor();
        }
        public static void ShowError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.BackgroundColor = ConsoleColor.Yellow;
            Logger.LogError(message);
            Console.WriteLine(message);
            Console.ResetColor();
        }

    }
}
