﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;

namespace Zivsoft.Business.Spider
{
    class ServerList
    {
        #region Single
        private ServerList()
        {
            this.Servers = new List<Server>();
            Init();
        }
        static ServerList _single;
        public static ServerList Single()
        {
            if (_single == null)
            {
                _single = new ServerList();
            }
            return _single;

        }

        #endregion

        public IList<Server> Servers
        {
            get;
            set;
        }

        private void Init()
        {
            
            XElement xes = XElement.Load("ServerList.DAT");
            IEnumerable<XElement> servers = from value in xes.Elements()
                                            select value;
            foreach (XElement server in servers)
            {
                Server srv = new Server();
                srv.Url = server.Attribute("Url").Value;

                
                IEnumerable<XElement> expressions = from value in server.Element("Expressions").Elements()
                                                    select value;
                foreach (XElement exp in expressions)
                {
                    srv.Expressions.Add(
                        new Expression 
                        { 
                            FolderName = exp.Attribute("Folder").Value, 
                            Value = exp.Value 
                        }
                        );
                }
                this.Servers.Add(srv);
            }

        }
    }
    class Server
    {
        public Server()
        {
            this.Expressions = new List<Expression>();

        }
        public string Url { get; set; }
        
        public IList<Expression> Expressions { get; set; }
    }

    class Expression
    {
        public string FolderName { get; set; }
        public string Value { get; set; }
    }
}
