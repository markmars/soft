﻿using System;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Specialized;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Web;
using System.Drawing;
using System.Net;
using Zivsoft.Business.Spider;
using Zivsoft.Log;


namespace Zivsoft.Business.Spider
{
    class RecursionSearch
    {
        private readonly string URL = @"http://www\.\w*\.com";
        private ArrayList _htUrls;
        
        public ArrayList Urls
        {
            get
            {
                return _htUrls;
            }
        }

        public RecursionSearch(string exp)
        {
            URL = exp;
            _htUrls = new ArrayList(0);
        }

        /// <summary>
        /// Get inner html content from url
        /// </summary>
        /// <param name="url">url</param>
        /// <returns>return the html source</returns>
        public void FilterInnerUrl(string url)
        {
            Stream s = null;
            Uri uri = new Uri(url);
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(uri);
            WebResponse res = null;
            try
            {
                res = req.GetResponse();
            }
            catch
            {
                //Logger.LogError(e.Message);
                return;
            }
            s = res.GetResponseStream();
            StreamReader sr = new StreamReader(s);
            string text=sr.ReadToEnd();
            string rex = URL;
            if (string.IsNullOrEmpty(text))
            {
                return;
            }
            string str = text;
            ArrayList al = new ArrayList();
            Regex rgx = new Regex(rex, RegexOptions.Singleline);
            MatchCollection cols = rgx.Matches(str);
            foreach (Match m in cols)
            {
                string v = m.Groups[0].Value;
                if (!_htUrls.Contains(v))
                {
                    _htUrls.Add(v);
                    //Logger.Info("{0}[from {1}]",v,url);
                    Logger.LogInfo(v);
                    FilterInnerUrl(v);
                }
            }
        }

    }
}