﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Zivsoft.Business.Spider
{
    interface ISearch
    {
        string GetHtmlSourceText();
        ArrayList MachItems(string text, string rex);
        void SavePicFromUrl(string imgUrl, string folderName);
    }
}
