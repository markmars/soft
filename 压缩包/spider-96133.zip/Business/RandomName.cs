﻿using System;
using System.IO;

using Zivsoft.Utils;

/*
 * Created by ziv at 2007-2-10
 */
namespace Zivsoft.Business.Spider
{
    /// <summary>
    /// </summary>
    class RandomName
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string GetUniqueNameByDateTime()
        {
            string y = DateTime.Now.Year.ToString();
            if (y.Length == 4)
            {
                y=y.Remove(0, 2);
            }
            string m = DateTime.Now.Month.ToString();
            if (m.Length == 1)
            {
                m = "0" + m;
            }
            string d = DateTime.Now.Day.ToString();
            if (d.Length == 1)
            {
                d = "0" + d;
            }
            string hour = DateTime.Now.Hour.ToString();
            if (hour.Length == 1)
            {
                hour = "0" + hour;
            }
            string minute = DateTime.Now.Minute.ToString();
            if (minute.Length == 1)
            {
                minute = "0" + minute;
            }
            string second = DateTime.Now.Second.ToString();
            if (second.Length == 1)
            {
                second = "0" + second;
            }
            string millisecond = DateTime.Now.Millisecond.ToString();
            if (millisecond.Length == 1)
            {
                millisecond = "00" + millisecond;
            }
            else if(millisecond.Length==2)
            {
                millisecond = "0" + millisecond;
            }
            return "_"+y + m + d + "_" +hour+ minute + second + "_" + millisecond;
        }

        /// <summary>
        public static string GetUniqueNameByStoreFile(string filePath, string fileName)
        {
            if (filePath == null || filePath.Trim() == "" || fileName == null || fileName.Trim() == "")
            {
                return String.Empty;
            }
            string fileFullPath = Path.Combine(filePath , fileName);
            while (File.Exists(fileFullPath))
            {
                fileName =FileUtils.getFileNameWithoutExt(fileName) +"_" + FileUtils.GetFileExtension(fileName);
                fileFullPath = Path.Combine(filePath,fileName);
            }
            return fileName;
        }
    }
}
